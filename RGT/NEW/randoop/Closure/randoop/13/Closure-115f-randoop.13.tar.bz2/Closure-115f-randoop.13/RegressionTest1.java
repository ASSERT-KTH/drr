import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str8 = compiler4.toSource(jSModule7);
        java.lang.String str9 = jSModule7.toString();
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi! 0 [quoted: 1]" + "'", str9.equals("STRING hi! 0 [quoted: 1]"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = jSTypeRegistry45.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node56.isCast();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        node62.setQuotedString();
        com.google.javascript.rhino.Node node71 = node56.useSourceInfoIfMissingFrom(node62);
        com.google.javascript.rhino.InputId inputId72 = node62.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry45.createFromTypeNodes(node62, "", jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry43.createConstructorType(jSType75, true, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType78.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType40.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType79);
        functionType40.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType82 = templateTypeMapReplacer3.caseFunctionType(functionType40);
        com.google.javascript.rhino.jstype.JSType jSType83 = templateTypeMapReplacer3.caseAllType();
        com.google.javascript.rhino.jstype.JSType jSType84 = templateTypeMapReplacer3.caseVoidType();
        com.google.javascript.rhino.jstype.TemplateType templateType85 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType86 = templateTypeMapReplacer3.caseTemplateType(templateType85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(inputId72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(jSType84);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable1 = node0.siblings();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeIterable1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = com.google.javascript.rhino.Token.LSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        java.lang.String str31 = compiler28.toSource();
        boolean boolean32 = compiler28.acceptEcmaScript5();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str8 = compiler4.toSource(jSModule7);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder9 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int10 = codeBuilder9.getLength();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node22.isCast();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node37 = node22.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        boolean boolean43 = node41.isCall();
        boolean boolean44 = node41.isNE();
        int int45 = node41.getLength();
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node28, node41 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(101, nodeArray46, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType50 = node49.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel51 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray59 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType57, strArray59);
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node49, checkLevel51, diagnosticType54, strArray59);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.pos(node49);
        try {
            compiler4.toSource(codeBuilder9, 45, node62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(node62);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        boolean boolean24 = node22.isCall();
        boolean boolean25 = node13.isEquivalentToTyped(node22);
        com.google.javascript.rhino.Node node26 = null;
        try {
            node22.addChildrenToBack(node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        compilerInput22.clearAst();
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot26 = null;
        compiler24.setOldParseTree("", astRoot26);
        com.google.javascript.rhino.Node node28 = compilerInput22.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler24);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        boolean boolean42 = functionType40.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot44 = functionType40.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable45 = functionType40.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = functionType40.getBindReturnType(100);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = functionType40.getBindReturnType(301);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = null;
        try {
            com.google.javascript.rhino.jstype.TemplatizedType templatizedType51 = jSTypeRegistry1.createTemplatizedType((com.google.javascript.rhino.jstype.ObjectType) functionType40, jSTypeList50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(staticSlot44);
        org.junit.Assert.assertNotNull(nodeIterable45);
        org.junit.Assert.assertNotNull(functionType47);
        org.junit.Assert.assertNotNull(functionType49);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        boolean boolean16 = node13.isAssign();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node13);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback11);
        com.google.javascript.jscomp.Scope scope13 = nodeTraversal12.getScope();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler14 = nodeTraversal12.getCompiler();
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNull(scope13);
        org.junit.Assert.assertNotNull(abstractCompiler14);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = functionType36.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType38.toMaybeFunctionType();
        functionType39.clearCachedValues();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNotNull(functionType39);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isUnscopedQualifiedName();
        node1.addChildrenToBack(node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str17 = diagnosticType16.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(node10, diagnosticType16, strArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray27 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry26.createUnionType(jSTypeNativeArray27);
        boolean boolean29 = jSType28.isInterface();
        boolean boolean30 = jSType28.isTemplatizedType();
        boolean boolean31 = diagnosticType16.equals((java.lang.Object) boolean30);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup32 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType16);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str17.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSTypeNativeArray27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        boolean boolean12 = node10.isCall();
        boolean boolean13 = node10.isNE();
        int int14 = node10.getLength();
        boolean boolean15 = node10.isWith();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node26.isCast();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node41 = node26.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        boolean boolean47 = node45.isCall();
        boolean boolean48 = node45.isNE();
        int int49 = node45.getLength();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node32, node45 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(101, nodeArray50, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel55 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray63 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray63);
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node53, checkLevel55, diagnosticType58, strArray63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.pos(node53);
        boolean boolean67 = node10.isEquivalentTo(node53);
        java.lang.String str68 = closureCodingConvention0.getSingletonGetterClassName(node53);
        boolean boolean69 = node53.isBlock();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean5 = googleCodingConvention0.isExported("hi!", false);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap9 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer10 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry8, templateTypeMap9);
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter11 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        java.lang.String str39 = node27.checkTreeEquals(node37);
        com.google.javascript.jscomp.SourceFile sourceFile41 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node37.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile41);
        java.lang.String str43 = sourceFile41.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceFile41);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput44, true);
        compilerInput46.clearAst();
        jSModule1.add(compilerInput46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType53 = node52.getJSType();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap63 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node57, node62);
        java.lang.String str64 = node52.checkTreeEquals(node62);
        com.google.javascript.jscomp.SourceFile sourceFile66 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node62.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile66);
        java.lang.String str68 = sourceFile66.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput69 = new com.google.javascript.jscomp.CompilerInput(sourceFile66);
        int int70 = compilerInput69.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput69, true);
        jSModule1.remove(compilerInput72);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(sourceFile41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeMap63);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertNotNull(sourceFile66);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "hi!" + "'", str68.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        java.lang.String str77 = functionType36.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertNull(str77);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile("DiagnosticGroup<missingRequire>(WARNING)");
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.SourceFile sourceFile8 = builder0.buildFromGenerator("hi!", generator7);
        boolean boolean9 = sourceFile8.isExtern();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        boolean boolean18 = node15.isAssign();
        java.lang.String str19 = node15.getString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        node23.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot26 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult27 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node23, astRoot26);
        try {
            astValidator1.process(node15, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        boolean boolean24 = node14.isLabelName();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot31 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult32 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node28, astRoot31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.throwNode(node28);
        boolean boolean34 = node28.isQuotedString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("STRING hi! 0");
        int int37 = node28.getIndexOfChild(node36);
        com.google.javascript.rhino.Node node38 = node14.useSourceInfoIfMissingFrom(node36);
        boolean boolean39 = node38.isInstanceOf();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean77 = functionType36.hasInstanceType();
        boolean boolean78 = functionType36.isTemplatizedType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        java.util.Set<java.lang.String> strSet39 = functionType36.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.TemplateType templateType40 = functionType36.toMaybeTemplateType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(strSet39);
        org.junit.Assert.assertNull(templateType40);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        java.util.Set<java.lang.String> strSet39 = functionType36.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.FunctionType functionType40 = functionType36.getOwnerFunction();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(strSet39);
        org.junit.Assert.assertNull(functionType40);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        int int66 = node19.getChangeTime();
        com.google.javascript.rhino.head.ast.AstRoot astRoot67 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult68 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node19, astRoot67);
        com.google.javascript.rhino.Node node69 = parseResult68.ast;
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(node69);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        java.lang.String str31 = compiler28.toSource();
        com.google.javascript.jscomp.JSModule jSModule32 = null;
        try {
            java.lang.String str33 = compiler28.toSource(jSModule32);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.InputId inputId28 = node18.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createFromTypeNodes(node18, "", jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        boolean boolean33 = jSType31.canCastTo(jSType32);
        com.google.javascript.rhino.JSDocInfo jSDocInfo34 = jSType31.getJSDocInfo();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(inputId28);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(jSDocInfo34);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState6 = null;
        try {
            compiler4.setState(intermediateState6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("2019/06/10 12:15");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node21.isCast();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        boolean boolean34 = node27.isWith();
        node27.setQuotedString();
        com.google.javascript.rhino.Node node36 = node21.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.Node node37 = node4.copyInformationFromForTree(node27);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.Compiler compiler41 = new com.google.javascript.jscomp.Compiler();
        compiler41.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback43 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal44 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler41, callback43);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray53 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make(diagnosticType51, strArray53);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = jSError54.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray62 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError63 = nodeTraversal44.makeError(node48, checkLevel55, diagnosticType58, strArray62);
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("INSTANCEOF", node4, diagnosticType40, strArray62);
        com.google.javascript.rhino.InputId inputId65 = node4.getInputId();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNull(inputId65);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        java.lang.String str10 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str11 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = sideEffectFlags0.clearAllFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesArguments();
        org.junit.Assert.assertNotNull(sideEffectFlags1);
        org.junit.Assert.assertNotNull(sideEffectFlags2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, "Not declared as a constructor", false);
        try {
            java.lang.String str26 = compilerInput25.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        java.lang.String str2 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = googleCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISPLACED_TYPE_ANNOTATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("hi!");
        java.lang.String str2 = node1.toStringTree();
        com.google.javascript.rhino.Node node3 = node1.getNext();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi!\n" + "'", str2.equals("STRING hi!\n"));
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! 0", "STRING hi! 0 [quoted: 1]. Not declared as a type name at (unknown source) line 0 : 0");
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("STRING hi! 0 [quoted: 1]", "Unknown class name");
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.or(node3, node9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean16 = node15.wasEmptyNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node26.isCast();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node41 = node26.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        boolean boolean47 = node45.isCall();
        boolean boolean48 = node45.isNE();
        int int49 = node45.getLength();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node32, node45 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(101, nodeArray50, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node54 = node15.useSourceInfoFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType66 = node65.getJSType();
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap71 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node65, node70);
        boolean boolean72 = node65.isWith();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(10, node59, node65, 0, 0);
        java.lang.String str76 = node15.checkTreeEquals(node65);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType83 = node82.getJSType();
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap88 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node82, node87);
        boolean boolean89 = node87.isUnscopedQualifiedName();
        node78.addChildrenToBack(node87);
        try {
            com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.IR.ifNode(node11, node15, node87);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(nodeMap71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n" + "'", str76.equals("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n"));
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNull(jSType83);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(nodeMap88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str2 = googleCodingConvention1.getExportPropertyFunction();
        java.lang.String str3 = googleCodingConvention1.getAbstractMethodName();
        boolean boolean5 = googleCodingConvention1.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        boolean boolean25 = googleCodingConvention1.isOptionalParameter(node19);
        com.google.javascript.rhino.Node node26 = node0.useSourceInfoFrom(node19);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node0.new FileLevelJsDocBuilder();
        int int29 = node0.getIntProp(20);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isNoType();
        boolean boolean39 = functionType36.isNumber();
        boolean boolean40 = functionType36.matchesStringContext();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        int int78 = functionType36.getExtendedInterfacesCount();
        java.util.Set<java.lang.String> strSet79 = functionType36.getPropertyNames();
        com.google.javascript.rhino.jstype.Property property81 = functionType36.getSlot("Not declared as a type name");
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(strSet79);
        org.junit.Assert.assertNull(property81);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean4 = node3.isNull();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        node8.setQuotedString();
        boolean boolean11 = node8.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot12 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult13 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot12);
        node8.setCharno((int) (byte) 100);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap25 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node19, node24);
        boolean boolean26 = node19.isWith();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.eq(node8, node19);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.add(node3, node27);
        boolean boolean29 = node28.isNot();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeMap25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType31 = node30.getJSType();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap36 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node30, node35);
        boolean boolean37 = node35.isCast();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap47 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node41, node46);
        boolean boolean48 = node41.isWith();
        node41.setQuotedString();
        com.google.javascript.rhino.Node node50 = node35.useSourceInfoIfMissingFrom(node41);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        boolean boolean56 = node54.isCall();
        boolean boolean57 = node54.isNE();
        int int58 = node54.getLength();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node41, node54 };
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(101, nodeArray59, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel64 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType70 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray72 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make(diagnosticType70, strArray72);
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node62, checkLevel64, diagnosticType67, strArray72);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.pos(node62);
        com.google.javascript.jscomp.CodingConvention.Bind bind77 = googleCodingConvention0.describeFunctionBind(node75, false);
        boolean boolean79 = googleCodingConvention0.isPrivate("INSTANCEOF");
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType85 = node84.getJSType();
        com.google.javascript.rhino.Node node88 = new com.google.javascript.rhino.Node(46, node84, 0, 0);
        com.google.javascript.jscomp.CodingConvention.Bind bind89 = googleCodingConvention0.describeFunctionBind(node84);
        boolean boolean92 = googleCodingConvention0.isExported("goog.exportProperty", false);
        java.lang.String str93 = googleCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeMap36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeMap47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(diagnosticType70);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(bind77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNull(jSType85);
        org.junit.Assert.assertNull(bind89);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNull(str93);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = null;
        try {
            com.google.javascript.jscomp.Result result9 = compiler0.compile(jSSourceFileArray5, jSSourceFileArray7, compilerOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(2);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesGlobalState();
        int int3 = sideEffectFlags1.valueOf();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags4 = sideEffectFlags1.setMutatesArguments();
        int int5 = sideEffectFlags1.valueOf();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(sideEffectFlags4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("STRING hi!\n");
        try {
            boolean boolean18 = closureCodingConvention0.isPropertyTestFunction(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 10);
        node1.setType(37);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap18 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node12, node17);
        java.lang.String str19 = node7.checkTreeEquals(node17);
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.caseNode(node1, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeMap18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node10.isNew();
        boolean boolean22 = node10.isLabelName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        boolean boolean11 = node8.isNew();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("goog.abstractMethod", "INSTANCEOF");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        boolean boolean11 = closureCodingConvention0.isValidEnumKey("DiagnosticGroup<missingRequire>(WARNING)");
        boolean boolean13 = closureCodingConvention0.isPrivate("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = sideEffectFlags0.clearAllFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags0.setAllFlags();
        org.junit.Assert.assertNotNull(sideEffectFlags1);
        org.junit.Assert.assertNotNull(sideEffectFlags2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            boolean boolean2 = compiler1.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        java.lang.String str46 = assertInstanceofSpec1.getFunctionName();
        com.google.javascript.rhino.Node node47 = null;
        com.google.javascript.rhino.Node node48 = assertInstanceofSpec1.getAssertedParam(node47);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertNull(node48);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 98, 49, 77);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str2 = googleCodingConvention1.getExportPropertyFunction();
        java.lang.String str3 = googleCodingConvention1.getAbstractMethodName();
        boolean boolean5 = googleCodingConvention1.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        boolean boolean25 = googleCodingConvention1.isOptionalParameter(node19);
        com.google.javascript.rhino.Node node26 = node0.useSourceInfoFrom(node19);
        node0.putBooleanProp(2, false);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray2 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createUnionType(jSTypeNativeArray2);
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSType3.toMaybeFunctionType();
        boolean boolean5 = jSType3.isCheckedUnknownType();
        org.junit.Assert.assertNotNull(jSTypeNativeArray2);
        org.junit.Assert.assertNotNull(jSType3);
        org.junit.Assert.assertNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        boolean boolean31 = compiler28.isTypeCheckingEnabled();
        java.lang.String str32 = compiler28.toSource();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isExported("goog.exportProperty");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (byte) 10);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable6 = node5.children();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(87, node5);
        java.util.List<java.lang.String> strList8 = closureCodingConvention0.identifyTypeDeclarationCall(node7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(nodeIterable6);
        org.junit.Assert.assertNull(strList8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray10);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = jSError11.level;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel13 = compiler4.getErrorLevel(jSError11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType31 = node30.getJSType();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap36 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node30, node35);
        boolean boolean37 = node35.isCast();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap47 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node41, node46);
        boolean boolean48 = node41.isWith();
        node41.setQuotedString();
        com.google.javascript.rhino.Node node50 = node35.useSourceInfoIfMissingFrom(node41);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        boolean boolean56 = node54.isCall();
        boolean boolean57 = node54.isNE();
        int int58 = node54.getLength();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node41, node54 };
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(101, nodeArray59, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel64 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType70 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray72 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make(diagnosticType70, strArray72);
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node62, checkLevel64, diagnosticType67, strArray72);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.pos(node62);
        com.google.javascript.jscomp.CodingConvention.Bind bind77 = googleCodingConvention0.describeFunctionBind(node75, false);
        int int78 = node75.getCharno();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable79 = node75.children();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeMap36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeMap47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(diagnosticType70);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(bind77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(nodeIterable79);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        jSTypeRegistry1.incrementGeneration();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        compiler28.reportCodeChange();
        com.google.javascript.jscomp.Scope scope32 = compiler28.getTopScope();
        com.google.javascript.jscomp.SourceFile sourceFile33 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray34 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = null;
        try {
            com.google.javascript.jscomp.Result result36 = compiler28.compile(sourceFile33, jSSourceFileArray34, compilerOptions35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(scope32);
        org.junit.Assert.assertNotNull(jSSourceFileArray34);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = dependencyOptions2.setDependencyPruning(false);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention9 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        java.lang.String str10 = googleCodingConvention9.getExportPropertyFunction();
//        boolean boolean12 = googleCodingConvention9.isValidEnumKey("");
//        java.util.Collection<java.lang.String> strCollection13 = googleCodingConvention9.getIndirectlyDeclaredProperties();
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions14 = dependencyOptions8.setEntryPoints(strCollection13);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions16 = dependencyOptions8.setDependencySorting(false);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(dependencyOptions8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(strCollection13);
//        org.junit.Assert.assertNotNull(dependencyOptions14);
//        org.junit.Assert.assertNotNull(dependencyOptions16);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str4 = diagnosticType3.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int8 = diagnosticType3.compareTo(diagnosticType7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType3);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = diagnosticType3.level;
        boolean boolean11 = diagnosticGroup0.matches(diagnosticType3);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str4.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-20) + "'", int8 == (-20));
        org.junit.Assert.assertNotNull(diagnosticGroup9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node25 = node10.useSourceInfoIfMissingFrom(node16);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        boolean boolean31 = node29.isCall();
        boolean boolean32 = node29.isNE();
        int int33 = node29.getLength();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node16, node29 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(101, nodeArray34, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel39 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make(diagnosticType45, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node37, checkLevel39, diagnosticType42, strArray47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap59 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node53, node58);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.returnNode(node53);
        boolean boolean61 = diagnosticType42.equals((java.lang.Object) node60);
        boolean boolean62 = node60.isGetElem();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeMap59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("goog.abstractMethod", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("STRING hi! 0 [quoted: 1]");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention7 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str8 = googleCodingConvention7.getExportPropertyFunction();
        java.lang.String str9 = googleCodingConvention7.getAbstractMethodName();
        boolean boolean11 = googleCodingConvention7.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        java.lang.String str27 = node15.checkTreeEquals(node25);
        com.google.javascript.jscomp.SourceFile sourceFile29 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node25.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile29);
        boolean boolean31 = googleCodingConvention7.isOptionalParameter(node25);
        com.google.javascript.rhino.Node node32 = node6.useSourceInfoFrom(node25);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder33 = node6.new FileLevelJsDocBuilder();
        boolean boolean34 = node6.isNew();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.and(node3, node6);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "goog.exportProperty" + "'", str8.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.abstractMethod" + "'", str9.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(sourceFile29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        boolean boolean11 = closureCodingConvention0.isValidEnumKey("DiagnosticGroup<missingRequire>(WARNING)");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(10, node16, node22, 0, 0);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast33 = closureCodingConvention0.getObjectLiteralCast(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(38, nodeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean77 = functionType36.hasInstanceType();
        java.util.Set<java.lang.String> strSet78 = functionType36.getPropertyNames();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(strSet78);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        java.lang.String str18 = node6.checkTreeEquals(node16);
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node16.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile20);
        java.lang.String str22 = sourceFile20.getOriginalPath();
        java.lang.String str23 = sourceFile20.getOriginalPath();
        sourceFile20.clearCachedSource();
        java.lang.String str25 = sourceFile20.getOriginalPath();
        jsAst2.setSourceFile(sourceFile20);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(sourceFile20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.Node[] nodeArray0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList(nodeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Not declared as a type name", "Not declared as a type name");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node20.mayMutateGlobalStateOrThrow();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        int int23 = jSError22.getLineNumber();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        node8.putBooleanProp(46, false);
        boolean boolean15 = node8.isWhile();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node23, node28);
        boolean boolean30 = node28.isCast();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        node34.setQuotedString();
        com.google.javascript.rhino.Node node43 = node28.useSourceInfoIfMissingFrom(node34);
        com.google.javascript.rhino.InputId inputId44 = node34.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry17.createFromTypeNodes(node34, "", jSTypeStaticScope46);
        com.google.javascript.rhino.Node node48 = node8.useSourceInfoIfMissingFromForTree(node34);
        node48.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(inputId44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        boolean boolean59 = node26.isEquivalentTo(node42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = null;
        com.google.javascript.rhino.Node node61 = node42.setJSDocInfo(jSDocInfo60);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        java.lang.String str41 = node29.checkTreeEquals(node39);
        com.google.javascript.jscomp.SourceFile sourceFile43 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node39.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile43);
        java.lang.String str45 = sourceFile43.getOriginalPath();
        java.lang.String str46 = sourceFile43.getOriginalPath();
        jSModule25.add(sourceFile43);
        compilerInput20.setModule(jSModule25);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(sourceFile43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 301, 52, 29);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        boolean boolean59 = node26.isEquivalentTo(node42);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        boolean boolean65 = node63.isCall();
        com.google.javascript.rhino.Node node66 = node63.cloneTree();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.and(node26, node66);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        node71.setQuotedString();
        boolean boolean74 = node71.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot75 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult76 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node71, astRoot75);
        node71.setCharno((int) (byte) 100);
        try {
            com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.IR.comma(node26, node71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        java.lang.String str83 = enumType82.getNormalizedReferenceName();
        boolean boolean84 = enumType82.isVoidType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "enum{InputId: }" + "'", str83.equals("enum{InputId: }"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node10.isVarArgs();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        boolean boolean6 = googleCodingConvention0.isConstantKey("STRING hi! 0 [quoted: 1]");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        boolean boolean78 = functionType36.makesStructs();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet79 = functionType36.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet79 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet79.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType36.getPrototype();
        boolean boolean39 = functionType36.matchesStringContext();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot39 = functionType36.getSlot("goog.exportSymbol");
        com.google.javascript.rhino.jstype.Property property41 = functionType36.getOwnSlot("INSTANCEOF");
        com.google.javascript.rhino.jstype.StaticSlot staticSlot43 = functionType36.getSlot("Unknown class name");
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = null;
        functionType36.setJSDocInfo(jSDocInfo44);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNull(staticSlot39);
        org.junit.Assert.assertNull(property41);
        org.junit.Assert.assertNull(staticSlot43);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str14 = googleCodingConvention13.getExportPropertyFunction();
        java.lang.String str15 = googleCodingConvention13.getAbstractMethodName();
        boolean boolean17 = googleCodingConvention13.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        boolean boolean37 = googleCodingConvention13.isOptionalParameter(node31);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        java.lang.String str54 = node42.checkTreeEquals(node52);
        boolean boolean55 = node52.isAssign();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(30, node4, node31, node52);
        boolean boolean57 = node52.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        int int0 = com.google.javascript.rhino.Token.LC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 309 + "'", int0 == 309);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger4);
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager5.getWarnings();
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str8 = compiler4.toSource(jSModule7);
        try {
            java.lang.String str9 = compiler4.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        boolean boolean78 = functionType36.makesStructs();
        functionType36.setDict();
        com.google.javascript.rhino.JSDocInfo jSDocInfo80 = null;
        functionType36.setJSDocInfo(jSDocInfo80);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        node8.addSuppression("InputId: ");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        boolean boolean78 = functionType36.makesStructs();
        functionType36.setDict();
        boolean boolean80 = functionType36.isNoObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        compiler5.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal8 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler5, callback7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType15, strArray17);
        com.google.javascript.jscomp.CheckLevel checkLevel19 = jSError18.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray26 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError27 = nodeTraversal8.makeError(node12, checkLevel19, diagnosticType22, strArray26);
        com.google.javascript.jscomp.CheckLevel checkLevel28 = jSError27.getDefaultLevel();
        java.lang.String str29 = lightweightMessageFormatter4.formatWarning(jSError27);
        boolean boolean30 = diagnosticGroup0.matches(jSError27);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "WARNING - Not declared as a type name\n" + "'", str29.equals("WARNING - Not declared as a type name\n"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.string("hi!");
        java.lang.String str3 = node2.toStringTree();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(23, node2);
        boolean boolean5 = node4.isIn();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi!\n" + "'", str3.equals("STRING hi!\n"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node5.isWith();
        node5.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str15 = googleCodingConvention14.getExportPropertyFunction();
        java.lang.String str16 = googleCodingConvention14.getAbstractMethodName();
        boolean boolean18 = googleCodingConvention14.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        java.lang.String str34 = node22.checkTreeEquals(node32);
        com.google.javascript.jscomp.SourceFile sourceFile36 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node32.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile36);
        boolean boolean38 = googleCodingConvention14.isOptionalParameter(node32);
        java.lang.String str39 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node32);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        java.lang.String str55 = node43.checkTreeEquals(node53);
        boolean boolean56 = node53.isAssign();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(30, node5, node32, node53);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable58 = node5.siblings();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup59 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_EVENTFUL_OBJECT_DISPOSAL;
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str63 = diagnosticType62.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int67 = diagnosticType62.compareTo(diagnosticType66);
        boolean boolean68 = diagnosticGroup59.matches(diagnosticType66);
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray73 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make(diagnosticType71, strArray73);
        com.google.javascript.jscomp.JSError jSError75 = com.google.javascript.jscomp.JSError.make("goog.abstractMethod", node5, diagnosticType66, strArray73);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.exportProperty" + "'", str15.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(sourceFile36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeIterable58);
        org.junit.Assert.assertNotNull(diagnosticGroup59);
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str63.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-20) + "'", int67 == (-20));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(jSError75);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = compiler0.getOldParseTreeByName("goog.exportProperty");
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt3 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt3);
        try {
            boolean boolean5 = compiler0.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(astRoot2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        boolean boolean38 = functionType37.matchesObjectContext();
        boolean boolean39 = functionType37.hasCachedValues();
        boolean boolean40 = functionType37.isNoType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        boolean boolean33 = node31.isCall();
        boolean boolean34 = node31.isNE();
        int int35 = node31.getLength();
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node18, node31 };
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(101, nodeArray36, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel41 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray49 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(diagnosticType47, strArray49);
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node39, checkLevel41, diagnosticType44, strArray49);
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel41, "goog.abstractMethod");
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard54 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel41);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(diagnosticType53);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = compiler0.getOldParseTreeByName("goog.exportProperty");
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt3 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt3);
        try {
            java.lang.String str5 = compiler0.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(astRoot2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray2 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createUnionType(jSTypeNativeArray2);
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSType3.toObjectType();
        boolean boolean5 = jSType3.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeNativeArray2);
        org.junit.Assert.assertNotNull(jSType3);
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions7 = null;
//        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions10 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray11 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList12 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList12, compilerInputArray11);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList14 = jSModuleGraph9.manageDependencies(dependencyOptions10, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList12);
//        jSModuleGraph9.coalesceDuplicateFiles();
//        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph17 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray16);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions18 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray19 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList20 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList20, compilerInputArray19);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList22 = jSModuleGraph17.manageDependencies(dependencyOptions18, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList20);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions24 = dependencyOptions18.setDependencyPruning(false);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions26 = dependencyOptions18.setMoocherDropping(false);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray27 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph28 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray27);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions29 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray30 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList31 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList31, compilerInputArray30);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList33 = jSModuleGraph28.manageDependencies(dependencyOptions29, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList31);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList34 = jSModuleGraph9.manageDependencies(dependencyOptions18, compilerInputList33);
//        try {
//            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList35 = jSModuleGraph1.manageDependencies(dependencyOptions7, compilerInputList34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(jSModuleArray8);
//        org.junit.Assert.assertNotNull(compilerInputArray11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(compilerInputList14);
//        org.junit.Assert.assertNotNull(jSModuleArray16);
//        org.junit.Assert.assertNotNull(compilerInputArray19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(compilerInputList22);
//        org.junit.Assert.assertNotNull(dependencyOptions24);
//        org.junit.Assert.assertNotNull(dependencyOptions26);
//        org.junit.Assert.assertNotNull(jSModuleArray27);
//        org.junit.Assert.assertNotNull(compilerInputArray30);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(compilerInputList33);
//        org.junit.Assert.assertNotNull(compilerInputList34);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int0 = com.google.javascript.rhino.Token.POS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        com.google.javascript.rhino.jstype.JSType jSType41 = functionType36.getTypeOfThis();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(jSType41);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot39 = functionType36.getSlot("goog.exportSymbol");
        com.google.javascript.rhino.jstype.Property property41 = functionType36.getOwnSlot("INSTANCEOF");
        com.google.javascript.rhino.jstype.StaticSlot staticSlot43 = functionType36.getSlot("Unknown class name");
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = functionType36.getExtendedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNull(staticSlot39);
        org.junit.Assert.assertNull(property41);
        org.junit.Assert.assertNull(staticSlot43);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        boolean boolean78 = functionType36.makesStructs();
        functionType36.setDict();
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable83 = jSTypeRegistry81.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray84 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList85 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean86 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList85, templateTypeArray84);
        jSTypeRegistry81.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList85);
        jSTypeRegistry81.clearTemplateTypeNames();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList89 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList90 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap91 = jSTypeRegistry81.createTemplateTypeMap(templateTypeList89, jSTypeList90);
        boolean boolean92 = templateTypeMap91.isEmpty();
        functionType36.extendTemplateTypeMap(templateTypeMap91);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable83);
        org.junit.Assert.assertNotNull(templateTypeArray84);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(templateTypeMap91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        compiler0.disableThreads();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = null;
        try {
            compiler0.init(jSSourceFileArray3, jSSourceFileArray4, compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str7 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType8, objectType9, objectType10, functionType11, functionType12);
        boolean boolean15 = closureCodingConvention0.isPrivate("");
        java.util.Collection<java.lang.String> strCollection16 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportProperty" + "'", str7.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(strCollection16);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        boolean boolean30 = node28.isCall();
        boolean boolean31 = node19.isEquivalentToTyped(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.voidNode(node19);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention0.getClassesDefinedByCall(node32);
        node32.setLength(86);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node21.isCast();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        boolean boolean34 = node27.isWith();
        node27.setQuotedString();
        com.google.javascript.rhino.Node node36 = node21.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.InputId inputId37 = node27.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry10.createFromTypeNodes(node27, "", jSTypeStaticScope39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry8.createConstructorType(jSType40, true, jSTypeArray42);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = functionType43.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType45 = functionType43.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType46 = functionType45.toMaybeFunctionType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType46.getOwnImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType49 = jSTypeRegistry1.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType46, "2019/06/10 12:15");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(errorReporter6);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(inputId37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(jSType49);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isUnscopedQualifiedName();
        node1.addChildrenToBack(node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str17 = diagnosticType16.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(node10, diagnosticType16, strArray22);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = diagnosticType16.level;
        java.lang.String str26 = diagnosticType16.toString();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str17.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str26.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean4 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node15.isCast();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node21.isWith();
        node21.setQuotedString();
        com.google.javascript.rhino.Node node30 = node15.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        boolean boolean36 = node34.isCall();
        boolean boolean37 = node34.isNE();
        int int38 = node34.getLength();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node21, node34 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(101, nodeArray39, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel44 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray52 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node42, checkLevel44, diagnosticType47, strArray52);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = diagnosticGroupWarningsGuard2.level(jSError54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType58, strArray60);
        com.google.javascript.jscomp.CheckLevel checkLevel62 = jSError61.level;
        com.google.javascript.jscomp.CheckLevel checkLevel63 = diagnosticGroupWarningsGuard2.level(jSError61);
        com.google.javascript.jscomp.CheckLevel checkLevel64 = jSError61.getDefaultLevel();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNull(checkLevel55);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        int int78 = functionType36.getExtendedInterfacesCount();
        java.util.Set<java.lang.String> strSet79 = functionType36.getPropertyNames();
        int int80 = functionType36.getMinArguments();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(strSet79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        int int4 = loggerErrorManager3.getErrorCount();
        int int5 = loggerErrorManager3.getErrorCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        boolean boolean42 = functionType36.isEnumType();
        java.lang.Object obj43 = null;
        boolean boolean44 = functionType36.equals(obj43);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        com.google.javascript.rhino.Node node83 = functionType77.getSource();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertNull(node83);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        java.lang.String str2 = assertInstanceofSpec1.getFunctionName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean11 = node10.isAssignAdd();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        node15.setQuotedString();
        boolean boolean18 = node15.isCatch();
        boolean boolean19 = node15.isOnlyModifiesThisCall();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable25 = jSTypeRegistry23.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node29, node34);
        boolean boolean36 = node34.isCast();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        boolean boolean47 = node40.isWith();
        node40.setQuotedString();
        com.google.javascript.rhino.Node node49 = node34.useSourceInfoIfMissingFrom(node40);
        com.google.javascript.rhino.InputId inputId50 = node40.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry23.createFromTypeNodes(node40, "", jSTypeStaticScope52);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry21.createConstructorType(jSType53, true, jSTypeArray55);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList57 = functionType56.getTemplateTypes();
        boolean boolean58 = functionType56.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot60 = functionType56.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable61 = functionType56.getParameters();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray66 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList67 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean68 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList67, templateTypeArray66);
        jSTypeRegistry63.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList67);
        jSTypeRegistry63.clearTemplateTypeNames();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList71 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap73 = jSTypeRegistry63.createTemplateTypeMap(templateTypeList71, jSTypeList72);
        boolean boolean74 = templateTypeMap73.isEmpty();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList75 = templateTypeMap73.getTemplateKeys();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry1.createConstructorType("STRING hi! 0 [quoted: 1]", node10, node15, (com.google.javascript.rhino.jstype.JSType) functionType56, templateTypeList75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(inputId50);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertNotNull(functionType56);
        org.junit.Assert.assertNull(jSTypeList57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(staticSlot60);
        org.junit.Assert.assertNotNull(nodeIterable61);
        org.junit.Assert.assertNotNull(objectTypeIterable65);
        org.junit.Assert.assertNotNull(templateTypeArray66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(templateTypeMap73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(templateTypeList75);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType42 = functionType36.getSuperClassConstructor();
        com.google.javascript.rhino.Node node43 = functionType36.getSource();
        com.google.javascript.rhino.jstype.FunctionType functionType45 = functionType36.getBindReturnType(85);
        boolean boolean46 = functionType36.isEnumType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNull(functionType42);
        org.junit.Assert.assertNull(node43);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        compiler2.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal5 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler2, callback4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray14 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray14);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError15.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray23 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError24 = nodeTraversal5.makeError(node9, checkLevel16, diagnosticType19, strArray23);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = jSError24.getDefaultLevel();
        java.lang.String str26 = lightweightMessageFormatter1.formatWarning(jSError24);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = jSError24.getDefaultLevel();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap37 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node31, node36);
        boolean boolean38 = node36.isCast();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap48 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node42, node47);
        boolean boolean49 = node42.isWith();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node51 = node36.useSourceInfoIfMissingFrom(node42);
        node42.detachChildren();
        boolean boolean53 = jSError24.equals((java.lang.Object) node42);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "WARNING - Not declared as a type name\n" + "'", str26.equals("WARNING - Not declared as a type name\n"));
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeMap37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeMap48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        boolean boolean66 = node61.isIn();
        boolean boolean67 = node61.isLabelName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(16, "STRING hi! 0", 50, (int) (byte) 10);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.throwNode(node3);
        boolean boolean9 = node3.isQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("STRING hi! 0");
        int int12 = node3.getIndexOfChild(node11);
        com.google.javascript.rhino.Node node14 = node11.getAncestor(4);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        boolean boolean11 = node3.isVoid();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node11.isWith();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10, node5, node11, 0, 0);
        boolean boolean22 = node21.hasMoreThanOneChild();
        boolean boolean23 = node21.isContinue();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(94, node21);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable28 = jSTypeRegistry26.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node37.isCast();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap49 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node43, node48);
        boolean boolean50 = node43.isWith();
        node43.setQuotedString();
        com.google.javascript.rhino.Node node52 = node37.useSourceInfoIfMissingFrom(node43);
        com.google.javascript.rhino.InputId inputId53 = node43.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope55 = null;
        com.google.javascript.rhino.jstype.JSType jSType56 = jSTypeRegistry26.createFromTypeNodes(node43, "", jSTypeStaticScope55);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.pos(node43);
        try {
            com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.catchNode(node21, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeMap49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(inputId53);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNotNull(node57);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node22.isCast();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node37 = node22.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        boolean boolean43 = node41.isCall();
        boolean boolean44 = node41.isNE();
        int int45 = node41.getLength();
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node28, node41 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(101, nodeArray46, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType50 = node49.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel51 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray59 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType57, strArray59);
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node49, checkLevel51, diagnosticType54, strArray59);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.pos(node49);
        boolean boolean63 = node49.isRegExp();
        com.google.javascript.rhino.Node node64 = node8.copyInformationFrom(node49);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSTypeRegistry.OBJECT_INDEX_TEMPLATE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Object#Key" + "'", str0.equals("Object#Key"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = compiler4.getOldParseTreeByName("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        boolean boolean34 = node24.isAssignAdd();
        boolean boolean35 = node24.isVoid();
        com.google.javascript.jscomp.NodeTraversal.Callback callback36 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler4, node24, callback36);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNull(astRoot9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node13 = node10.cloneTree();
        astValidator1.validateExpression(node10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node23.isCast();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node29, node34);
        boolean boolean36 = node29.isWith();
        node29.setQuotedString();
        com.google.javascript.rhino.Node node38 = node23.useSourceInfoIfMissingFrom(node29);
        try {
            astValidator1.validateStatement(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = googleCodingConvention0.isValidEnumKey("");
        java.util.Collection<java.lang.String> strCollection4 = googleCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray7 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, objectTypeArray7);
        java.util.Map<java.lang.String, java.lang.String> strMap10 = null;
        googleCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry5, jSTypeStaticScope6, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, strMap10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean17 = node16.isEmpty();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        node31.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention39 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str40 = googleCodingConvention39.getExportPropertyFunction();
        java.lang.String str41 = googleCodingConvention39.getAbstractMethodName();
        boolean boolean43 = googleCodingConvention39.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType53 = node52.getJSType();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap58 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node52, node57);
        java.lang.String str59 = node47.checkTreeEquals(node57);
        com.google.javascript.jscomp.SourceFile sourceFile61 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node57.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile61);
        boolean boolean63 = googleCodingConvention39.isOptionalParameter(node57);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile68 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node67);
        boolean boolean69 = googleCodingConvention39.isPrototypeAlias(node67);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
        boolean boolean75 = node73.isCall();
        com.google.javascript.rhino.Node node76 = node73.cloneTree();
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node(98, node16, node31, node67, node73);
        boolean boolean78 = googleCodingConvention0.isPrototypeAlias(node77);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strCollection4);
        org.junit.Assert.assertNotNull(objectTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "goog.exportProperty" + "'", str40.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "goog.abstractMethod" + "'", str41.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeMap58);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertNotNull(sourceFile61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(staticSourceFile68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Region region25 = compilerInput23.getRegion(10);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(region25);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap42 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node36, node41);
        boolean boolean43 = node41.isCast();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node47.isWith();
        node47.setQuotedString();
        com.google.javascript.rhino.Node node56 = node41.useSourceInfoIfMissingFrom(node47);
        com.google.javascript.rhino.Node node57 = node24.copyInformationFromForTree(node47);
        boolean boolean58 = node47.isParamList();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        node63.setQuotedString();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType70 = node69.getJSType();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap75 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node69, node74);
        boolean boolean76 = node69.isWith();
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(10, node63, node69, 0, 0);
        boolean boolean80 = node47.isEquivalentTo(node63);
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType85 = node84.getJSType();
        boolean boolean86 = node84.isCall();
        com.google.javascript.rhino.Node node87 = node84.cloneTree();
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.IR.and(node47, node87);
        boolean boolean89 = node47.isDebugger();
        com.google.javascript.rhino.Node node90 = node4.useSourceInfoIfMissingFromForTree(node47);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeMap42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(jSType70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(nodeMap75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNull(jSType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(node90);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType36.getPrototype();
        boolean boolean39 = objectType38.isObject();
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType38.getPropertyType("InputId: ");
        com.google.javascript.rhino.jstype.JSType jSType42 = jSType41.autoboxesTo();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNull(jSType42);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int0 = com.google.javascript.rhino.Token.EQUALS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 307 + "'", int0 == 307);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        java.lang.String str39 = node27.checkTreeEquals(node37);
        com.google.javascript.jscomp.SourceFile sourceFile41 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node37.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile41);
        java.lang.String str43 = sourceFile41.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceFile41);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput44, true);
        compilerInput46.clearAst();
        jSModule1.add(compilerInput46);
        java.util.List<java.lang.String> strList49 = jSModule1.getProvides();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(sourceFile41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(strList49);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = functionType36.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType38.toMaybeFunctionType();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = functionType39.getTemplateTypes();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNull(jSTypeList40);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean83 = functionType77.matchesNumberContext();
        boolean boolean85 = functionType77.hasProperty("STRING hi! 0");
        boolean boolean86 = functionType77.isTemplatizedType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node45.isHook();
        node45.setSourceEncodedPositionForTree(101);
        try {
            com.google.javascript.rhino.Node node49 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        boolean boolean78 = functionType36.isDict();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType36.findPropertyType("goog.global");
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(jSType80);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean83 = functionType77.matchesNumberContext();
        com.google.javascript.rhino.jstype.JSType jSType84 = functionType77.unboxesTo();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(jSType84);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int0 = com.google.javascript.rhino.Token.GETPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, "Not declared as a constructor", false);
        int int26 = compilerInput25.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput25, "goog.abstractMethod", true);
        com.google.javascript.jscomp.SourceFile sourceFile30 = compilerInput25.getSourceFile();
        java.lang.String str31 = compilerInput25.getName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(sourceFile30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Not declared as a constructor" + "'", str31.equals("Not declared as a constructor"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType31 = node30.getJSType();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap36 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node30, node35);
        boolean boolean37 = node35.isCast();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap47 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node41, node46);
        boolean boolean48 = node41.isWith();
        node41.setQuotedString();
        com.google.javascript.rhino.Node node50 = node35.useSourceInfoIfMissingFrom(node41);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        boolean boolean56 = node54.isCall();
        boolean boolean57 = node54.isNE();
        int int58 = node54.getLength();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node41, node54 };
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(101, nodeArray59, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel64 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType67 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType70 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray72 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make(diagnosticType70, strArray72);
        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node62, checkLevel64, diagnosticType67, strArray72);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.pos(node62);
        com.google.javascript.jscomp.CodingConvention.Bind bind77 = googleCodingConvention0.describeFunctionBind(node75, false);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType82 = node81.getJSType();
        boolean boolean83 = node81.isCall();
        com.google.javascript.rhino.Node node84 = node81.cloneTree();
        boolean boolean85 = googleCodingConvention0.isOptionalParameter(node81);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(jSType31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeMap36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeMap47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType67);
        org.junit.Assert.assertNotNull(diagnosticType70);
        org.junit.Assert.assertNotNull(strArray72);
        org.junit.Assert.assertNotNull(jSError73);
        org.junit.Assert.assertNotNull(jSError74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(bind77);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        int int0 = com.google.javascript.rhino.Token.IF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 108 + "'", int0 == 108);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("WARNING - \n");
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        boolean boolean11 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node12 = node3.removeFirstChild();
        try {
            node3.setDouble((double) 126);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.InputId inputId28 = node18.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createFromTypeNodes(node18, "", jSTypeStaticScope30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        boolean boolean33 = jSType31.canCastTo(jSType32);
        java.lang.String str34 = jSType31.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = jSTypeRegistry38.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        boolean boolean51 = node49.isCast();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap61 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node55, node60);
        boolean boolean62 = node55.isWith();
        node55.setQuotedString();
        com.google.javascript.rhino.Node node64 = node49.useSourceInfoIfMissingFrom(node55);
        com.google.javascript.rhino.InputId inputId65 = node55.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope67 = null;
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeRegistry38.createFromTypeNodes(node55, "", jSTypeStaticScope67);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry36.createConstructorType(jSType68, true, jSTypeArray70);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = functionType71.getTemplateTypes();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot74 = functionType71.getSlot("goog.exportSymbol");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair75 = jSType31.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType71);
        boolean boolean76 = jSType31.isUnionType();
        com.google.javascript.rhino.jstype.JSType jSType78 = jSType31.getRestrictedTypeGivenToBooleanOutcome(false);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(inputId28);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeMap61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNull(inputId65);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSTypeArray70);
        org.junit.Assert.assertNotNull(functionType71);
        org.junit.Assert.assertNull(jSTypeList72);
        org.junit.Assert.assertNull(staticSlot74);
        org.junit.Assert.assertNotNull(typePair75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(jSType78);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        jSTypeRegistry1.forwardDeclareType("STRING hi!\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray85 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList86 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean87 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList86, templateTypeArray85);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList86);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertNotNull(templateTypeArray85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int0 = com.google.javascript.rhino.Token.DEBUGGER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 152 + "'", int0 == 152);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback11);
        com.google.javascript.jscomp.Scope scope13 = nodeTraversal12.getScope();
        com.google.javascript.rhino.Node node14 = nodeTraversal12.getCurrentNode();
        com.google.javascript.rhino.Node node15 = nodeTraversal12.getCurrentNode();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler16 = nodeTraversal12.getCompiler();
        com.google.javascript.rhino.Node node17 = nodeTraversal12.getEnclosingFunction();
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNull(scope13);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(abstractCompiler16);
        org.junit.Assert.assertNull(node17);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        boolean boolean24 = node14.isLabelName();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot31 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult32 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node28, astRoot31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.throwNode(node28);
        boolean boolean34 = node28.isQuotedString();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("STRING hi! 0");
        int int37 = node28.getIndexOfChild(node36);
        com.google.javascript.rhino.Node node38 = node14.useSourceInfoIfMissingFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        boolean boolean44 = node42.isCall();
        com.google.javascript.rhino.Node node45 = node42.cloneTree();
        com.google.javascript.rhino.Node node46 = node36.copyInformationFrom(node42);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) '4', node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        boolean boolean24 = node22.isCall();
        boolean boolean25 = node13.isEquivalentToTyped(node22);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean31 = node30.isEmpty();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        node45.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention53 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str54 = googleCodingConvention53.getExportPropertyFunction();
        java.lang.String str55 = googleCodingConvention53.getAbstractMethodName();
        boolean boolean57 = googleCodingConvention53.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType67 = node66.getJSType();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap72 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node66, node71);
        java.lang.String str73 = node61.checkTreeEquals(node71);
        com.google.javascript.jscomp.SourceFile sourceFile75 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node71.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile75);
        boolean boolean77 = googleCodingConvention53.isOptionalParameter(node71);
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile82 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node81);
        boolean boolean83 = googleCodingConvention53.isPrototypeAlias(node81);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType88 = node87.getJSType();
        boolean boolean89 = node87.isCall();
        com.google.javascript.rhino.Node node90 = node87.cloneTree();
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node(98, node30, node45, node81, node87);
        com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.IR.continueNode();
        try {
            node22.replaceChildAfter(node87, node92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "goog.exportProperty" + "'", str54.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "goog.abstractMethod" + "'", str55.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeMap72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(sourceFile75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(staticSourceFile82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNull(jSType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(node92);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        int int2 = node1.getSideEffectFlags();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str5 = googleCodingConvention4.getExportPropertyFunction();
        java.lang.String str6 = googleCodingConvention4.getAbstractMethodName();
        boolean boolean9 = googleCodingConvention4.isExported("hi!", false);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention10 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention4);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope12 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray13 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList14 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList14, objectTypeArray13);
        java.util.Map<java.lang.String, java.lang.String> strMap16 = null;
        googleCodingConvention10.defineDelegateProxyPrototypeProperties(jSTypeRegistry11, jSTypeStaticScope12, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList14, strMap16);
        node1.putProp(4, (java.lang.Object) googleCodingConvention10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportProperty" + "'", str5.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.abstractMethod" + "'", str6.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objectTypeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.ModificationVisitor modificationVisitor2 = new com.google.javascript.rhino.jstype.ModificationVisitor(jSTypeRegistry1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        boolean boolean38 = functionType37.isUnknownType();
        boolean boolean39 = functionType37.hasInstanceType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean5 = googleCodingConvention0.isExported("hi!", false);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        java.lang.String str7 = googleCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType43 = functionType36.getBindReturnType(100);
        com.google.javascript.rhino.jstype.FunctionType functionType45 = functionType36.getBindReturnType(301);
        com.google.javascript.rhino.JSDocInfo jSDocInfo47 = functionType36.getOwnPropertyJSDocInfo("hi!");
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNull(jSDocInfo47);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        compiler28.reportCodeChange();
        com.google.javascript.jscomp.Scope scope32 = compiler28.getTopScope();
        try {
            com.google.javascript.jscomp.SymbolTable symbolTable33 = compiler28.buildKnownSymbolTable();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(scope32);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean4 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node15.isCast();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node21.isWith();
        node21.setQuotedString();
        com.google.javascript.rhino.Node node30 = node15.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        boolean boolean36 = node34.isCall();
        boolean boolean37 = node34.isNE();
        int int38 = node34.getLength();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node21, node34 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(101, nodeArray39, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel44 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray52 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node42, checkLevel44, diagnosticType47, strArray52);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = diagnosticGroupWarningsGuard2.level(jSError54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType58, strArray60);
        com.google.javascript.jscomp.CheckLevel checkLevel62 = jSError61.level;
        com.google.javascript.jscomp.CheckLevel checkLevel63 = diagnosticGroupWarningsGuard2.level(jSError61);
        java.lang.String str64 = jSError61.sourceName;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNull(checkLevel55);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(checkLevel63);
        org.junit.Assert.assertNull(str64);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList4 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap5 = null;
        closureCodingConvention1.defineDelegateProxyPrototypeProperties(jSTypeRegistry2, jSTypeStaticScope3, objectTypeList4, strMap5);
        boolean boolean9 = closureCodingConvention1.isExported("STRING hi!\n", true);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(10, node14, node20, 0, 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship31 = closureCodingConvention1.getDelegateRelationship(node14);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.stringKey("Not declared as a type name");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean38 = node37.isEmpty();
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec40 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean45 = node44.wasEmptyNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType75 = node74.getJSType();
        boolean boolean76 = node74.isCall();
        boolean boolean77 = node74.isNE();
        int int78 = node74.getLength();
        com.google.javascript.rhino.Node[] nodeArray79 = new com.google.javascript.rhino.Node[] { node61, node74 };
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(101, nodeArray79, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node83 = node44.useSourceInfoFrom(node82);
        com.google.javascript.rhino.Node node84 = assertInstanceofSpec40.getAssertedParam(node82);
        try {
            com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(0, node14, node33, node37, node82, (-20), 14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(delegateRelationship31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(nodeArray79);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node84);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isNoType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = functionType36.getExtendedInterfaces();
        boolean boolean40 = functionType36.isFunctionPrototypeType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        boolean boolean6 = node3.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot7);
        node3.setCharno((int) (byte) 100);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.eq(node3, node14);
        try {
            com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.defaultCase(node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.returnNode(node3);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile15 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node14);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap25 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node19, node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.returnNode(node19);
        com.google.javascript.rhino.Node node27 = node14.useSourceInfoFrom(node26);
        try {
            com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.and(node10, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(staticSourceFile15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeMap25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        boolean boolean31 = compiler28.isTypeCheckingEnabled();
        com.google.javascript.jscomp.JSError[] jSErrorArray32 = compiler28.getWarnings();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSErrorArray32);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node45.isHook();
        com.google.javascript.rhino.Node node47 = node45.removeFirstChild();
        boolean boolean48 = node45.isObjectLit();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        int int4 = loggerErrorManager3.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = compiler0.getOldParseTreeByName("");
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(astRoot4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        java.lang.String str20 = sourceFile17.getName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        int int24 = node14.getSourceOffset();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile("DiagnosticGroup<missingRequire>(WARNING)");
        com.google.javascript.jscomp.SourceFile sourceFile8 = builder0.buildFromCode("2019/06/10 12:15", "");
        com.google.javascript.jscomp.SourceFile.Builder builder10 = builder0.withOriginalPath("2019/06/10 12:15");
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertNotNull(builder10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType43 = functionType36.getBindReturnType(100);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
        boolean boolean45 = functionType43.isNumberValueType();
        boolean boolean47 = functionType43.hasOwnProperty("");
        com.google.javascript.rhino.Node node48 = functionType43.getSource();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(functionTypeList44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(node48);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.or(node3, node9);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable12 = node11.children();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeIterable12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(33, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap41 = functionType36.getTemplateTypeMap();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(templateTypeMap41);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType jSType6 = jSTypeRegistry1.getGreatestSubtypeWithProperty(jSType4, "");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder9 = functionBuilder7.withName("Not declared as a type name");
        org.junit.Assert.assertNotNull(jSType6);
        org.junit.Assert.assertNotNull(functionBuilder9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int0 = com.google.javascript.rhino.Token.ARRAYLIT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 63 + "'", int0 == 63);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.returnNode(node8);
        com.google.javascript.rhino.Node node16 = node3.useSourceInfoFrom(node15);
        boolean boolean17 = node16.isFunction();
        org.junit.Assert.assertNull(staticSourceFile4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative4 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = jSTypeRegistry1.getNativeObjectType(jSTypeNative4);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertTrue("'" + jSTypeNative4 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative4.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(objectType5);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean83 = functionType77.matchesNumberContext();
        com.google.javascript.rhino.jstype.UnionType unionType84 = functionType77.toMaybeUnionType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(unionType84);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean77 = jSType76.isArrayType();
        jSType76.clearResolved();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 92 + "'", int0 == 92);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = jSTypeRegistry1.createAnonymousObjectType(jSDocInfo2);
        org.junit.Assert.assertNotNull(objectType3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList38 = functionType37.getSubTypes();
        boolean boolean39 = functionType37.isRecordType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(functionTypeList38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.incrementGeneration();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable4 = jSTypeRegistry1.getTypesWithProperty("D4J_Closure_115_FIXED_VERSION");
        org.junit.Assert.assertNotNull(jSTypeIterable4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap37 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node31, node36);
        java.lang.String str38 = node26.checkTreeEquals(node36);
        com.google.javascript.jscomp.SourceFile sourceFile40 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node36.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile40);
        java.lang.String str42 = sourceFile40.getOriginalPath();
        java.lang.String str43 = sourceFile40.getOriginalPath();
        compilerInput20.setSourceFile(sourceFile40);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeMap37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(sourceFile40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray2 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", diagnosticGroupArray2);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean9 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        boolean boolean41 = node39.isCall();
        boolean boolean42 = node39.isNE();
        int int43 = node39.getLength();
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node26, node39 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(101, nodeArray44, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel49 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray57 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make(diagnosticType55, strArray57);
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node47, checkLevel49, diagnosticType52, strArray57);
        com.google.javascript.jscomp.CheckLevel checkLevel60 = diagnosticGroupWarningsGuard7.level(jSError59);
        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray65 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError66 = com.google.javascript.jscomp.JSError.make(diagnosticType63, strArray65);
        com.google.javascript.jscomp.CheckLevel checkLevel67 = jSError66.level;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = diagnosticGroupWarningsGuard7.level(jSError66);
        boolean boolean69 = diagnosticGroup4.matches(jSError66);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroupArray2);
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(strArray57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNull(checkLevel60);
        org.junit.Assert.assertNotNull(diagnosticType63);
        org.junit.Assert.assertNotNull(strArray65);
        org.junit.Assert.assertNotNull(jSError66);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(checkLevel68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int0 = com.google.javascript.rhino.Token.DEC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 103 + "'", int0 == 103);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node45.isHook();
        node45.setSourceEncodedPositionForTree(101);
        node45.setSourceEncodedPositionForTree(115);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        try {
            boolean boolean5 = node4.isCatch();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        boolean boolean23 = compilerInput20.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray2 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createUnionType(jSTypeNativeArray2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap6 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer7 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry5, templateTypeMap6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = jSTypeRegistry11.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node22.isCast();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node37 = node22.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.InputId inputId38 = node28.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope40 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry11.createFromTypeNodes(node28, "", jSTypeStaticScope40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry9.createConstructorType(jSType41, true, jSTypeArray43);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = functionType44.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = jSTypeRegistry49.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap61 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node55, node60);
        boolean boolean62 = node60.isCast();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType67 = node66.getJSType();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap72 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node66, node71);
        boolean boolean73 = node66.isWith();
        node66.setQuotedString();
        com.google.javascript.rhino.Node node75 = node60.useSourceInfoIfMissingFrom(node66);
        com.google.javascript.rhino.InputId inputId76 = node66.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry49.createFromTypeNodes(node66, "", jSTypeStaticScope78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry47.createConstructorType(jSType79, true, jSTypeArray81);
        com.google.javascript.rhino.jstype.FunctionType functionType83 = functionType82.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType84 = functionType44.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType83);
        com.google.javascript.rhino.ErrorReporter errorReporter86 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry87 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter86);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable89 = jSTypeRegistry87.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node91 = jSTypeRegistry87.createParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry5.createFunctionType((com.google.javascript.rhino.jstype.JSType) functionType44, true, jSTypeArray90);
        com.google.javascript.rhino.jstype.JSType jSType93 = jSTypeRegistry1.createUnionType(jSTypeArray90);
        org.junit.Assert.assertNotNull(jSTypeNativeArray2);
        org.junit.Assert.assertNotNull(jSType3);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(inputId38);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSTypeList45);
        org.junit.Assert.assertNotNull(objectTypeIterable51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeMap61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeMap72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(inputId76);
        org.junit.Assert.assertNotNull(jSType79);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertNotNull(functionType83);
        org.junit.Assert.assertNotNull(jSType84);
        org.junit.Assert.assertNotNull(objectTypeIterable89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertNotNull(jSType93);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean4 = node3.mayMutateArguments();
        boolean boolean5 = node3.isName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, node10, node16, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node10.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFrom(node10);
        com.google.javascript.rhino.InputId inputId30 = new com.google.javascript.rhino.InputId("");
        node3.setInputId(inputId30);
        try {
            com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback11);
        com.google.javascript.jscomp.Scope scope13 = nodeTraversal12.getScope();
        java.lang.String str14 = nodeTraversal12.getSourceName();
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNull(scope13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType43 = functionType36.getBindReturnType(100);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
        boolean boolean45 = functionType43.hasReferenceName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(functionTypeList44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        boolean boolean15 = node3.isEquivalentTo(node13);
        boolean boolean16 = node3.isInstanceOf();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = jSTypeRegistry45.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node56.isCast();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        node62.setQuotedString();
        com.google.javascript.rhino.Node node71 = node56.useSourceInfoIfMissingFrom(node62);
        com.google.javascript.rhino.InputId inputId72 = node62.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry45.createFromTypeNodes(node62, "", jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry43.createConstructorType(jSType75, true, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType78.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType40.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType79);
        functionType40.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType82 = templateTypeMapReplacer3.caseFunctionType(functionType40);
        com.google.javascript.rhino.jstype.UnionType unionType83 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType84 = templateTypeMapReplacer3.caseUnionType(unionType83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(inputId72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node43.isTry();
        boolean boolean47 = node43.isInstanceOf();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile48 = node43.getStaticSourceFile();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(staticSourceFile48);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType43 = functionType36.getBindReturnType(100);
        com.google.javascript.rhino.jstype.FunctionType functionType45 = functionType36.getBindReturnType(301);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = functionType45.getCtorExtendedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(30, "STRING hi! 0 [quoted: 1]. Not declared as a type name at (unknown source) line 0 : 0", 57, 63);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        try {
            node0.setDouble((double) 50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BREAK is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        compiler0.disableThreads();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler0.getSourceMap();
        org.junit.Assert.assertNull(sourceMap3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        int int2 = node1.getSideEffectFlags();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.var(node1);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable4 = node1.siblings();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(nodeIterable4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int0 = com.google.javascript.rhino.Token.BITNOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str32 = compiler28.toSource(jSModule31);
        jSModule1.addDependency(jSModule31);
        java.util.List<java.lang.String> strList34 = jSModule1.getRequires();
        jSModule1.clearAsts();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(strList34);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("Not declared as a type name");
        com.google.javascript.rhino.Node node3 = node1.getAncestor(120);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        boolean boolean24 = node14.isAssignAdd();
        boolean boolean26 = node14.getBooleanProp((int) (byte) 1);
        boolean boolean27 = node14.isVoid();
        boolean boolean28 = node14.isOptionalArg();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isExported("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType5 = null;
        closureCodingConvention0.applySubclassRelationship(functionType3, functionType4, subclassType5);
        boolean boolean8 = closureCodingConvention0.isSuperClassReference("InputId: ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        com.google.javascript.rhino.jstype.FunctionType functionType41 = functionType36.getOwnerFunction();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNull(functionType41);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        int int78 = functionType36.getExtendedInterfacesCount();
        boolean boolean79 = functionType36.isNominalType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType36.getReturnType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(jSType80);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 16, 32);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        int int20 = sourceFile17.getLineOfOffset((int) (byte) 100);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        boolean boolean38 = functionType37.matchesObjectContext();
        boolean boolean39 = functionType37.hasCachedValues();
        com.google.javascript.rhino.jstype.EnumType enumType40 = functionType37.toMaybeEnumType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(enumType40);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType43 = functionType36.getBindReturnType(100);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList44 = functionType43.getSubTypes();
        boolean boolean45 = functionType43.isNumberValueType();
        boolean boolean46 = functionType43.isDateType();
        boolean boolean47 = functionType43.hasReferenceName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(functionTypeList44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node21.isCast();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        boolean boolean34 = node27.isWith();
        node27.setQuotedString();
        com.google.javascript.rhino.Node node36 = node21.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.InputId inputId37 = node27.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry10.createFromTypeNodes(node27, "", jSTypeStaticScope39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry8.createConstructorType(jSType40, true, jSTypeArray42);
        java.lang.String str44 = functionType43.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable48 = jSTypeRegistry46.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType53 = node52.getJSType();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap58 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node52, node57);
        boolean boolean59 = node57.isCast();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap69 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node63, node68);
        boolean boolean70 = node63.isWith();
        node63.setQuotedString();
        com.google.javascript.rhino.Node node72 = node57.useSourceInfoIfMissingFrom(node63);
        com.google.javascript.rhino.InputId inputId73 = node63.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope75 = null;
        com.google.javascript.rhino.jstype.JSType jSType76 = jSTypeRegistry46.createFromTypeNodes(node63, "", jSTypeStaticScope75);
        com.google.javascript.rhino.jstype.JSType jSType77 = null;
        boolean boolean78 = jSType76.canCastTo(jSType77);
        java.lang.String str79 = jSType76.getDisplayName();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair80 = functionType43.getTypesUnderInequality(jSType76);
        boolean boolean82 = jSTypeRegistry1.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType43, "STRING hi! 0 [quoted: 1]: Not declared as a type name");
        com.google.javascript.rhino.jstype.JSType jSType84 = functionType43.getPropertyType("Unknown class name");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(inputId37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(objectTypeIterable48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeMap58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeMap69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNull(inputId73);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(typePair80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(jSType84);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isNot();
        com.google.javascript.rhino.jstype.JSType jSType2 = node0.getJSType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(jSType2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int0 = com.google.javascript.rhino.Token.SUB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isConstant("D4J_Closure_115_FIXED_VERSION");
        boolean boolean6 = googleCodingConvention0.isPrivate("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node2 = node0.getChildAtIndex(0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        int int42 = functionType36.getExtendedInterfacesCount();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean83 = functionType77.matchesNumberContext();
        boolean boolean85 = functionType77.hasProperty("STRING hi! 0");
        java.lang.Object obj86 = functionType77.getTypeOfThis();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(obj86);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.InputId inputId36 = node26.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope38 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry9.createFromTypeNodes(node26, "", jSTypeStaticScope38);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry7.createConstructorType(jSType39, true, jSTypeArray41);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList43 = functionType42.getTemplateTypes();
        boolean boolean44 = functionType42.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = jSTypeRegistry48.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap60 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node54, node59);
        boolean boolean61 = node59.isCast();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType66 = node65.getJSType();
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap71 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node65, node70);
        boolean boolean72 = node65.isWith();
        node65.setQuotedString();
        com.google.javascript.rhino.Node node74 = node59.useSourceInfoIfMissingFrom(node65);
        com.google.javascript.rhino.InputId inputId75 = node65.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = jSTypeRegistry48.createFromTypeNodes(node65, "", jSTypeStaticScope77);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry46.createConstructorType(jSType78, true, jSTypeArray80);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair82 = functionType42.getTypesUnderShallowEquality(jSType78);
        boolean boolean83 = functionType42.isNoResolvedType();
        int int84 = functionType42.getExtendedInterfacesCount();
        boolean boolean85 = functionType42.isNominalType();
        java.lang.String str86 = functionType42.getDisplayName();
        boolean boolean88 = jSTypeRegistry1.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType42, "goog.abstractMethod");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(inputId36);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNull(jSTypeList43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeMap60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(nodeMap71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(inputId75);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(typePair82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(str86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
        try {
            java.lang.String str3 = sourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter12 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        node16.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult20 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node16, astRoot19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.throwNode(node16);
        boolean boolean22 = node16.isQuotedString();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("STRING hi! 0");
        int int25 = node16.getIndexOfChild(node24);
        com.google.javascript.jscomp.type.FlowScope flowScope26 = null;
        com.google.javascript.jscomp.type.FlowScope flowScope28 = semanticReverseAbstractInterpreter12.getPreciserScopeKnowingConditionOutcome(node24, flowScope26, true);
        boolean boolean29 = node24.isLabelName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNull(flowScope28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isExported("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType5 = null;
        closureCodingConvention0.applySubclassRelationship(functionType3, functionType4, subclassType5);
        java.lang.String str7 = closureCodingConvention0.getExportSymbolFunction();
        java.util.Collection<java.lang.String> strCollection8 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(strCollection8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        java.lang.Object obj12 = node8.getProp(23);
        boolean boolean13 = node8.isString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        node8.putBooleanProp(46, false);
        boolean boolean15 = node8.isWhile();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node23, node28);
        boolean boolean30 = node28.isCast();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        node34.setQuotedString();
        com.google.javascript.rhino.Node node43 = node28.useSourceInfoIfMissingFrom(node34);
        com.google.javascript.rhino.InputId inputId44 = node34.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry17.createFromTypeNodes(node34, "", jSTypeStaticScope46);
        com.google.javascript.rhino.Node node48 = node8.useSourceInfoIfMissingFromForTree(node34);
        boolean boolean49 = node48.isNumber();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(inputId44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType36.getSuperClassConstructor();
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList40 = functionType36.getSubTypes();
        com.google.javascript.rhino.jstype.FunctionType functionType41 = functionType36.getOwnerFunction();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(functionType39);
        org.junit.Assert.assertNull(functionTypeList40);
        org.junit.Assert.assertNull(functionType41);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList75 = functionType74.getTemplateTypes();
        boolean boolean76 = functionType74.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot78 = functionType74.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable79 = functionType74.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType80 = functionType74.getSuperClassConstructor();
        boolean boolean81 = functionType74.isObject();
        boolean boolean82 = functionType74.hasAnyTemplateTypesInternal();
        functionType36.matchConstraint((com.google.javascript.rhino.jstype.JSType) functionType74);
        java.lang.String str84 = functionType74.getDisplayName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(staticSlot78);
        org.junit.Assert.assertNotNull(nodeIterable79);
        org.junit.Assert.assertNull(functionType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(str84);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType42 = functionType36.getSuperClassConstructor();
        boolean boolean43 = functionType36.isObject();
        com.google.javascript.rhino.jstype.ObjectType objectType44 = functionType36.toObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(objectType44);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy1 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF;
        try {
            com.google.javascript.jscomp.CheckEventfulObjectDisposal checkEventfulObjectDisposal2 = new com.google.javascript.jscomp.CheckEventfulObjectDisposal(abstractCompiler0, disposalCheckingPolicy1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy1 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy1.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(22, "D4J_Closure_115_FIXED_VERSION", 9, 148);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter12 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry11);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean17 = node16.isNull();
        com.google.javascript.jscomp.type.FlowScope flowScope18 = null;
        com.google.javascript.jscomp.type.FlowScope flowScope20 = semanticReverseAbstractInterpreter12.getPreciserScopeKnowingConditionOutcome(node16, flowScope18, true);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(flowScope20);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_EVENTFUL_OBJECT_DISPOSAL;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str7 = diagnosticType6.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int11 = diagnosticType6.compareTo(diagnosticType10);
        boolean boolean12 = diagnosticGroup3.matches(diagnosticType10);
        boolean boolean13 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean18 = diagnosticGroupWarningsGuard16.disables(diagnosticGroup17);
        boolean boolean19 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup17);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str7.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-20) + "'", int11 == (-20));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, "Not declared as a constructor", false);
        int int26 = compilerInput25.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput25, "goog.abstractMethod", true);
        com.google.javascript.jscomp.SourceFile sourceFile30 = compilerInput25.getSourceFile();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode33 = null;
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap44 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node38, node43);
        boolean boolean45 = node38.isWith();
        boolean boolean46 = node38.isOnlyModifiesThisCall();
        java.lang.String[] strArray51 = new java.lang.String[] { "goog.exportProperty", "hi!", "InputId: ", "goog.abstractMethod" };
        java.util.LinkedHashSet<java.lang.String> strSet52 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet52, strArray51);
        node38.setDirectives((java.util.Set<java.lang.String>) strSet52);
        com.google.javascript.jscomp.parsing.Config config55 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode33, false, (java.util.Set<java.lang.String>) strSet52);
        com.google.javascript.rhino.head.ErrorReporter errorReporter56 = null;
        java.util.logging.Logger logger57 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult58 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile30, "STRING hi!\n", config55, errorReporter56, logger57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(sourceFile30);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeMap44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(config55);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("STRING hi! 0");
        boolean boolean2 = node1.isGetElem();
        boolean boolean3 = node1.isTypeOf();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        jSModule1.clearAsts();
        int int3 = jSModule1.getDepth();
        java.util.List<java.lang.String> strList4 = jSModule1.getRequires();
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList5 = jSModule1.getInputs();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertNotNull(compilerInputList5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isSwitch();
        int int11 = node3.getLineno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str8 = compiler4.toSource(jSModule7);
        jSModule7.clearAsts();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        compiler10.disableThreads();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = compiler10.getOldParseTreeByName("STRING hi! 0 [quoted: 1]: Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig15 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions14);
        compiler10.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig15);
        jSModule7.sortInputsByDeps(compiler10);
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(astRoot13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        java.lang.String str3 = sourceFile1.getLine(14);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        boolean boolean8 = closureCodingConvention0.isExported("STRING hi!\n", true);
        java.lang.String str9 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        java.lang.String str25 = node13.checkTreeEquals(node23);
        boolean boolean26 = node23.isAssign();
        java.lang.String str27 = node23.getString();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile32 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node31);
        com.google.javascript.rhino.Node node33 = node23.copyInformationFrom(node31);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap49 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node43, node48);
        java.lang.String str50 = node38.checkTreeEquals(node48);
        com.google.javascript.jscomp.SourceFile sourceFile52 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node48.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile52);
        node48.setIsSyntheticBlock(true);
        node34.addChildToBack(node48);
        java.lang.String str57 = closureCodingConvention0.extractClassNameIfProvide(node33, node34);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "goog.global" + "'", str9.equals("goog.global"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertNull(staticSourceFile32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeMap49);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(sourceFile52);
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node43.isInc();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str7 = closureCodingConvention0.getExportPropertyFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection8 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection9 = closureCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportProperty" + "'", str7.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection8);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        node8.putBooleanProp(46, false);
        boolean boolean15 = node8.isWhile();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node23, node28);
        boolean boolean30 = node28.isCast();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        node34.setQuotedString();
        com.google.javascript.rhino.Node node43 = node28.useSourceInfoIfMissingFrom(node34);
        com.google.javascript.rhino.InputId inputId44 = node34.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry17.createFromTypeNodes(node34, "", jSTypeStaticScope46);
        com.google.javascript.rhino.Node node48 = node8.useSourceInfoIfMissingFromForTree(node34);
        boolean boolean49 = node8.isDebugger();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType55 = node54.getJSType();
        node54.setQuotedString();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        boolean boolean67 = node60.isWith();
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(10, node54, node60, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder71 = node54.new FileLevelJsDocBuilder();
        int int72 = node54.getChildCount();
        int int73 = node54.getSideEffectFlags();
        try {
            com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.caseNode(node8, node54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(inputId44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNull(jSType55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        boolean boolean6 = node3.isNE();
        int int7 = node3.getLength();
        boolean boolean8 = node3.isWith();
        boolean boolean9 = node3.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        java.lang.String str20 = sourceFile17.getOriginalPath();
        boolean boolean21 = sourceFile17.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int23 = compilerInput22.getNumLines();
        com.google.javascript.jscomp.SourceFile sourceFile24 = compilerInput22.getSourceFile();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(sourceFile24);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = jSTypeRegistry1.getErrorReporter();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertNull(errorReporter83);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(306, 0, 147);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray4 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5, templateTypeArray4);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList9 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap11 = jSTypeRegistry1.createTemplateTypeMap(templateTypeList9, jSTypeList10);
        com.google.javascript.rhino.jstype.TemplateType templateType12 = null;
        boolean boolean13 = templateTypeMap11.hasTemplateType(templateType12);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList14 = templateTypeMap11.getTemplateKeys();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(templateTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(templateTypeMap11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(templateTypeList14);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        boolean boolean2 = node1.isFromExterns();
        boolean boolean3 = node1.isThrow();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        boolean boolean41 = functionType36.isNullType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.CompilerOptions.Reach reach0 = com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY;
        org.junit.Assert.assertTrue("'" + reach0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY + "'", reach0.equals(com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager3.getErrors();
        loggerErrorManager3.setTypedPercent((double) 115);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("2019/06/10 12:15");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray4 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5, templateTypeArray4);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList9 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap11 = jSTypeRegistry1.createTemplateTypeMap(templateTypeList9, jSTypeList10);
        boolean boolean12 = templateTypeMap11.isEmpty();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList13 = templateTypeMap11.getTemplateKeys();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable17 = jSTypeRegistry15.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node19 = jSTypeRegistry15.createParameters(jSTypeArray18);
        jSTypeRegistry15.clearTemplateTypeNames();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable22 = jSTypeRegistry15.getTypesWithProperty("");
        com.google.javascript.rhino.jstype.TemplateType templateType24 = jSTypeRegistry15.createTemplateType("");
        boolean boolean25 = templateTypeMap11.hasTemplateType(templateType24);
        boolean boolean26 = templateType24.isNominalType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(templateTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(templateTypeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(templateTypeList13);
        org.junit.Assert.assertNotNull(objectTypeIterable17);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(jSTypeIterable22);
        org.junit.Assert.assertNotNull(templateType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        boolean boolean24 = node22.isCall();
        boolean boolean25 = node13.isEquivalentToTyped(node22);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.voidNode(node13);
        node26.setSourceFileForTesting("");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.javascript.rhino.jstype.ModificationVisitor modificationVisitor7 = new com.google.javascript.rhino.jstype.ModificationVisitor(jSTypeRegistry1);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        boolean boolean6 = node3.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot7);
        node3.setCharno((int) (byte) 100);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.eq(node3, node14);
        com.google.javascript.rhino.InputId inputId24 = new com.google.javascript.rhino.InputId("");
        java.lang.String str25 = inputId24.getIdName();
        java.lang.String str26 = inputId24.getIdName();
        node3.setInputId(inputId24);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.AstValidator astValidator0 = new com.google.javascript.jscomp.AstValidator();
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        jSModule1.clearAsts();
        java.lang.String str3 = jSModule1.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi! 0 [quoted: 1]" + "'", str3.equals("STRING hi! 0 [quoted: 1]"));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.JSModule jSModule7 = null;
//        com.google.javascript.jscomp.JSModule jSModule8 = null;
//        com.google.javascript.jscomp.JSModule jSModule9 = jSModuleGraph1.getDeepestCommonDependencyInclusive(jSModule7, jSModule8);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNull(jSModule9);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        int int23 = compilerInput22.getNumLines();
        com.google.javascript.jscomp.SourceAst sourceAst24 = compilerInput22.getSourceAst();
        jSModule1.addFirst(compilerInput22);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(sourceAst24);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = jSTypeRegistry11.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node22.isCast();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node37 = node22.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.InputId inputId38 = node28.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope40 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry11.createFromTypeNodes(node28, "", jSTypeStaticScope40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry9.createConstructorType(jSType41, true, jSTypeArray43);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = functionType44.getTemplateTypes();
        com.google.javascript.rhino.JSDocInfo jSDocInfo47 = null;
        functionType44.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", jSDocInfo47);
        com.google.javascript.rhino.jstype.ObjectType objectType50 = functionType44.getTopMostDefiningType("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable56 = jSTypeRegistry54.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        boolean boolean67 = node65.isCast();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap77 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node71, node76);
        boolean boolean78 = node71.isWith();
        node71.setQuotedString();
        com.google.javascript.rhino.Node node80 = node65.useSourceInfoIfMissingFrom(node71);
        com.google.javascript.rhino.InputId inputId81 = node71.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope83 = null;
        com.google.javascript.rhino.jstype.JSType jSType84 = jSTypeRegistry54.createFromTypeNodes(node71, "", jSTypeStaticScope83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry52.createConstructorType(jSType84, true, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType88 = functionType87.toMaybeFunctionType();
        boolean boolean89 = functionType88.isUnknownType();
        boolean boolean91 = functionType88.removeProperty("WARNING - Not declared as a type name\n");
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createFunctionTypeWithNewThisType(functionType44, (com.google.javascript.rhino.jstype.ObjectType) functionType88);
        boolean boolean93 = functionType92.isFunctionPrototypeType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(errorReporter6);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(inputId38);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSTypeList45);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(objectTypeIterable56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(nodeMap77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNull(inputId81);
        org.junit.Assert.assertNotNull(jSType84);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = jSTypeRegistry45.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node56.isCast();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        node62.setQuotedString();
        com.google.javascript.rhino.Node node71 = node56.useSourceInfoIfMissingFrom(node62);
        com.google.javascript.rhino.InputId inputId72 = node62.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry45.createFromTypeNodes(node62, "", jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry43.createConstructorType(jSType75, true, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType78.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType40.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType79);
        functionType40.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType82 = templateTypeMapReplacer3.caseFunctionType(functionType40);
        com.google.javascript.rhino.jstype.JSType jSType83 = templateTypeMapReplacer3.caseAllType();
        com.google.javascript.rhino.jstype.JSType jSType84 = templateTypeMapReplacer3.caseVoidType();
        boolean boolean85 = jSType84.matchesUint32Context();
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(inputId72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(jSType84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str14 = googleCodingConvention13.getExportPropertyFunction();
        java.lang.String str15 = googleCodingConvention13.getAbstractMethodName();
        boolean boolean17 = googleCodingConvention13.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        boolean boolean37 = googleCodingConvention13.isOptionalParameter(node31);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        java.lang.String str54 = node42.checkTreeEquals(node52);
        boolean boolean55 = node52.isAssign();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(30, node4, node31, node52);
        boolean boolean57 = node52.isContinue();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        boolean boolean59 = node26.isEquivalentTo(node42);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        boolean boolean65 = node63.isCall();
        com.google.javascript.rhino.Node node66 = node63.cloneTree();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.and(node26, node66);
        node67.removeProp(19);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        boolean boolean23 = node7.isNull();
        boolean boolean24 = node7.isRegExp();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.rhino.Node node0 = null;
        try {
            boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isLValue(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable11 = jSTypeRegistry9.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.InputId inputId36 = node26.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope38 = null;
        com.google.javascript.rhino.jstype.JSType jSType39 = jSTypeRegistry9.createFromTypeNodes(node26, "", jSTypeStaticScope38);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry7.createConstructorType(jSType39, true, jSTypeArray41);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList43 = functionType42.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable49 = jSTypeRegistry47.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap59 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node53, node58);
        boolean boolean60 = node58.isCast();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType65 = node64.getJSType();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap70 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node64, node69);
        boolean boolean71 = node64.isWith();
        node64.setQuotedString();
        com.google.javascript.rhino.Node node73 = node58.useSourceInfoIfMissingFrom(node64);
        com.google.javascript.rhino.InputId inputId74 = node64.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope76 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry47.createFromTypeNodes(node64, "", jSTypeStaticScope76);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry45.createConstructorType(jSType77, true, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = functionType80.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType42.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType81);
        functionType42.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType85 = functionType42.findPropertyType("goog.exportSymbol");
        jSTypeRegistry1.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType42);
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(objectTypeIterable11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(inputId36);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertNull(jSTypeList43);
        org.junit.Assert.assertNotNull(objectTypeIterable49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeMap59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNull(jSType65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(nodeMap70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(inputId74);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNull(jSType85);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        com.google.javascript.jscomp.Region region3 = sourceFile1.getRegion(304);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode6 = null;
        com.google.javascript.jscomp.parsing.Config config8 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode6, true);
        com.google.javascript.rhino.head.ErrorReporter errorReporter9 = null;
        java.util.logging.Logger logger10 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult11 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile1, "hi!", config8, errorReporter9, logger10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(region3);
        org.junit.Assert.assertNotNull(config8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray4 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5, templateTypeArray4);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList9 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList10 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap11 = jSTypeRegistry1.createTemplateTypeMap(templateTypeList9, jSTypeList10);
        boolean boolean12 = templateTypeMap11.isEmpty();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList13 = templateTypeMap11.getTemplateKeys();
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable17 = jSTypeRegistry15.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node19 = jSTypeRegistry15.createParameters(jSTypeArray18);
        jSTypeRegistry15.clearTemplateTypeNames();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable22 = jSTypeRegistry15.getTypesWithProperty("");
        com.google.javascript.rhino.jstype.TemplateType templateType24 = jSTypeRegistry15.createTemplateType("");
        boolean boolean25 = templateTypeMap11.hasTemplateType(templateType24);
        boolean boolean26 = templateType24.isNoType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(templateTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(templateTypeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(templateTypeList13);
        org.junit.Assert.assertNotNull(objectTypeIterable17);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(jSTypeIterable22);
        org.junit.Assert.assertNotNull(templateType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        java.lang.String str39 = node27.checkTreeEquals(node37);
        com.google.javascript.jscomp.SourceFile sourceFile41 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node37.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile41);
        java.lang.String str43 = sourceFile41.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceFile41);
        com.google.javascript.jscomp.CompilerInput compilerInput46 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput44, true);
        compilerInput46.clearAst();
        jSModule1.add(compilerInput46);
        com.google.javascript.jscomp.SourceFile sourceFile52 = com.google.javascript.jscomp.SourceFile.fromCode("DiagnosticGroup<missingRequire>(WARNING)", "", "");
        jSModule1.add(sourceFile52);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(sourceFile41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceFile52);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str32 = compiler28.toSource(jSModule31);
        jSModule1.addDependency(jSModule31);
        jSModule31.removeAll();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        java.lang.String str10 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        node15.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot18 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult19 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node15, astRoot18);
        com.google.javascript.rhino.JSDocInfo jSDocInfo20 = null;
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNodeDeclaration((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "Unknown class name", node15, jSDocInfo20);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("INSTANCEOF", charset1);
        int int4 = sourceFile2.getLineOfOffset(32);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node21.isCast();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        boolean boolean34 = node27.isWith();
        node27.setQuotedString();
        com.google.javascript.rhino.Node node36 = node21.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.InputId inputId37 = node27.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry10.createFromTypeNodes(node27, "", jSTypeStaticScope39);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry8.createConstructorType(jSType40, true, jSTypeArray42);
        java.lang.String str44 = functionType43.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable48 = jSTypeRegistry46.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType53 = node52.getJSType();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap58 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node52, node57);
        boolean boolean59 = node57.isCast();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap69 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node63, node68);
        boolean boolean70 = node63.isWith();
        node63.setQuotedString();
        com.google.javascript.rhino.Node node72 = node57.useSourceInfoIfMissingFrom(node63);
        com.google.javascript.rhino.InputId inputId73 = node63.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope75 = null;
        com.google.javascript.rhino.jstype.JSType jSType76 = jSTypeRegistry46.createFromTypeNodes(node63, "", jSTypeStaticScope75);
        com.google.javascript.rhino.jstype.JSType jSType77 = null;
        boolean boolean78 = jSType76.canCastTo(jSType77);
        java.lang.String str79 = jSType76.getDisplayName();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair80 = functionType43.getTypesUnderInequality(jSType76);
        boolean boolean82 = jSTypeRegistry1.canPropertyBeDefined((com.google.javascript.rhino.jstype.JSType) functionType43, "STRING hi! 0 [quoted: 1]: Not declared as a type name");
        com.google.javascript.rhino.jstype.JSType jSType84 = functionType43.getPropertyType("goog.exportProperty");
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(inputId37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(objectTypeIterable48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(nodeMap58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeMap69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNull(inputId73);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertNotNull(typePair80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(jSType84);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(2);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesGlobalState();
        int int3 = sideEffectFlags1.valueOf();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags4 = sideEffectFlags1.setThrows();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags5 = sideEffectFlags4.setMutatesGlobalState();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = sideEffectFlags4.setReturnsTainted();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags7 = sideEffectFlags6.setMutatesGlobalState();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags8 = sideEffectFlags6.setMutatesThis();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(sideEffectFlags4);
        org.junit.Assert.assertNotNull(sideEffectFlags5);
        org.junit.Assert.assertNotNull(sideEffectFlags6);
        org.junit.Assert.assertNotNull(sideEffectFlags7);
        org.junit.Assert.assertNotNull(sideEffectFlags8);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        boolean boolean31 = compiler28.isTypeCheckingEnabled();
        boolean boolean32 = compiler28.isTypeCheckingEnabled();
        com.google.javascript.jscomp.ErrorManager errorManager33 = compiler28.getErrorManager();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(errorManager33);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder46 = node45.getJsDocBuilderForNode();
        int int47 = node45.getCharno();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isNoType();
        com.google.javascript.rhino.jstype.JSType jSType40 = functionType36.getPropertyType("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        boolean boolean41 = functionType36.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType43 = functionType36.findPropertyType("STRING hi! 0 [quoted: 1]: Not declared as a type name");
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet44 = functionType36.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet44 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet44.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        compiler28.reportCodeChange();
        com.google.javascript.rhino.Node node32 = compiler28.getRoot();
        com.google.javascript.jscomp.JSError[] jSErrorArray33 = compiler28.getMessages();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(jSErrorArray33);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        java.lang.String str20 = sourceFile17.getOriginalPath();
        sourceFile17.clearCachedSource();
        java.lang.String str22 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceFile17, true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode27 = null;
        com.google.javascript.jscomp.parsing.Config config29 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode27, true);
        com.google.javascript.rhino.head.ErrorReporter errorReporter30 = null;
        java.util.logging.Logger logger31 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult32 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17, "STRING hi! 0", config29, errorReporter30, logger31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(config29);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("2019/06/10 12:15");
        com.google.javascript.jscomp.JsAst jsAst2 = new com.google.javascript.jscomp.JsAst(sourceFile1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        compiler28.reportCodeChange();
        com.google.javascript.rhino.Node node32 = compiler28.getRoot();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = compiler28.getTypeRegistry();
        com.google.javascript.rhino.head.ast.AstRoot astRoot35 = null;
        compiler28.setOldParseTree("INSTANCEOF", astRoot35);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(node32);
        org.junit.Assert.assertNotNull(jSTypeRegistry33);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        jSTypeRegistry1.clearTemplateTypeNames();
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable8 = jSTypeRegistry1.getTypesWithProperty("");
        com.google.javascript.rhino.jstype.TemplateType templateType10 = jSTypeRegistry1.createTemplateType("");
        boolean boolean11 = templateType10.matchesStringContext();
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = null;
        templateType10.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", jSDocInfo13);
        com.google.javascript.rhino.jstype.TemplateType templateType15 = templateType10.toMaybeTemplateType();
        com.google.javascript.rhino.jstype.EnumType enumType16 = templateType10.toMaybeEnumType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(jSTypeIterable8);
        org.junit.Assert.assertNotNull(templateType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(templateType15);
        org.junit.Assert.assertNull(enumType16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        boolean boolean12 = node10.isCall();
        boolean boolean13 = node10.isNE();
        int int14 = node10.getLength();
        boolean boolean15 = node10.isWith();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node26.isCast();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node41 = node26.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        boolean boolean47 = node45.isCall();
        boolean boolean48 = node45.isNE();
        int int49 = node45.getLength();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node32, node45 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(101, nodeArray50, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel55 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray63 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray63);
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node53, checkLevel55, diagnosticType58, strArray63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.pos(node53);
        boolean boolean67 = node10.isEquivalentTo(node53);
        java.lang.String str68 = closureCodingConvention0.getSingletonGetterClassName(node53);
        java.util.Collection<java.lang.String> strCollection69 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(strCollection69);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("STRING hi! 0 [quoted: 1]: Not declared as a type name", "Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = jSTypeRegistry1.getErrorReporter();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = jSTypeRegistry11.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node22.isCast();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node37 = node22.useSourceInfoIfMissingFrom(node28);
        com.google.javascript.rhino.InputId inputId38 = node28.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope40 = null;
        com.google.javascript.rhino.jstype.JSType jSType41 = jSTypeRegistry11.createFromTypeNodes(node28, "", jSTypeStaticScope40);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry9.createConstructorType(jSType41, true, jSTypeArray43);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = functionType44.getTemplateTypes();
        com.google.javascript.rhino.JSDocInfo jSDocInfo47 = null;
        functionType44.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", jSDocInfo47);
        com.google.javascript.rhino.jstype.ObjectType objectType50 = functionType44.getTopMostDefiningType("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable56 = jSTypeRegistry54.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        boolean boolean67 = node65.isCast();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap77 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node71, node76);
        boolean boolean78 = node71.isWith();
        node71.setQuotedString();
        com.google.javascript.rhino.Node node80 = node65.useSourceInfoIfMissingFrom(node71);
        com.google.javascript.rhino.InputId inputId81 = node71.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope83 = null;
        com.google.javascript.rhino.jstype.JSType jSType84 = jSTypeRegistry54.createFromTypeNodes(node71, "", jSTypeStaticScope83);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry52.createConstructorType(jSType84, true, jSTypeArray86);
        com.google.javascript.rhino.jstype.FunctionType functionType88 = functionType87.toMaybeFunctionType();
        boolean boolean89 = functionType88.isUnknownType();
        boolean boolean91 = functionType88.removeProperty("WARNING - Not declared as a type name\n");
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createFunctionTypeWithNewThisType(functionType44, (com.google.javascript.rhino.jstype.ObjectType) functionType88);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable93 = functionType44.getImplementedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(errorReporter6);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(inputId38);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNull(jSTypeList45);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(objectTypeIterable56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(nodeMap77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNull(inputId81);
        org.junit.Assert.assertNotNull(jSType84);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertNotNull(objectTypeIterable93);
    }
}

