import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.jscomp.WarningsGuard warningsGuard0 = null;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray1 = new com.google.javascript.jscomp.WarningsGuard[] { warningsGuard0 };
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard2 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.exprResult(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Token.LT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Token.COLON;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 310 + "'", int0 == 310);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy1 = null;
        try {
            com.google.javascript.jscomp.CheckEventfulObjectDisposal checkEventfulObjectDisposal2 = new com.google.javascript.jscomp.CheckEventfulObjectDisposal(abstractCompiler0, disposalCheckingPolicy1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_VARS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        java.lang.Appendable appendable16 = null;
        try {
            node13.appendStringTree(appendable16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Token.AND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 101 + "'", int0 == 101);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray0 = new com.google.javascript.jscomp.DiagnosticType[] {};
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray0);
        org.junit.Assert.assertNotNull(diagnosticTypeArray0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Token.WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 119 + "'", int0 == 119);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = com.google.javascript.rhino.Token.ANNOTATION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 300 + "'", int0 == 300);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap25 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node19, node24);
        boolean boolean26 = node24.isUnscopedQualifiedName();
        try {
            com.google.javascript.rhino.Node node27 = node13.removeChildAfter(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeMap25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Token.REGEXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Token.NOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_RETURN;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = com.google.javascript.rhino.Node.INFERRED_FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean4 = node3.mayMutateArguments();
        com.google.javascript.rhino.Node node5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.sheq(node3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = com.google.javascript.rhino.Token.EMPTY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 124 + "'", int0 == 124);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node9.isWith();
        boolean boolean17 = node9.isOnlyModifiesThisCall();
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '4', node1, node5, node9, 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("");
        java.lang.String str2 = inputId1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "InputId: " + "'", str2.equals("InputId: "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Token.VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 118 + "'", int0 == 118);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Token.HOOK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 98 + "'", int0 == 98);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        boolean boolean6 = node3.isCatch();
        boolean boolean7 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = node3.removeChildAfter(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = com.google.javascript.rhino.Token.WHILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 113 + "'", int0 == 113);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.propdef(node3, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Token.IN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node4, callback12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.Token.BREAK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 116 + "'", int0 == 116);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.SourceMap.LocationMapping locationMapping2 = new com.google.javascript.jscomp.SourceMap.LocationMapping("Not declared as a type name", "Not declared as a type name");
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V3;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile6 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node15.isUnscopedQualifiedName();
        try {
            astValidator1.process(node5, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(staticSourceFile6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.doNode(node13, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        java.lang.String str16 = node4.checkTreeEquals(node14);
        boolean boolean17 = node14.isAssign();
        java.lang.String str18 = node14.getString();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast19 = closureCodingConvention0.getObjectLiteralCast(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Token.SHNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        boolean boolean2 = node1.isOnlyModifiesArgumentsCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Token.NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Token.QMARK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 304 + "'", int0 == 304);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 87 + "'", int0 == 87);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        try {
            double double4 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! 0 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.trueNode();
        node2.setLength(100);
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] { node1, node2 };
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script(nodeArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(nodeArray5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        java.lang.String[] strArray3 = new java.lang.String[] { "goog.abstractMethod" };
//        java.util.ArrayList<java.lang.String> strList4 = new java.util.ArrayList<java.lang.String>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList4, strArray3);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray6);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray9 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList10 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList10, compilerInputArray9);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList12 = jSModuleGraph7.manageDependencies(dependencyOptions8, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList10);
//        try {
//            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList13 = jSModuleGraph1.manageDependencies((java.util.List<java.lang.String>) strList4, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList10);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException; message: goog.abstractMethod");
//        } catch (com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(strArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray6);
//        org.junit.Assert.assertNotNull(compilerInputArray9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(compilerInputList12);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DISPOSE_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node11.isWith();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(10, node5, node11, 0, 0);
        try {
            com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(55, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        java.lang.String str22 = node10.checkTreeEquals(node20);
        boolean boolean23 = node20.isAssign();
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.tryCatchFinally(node3, node6, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_ADD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 93 + "'", int0 == 93);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VIOLATED_MODULE_DEP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.exprResult(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.assign(node0, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Token.GET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 147 + "'", int0 == 147);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Token.SETTER_DEF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 148 + "'", int0 == 148);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node25 = node10.useSourceInfoIfMissingFrom(node16);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        boolean boolean31 = node29.isCall();
        boolean boolean32 = node29.isNE();
        int int33 = node29.getLength();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node16, node29 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(101, nodeArray34, 300, (int) (byte) 1);
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.switchNode(node0, nodeArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeArray34);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean4 = node3.mayMutateArguments();
        boolean boolean5 = node3.isName();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        node9.setQuotedString();
        boolean boolean12 = node9.isCatch();
        java.lang.String str16 = node9.toString(true, true, true);
        boolean boolean17 = node9.isGetProp();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node21.isWith();
        node21.setQuotedString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap39 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node33, node38);
        boolean boolean40 = node38.isCast();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        boolean boolean51 = node44.isWith();
        node44.setQuotedString();
        com.google.javascript.rhino.Node node53 = node38.useSourceInfoIfMissingFrom(node44);
        com.google.javascript.rhino.Node node54 = node21.copyInformationFromForTree(node44);
        try {
            com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.forIn(node3, node9, node54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "STRING hi! 0 [quoted: 1]" + "'", str16.equals("STRING hi! 0 [quoted: 1]"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeMap39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node5.isWith();
        boolean boolean13 = node5.isOnlyModifiesThisCall();
        java.lang.String[] strArray18 = new java.lang.String[] { "goog.exportProperty", "hi!", "InputId: ", "goog.abstractMethod" };
        java.util.LinkedHashSet<java.lang.String> strSet19 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet19, strArray18);
        node5.setDirectives((java.util.Set<java.lang.String>) strSet19);
        try {
            astValidator1.validateCodeRoot(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = com.google.javascript.rhino.Token.INC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 102 + "'", int0 == 102);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.pos(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = com.google.javascript.rhino.Token.STRING_KEY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 154 + "'", int0 == 154);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES3;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.Token.EOC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 303 + "'", int0 == 303);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node[] nodeArray38 = null;
        try {
            com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.newNode(node26, nodeArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITXOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 88 + "'", int0 == 88);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Token.TYPEOF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node10 = null;
        try {
            com.google.javascript.rhino.Node node11 = node3.copyInformationFromForTree(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags19 = null;
        try {
            node13.setSideEffectFlags(sideEffectFlags19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Token.DO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 114 + "'", int0 == 114);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        boolean boolean7 = node4.isCatch();
        java.lang.String str11 = node4.toString(true, true, true);
        boolean boolean12 = node4.isGetProp();
        com.google.javascript.rhino.Node node13 = null;
        try {
            com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(38, node4, node13, 114, 304);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "STRING hi! 0 [quoted: 1]" + "'", str11.equals("STRING hi! 0 [quoted: 1]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.io.Reader reader2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromReader("goog.exportProperty", reader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        boolean boolean12 = node4.isOnlyModifiesThisCall();
        try {
            boolean boolean13 = googleCodingConvention0.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = com.google.javascript.rhino.Token.ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = com.google.javascript.rhino.Token.BITAND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = com.google.javascript.rhino.Token.VOID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 122 + "'", int0 == 122);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Token.FOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 115 + "'", int0 == 115);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        boolean boolean2 = node1.isFunction();
        node1.setChangeTime(154);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int0 = com.google.javascript.rhino.Token.SET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 148 + "'", int0 == 148);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V2;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder59 = node42.new FileLevelJsDocBuilder();
        try {
            com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.eq(node26, node42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        node18.setSourceEncodedPositionForTree(26);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        try {
            int int3 = sourceFile1.getLineOffset(93);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 93");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.Token.CONTINUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 117 + "'", int0 == 117);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        com.google.javascript.jscomp.JSModule jSModule0 = null;
//        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
//        try {
//            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray1);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        boolean boolean11 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.string("hi!");
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.catchNode(node3, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        try {
            boolean boolean37 = com.google.javascript.jscomp.NodeUtil.isLValue(node36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        int int0 = com.google.javascript.rhino.Token.COMMA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 85 + "'", int0 == 85);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        int int0 = com.google.javascript.rhino.Token.CATCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node4.new FileLevelJsDocBuilder();
        boolean boolean22 = node4.isLocalResultCall();
        node4.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TOP_LEVEL_PROTOTYPE));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean9 = node8.isEmpty();
        com.google.javascript.rhino.Node[] nodeArray10 = new com.google.javascript.rhino.Node[] { node3, node8 };
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.paramList(nodeArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(staticSourceFile4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(nodeArray10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType32 = node31.getJSType();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap37 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node31, node36);
        java.lang.String str38 = node26.checkTreeEquals(node36);
        com.google.javascript.jscomp.SourceFile sourceFile40 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node36.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile40);
        java.lang.String str42 = sourceFile40.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(sourceFile40);
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = null;
        try {
            com.google.javascript.jscomp.Result result45 = compiler0.compile(sourceFile19, sourceFile40, compilerOptions44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSType32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeMap37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(sourceFile40);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node4.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap31 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node25, node30);
        boolean boolean32 = node25.isWith();
        node25.setQuotedString();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap43 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node37, node42);
        boolean boolean44 = node42.isCast();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        node48.setQuotedString();
        com.google.javascript.rhino.Node node57 = node42.useSourceInfoIfMissingFrom(node48);
        com.google.javascript.rhino.Node node58 = node25.copyInformationFromForTree(node48);
        try {
            com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.or(node4, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeMap31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeMap43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        node20.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Token.OR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_STRUCT_DICT_INHERITANCE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = com.google.javascript.rhino.Token.PIPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 301 + "'", int0 == 301);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DISPOSE_SELF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        sourceFile17.clearCachedSource();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        try {
            node13.setDouble(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: STRING hi! 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder4 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node6 = null;
        try {
            compiler0.toSource(codeBuilder4, 26, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = compiler4.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention4 = compiler0.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        try {
            com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.voidNode(node55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        boolean boolean16 = node13.isAssign();
        boolean boolean17 = node13.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("Not declared as a type name");
        boolean boolean2 = node1.isCase();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = com.google.javascript.rhino.Token.LABEL_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 153 + "'", int0 == 153);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap34 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node33);
        boolean boolean35 = node28.isWith();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        boolean boolean47 = node45.isCast();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node51.isWith();
        node51.setQuotedString();
        com.google.javascript.rhino.Node node60 = node45.useSourceInfoIfMissingFrom(node51);
        com.google.javascript.rhino.Node node61 = node28.copyInformationFromForTree(node51);
        boolean boolean62 = node51.isParamList();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType68 = node67.getJSType();
        node67.setQuotedString();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap79 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node73, node78);
        boolean boolean80 = node73.isWith();
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node(10, node67, node73, 0, 0);
        boolean boolean84 = node51.isEquivalentTo(node67);
        try {
            boolean boolean85 = googleCodingConvention0.isInlinableFunction(node51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeMap34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(jSType68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(nodeMap79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Token.FALSE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean4 = node3.mayMutateArguments();
        boolean boolean5 = node3.isName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, node10, node16, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node10.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFrom(node10);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        boolean boolean51 = node49.isCast();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap61 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node55, node60);
        boolean boolean62 = node55.isWith();
        node55.setQuotedString();
        com.google.javascript.rhino.Node node64 = node49.useSourceInfoIfMissingFrom(node55);
        com.google.javascript.rhino.Node node65 = node32.copyInformationFromForTree(node55);
        boolean boolean66 = node55.isParamList();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        node71.setQuotedString();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType78 = node77.getJSType();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap83 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node77, node82);
        boolean boolean84 = node77.isWith();
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(10, node71, node77, 0, 0);
        boolean boolean88 = node55.isEquivalentTo(node71);
        boolean boolean89 = node71.isFromExterns();
        boolean boolean90 = node71.isGetProp();
        try {
            com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.IR.ifNode(node28, node71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeMap61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(jSType78);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(nodeMap83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int0 = com.google.javascript.rhino.Node.REFLECTED_OBJECT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        boolean boolean6 = node3.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot7);
        node3.setCharno((int) (byte) 100);
        try {
            com.google.javascript.rhino.Node node11 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Token.MUL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str3 = googleCodingConvention2.getExportPropertyFunction();
        java.lang.String str4 = googleCodingConvention2.getAbstractMethodName();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean9 = node8.mayMutateArguments();
        boolean boolean10 = node8.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind12 = googleCodingConvention2.describeFunctionBind(node8, true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter14 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention2, jSTypeRegistry13);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
        try {
            com.google.javascript.jscomp.TypeCheck typeCheck17 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.type.ReverseAbstractInterpreter) semanticReverseAbstractInterpreter14, jSTypeRegistry15, checkLevel16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.abstractMethod" + "'", str4.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(bind12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("goog.exportSymbol", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = com.google.javascript.rhino.Token.CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        java.lang.String str6 = node3.toString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "STRING hi! 0" + "'", str6.equals("STRING hi! 0"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        java.lang.String str23 = node11.checkTreeEquals(node21);
        com.google.javascript.jscomp.SourceFile sourceFile25 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node21.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile25);
        node21.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention29 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str30 = googleCodingConvention29.getExportPropertyFunction();
        java.lang.String str31 = googleCodingConvention29.getAbstractMethodName();
        boolean boolean33 = googleCodingConvention29.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap48 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node42, node47);
        java.lang.String str49 = node37.checkTreeEquals(node47);
        com.google.javascript.jscomp.SourceFile sourceFile51 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node47.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile51);
        boolean boolean53 = googleCodingConvention29.isOptionalParameter(node47);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile58 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node57);
        boolean boolean59 = googleCodingConvention29.isPrototypeAlias(node57);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        boolean boolean65 = node63.isCall();
        com.google.javascript.rhino.Node node66 = node63.cloneTree();
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(98, node6, node21, node57, node63);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        boolean boolean73 = node71.isCall();
        boolean boolean74 = node71.isNE();
        boolean boolean75 = node71.isEmpty();
        try {
            com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((-2), node1, node6, node71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(sourceFile25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportProperty" + "'", str30.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "goog.abstractMethod" + "'", str31.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeMap48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(sourceFile51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(staticSourceFile58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec5 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean10 = node9.wasEmptyNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        boolean boolean41 = node39.isCall();
        boolean boolean42 = node39.isNE();
        int int43 = node39.getLength();
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node26, node39 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(101, nodeArray44, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node48 = node9.useSourceInfoFrom(node47);
        com.google.javascript.rhino.Node node49 = assertInstanceofSpec5.getAssertedParam(node47);
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = null;
        java.lang.String[] strArray54 = new java.lang.String[] { "Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "STRING hi! 0 [quoted: 1]", "hi!" };
        try {
            com.google.javascript.jscomp.JSError jSError55 = nodeTraversal3.makeError(node47, diagnosticType50, strArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(strArray54);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        boolean boolean26 = googleCodingConvention0.isPrivate("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int0 = com.google.javascript.rhino.Node.CHANGE_TIME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        node15.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot18 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult19 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node15, astRoot18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.throwNode(node15);
        try {
            node8.removeChild(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        try {
            com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.defaultCase(node36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = com.google.javascript.rhino.Token.RSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean5 = googleCodingConvention0.isExported("hi!", false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        boolean boolean11 = node9.isCall();
        boolean boolean12 = node9.isNE();
        int int13 = node9.getLength();
        boolean boolean14 = node9.isWith();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast15 = googleCodingConvention0.getObjectLiteralCast(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = null;
        try {
            compiler4.setState(intermediateState5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node7 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship8 = closureCodingConvention0.getClassesDefinedByCall(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        int int67 = node65.getIntProp(102);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.rhino.Node[] nodeArray3 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2, nodeArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("STRING hi! 0");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.io.File file1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile(file1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec2 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean7 = node6.wasEmptyNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap18 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node12, node17);
        boolean boolean19 = node17.isCast();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node23, node28);
        boolean boolean30 = node23.isWith();
        node23.setQuotedString();
        com.google.javascript.rhino.Node node32 = node17.useSourceInfoIfMissingFrom(node23);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        boolean boolean38 = node36.isCall();
        boolean boolean39 = node36.isNE();
        int int40 = node36.getLength();
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node23, node36 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(101, nodeArray41, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node45 = node6.useSourceInfoFrom(node44);
        com.google.javascript.rhino.Node node46 = assertInstanceofSpec2.getAssertedParam(node44);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder47 = node46.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node48 = null;
        try {
            com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(310, node46, node48, 113, 116);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeMap18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder47);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.CompilerOptions.Reach reach0 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        org.junit.Assert.assertTrue("'" + reach0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach0.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        java.lang.String str11 = googleCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.exportSymbol" + "'", str11.equals("goog.exportSymbol"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        java.lang.String[] strArray5 = new java.lang.String[] { "Not declared as a type name", "", "Not declared as a type name" };
//        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
//        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray8);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions10 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray11 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList12 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList12, compilerInputArray11);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList14 = jSModuleGraph9.manageDependencies(dependencyOptions10, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList12);
//        try {
//            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList15 = jSModuleGraph1.manageDependencies((java.util.List<java.lang.String>) strList6, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList12);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException; message: ");
//        } catch (com.google.javascript.jscomp.deps.SortedDependencies.MissingProvideException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(strArray5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray8);
//        org.junit.Assert.assertNotNull(compilerInputArray11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(compilerInputList14);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(46, node4, 0, 0);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        java.lang.String str24 = node12.checkTreeEquals(node22);
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node22.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        node22.setType(47);
        boolean boolean30 = node22.isBlock();
        try {
            com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.getprop(node8, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = com.google.javascript.rhino.Token.URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.String str1 = com.google.javascript.rhino.Token.name((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "INSTANCEOF" + "'", str1.equals("INSTANCEOF"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        node13.setIsSyntheticBlock(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec22 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean27 = node26.wasEmptyNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node37.isCast();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType44 = node43.getJSType();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap49 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node43, node48);
        boolean boolean50 = node43.isWith();
        node43.setQuotedString();
        com.google.javascript.rhino.Node node52 = node37.useSourceInfoIfMissingFrom(node43);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType57 = node56.getJSType();
        boolean boolean58 = node56.isCall();
        boolean boolean59 = node56.isNE();
        int int60 = node56.getLength();
        com.google.javascript.rhino.Node[] nodeArray61 = new com.google.javascript.rhino.Node[] { node43, node56 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(101, nodeArray61, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node65 = node26.useSourceInfoFrom(node64);
        com.google.javascript.rhino.Node node66 = assertInstanceofSpec22.getAssertedParam(node64);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder67 = node66.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.IR.add(node13, node66);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(jSType44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeMap49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(nodeArray61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder67);
        org.junit.Assert.assertNotNull(node68);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int0 = com.google.javascript.rhino.Token.LE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = googleCodingConvention0.isValidEnumKey("");
        java.util.Collection<java.lang.String> strCollection4 = googleCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray7 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, objectTypeArray7);
        java.util.Map<java.lang.String, java.lang.String> strMap10 = null;
        googleCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry5, jSTypeStaticScope6, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, strMap10);
        boolean boolean13 = googleCodingConvention0.isValidEnumKey("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strCollection4);
        org.junit.Assert.assertNotNull(objectTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        java.io.InputStream inputStream5 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile6 = builder0.buildFromInputStream("goog.exportProperty", inputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        try {
            int int5 = sourceFile3.getLineOffset(301);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 301");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node25 = node10.useSourceInfoIfMissingFrom(node16);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        boolean boolean31 = node29.isCall();
        boolean boolean32 = node29.isNE();
        int int33 = node29.getLength();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node16, node29 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(101, nodeArray34, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel39 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make(diagnosticType45, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node37, checkLevel39, diagnosticType42, strArray47);
        boolean boolean50 = node37.isLocalResultCall();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        boolean boolean15 = node13.isCast();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType20 = node19.getJSType();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap25 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node19, node24);
        boolean boolean26 = node19.isWith();
        node19.setQuotedString();
        com.google.javascript.rhino.Node node28 = node13.useSourceInfoIfMissingFrom(node19);
        boolean boolean29 = node19.isAssignAdd();
        boolean boolean30 = node19.isVoid();
        try {
            com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.assign(node3, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(staticSourceFile4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeMap25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("hi!");
        boolean boolean2 = node1.isOptionalArg();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str14 = googleCodingConvention13.getExportPropertyFunction();
        java.lang.String str15 = googleCodingConvention13.getAbstractMethodName();
        boolean boolean17 = googleCodingConvention13.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        boolean boolean37 = googleCodingConvention13.isOptionalParameter(node31);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        java.lang.String str54 = node42.checkTreeEquals(node52);
        boolean boolean55 = node52.isAssign();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(30, node4, node31, node52);
        node4.setSourceEncodedPosition((-1));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo66 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int0 = com.google.javascript.rhino.Token.ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = com.google.javascript.rhino.Token.GE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        try {
            java.io.Reader reader20 = sourceFile17.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue1 = com.google.javascript.jscomp.NodeUtil.isStrWhiteSpaceChar(88);
        org.junit.Assert.assertNotNull(ternaryValue1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseVersion();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "D4J_Closure_115_FIXED_VERSION" + "'", str0.equals("D4J_Closure_115_FIXED_VERSION"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.RenamingMap renamingMap0 = com.google.javascript.jscomp.CompilerOptions.UNIQUE_ID_GENERATOR;
        org.junit.Assert.assertNotNull(renamingMap0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = null;
        try {
            compiler0.initOptions(compilerOptions2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            java.lang.String str1 = com.google.javascript.rhino.SimpleErrorReporter.getMessage0("D4J_Closure_115_FIXED_VERSION");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property D4J_Closure_115_FIXED_VERSION");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.NodeTraversal.FunctionCallback functionCallback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseChangedFunctions((com.google.javascript.jscomp.AbstractCompiler) compiler0, functionCallback2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isExported("goog.exportProperty");
        java.util.Collection<java.lang.String> strCollection3 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        boolean boolean28 = node18.isAssignAdd();
        boolean boolean30 = node18.getBooleanProp((int) (byte) 1);
        com.google.javascript.rhino.Node node31 = null;
        try {
            java.lang.String str32 = closureCodingConvention0.extractClassNameIfProvide(node18, node31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strCollection3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = com.google.javascript.rhino.Node.SLASH_V;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.throwNode(node3);
        boolean boolean9 = node3.isQuotedString();
        boolean boolean10 = node3.isInstanceOf();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(2);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesGlobalState();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = sideEffectFlags1.setMutatesThis();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertNotNull(sideEffectFlags3);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean4 = node3.mayMutateArguments();
        boolean boolean5 = node3.isName();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(10, node10, node16, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node10.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node28 = node3.copyInformationFrom(node10);
        boolean boolean29 = node10.isContinue();
        boolean boolean30 = node10.isFalse();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        node34.setQuotedString();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap52 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node46, node51);
        boolean boolean53 = node51.isCast();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap63 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node57, node62);
        boolean boolean64 = node57.isWith();
        node57.setQuotedString();
        com.google.javascript.rhino.Node node66 = node51.useSourceInfoIfMissingFrom(node57);
        com.google.javascript.rhino.Node node67 = node34.copyInformationFromForTree(node57);
        boolean boolean68 = node57.isParamList();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
        node73.setQuotedString();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType80 = node79.getJSType();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap85 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node79, node84);
        boolean boolean86 = node79.isWith();
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node(10, node73, node79, 0, 0);
        boolean boolean90 = node57.isEquivalentTo(node73);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType95 = node94.getJSType();
        node94.setQuotedString();
        boolean boolean97 = node94.isCatch();
        boolean boolean98 = node94.isOnlyModifiesThisCall();
        try {
            node10.replaceChildAfter(node57, node94);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeMap52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeMap63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(nodeMap85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNull(jSType95);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = com.google.javascript.rhino.Token.PARAM_LIST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 83 + "'", int0 == 83);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        java.lang.String str20 = node8.checkTreeEquals(node18);
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node18.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile22);
        boolean boolean24 = googleCodingConvention0.isOptionalParameter(node18);
        try {
            com.google.javascript.rhino.Node node25 = node18.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        com.google.javascript.rhino.Node node4 = node3.getLastChild();
        try {
            java.lang.String str5 = node4.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray2 = compiler1.getErrors();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.string("hi!");
        java.lang.String str9 = node8.toStringTree();
        boolean boolean10 = node8.isThrow();
        try {
            boolean boolean11 = closureCodingConvention0.isPropertyTestFunction(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi!\n" + "'", str9.equals("STRING hi!\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy1 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        try {
            java.lang.String str2 = com.google.javascript.rhino.SimpleErrorReporter.getMessage1("", (java.lang.Object) propertyRenamingPolicy1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy1 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy1.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        try {
            java.lang.String str66 = node65.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: HOOK is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.returnNode(node3);
        boolean boolean11 = node10.isCatch();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = null;
//        try {
//            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(46, node4, 0, 0);
        boolean boolean9 = node8.isSetterDef();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int7 = diagnosticType2.compareTo(diagnosticType6);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        boolean boolean39 = node37.isCall();
        boolean boolean40 = node37.isNE();
        int int41 = node37.getLength();
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node24, node37 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(101, nodeArray42, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel47 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray55 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make(diagnosticType53, strArray55);
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node45, checkLevel47, diagnosticType50, strArray55);
        int int58 = diagnosticType2.compareTo(diagnosticType50);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str3.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-20) + "'", int7 == (-20));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + checkLevel47 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel47.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-20) + "'", int58 == (-20));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isExported("goog.exportProperty");
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType5 = null;
        closureCodingConvention0.applySubclassRelationship(functionType3, functionType4, subclassType5);
        java.lang.String str7 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = null;
        try {
            java.lang.String str9 = closureCodingConvention0.getSingletonGetterClassName(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportSymbol" + "'", str7.equals("goog.exportSymbol"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("Not declared as a type name");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("hi!");
        java.lang.String str2 = node1.toStringTree();
        boolean boolean3 = node1.isThrow();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = node1.getStaticSourceFile();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "STRING hi!\n" + "'", str2.equals("STRING hi!\n"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(staticSourceFile4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CodePrinter codePrinter0 = new com.google.javascript.jscomp.CodePrinter();
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        try {
            boolean boolean15 = closureCodingConvention0.isInlinableFunction(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        boolean boolean24 = node8.isDefaultCase();
        node8.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = com.google.javascript.rhino.Token.BITXOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node10.isOptionalArg();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        try {
            com.google.javascript.rhino.Node node4 = nodeTraversal3.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = com.google.javascript.rhino.Token.THIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(2);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesGlobalState();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = sideEffectFlags2.setMutatesGlobalState();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertNotNull(sideEffectFlags3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        int int0 = com.google.javascript.rhino.Token.BANG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 306 + "'", int0 == 306);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int0 = com.google.javascript.rhino.Token.DELPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.string("hi!");
        boolean boolean3 = node2.isGetterDef();
        com.google.javascript.rhino.Node node4 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, node2, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile("DiagnosticGroup<missingRequire>(WARNING)");
        java.io.File file6 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile7 = builder0.buildFromFile(file6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = dependencyOptions2.setDependencySorting(true);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(dependencyOptions8);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("STRING hi!\n");
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.assign(node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType8 = null;
        closureCodingConvention0.applySubclassRelationship(functionType6, functionType7, subclassType8);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection10 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str11 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        java.lang.String str4 = nodeTraversal3.getSourceName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int0 = com.google.javascript.rhino.Token.NULL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, "Not declared as a constructor", false);
        try {
            int int27 = compilerInput20.getLineOffset(19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 19");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot6);
        com.google.javascript.rhino.head.ast.AstRoot astRoot8 = parseResult7.oldAst;
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNull(astRoot8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable12 = node3.children();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(nodeIterable12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        node0.setWasEmptyNode(true);
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        try {
            boolean boolean6 = compiler4.acceptConstKeyword();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        java.lang.String str23 = jSError22.sourceName;
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap1 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer2 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry0, templateTypeMap1);
        try {
            com.google.javascript.rhino.jstype.JSType jSType3 = templateTypeMapReplacer2.caseStringType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap1 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer2 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry0, templateTypeMap1);
        try {
            com.google.javascript.rhino.jstype.JSType jSType3 = templateTypeMapReplacer2.caseNullType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        try {
            java.lang.String str23 = compilerInput20.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        com.google.javascript.jscomp.Region region3 = sourceFile1.getRegion(0);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertNull(region3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        int int0 = com.google.javascript.rhino.Token.SHEQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = com.google.javascript.rhino.Token.BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 125 + "'", int0 == 125);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 10);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.children();
        node1.setSourceFileForTesting("goog.exportProperty");
        org.junit.Assert.assertNotNull(nodeIterable2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        boolean boolean30 = node28.isCall();
        boolean boolean31 = node19.isEquivalentToTyped(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.voidNode(node19);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention0.getClassesDefinedByCall(node32);
        boolean boolean36 = closureCodingConvention0.isExported("goog.exportSymbol", true);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput22, true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = null;
        try {
            com.google.javascript.jscomp.Result result8 = compiler0.compile(jSSourceFileArray5, jSSourceFileArray6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int0 = com.google.javascript.rhino.Token.LABEL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 126 + "'", int0 == 126);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        int int0 = com.google.javascript.rhino.Token.INSTANCEOF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseDate();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "2019/06/10 12:15" + "'", str0.equals("2019/06/10 12:15"));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.CompilerOptions.Reach reach0 = com.google.javascript.jscomp.CompilerOptions.Reach.NONE;
        org.junit.Assert.assertTrue("'" + reach0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.NONE + "'", reach0.equals(com.google.javascript.jscomp.CompilerOptions.Reach.NONE));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 11, 42, 118);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node4.isStringKey();
        node4.setSourceEncodedPosition(85);
        com.google.javascript.rhino.Node node24 = null;
        try {
            java.lang.String str25 = node4.checkTreeEquals(node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        boolean boolean4 = nodeTraversal3.hasScope();
        try {
            com.google.javascript.rhino.Node node5 = nodeTraversal3.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        boolean boolean30 = node28.isCall();
        boolean boolean31 = node19.isEquivalentToTyped(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.voidNode(node19);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention0.getClassesDefinedByCall(node32);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention34 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        node8.setSourceEncodedPosition((int) (short) 1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = compiler0.getOldParseTreeByName("goog.exportProperty");
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        boolean boolean9 = node7.isCall();
        boolean boolean10 = node7.isNE();
        int int11 = node7.getLength();
        boolean boolean12 = node7.isWith();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node23.isCast();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node29, node34);
        boolean boolean36 = node29.isWith();
        node29.setQuotedString();
        com.google.javascript.rhino.Node node38 = node23.useSourceInfoIfMissingFrom(node29);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        boolean boolean44 = node42.isCall();
        boolean boolean45 = node42.isNE();
        int int46 = node42.getLength();
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node29, node42 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(101, nodeArray47, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel52 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType58, strArray60);
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node50, checkLevel52, diagnosticType55, strArray60);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.pos(node50);
        boolean boolean64 = node7.isEquivalentTo(node50);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType69 = node68.getJSType();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap74 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node68, node73);
        boolean boolean75 = node73.isCast();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType80 = node79.getJSType();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap85 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node79, node84);
        boolean boolean86 = node79.isWith();
        node79.setQuotedString();
        com.google.javascript.rhino.Node node88 = node73.useSourceInfoIfMissingFrom(node79);
        boolean boolean89 = node79.isAssignAdd();
        boolean boolean90 = node79.isVoid();
        com.google.javascript.rhino.ErrorReporter errorReporter91 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry92 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter91);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable94 = jSTypeRegistry92.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray95 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node96 = jSTypeRegistry92.createParameters(jSTypeArray95);
        com.google.javascript.rhino.Node[] nodeArray97 = new com.google.javascript.rhino.Node[] { node7, node79, node96 };
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback3, nodeArray97);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(astRoot2);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(nodeArray47);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(jSType69);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(nodeMap74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(nodeMap85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable94);
        org.junit.Assert.assertNotNull(jSTypeArray95);
        org.junit.Assert.assertNotNull(node96);
        org.junit.Assert.assertNotNull(nodeArray97);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int0 = com.google.javascript.rhino.Token.SWITCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        java.lang.String str23 = nodeTraversal3.getSourceName();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        node28.setQuotedString();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(10, node28, node34, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder45 = node28.new FileLevelJsDocBuilder();
        boolean boolean46 = node28.isLocalResultCall();
        int int47 = node28.getLength();
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str51 = diagnosticType50.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int55 = diagnosticType50.compareTo(diagnosticType54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray60 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType58, strArray60);
        nodeTraversal3.report(node28, diagnosticType50, strArray60);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str51.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-20) + "'", int55 == (-20));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(strArray60);
        org.junit.Assert.assertNotNull(jSError61);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("STRING hi! 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        java.lang.Appendable appendable5 = null;
        try {
            node3.appendStringTree(appendable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder1 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int2 = codeBuilder1.getLength();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean9 = node8.isEmpty();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        java.lang.String str25 = node13.checkTreeEquals(node23);
        com.google.javascript.jscomp.SourceFile sourceFile27 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node23.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile27);
        node23.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str32 = googleCodingConvention31.getExportPropertyFunction();
        java.lang.String str33 = googleCodingConvention31.getAbstractMethodName();
        boolean boolean35 = googleCodingConvention31.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType40 = node39.getJSType();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        java.lang.String str51 = node39.checkTreeEquals(node49);
        com.google.javascript.jscomp.SourceFile sourceFile53 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node49.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile53);
        boolean boolean55 = googleCodingConvention31.isOptionalParameter(node49);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile60 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node59);
        boolean boolean61 = googleCodingConvention31.isPrototypeAlias(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType66 = node65.getJSType();
        boolean boolean67 = node65.isCall();
        com.google.javascript.rhino.Node node68 = node65.cloneTree();
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node(98, node8, node23, node59, node65);
        try {
            compiler0.toSource(codeBuilder1, 46, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(sourceFile27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "goog.exportProperty" + "'", str32.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.abstractMethod" + "'", str33.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(jSType40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(sourceFile53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(staticSourceFile60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
//        try {
//            com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
//            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
//        } catch (java.util.NoSuchElementException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(jSModuleArray4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = com.google.javascript.rhino.Token.DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 112 + "'", int0 == 112);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        int int0 = com.google.javascript.rhino.Token.ELLIPSIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 305 + "'", int0 == 305);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        int int66 = node19.getChangeTime();
        try {
            node19.setSideEffectFlags(4095);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got REGEXP");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSError jSError2 = null;
        try {
            compiler1.report(jSError2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = googleCodingConvention0.isValidEnumKey("");
        java.util.Collection<java.lang.String> strCollection4 = googleCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope6 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray7 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList8 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, objectTypeArray7);
        java.util.Map<java.lang.String, java.lang.String> strMap10 = null;
        googleCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry5, jSTypeStaticScope6, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList8, strMap10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        java.lang.String str27 = node15.checkTreeEquals(node25);
        com.google.javascript.jscomp.SourceFile sourceFile29 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node25.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile29);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        boolean boolean36 = node34.isCall();
        boolean boolean37 = node25.isEquivalentToTyped(node34);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.voidNode(node25);
        try {
            boolean boolean39 = googleCodingConvention0.isVarArgsParameter(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: VOID is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strCollection4);
        org.junit.Assert.assertNotNull(objectTypeArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(sourceFile29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder21 = node4.new FileLevelJsDocBuilder();
        int int22 = node4.getChildCount();
        node4.detachChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.jstype.TemplateType templateType4 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType5 = templateTypeMapReplacer3.caseTemplateType(templateType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int0 = com.google.javascript.rhino.Token.EQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (byte) 10);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable2 = node1.children();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node7.isWith();
        node7.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str17 = googleCodingConvention16.getExportPropertyFunction();
        java.lang.String str18 = googleCodingConvention16.getAbstractMethodName();
        boolean boolean20 = googleCodingConvention16.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node29, node34);
        java.lang.String str36 = node24.checkTreeEquals(node34);
        com.google.javascript.jscomp.SourceFile sourceFile38 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node34.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile38);
        boolean boolean40 = googleCodingConvention16.isOptionalParameter(node34);
        java.lang.String str41 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node34);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        java.lang.String str57 = node45.checkTreeEquals(node55);
        boolean boolean58 = node55.isAssign();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(30, node7, node34, node55);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap69 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node63, node68);
        boolean boolean70 = node68.isCast();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType75 = node74.getJSType();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap80 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node74, node79);
        boolean boolean81 = node74.isWith();
        node74.setQuotedString();
        com.google.javascript.rhino.Node node83 = node68.useSourceInfoIfMissingFrom(node74);
        com.google.javascript.rhino.InputId inputId84 = node74.getInputId();
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType89 = node88.getJSType();
        com.google.javascript.rhino.Node node93 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap94 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node88, node93);
        com.google.javascript.rhino.Node node95 = com.google.javascript.rhino.IR.returnNode(node88);
        com.google.javascript.rhino.Node[] nodeArray96 = new com.google.javascript.rhino.Node[] { node1, node59, node74, node88 };
        try {
            com.google.javascript.rhino.Node node97 = com.google.javascript.rhino.IR.arraylit(nodeArray96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(nodeIterable2);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportProperty" + "'", str17.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "goog.abstractMethod" + "'", str18.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertNotNull(sourceFile38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeMap69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(nodeMap80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNull(inputId84);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNull(jSType89);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertNotNull(nodeMap94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNotNull(nodeArray96);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        boolean boolean6 = node3.isNE();
        int int7 = node3.getLength();
        boolean boolean8 = node3.isWith();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node19.isCast();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap31 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node25, node30);
        boolean boolean32 = node25.isWith();
        node25.setQuotedString();
        com.google.javascript.rhino.Node node34 = node19.useSourceInfoIfMissingFrom(node25);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        boolean boolean40 = node38.isCall();
        boolean boolean41 = node38.isNE();
        int int42 = node38.getLength();
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node25, node38 };
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(101, nodeArray43, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel48 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType51 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray56 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make(diagnosticType54, strArray56);
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node46, checkLevel48, diagnosticType51, strArray56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.pos(node46);
        boolean boolean60 = node3.isEquivalentTo(node46);
        int int61 = node46.getChangeTime();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeMap31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType51);
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        try {
            compiler4.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        node3.setCharno(14);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        int int0 = com.google.javascript.rhino.Token.BITOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback11);
        try {
            com.google.javascript.rhino.Node node13 = nodeTraversal12.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        java.lang.String str27 = node15.checkTreeEquals(node25);
        com.google.javascript.jscomp.SourceFile sourceFile29 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node25.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile29);
        node25.setType(47);
        boolean boolean33 = node25.isBlock();
        com.google.javascript.rhino.Node node34 = node4.useSourceInfoFromForTree(node25);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap44 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node38, node43);
        boolean boolean45 = node43.isCast();
        try {
            com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.forIn(node0, node4, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(sourceFile29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeMap44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node5 = jSTypeRegistry1.createParameters(jSTypeArray4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        node10.setQuotedString();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.or(node10, node16);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        try {
            com.google.javascript.rhino.jstype.EnumType enumType20 = jSTypeRegistry1.createEnumType("INSTANCEOF", node18, jSType19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node18);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = dependencyOptions2.setMoocherDropping(true);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(dependencyOptions8);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        compiler0.setOldParseTree("", astRoot2);
        try {
            boolean boolean4 = compiler0.acceptEcmaScript5();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str14 = googleCodingConvention13.getExportPropertyFunction();
        java.lang.String str15 = googleCodingConvention13.getAbstractMethodName();
        boolean boolean17 = googleCodingConvention13.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        boolean boolean37 = googleCodingConvention13.isOptionalParameter(node31);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        java.lang.String str54 = node42.checkTreeEquals(node52);
        boolean boolean55 = node52.isAssign();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(30, node4, node31, node52);
        boolean boolean57 = node31.isCase();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) 10);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        boolean boolean12 = node10.isCall();
        boolean boolean13 = node10.isNE();
        com.google.javascript.rhino.Node node14 = null;
        try {
            com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(30, node2, node6, node10, node14, (int) (short) 1, 304);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        java.lang.String str22 = compilerInput20.getLine(43);
        com.google.javascript.jscomp.Region region24 = compilerInput20.getRegion(4);
        com.google.javascript.jscomp.Region region26 = compilerInput20.getRegion(53);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNull(region24);
        org.junit.Assert.assertNull(region26);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative83 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative84 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray86 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative83, jSTypeNative84, jSTypeNative85 };
        com.google.javascript.rhino.jstype.JSType jSType87 = jSTypeRegistry1.createUnionType(jSTypeNativeArray86);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + jSTypeNative83 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative83.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative84 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative84.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray86);
        org.junit.Assert.assertNotNull(jSType87);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        boolean boolean6 = node3.isCatch();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot7);
        node3.setCharno((int) (byte) 100);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.eq(node3, node14);
        boolean boolean23 = node14.isSetterDef();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        try {
            int int67 = node65.getExistingIntProp((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 35");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        com.google.javascript.rhino.Node node6 = node3.cloneTree();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.throwNode(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        java.lang.String str23 = node11.checkTreeEquals(node21);
        com.google.javascript.jscomp.SourceFile sourceFile25 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node21.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile25);
        boolean boolean27 = node21.mayMutateArguments();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.regexp(node21);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        boolean boolean51 = node49.isCast();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap61 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node55, node60);
        boolean boolean62 = node55.isWith();
        node55.setQuotedString();
        com.google.javascript.rhino.Node node64 = node49.useSourceInfoIfMissingFrom(node55);
        com.google.javascript.rhino.Node node65 = node32.copyInformationFromForTree(node55);
        boolean boolean66 = node55.isParamList();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType72 = node71.getJSType();
        node71.setQuotedString();
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType78 = node77.getJSType();
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap83 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node77, node82);
        boolean boolean84 = node77.isWith();
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node(10, node71, node77, 0, 0);
        boolean boolean88 = node55.isEquivalentTo(node71);
        com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType93 = node92.getJSType();
        boolean boolean94 = node92.isCall();
        com.google.javascript.rhino.Node node95 = node92.cloneTree();
        com.google.javascript.rhino.Node node96 = com.google.javascript.rhino.IR.and(node55, node95);
        try {
            com.google.javascript.rhino.Node node97 = com.google.javascript.rhino.IR.forIn(node6, node21, node96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(sourceFile25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeMap61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(jSType72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(jSType78);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(nodeMap83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNull(jSType93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = null;
        try {
            compiler4.setState(intermediateState7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable42 = jSTypeRegistry40.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap52 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node46, node51);
        boolean boolean53 = node51.isCast();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap63 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node57, node62);
        boolean boolean64 = node57.isWith();
        node57.setQuotedString();
        com.google.javascript.rhino.Node node66 = node51.useSourceInfoIfMissingFrom(node57);
        com.google.javascript.rhino.InputId inputId67 = node57.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope69 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry40.createFromTypeNodes(node57, "", jSTypeStaticScope69);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry38.createConstructorType(jSType70, true, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = functionType73.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType79 = jSTypeRegistry1.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType73, "hi!", "Not declared as a constructor", (-1), (int) (byte) -1);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(objectTypeIterable42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeMap52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeMap63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(inputId67);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(jSType79);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap1 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer2 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry0, templateTypeMap1);
        try {
            com.google.javascript.rhino.jstype.JSType jSType3 = templateTypeMapReplacer2.caseVoidType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        node4.setQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node10.isWith();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(10, node4, node10, 0, 0);
        boolean boolean21 = node10.isNew();
        boolean boolean22 = node10.isDelProp();
        com.google.javascript.rhino.Node node23 = node10.getNext();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(node23);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("", "goog.exportProperty");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.jstype.UnionType unionType4 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType5 = templateTypeMapReplacer3.caseUnionType(unionType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        node13.setType(47);
        boolean boolean21 = node13.isBlock();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        boolean boolean27 = node25.isCall();
        boolean boolean28 = node25.isNE();
        int int29 = node25.getLength();
        boolean boolean30 = node25.isWith();
        node25.setQuotedString();
        com.google.javascript.rhino.Node node32 = null;
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType42 = node41.getJSType();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap47 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node41, node46);
        java.lang.String str48 = node36.checkTreeEquals(node46);
        try {
            com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.forNode(node13, node25, node32, node46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSType42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeMap47);
        org.junit.Assert.assertNull(str48);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray11 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile12 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = null;
        try {
            com.google.javascript.jscomp.Result result15 = compiler4.compile(jSSourceFileArray11, jSSourceFileArray13, compilerOptions14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
        org.junit.Assert.assertNotNull(jSSourceFileArray11);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_DIV;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 96 + "'", int0 == 96);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        boolean boolean16 = node3.isCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType36.getPrototype();
        boolean boolean39 = objectType38.isNoObjectType();
        boolean boolean40 = objectType38.isNominalConstructor();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("Not declared as a type name");
        boolean boolean2 = node1.isCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node25 = node10.useSourceInfoIfMissingFrom(node16);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        boolean boolean31 = node29.isCall();
        boolean boolean32 = node29.isNE();
        int int33 = node29.getLength();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node16, node29 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(101, nodeArray34, 300, (int) (byte) 1);
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.call(node0, nodeArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeArray34);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        boolean boolean24 = node14.isAssignAdd();
        boolean boolean26 = node14.getBooleanProp((int) (byte) 1);
        node14.setChangeTime(93);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = jSError22.getDefaultLevel();
        int int24 = jSError22.getLineNumber();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.isOn();
        boolean boolean2 = tweakProcessing0.shouldStrip();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        compiler0.disableThreads();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = compiler0.tracker;
        org.junit.Assert.assertNull(performanceTracker3);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node5.isWith();
        node5.setQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node17.isWith();
        node17.setQuotedString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node29, node34);
        boolean boolean36 = node34.isCast();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        boolean boolean47 = node40.isWith();
        node40.setQuotedString();
        com.google.javascript.rhino.Node node49 = node34.useSourceInfoIfMissingFrom(node40);
        com.google.javascript.rhino.Node node50 = node17.copyInformationFromForTree(node40);
        boolean boolean51 = node40.isParamList();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType57 = node56.getJSType();
        node56.setQuotedString();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(10, node56, node62, 0, 0);
        boolean boolean73 = node40.isEquivalentTo(node56);
        try {
            node1.addChildrenAfter(node5, node56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        node0.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        boolean boolean8 = node6.isCall();
        com.google.javascript.rhino.Node node9 = node6.cloneTree();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.catchNode(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        boolean boolean4 = googleCodingConvention0.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = null;
        try {
            boolean boolean6 = googleCodingConvention0.isOptionalParameter(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        boolean boolean66 = node19.isGetElem();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        functionType36.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType36.findPropertyType("goog.exportSymbol");
        try {
            boolean boolean80 = jSType79.isUnionType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertNull(jSType79);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        compiler0.disableThreads();
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType36.getSuperClassConstructor();
        try {
            boolean boolean40 = functionType39.hasInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(functionType39);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.InputId inputId28 = node18.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createFromTypeNodes(node18, "", jSTypeStaticScope30);
        jSTypeRegistry1.clearTemplateTypeNames();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(inputId28);
        org.junit.Assert.assertNotNull(jSType31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        node19.setType(47);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str28 = googleCodingConvention27.getExportPropertyFunction();
        java.lang.String str29 = googleCodingConvention27.getAbstractMethodName();
        boolean boolean31 = googleCodingConvention27.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap46 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node40, node45);
        java.lang.String str47 = node35.checkTreeEquals(node45);
        com.google.javascript.jscomp.SourceFile sourceFile49 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node45.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile49);
        boolean boolean51 = googleCodingConvention27.isOptionalParameter(node45);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile56 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node55);
        boolean boolean57 = googleCodingConvention27.isPrototypeAlias(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        boolean boolean63 = node61.isCall();
        com.google.javascript.rhino.Node node64 = node61.cloneTree();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(98, node4, node19, node55, node61);
        boolean boolean66 = node61.isIn();
        try {
            com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.defaultCase(node61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.exportProperty" + "'", str28.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeMap46);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertNotNull(sourceFile49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(staticSourceFile56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        int int78 = functionType36.getExtendedInterfacesCount();
        java.util.Set<java.lang.String> strSet79 = functionType36.getPropertyNames();
        boolean boolean80 = functionType36.isInstanceType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(strSet79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        try {
            compiler4.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        boolean boolean19 = node13.mayMutateArguments();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.regexp(node13);
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.exprResult(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.rhino.InputId inputId7 = new com.google.javascript.rhino.InputId("");
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = compiler4.getInput(inputId7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        compiler0.setOldParseTree("", astRoot2);
        try {
            com.google.javascript.jscomp.JSError[] jSErrorArray4 = compiler0.getMessages();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean4 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup3);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray5 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList6 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList6, warningsGuardArray5);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard8 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList6);
        java.lang.String str9 = composeWarningsGuard8.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str13 = diagnosticType12.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType12);
        boolean boolean15 = composeWarningsGuard8.enables(diagnosticGroup14);
        java.lang.String str16 = composeWarningsGuard8.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DiagnosticGroup<missingRequire>(WARNING)" + "'", str9.equals("DiagnosticGroup<missingRequire>(WARNING)"));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str13.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticGroup14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DiagnosticGroup<missingRequire>(WARNING)" + "'", str16.equals("DiagnosticGroup<missingRequire>(WARNING)"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue1 = com.google.javascript.jscomp.NodeUtil.isStrWhiteSpaceChar(0);
        org.junit.Assert.assertNotNull(ternaryValue1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(10, node14, node20, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node14.new FileLevelJsDocBuilder();
        boolean boolean32 = node14.isLocalResultCall();
        int int33 = node14.getLength();
        com.google.javascript.jscomp.Compiler compiler35 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter36 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler35);
        java.util.logging.Logger logger37 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager38 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter36, logger37);
        com.google.javascript.jscomp.Compiler compiler39 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager38);
        com.google.javascript.jscomp.Result result40 = compiler39.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter41 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler39);
        com.google.javascript.jscomp.JSError[] jSErrorArray42 = compiler39.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot44 = compiler39.getOldParseTreeByName("");
        try {
            com.google.javascript.jscomp.NodeUtil.verifyScopeChanges(nodeMap9, node14, true, (com.google.javascript.jscomp.AbstractCompiler) compiler39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(result40);
        org.junit.Assert.assertNotNull(jSErrorArray42);
        org.junit.Assert.assertNull(astRoot44);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int0 = com.google.javascript.rhino.Token.EXPR_RESULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray4 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5, templateTypeArray4);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable12 = jSTypeRegistry10.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node21.isCast();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap33 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node27, node32);
        boolean boolean34 = node27.isWith();
        node27.setQuotedString();
        com.google.javascript.rhino.Node node36 = node21.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.InputId inputId37 = node27.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope39 = null;
        com.google.javascript.rhino.jstype.JSType jSType40 = jSTypeRegistry10.createFromTypeNodes(node27, "", jSTypeStaticScope39);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        boolean boolean42 = jSType40.canCastTo(jSType41);
        java.lang.String str43 = jSType40.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable49 = jSTypeRegistry47.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap59 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node53, node58);
        boolean boolean60 = node58.isCast();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType65 = node64.getJSType();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap70 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node64, node69);
        boolean boolean71 = node64.isWith();
        node64.setQuotedString();
        com.google.javascript.rhino.Node node73 = node58.useSourceInfoIfMissingFrom(node64);
        com.google.javascript.rhino.InputId inputId74 = node64.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope76 = null;
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry47.createFromTypeNodes(node64, "", jSTypeStaticScope76);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType80 = jSTypeRegistry45.createConstructorType(jSType77, true, jSTypeArray79);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList81 = functionType80.getTemplateTypes();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot83 = functionType80.getSlot("goog.exportSymbol");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair84 = jSType40.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType80);
        com.google.javascript.rhino.ErrorReporter errorReporter86 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry87 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter86);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable89 = jSTypeRegistry87.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.Node node91 = jSTypeRegistry87.createParameters(jSTypeArray90);
        com.google.javascript.rhino.jstype.FunctionType functionType92 = jSTypeRegistry1.createConstructorType(jSType40, true, jSTypeArray90);
        boolean boolean93 = functionType92.isUnknownType();
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(templateTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeMap33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(inputId37);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(objectTypeIterable49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeMap59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNull(jSType65);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(nodeMap70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(inputId74);
        org.junit.Assert.assertNotNull(jSType77);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertNotNull(functionType80);
        org.junit.Assert.assertNull(jSTypeList81);
        org.junit.Assert.assertNull(staticSlot83);
        org.junit.Assert.assertNotNull(typePair84);
        org.junit.Assert.assertNotNull(objectTypeIterable89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(functionType92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.String str37 = functionType36.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable41 = jSTypeRegistry39.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap51 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node45, node50);
        boolean boolean52 = node50.isCast();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType57 = node56.getJSType();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap62 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node56, node61);
        boolean boolean63 = node56.isWith();
        node56.setQuotedString();
        com.google.javascript.rhino.Node node65 = node50.useSourceInfoIfMissingFrom(node56);
        com.google.javascript.rhino.InputId inputId66 = node56.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope68 = null;
        com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry39.createFromTypeNodes(node56, "", jSTypeStaticScope68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        boolean boolean71 = jSType69.canCastTo(jSType70);
        java.lang.String str72 = jSType69.getDisplayName();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair73 = functionType36.getTypesUnderInequality(jSType69);
        boolean boolean74 = jSType69.matchesUint32Context();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(objectTypeIterable41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeMap51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(jSType57);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeMap62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(inputId66);
        org.junit.Assert.assertNotNull(jSType69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNull(str72);
        org.junit.Assert.assertNotNull(typePair73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        node0.setWasEmptyNode(true);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        java.lang.String str18 = node6.checkTreeEquals(node16);
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node16.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile20);
        boolean boolean22 = node16.mayMutateArguments();
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] { node16 };
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.switchNode(node0, nodeArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(sourceFile20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(nodeArray23);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isUnscopedQualifiedName();
        node1.addChildrenToBack(node10);
        node1.setSourceEncodedPositionForTree(1);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair76 = functionType36.getTypesUnderShallowEquality(jSType72);
        boolean boolean77 = functionType36.isNoResolvedType();
        int int78 = functionType36.getExtendedInterfacesCount();
        java.util.Set<java.lang.String> strSet79 = functionType36.getPropertyNames();
        com.google.javascript.rhino.Node node81 = functionType36.getPropertyNode("Not declared as a constructor");
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(typePair76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(strSet79);
        org.junit.Assert.assertNull(node81);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node43.isTry();
        boolean boolean47 = node43.isInstanceOf();
        java.lang.Object obj49 = node43.getProp(305);
        boolean boolean50 = node43.isFunction();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.rhino.head.ast.AstRoot astRoot3 = compiler0.getOldParseTreeByName("STRING hi! 0 [quoted: 1]: Not declared as a type name");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap18 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node12, node17);
        java.lang.String str19 = node7.checkTreeEquals(node17);
        com.google.javascript.jscomp.SourceFile sourceFile21 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile21);
        java.lang.String str23 = sourceFile21.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceFile21);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap39 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node33, node38);
        java.lang.String str40 = node28.checkTreeEquals(node38);
        com.google.javascript.jscomp.SourceFile sourceFile42 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node38.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile42);
        java.lang.String str44 = sourceFile42.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = null;
        try {
            com.google.javascript.jscomp.Result result46 = compiler0.compile(sourceFile21, sourceFile42, compilerOptions45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(astRoot3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeMap18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(sourceFile21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeMap39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(sourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        try {
            com.google.javascript.jscomp.JSModule jSModule23 = nodeTraversal3.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = jSTypeRegistry45.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node56.isCast();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        node62.setQuotedString();
        com.google.javascript.rhino.Node node71 = node56.useSourceInfoIfMissingFrom(node62);
        com.google.javascript.rhino.InputId inputId72 = node62.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry45.createFromTypeNodes(node62, "", jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry43.createConstructorType(jSType75, true, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType78.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType40.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType79);
        functionType40.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType82 = templateTypeMapReplacer3.caseFunctionType(functionType40);
        com.google.javascript.rhino.jstype.JSType jSType83 = templateTypeMapReplacer3.caseUnknownType();
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(inputId72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(jSType83);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = jSTypeRegistry41.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        boolean boolean54 = node52.isCast();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType59 = node58.getJSType();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap64 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node58, node63);
        boolean boolean65 = node58.isWith();
        node58.setQuotedString();
        com.google.javascript.rhino.Node node67 = node52.useSourceInfoIfMissingFrom(node58);
        com.google.javascript.rhino.InputId inputId68 = node58.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry41.createFromTypeNodes(node58, "", jSTypeStaticScope70);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry39.createConstructorType(jSType71, true, jSTypeArray73);
        com.google.javascript.rhino.jstype.FunctionType functionType75 = functionType74.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType36.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType75);
        functionType36.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType36.findPropertyType("goog.exportSymbol");
        boolean boolean80 = functionType36.isStringObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectTypeIterable43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeMap64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(inputId68);
        org.junit.Assert.assertNotNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertNull(jSType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.InputId inputId28 = node18.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createFromTypeNodes(node18, "", jSTypeStaticScope30);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap41 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node35, node40);
        boolean boolean42 = node35.isWith();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        java.lang.String str58 = node46.checkTreeEquals(node56);
        com.google.javascript.jscomp.SourceFile sourceFile60 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node56.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile60);
        node56.setType(47);
        boolean boolean64 = node56.isBlock();
        com.google.javascript.rhino.Node node65 = node35.useSourceInfoFromForTree(node56);
        com.google.javascript.rhino.Node[] nodeArray66 = new com.google.javascript.rhino.Node[] { node18, node56 };
        try {
            com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.script(nodeArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(inputId28);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeMap41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(sourceFile60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeArray66);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        boolean boolean6 = node3.isNE();
        boolean boolean7 = node3.isEmpty();
        boolean boolean8 = node3.isTrue();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable42 = jSTypeRegistry40.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType47 = node46.getJSType();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap52 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node46, node51);
        boolean boolean53 = node51.isCast();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType58 = node57.getJSType();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap63 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node57, node62);
        boolean boolean64 = node57.isWith();
        node57.setQuotedString();
        com.google.javascript.rhino.Node node66 = node51.useSourceInfoIfMissingFrom(node57);
        com.google.javascript.rhino.InputId inputId67 = node57.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope69 = null;
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry40.createFromTypeNodes(node57, "", jSTypeStaticScope69);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry38.createConstructorType(jSType70, true, jSTypeArray72);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = functionType73.toMaybeFunctionType();
        boolean boolean75 = functionType74.matchesObjectContext();
        functionType36.matchRecordTypeConstraint((com.google.javascript.rhino.jstype.ObjectType) functionType74);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(objectTypeIterable42);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(jSType47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeMap52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeMap63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(inputId67);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(jSTypeArray72);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray2 = new com.google.javascript.rhino.jstype.JSTypeNative[] {};
        com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createUnionType(jSTypeNativeArray2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isQualifiedName();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable22 = jSTypeRegistry20.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node31.isCast();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap43 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node37, node42);
        boolean boolean44 = node37.isWith();
        node37.setQuotedString();
        com.google.javascript.rhino.Node node46 = node31.useSourceInfoIfMissingFrom(node37);
        com.google.javascript.rhino.InputId inputId47 = node37.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope49 = null;
        com.google.javascript.rhino.jstype.JSType jSType50 = jSTypeRegistry20.createFromTypeNodes(node37, "", jSTypeStaticScope49);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry18.createConstructorType(jSType50, true, jSTypeArray52);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = functionType53.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType55 = functionType53.getPrototype();
        boolean boolean56 = objectType55.isNoObjectType();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList57 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry1.createConstructorType("STRING hi! 0", node5, node14, (com.google.javascript.rhino.jstype.JSType) objectType55, templateTypeList57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeNativeArray2);
        org.junit.Assert.assertNotNull(jSType3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeMap43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(inputId47);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertNull(jSTypeList54);
        org.junit.Assert.assertNotNull(objectType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str7 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean12 = node11.mayMutateArguments();
        try {
            boolean boolean13 = closureCodingConvention0.isInlinableFunction(node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportProperty" + "'", str7.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.rhino.Node node0 = null;
        java.lang.String str1 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        jSModule5.clearAsts();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter8 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler7);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter8, logger9);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.jscomp.Result result12 = compiler11.getResult();
        com.google.javascript.jscomp.JSModule jSModule14 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str15 = compiler11.toSource(jSModule14);
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter17 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler16);
        java.util.logging.Logger logger18 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager19 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter17, logger18);
        com.google.javascript.jscomp.Compiler compiler20 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager19);
        com.google.javascript.jscomp.Result result21 = compiler20.getResult();
        com.google.javascript.jscomp.JSModule jSModule23 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str24 = compiler20.toSource(jSModule23);
        com.google.javascript.jscomp.Compiler compiler25 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter26 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler25);
        java.util.logging.Logger logger27 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager28 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter26, logger27);
        com.google.javascript.jscomp.Compiler compiler29 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager28);
        com.google.javascript.jscomp.Result result30 = compiler29.getResult();
        com.google.javascript.jscomp.JSModule jSModule32 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str33 = compiler29.toSource(jSModule32);
        com.google.javascript.jscomp.JSModule[] jSModuleArray34 = new com.google.javascript.jscomp.JSModule[] { jSModule5, jSModule14, jSModule23, jSModule32 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = null;
        try {
            compiler0.init(jSSourceFileArray3, jSModuleArray34, compilerOptions35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertNotNull(result12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(result21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(result30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray34);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        try {
            boolean boolean11 = compiler4.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        try {
            java.lang.String str9 = closureCodingConvention0.getSingletonGetterClassName(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        int int0 = com.google.javascript.rhino.Token.THROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean83 = functionType77.matchesNumberContext();
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = null;
        functionType77.setPropertyJSDocInfo("D4J_Closure_115_FIXED_VERSION", jSDocInfo85);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder46 = node45.getJsDocBuilderForNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention47 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str48 = googleCodingConvention47.getExportPropertyFunction();
        java.lang.String str49 = googleCodingConvention47.getAbstractMethodName();
        boolean boolean51 = googleCodingConvention47.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        java.lang.String str67 = node55.checkTreeEquals(node65);
        com.google.javascript.jscomp.SourceFile sourceFile69 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node65.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile69);
        boolean boolean71 = googleCodingConvention47.isOptionalParameter(node65);
        com.google.javascript.rhino.Node[] nodeArray72 = new com.google.javascript.rhino.Node[] { node45, node65 };
        try {
            com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.script(nodeArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "goog.exportProperty" + "'", str48.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "goog.abstractMethod" + "'", str49.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(sourceFile69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(nodeArray72);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = jSError5.level;
        int int7 = jSError5.getNodeLength();
        java.lang.String str8 = jSError5.description;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(jSError5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        boolean boolean59 = node26.isEquivalentTo(node42);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        boolean boolean65 = node63.isCall();
        com.google.javascript.rhino.Node node66 = node63.cloneTree();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.and(node26, node66);
        boolean boolean68 = node67.isNumber();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        int int0 = com.google.javascript.rhino.Token.NE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType36.getPrototype();
        boolean boolean39 = objectType38.isResolved();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable40 = objectType38.getCtorExtendedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable40);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        boolean boolean12 = node10.isCall();
        boolean boolean13 = node10.isNE();
        int int14 = node10.getLength();
        boolean boolean15 = node10.isWith();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node26.isCast();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node41 = node26.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        boolean boolean47 = node45.isCall();
        boolean boolean48 = node45.isNE();
        int int49 = node45.getLength();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node32, node45 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(101, nodeArray50, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel55 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray63 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray63);
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node53, checkLevel55, diagnosticType58, strArray63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.pos(node53);
        boolean boolean67 = node10.isEquivalentTo(node53);
        java.lang.String str68 = closureCodingConvention0.getSingletonGetterClassName(node53);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable69 = node53.children();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(nodeIterable69);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = dependencyOptions2.setDependencyPruning(false);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions10 = dependencyOptions2.setMoocherDropping(false);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions12 = dependencyOptions10.setMoocherDropping(true);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(dependencyOptions8);
//        org.junit.Assert.assertNotNull(dependencyOptions10);
//        org.junit.Assert.assertNotNull(dependencyOptions12);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("STRING hi!\n");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.string("hi!");
        boolean boolean4 = node3.isGetterDef();
        com.google.javascript.rhino.Node[] nodeArray5 = new com.google.javascript.rhino.Node[] { node1, node3 };
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.objectlit(nodeArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeArray5);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        node13.setIsSyntheticBlock(true);
        boolean boolean21 = node13.isComma();
        boolean boolean22 = node13.isTrue();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node3);
        boolean boolean5 = node3.isHook();
        org.junit.Assert.assertNull(staticSourceFile4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int0 = com.google.javascript.rhino.Token.TRY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 77 + "'", int0 == 77);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str7 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType8, objectType9, objectType10, functionType11, functionType12);
        boolean boolean15 = closureCodingConvention0.isPrivate("");
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("STRING hi!\n");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.falseNode();
        node18.setWasEmptyNode(true);
        java.lang.String str21 = closureCodingConvention0.extractClassNameIfRequire(node17, node18);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.exportProperty" + "'", str7.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean5 = node4.mayMutateArguments();
        boolean boolean6 = node4.isName();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        node11.setQuotedString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node17, node22);
        boolean boolean24 = node17.isWith();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(10, node11, node17, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder28 = node11.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node29 = node4.copyInformationFrom(node11);
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(86, node29);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = jSTypeRegistry7.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType14 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap19 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node18);
        boolean boolean20 = node18.isCast();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap30 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node24, node29);
        boolean boolean31 = node24.isWith();
        node24.setQuotedString();
        com.google.javascript.rhino.Node node33 = node18.useSourceInfoIfMissingFrom(node24);
        com.google.javascript.rhino.InputId inputId34 = node24.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope36 = null;
        com.google.javascript.rhino.jstype.JSType jSType37 = jSTypeRegistry7.createFromTypeNodes(node24, "", jSTypeStaticScope36);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry5.createConstructorType(jSType37, true, jSTypeArray39);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = functionType40.getTemplateTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = jSTypeRegistry45.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType52 = node51.getJSType();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap57 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node51, node56);
        boolean boolean58 = node56.isCast();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType63 = node62.getJSType();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap68 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node62, node67);
        boolean boolean69 = node62.isWith();
        node62.setQuotedString();
        com.google.javascript.rhino.Node node71 = node56.useSourceInfoIfMissingFrom(node62);
        com.google.javascript.rhino.InputId inputId72 = node62.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope74 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry45.createFromTypeNodes(node62, "", jSTypeStaticScope74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry43.createConstructorType(jSType75, true, jSTypeArray77);
        com.google.javascript.rhino.jstype.FunctionType functionType79 = functionType78.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType40.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType79);
        functionType40.clearResolved();
        com.google.javascript.rhino.jstype.JSType jSType82 = templateTypeMapReplacer3.caseFunctionType(functionType40);
        boolean boolean83 = jSType82.isNoResolvedType();
        org.junit.Assert.assertNotNull(objectTypeIterable9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(jSType14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeMap19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeMap30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(inputId34);
        org.junit.Assert.assertNotNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertNull(jSTypeList41);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(jSType52);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeMap57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNull(jSType63);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeMap68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(inputId72);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNotNull(functionType79);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        int int4 = node3.getChangeTime();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getMessages();
        com.google.javascript.rhino.head.ast.AstRoot astRoot9 = null;
        compiler4.setOldParseTree("D4J_Closure_115_FIXED_VERSION", astRoot9);
        try {
            compiler4.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = functionType36.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = functionType36.toMaybeFunctionType();
        boolean boolean39 = functionType38.hasReferenceName();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = sideEffectFlags0.clearAllFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags0.setMutatesArguments();
        org.junit.Assert.assertNotNull(sideEffectFlags1);
        org.junit.Assert.assertNotNull(sideEffectFlags2);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_REQUIRE;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        boolean boolean4 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        boolean boolean17 = node15.isCast();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node21.isWith();
        node21.setQuotedString();
        com.google.javascript.rhino.Node node30 = node15.useSourceInfoIfMissingFrom(node21);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        boolean boolean36 = node34.isCall();
        boolean boolean37 = node34.isNE();
        int int38 = node34.getLength();
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node21, node34 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(101, nodeArray39, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel44 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType50 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray52 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make(diagnosticType50, strArray52);
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node42, checkLevel44, diagnosticType47, strArray52);
        com.google.javascript.jscomp.CheckLevel checkLevel55 = diagnosticGroupWarningsGuard2.level(jSError54);
        java.lang.String str56 = diagnosticGroupWarningsGuard2.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(diagnosticType50);
        org.junit.Assert.assertNotNull(strArray52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNull(checkLevel55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "DiagnosticGroup<missingRequire>(WARNING)" + "'", str56.equals("DiagnosticGroup<missingRequire>(WARNING)"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.String str37 = functionType36.getDisplayName();
        boolean boolean38 = functionType36.hasImplementedInterfaces();
        boolean boolean39 = functionType36.isFunctionPrototypeType();
        boolean boolean40 = functionType36.makesStructs();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        boolean boolean11 = node8.isEmpty();
        node8.putBooleanProp(46, false);
        boolean boolean15 = node8.isWhile();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable19 = jSTypeRegistry17.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType24 = node23.getJSType();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node23, node28);
        boolean boolean30 = node28.isCast();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType35 = node34.getJSType();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node34, node39);
        boolean boolean41 = node34.isWith();
        node34.setQuotedString();
        com.google.javascript.rhino.Node node43 = node28.useSourceInfoIfMissingFrom(node34);
        com.google.javascript.rhino.InputId inputId44 = node34.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope46 = null;
        com.google.javascript.rhino.jstype.JSType jSType47 = jSTypeRegistry17.createFromTypeNodes(node34, "", jSTypeStaticScope46);
        com.google.javascript.rhino.Node node48 = node8.useSourceInfoIfMissingFromForTree(node34);
        boolean boolean49 = node48.isContinue();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(inputId44);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        java.lang.String str21 = node9.checkTreeEquals(node19);
        com.google.javascript.jscomp.SourceFile sourceFile23 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node19.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile23);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType29 = node28.getJSType();
        boolean boolean30 = node28.isCall();
        boolean boolean31 = node19.isEquivalentToTyped(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.voidNode(node19);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship33 = closureCodingConvention0.getClassesDefinedByCall(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        node38.setQuotedString();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType45 = node44.getJSType();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap50 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node44, node49);
        boolean boolean51 = node44.isWith();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(10, node38, node44, 0, 0);
        com.google.javascript.jscomp.CodingConvention.Bind bind56 = closureCodingConvention0.describeFunctionBind(node54, true);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(subclassRelationship33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(jSType45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(nodeMap50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(bind56);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap18 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node12, node17);
        java.lang.String str19 = node7.checkTreeEquals(node17);
        com.google.javascript.jscomp.SourceFile sourceFile21 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile21);
        java.lang.String str23 = sourceFile21.getOriginalPath();
        java.lang.String str24 = sourceFile21.getOriginalPath();
        sourceFile21.clearCachedSource();
        node3.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile21);
        try {
            com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '#', node1, node3, (-1), 41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeMap18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(sourceFile21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        compilerInput20.clearAst();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isUnscopedQualifiedName();
        node1.addChildrenToBack(node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str17 = diagnosticType16.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(node10, diagnosticType16, strArray22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType16);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str17.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(diagnosticGroup25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_FUNCTION_TYPE));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter6 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler4);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = compiler4.getWarnings();
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        com.google.javascript.rhino.jstype.ObjectType objectType38 = functionType36.getPrototype();
        boolean boolean39 = objectType38.isObject();
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType38.getPropertyType("InputId: ");
        boolean boolean42 = jSType41.isNoObjectType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) (short) 10);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isUnscopedQualifiedName();
        node1.addChildrenToBack(node10);
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str17 = diagnosticType16.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray22 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType20, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(node10, diagnosticType16, strArray22);
        int int25 = jSError24.getLineNumber();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str17.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType42 = functionType36.getSuperClassConstructor();
        try {
            boolean boolean43 = functionType42.hasAnyTemplateTypesInternal();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNull(functionType42);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str32 = compiler28.toSource(jSModule31);
        jSModule1.addDependency(jSModule31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap48 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node42, node47);
        java.lang.String str49 = node37.checkTreeEquals(node47);
        com.google.javascript.jscomp.SourceFile sourceFile51 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node47.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile51);
        java.lang.String str53 = sourceFile51.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput54 = new com.google.javascript.jscomp.CompilerInput(sourceFile51);
        java.lang.String str56 = compilerInput54.getLine(43);
        java.lang.String str57 = compilerInput54.toString();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType67 = node66.getJSType();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap72 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node66, node71);
        java.lang.String str73 = node61.checkTreeEquals(node71);
        com.google.javascript.jscomp.SourceFile sourceFile75 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node71.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile75);
        java.lang.String str77 = sourceFile75.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput78 = new com.google.javascript.jscomp.CompilerInput(sourceFile75);
        java.lang.String str80 = compilerInput78.getLine(43);
        com.google.javascript.jscomp.CompilerInput compilerInput83 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput78, "Not declared as a constructor", false);
        try {
            jSModule1.addAfter(compilerInput54, compilerInput78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeMap48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(sourceFile51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeMap72);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertNotNull(sourceFile75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertNull(str80);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        node3.setQuotedString();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.throwNode(node3);
        boolean boolean9 = node8.isSwitch();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make(diagnosticType10, strArray12);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = jSError13.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray21 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError22 = nodeTraversal3.makeError(node7, checkLevel14, diagnosticType17, strArray21);
        java.lang.String str23 = jSError22.toString();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "STRING hi! 0 [quoted: 1]. Not declared as a type name at (unknown source) line 0 : 0" + "'", str23.equals("STRING hi! 0 [quoted: 1]. Not declared as a type name at (unknown source) line 0 : 0"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_SUB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 94 + "'", int0 == 94);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        node5.setQuotedString();
        boolean boolean8 = node5.isCatch();
        boolean boolean9 = inputId1.equals((java.lang.Object) node5);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.FunctionType functionType39 = functionType36.getSuperClassConstructor();
        boolean boolean40 = functionType36.makesStructs();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V1;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        java.lang.String str22 = node10.checkTreeEquals(node20);
        com.google.javascript.jscomp.SourceFile sourceFile24 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node20.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile24);
        node20.setIsSyntheticBlock(true);
        node6.addChildToBack(node20);
        try {
            java.util.List<java.lang.String> strList29 = closureCodingConvention0.identifyTypeDeclarationCall(node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(sourceFile24);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int0 = com.google.javascript.rhino.Token.FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 105 + "'", int0 == 105);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int0 = com.google.javascript.rhino.Token.DEFAULT_CASE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 112 + "'", int0 == 112);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = new com.google.javascript.jscomp.DependencyOptions();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray3 = new com.google.javascript.jscomp.CompilerInput[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList4, compilerInputArray3);
//        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModuleGraph1.manageDependencies(dependencyOptions2, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList4);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = dependencyOptions2.setDependencyPruning(false);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions10 = dependencyOptions2.setMoocherDropping(false);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions12 = dependencyOptions10.setDependencyPruning(true);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertNotNull(compilerInputArray3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(compilerInputList6);
//        org.junit.Assert.assertNotNull(dependencyOptions8);
//        org.junit.Assert.assertNotNull(dependencyOptions10);
//        org.junit.Assert.assertNotNull(dependencyOptions12);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap1 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer2 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry0, templateTypeMap1);
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType3 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType4 = templateTypeMapReplacer2.caseTemplatizedType(templatizedType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 41, 110);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter2, logger3);
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.jscomp.Result result6 = compiler5.getResult();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter9 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, true);
        com.google.javascript.jscomp.JsAst jsAst10 = null;
        try {
            compiler5.replaceScript(jsAst10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(result6);
        org.junit.Assert.assertNotNull(messageFormatter9);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        boolean boolean13 = googleCodingConvention0.isExported("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean6 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node35.isCall();
        boolean boolean38 = node35.isNE();
        int int39 = node35.getLength();
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node22, node35 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(101, nodeArray40, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node44 = node5.useSourceInfoFrom(node43);
        com.google.javascript.rhino.Node node45 = assertInstanceofSpec1.getAssertedParam(node43);
        boolean boolean46 = node43.isTry();
        boolean boolean47 = node43.isInstanceOf();
        java.lang.Object obj49 = node43.getProp(305);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean54 = node53.mayMutateArguments();
        boolean boolean55 = node53.isName();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        node60.setQuotedString();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType67 = node66.getJSType();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap72 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node66, node71);
        boolean boolean73 = node66.isWith();
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(10, node60, node66, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder77 = node60.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node78 = node53.copyInformationFrom(node60);
        try {
            com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.IR.var(node43, node78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeMap72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node78);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int7 = diagnosticType2.compareTo(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType2);
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        compiler9.disableThreads();
        com.google.javascript.jscomp.NodeTraversal.Callback callback11 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal12 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler9, callback11);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(diagnosticType19, strArray21);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = jSError22.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String[] strArray30 = new java.lang.String[] { "STRING hi! 0 [quoted: 1]: Not declared as a type name", "STRING hi! 0 [quoted: 1]", "goog.exportProperty" };
        com.google.javascript.jscomp.JSError jSError31 = nodeTraversal12.makeError(node16, checkLevel23, diagnosticType26, strArray30);
        diagnosticType2.level = checkLevel23;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str3.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-20) + "'", int7 == (-20));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot40 = functionType36.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable41 = functionType36.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType42 = functionType36.getSuperClassConstructor();
        com.google.javascript.rhino.JSDocInfo jSDocInfo44 = null;
        try {
            functionType42.setPropertyJSDocInfo("DiagnosticGroup<missingRequire>(WARNING)", jSDocInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(staticSlot40);
        org.junit.Assert.assertNotNull(nodeIterable41);
        org.junit.Assert.assertNull(functionType42);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        org.junit.Assert.assertNotNull(diagnosticType0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap13 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node7, node12);
        boolean boolean14 = node12.isCast();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap24 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node18, node23);
        boolean boolean25 = node18.isWith();
        node18.setQuotedString();
        com.google.javascript.rhino.Node node27 = node12.useSourceInfoIfMissingFrom(node18);
        com.google.javascript.rhino.InputId inputId28 = node18.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.createFromTypeNodes(node18, "", jSTypeStaticScope30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType37 = node36.getJSType();
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(46, node36, 0, 0);
        try {
            com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.add(node18, node36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(nodeMap13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeMap24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(inputId28);
        org.junit.Assert.assertNotNull(jSType31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType37);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = functionType36.getTemplateTypes();
        boolean boolean38 = functionType36.isNoType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = functionType36.getExtendedInterfaces();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable45 = jSTypeRegistry43.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType50 = node49.getJSType();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap55 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node49, node54);
        boolean boolean56 = node54.isCast();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        boolean boolean67 = node60.isWith();
        node60.setQuotedString();
        com.google.javascript.rhino.Node node69 = node54.useSourceInfoIfMissingFrom(node60);
        com.google.javascript.rhino.InputId inputId70 = node60.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope72 = null;
        com.google.javascript.rhino.jstype.JSType jSType73 = jSTypeRegistry43.createFromTypeNodes(node60, "", jSTypeStaticScope72);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry41.createConstructorType(jSType73, true, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType77 = functionType76.toMaybeFunctionType();
        boolean boolean78 = functionType77.matchesObjectContext();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair79 = functionType36.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType77);
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSTypeList37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertNotNull(objectTypeIterable45);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(jSType50);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeMap55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNull(inputId70);
        org.junit.Assert.assertNotNull(jSType73);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(typePair79);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        double double4 = loggerErrorManager3.getTypedPercent();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("goog.abstractMethod", charset1);
        java.lang.String str3 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope2 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList3 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap4 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry1, jSTypeStaticScope2, objectTypeList3, strMap4);
        java.lang.String str6 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        boolean boolean12 = node10.isCall();
        boolean boolean13 = node10.isNE();
        int int14 = node10.getLength();
        boolean boolean15 = node10.isWith();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node21, node26);
        boolean boolean28 = node26.isCast();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        boolean boolean39 = node32.isWith();
        node32.setQuotedString();
        com.google.javascript.rhino.Node node41 = node26.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType46 = node45.getJSType();
        boolean boolean47 = node45.isCall();
        boolean boolean48 = node45.isNE();
        int int49 = node45.getLength();
        com.google.javascript.rhino.Node[] nodeArray50 = new com.google.javascript.rhino.Node[] { node32, node45 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(101, nodeArray50, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel55 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray63 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make(diagnosticType61, strArray63);
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node53, checkLevel55, diagnosticType58, strArray63);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.pos(node53);
        boolean boolean67 = node10.isEquivalentTo(node53);
        java.lang.String str68 = closureCodingConvention0.getSingletonGetterClassName(node53);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
        node73.setQuotedString();
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType80 = node79.getJSType();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap85 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node79, node84);
        boolean boolean86 = node79.isWith();
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node(10, node73, node79, 0, 0);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder90 = node73.new FileLevelJsDocBuilder();
        boolean boolean91 = node73.isLocalResultCall();
        java.util.Map<java.lang.String, java.lang.String> strMap92 = null;
        closureCodingConvention0.checkForCallingConventionDefiningCalls(node73, strMap92);
        java.lang.String str94 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(jSType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(nodeArray50);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + checkLevel55 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel55.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNull(jSType80);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(nodeMap85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "goog.abstractMethod" + "'", str94.equals("goog.abstractMethod"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter12 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry11);
        com.google.javascript.jscomp.type.ChainableReverseAbstractInterpreter chainableReverseAbstractInterpreter13 = semanticReverseAbstractInterpreter12.getFirst();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertNotNull(chainableReverseAbstractInterpreter13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType9 = node8.getJSType();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap14 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node13);
        java.lang.String str15 = node3.checkTreeEquals(node13);
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node13.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile17);
        java.lang.String str19 = sourceFile17.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17);
        int int21 = compilerInput20.getNumLines();
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput20, true);
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter25 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler24);
        java.util.logging.Logger logger26 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager27 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter25, logger26);
        com.google.javascript.jscomp.Compiler compiler28 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager27);
        com.google.javascript.jscomp.Result result29 = compiler28.getResult();
        com.google.javascript.rhino.Node node30 = compilerInput20.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler28);
        boolean boolean31 = node30.isVarArgs();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(jSType9);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeMap14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(result29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = googleCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) ' ', (int) '4', (int) ' ');
        boolean boolean7 = node6.mayMutateArguments();
        boolean boolean8 = node6.isName();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = googleCodingConvention0.describeFunctionBind(node6, true);
        boolean boolean12 = googleCodingConvention0.isConstantKey("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.abstractMethod" + "'", str2.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        try {
            java.lang.String str8 = compiler4.getSourceLine("D4J_Closure_115_FIXED_VERSION", 50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.isOn();
        boolean boolean2 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int0 = com.google.javascript.rhino.Token.TRUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable7 = jSTypeRegistry5.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType12 = node11.getJSType();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node11, node16);
        boolean boolean18 = node16.isCast();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType23 = node22.getJSType();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node22, node27);
        boolean boolean29 = node22.isWith();
        node22.setQuotedString();
        com.google.javascript.rhino.Node node31 = node16.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.InputId inputId32 = node22.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope34 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry5.createFromTypeNodes(node22, "", jSTypeStaticScope34);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        boolean boolean37 = jSType35.canCastTo(jSType36);
        java.lang.String str38 = jSType35.getDisplayName();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable44 = jSTypeRegistry42.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node53.isCast();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType60 = node59.getJSType();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap65 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node59, node64);
        boolean boolean66 = node59.isWith();
        node59.setQuotedString();
        com.google.javascript.rhino.Node node68 = node53.useSourceInfoIfMissingFrom(node59);
        com.google.javascript.rhino.InputId inputId69 = node59.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType72 = jSTypeRegistry42.createFromTypeNodes(node59, "", jSTypeStaticScope71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry40.createConstructorType(jSType72, true, jSTypeArray74);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = functionType75.getTemplateTypes();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot78 = functionType75.getSlot("goog.exportSymbol");
        com.google.javascript.rhino.jstype.JSType.TypePair typePair79 = jSType35.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.JSType jSType80 = jSTypeRegistry1.createOptionalNullableType(jSType35);
        org.junit.Assert.assertNotNull(objectTypeIterable7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(jSType12);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(inputId32);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(objectTypeIterable44);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(jSType60);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(nodeMap65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(inputId69);
        org.junit.Assert.assertNotNull(jSType72);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertNull(jSTypeList76);
        org.junit.Assert.assertNull(staticSlot78);
        org.junit.Assert.assertNotNull(typePair79);
        org.junit.Assert.assertNotNull(jSType80);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isCast();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node14.isWith();
        node14.setQuotedString();
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFrom(node14);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType28 = node27.getJSType();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType33 = node32.getJSType();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap38 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node32, node37);
        java.lang.String str39 = node27.checkTreeEquals(node37);
        com.google.javascript.jscomp.SourceFile sourceFile41 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node37.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile41);
        boolean boolean43 = node37.mayMutateArguments();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.regexp(node37);
        java.lang.String str45 = node14.checkTreeEquals(node37);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention46 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope48 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList49 = null;
        java.util.Map<java.lang.String, java.lang.String> strMap50 = null;
        closureCodingConvention46.defineDelegateProxyPrototypeProperties(jSTypeRegistry47, jSTypeStaticScope48, objectTypeList49, strMap50);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType56 = node55.getJSType();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType61 = node60.getJSType();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap66 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node60, node65);
        java.lang.String str67 = node55.checkTreeEquals(node65);
        com.google.javascript.jscomp.SourceFile sourceFile69 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node65.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile69);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType75 = node74.getJSType();
        boolean boolean76 = node74.isCall();
        boolean boolean77 = node65.isEquivalentToTyped(node74);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.IR.voidNode(node65);
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship79 = closureCodingConvention46.getClassesDefinedByCall(node78);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.IR.comma(node14, node78);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeMap38);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(sourceFile41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(jSType61);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(nodeMap66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(sourceFile69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNull(subclassRelationship79);
        org.junit.Assert.assertNotNull(node80);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10, (int) (byte) 0, (-1));
        boolean boolean4 = node3.wasEmptyNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType34 = node33.getJSType();
        boolean boolean35 = node33.isCall();
        boolean boolean36 = node33.isNE();
        int int37 = node33.getLength();
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] { node20, node33 };
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(101, nodeArray38, 300, (int) (byte) 1);
        com.google.javascript.rhino.Node node42 = node3.useSourceInfoFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        node47.setQuotedString();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap59 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node53, node58);
        boolean boolean60 = node53.isWith();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(10, node47, node53, 0, 0);
        java.lang.String str64 = node3.checkTreeEquals(node53);
        boolean boolean65 = node3.isAssignAdd();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(jSType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeMap59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n" + "'", str64.equals("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, true);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.returnNode(node3);
        java.lang.String str11 = node10.getQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node8.isQualifiedName();
        java.lang.Object obj12 = node8.getProp(23);
        node8.setQuotedString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        boolean boolean10 = node3.isWith();
        node3.setQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node15, node20);
        boolean boolean22 = node20.isCast();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        boolean boolean33 = node26.isWith();
        node26.setQuotedString();
        com.google.javascript.rhino.Node node35 = node20.useSourceInfoIfMissingFrom(node26);
        com.google.javascript.rhino.Node node36 = node3.copyInformationFromForTree(node26);
        boolean boolean37 = node26.isParamList();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        node42.setQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType49 = node48.getJSType();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap54 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node48, node53);
        boolean boolean55 = node48.isWith();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(10, node42, node48, 0, 0);
        boolean boolean59 = node26.isEquivalentTo(node42);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType64 = node63.getJSType();
        boolean boolean65 = node63.isCall();
        com.google.javascript.rhino.Node node66 = node63.cloneTree();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.and(node26, node66);
        node66.setSourceEncodedPositionForTree(119);
        try {
            com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.IR.not(node66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeMap54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(jSType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable1 = diagnosticGroup0.getTypes();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("STRING hi! 0 [quoted: 1]", "Not declared as a type name");
        java.lang.String str3 = diagnosticType2.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        int int7 = diagnosticType2.compareTo(diagnosticType6);
        java.lang.String str8 = diagnosticType2.toString();
        java.lang.String str9 = diagnosticType2.key;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str3.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-20) + "'", int7 == (-20));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING hi! 0 [quoted: 1]: Not declared as a type name" + "'", str8.equals("STRING hi! 0 [quoted: 1]: Not declared as a type name"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "STRING hi! 0 [quoted: 1]" + "'", str9.equals("STRING hi! 0 [quoted: 1]"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        jSModule1.clearAsts();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList4 = jSModule1.getInputs();
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertNotNull(compilerInputList4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger2 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager3 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter1, logger2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager3);
        com.google.javascript.jscomp.Result result5 = compiler4.getResult();
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        java.lang.String str8 = compiler4.toSource(jSModule7);
        try {
            boolean boolean9 = compiler4.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(result5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable3 = jSTypeRegistry1.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray4 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5, templateTypeArray4);
        jSTypeRegistry1.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList5);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry1.createOptionalType(jSType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable3);
        org.junit.Assert.assertNotNull(templateTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("goog.exportProperty");
        boolean boolean2 = node1.isFunction();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        boolean boolean8 = node6.isCall();
        com.google.javascript.rhino.Node node9 = node6.cloneTree();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.throwNode(node9);
        try {
            java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable10 = jSTypeRegistry8.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType15 = node14.getJSType();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node19);
        boolean boolean21 = node19.isCast();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap31 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node25, node30);
        boolean boolean32 = node25.isWith();
        node25.setQuotedString();
        com.google.javascript.rhino.Node node34 = node19.useSourceInfoIfMissingFrom(node25);
        com.google.javascript.rhino.InputId inputId35 = node25.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope37 = null;
        com.google.javascript.rhino.jstype.JSType jSType38 = jSTypeRegistry8.createFromTypeNodes(node25, "", jSTypeStaticScope37);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry6.createConstructorType(jSType38, true, jSTypeArray40);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList42 = functionType41.getTemplateTypes();
        boolean boolean43 = functionType41.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot45 = functionType41.getSlot("hi!");
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable46 = functionType41.getParameters();
        com.google.javascript.rhino.jstype.FunctionType functionType48 = functionType41.getBindReturnType(100);
        try {
            jSTypeRegistry1.overwriteDeclaredType("STRING hi! 0", (com.google.javascript.rhino.jstype.JSType) functionType48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(objectTypeIterable10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeMap31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(inputId35);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertNull(jSTypeList42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(staticSlot45);
        org.junit.Assert.assertNotNull(nodeIterable46);
        org.junit.Assert.assertNotNull(functionType48);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        node0.setLength(100);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable3 = node0.siblings();
        boolean boolean4 = node0.isString();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(nodeIterable3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        int int0 = com.google.javascript.rhino.Token.CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 149 + "'", int0 == 149);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap11 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node10);
        boolean boolean12 = node10.isCast();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap22 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node21);
        boolean boolean23 = node16.isWith();
        node16.setQuotedString();
        com.google.javascript.rhino.Node node25 = node10.useSourceInfoIfMissingFrom(node16);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType30 = node29.getJSType();
        boolean boolean31 = node29.isCall();
        boolean boolean32 = node29.isNE();
        int int33 = node29.getLength();
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node16, node29 };
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(101, nodeArray34, 300, (int) (byte) 1);
        com.google.javascript.rhino.jstype.JSType jSType38 = node37.getJSType();
        com.google.javascript.jscomp.CheckLevel checkLevel39 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.error("goog.exportProperty", "");
        java.lang.String[] strArray47 = new java.lang.String[] { "hi!" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make(diagnosticType45, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("Not declared as a type name", node37, checkLevel39, diagnosticType42, strArray47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = node53.getJSType();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap59 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node53, node58);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.returnNode(node53);
        boolean boolean61 = diagnosticType42.equals((java.lang.Object) node60);
        boolean boolean62 = node60.isOnlyModifiesArgumentsCall();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(nodeMap11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeMap22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeMap59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType5 = node4.getJSType();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap10 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node4, node9);
        boolean boolean11 = node4.isWith();
        node4.setQuotedString();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str14 = googleCodingConvention13.getExportPropertyFunction();
        java.lang.String str15 = googleCodingConvention13.getAbstractMethodName();
        boolean boolean17 = googleCodingConvention13.isSuperClassReference("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType22 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType27 = node26.getJSType();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap32 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node26, node31);
        java.lang.String str33 = node21.checkTreeEquals(node31);
        com.google.javascript.jscomp.SourceFile sourceFile35 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node31.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile35);
        boolean boolean37 = googleCodingConvention13.isOptionalParameter(node31);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node31);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType43 = node42.getJSType();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType48 = node47.getJSType();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap53 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node52);
        java.lang.String str54 = node42.checkTreeEquals(node52);
        boolean boolean55 = node52.isAssign();
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(30, node4, node31, node52);
        boolean boolean57 = node52.isDec();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(nodeMap10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.exportProperty" + "'", str14.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.abstractMethod" + "'", str15.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(jSType22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeMap32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(sourceFile35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(jSType48);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(nodeMap53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap9 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node8);
        node3.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(nodeMap9);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("STRING hi! 0 [quoted: 1]");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType11 = node10.getJSType();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node10, node15);
        java.lang.String str17 = node5.checkTreeEquals(node15);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromFile("hi!");
        node15.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceFile19);
        jSModule1.remove(compilerInput22);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = jSModule1.getByName("WARNING - \n");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNull(compilerInput25);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList0 = null;
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies1 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>(compilerInputList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue1 = com.google.javascript.jscomp.NodeUtil.isStrWhiteSpaceChar(117);
        org.junit.Assert.assertNotNull(ternaryValue1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        com.google.javascript.rhino.jstype.EnumType enumType37 = functionType36.toMaybeEnumType();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(enumType37);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap2 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMapReplacer templateTypeMapReplacer3 = new com.google.javascript.rhino.jstype.TemplateTypeMapReplacer(jSTypeRegistry1, templateTypeMap2);
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType4 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType5 = templateTypeMapReplacer3.caseTemplatizedType(templatizedType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n", "");
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromFile("DiagnosticGroup<missingRequire>(WARNING)");
        java.io.Reader reader7 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile8 = builder0.buildFromReader("hi!", reader7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable5 = jSTypeRegistry3.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap15 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node9, node14);
        boolean boolean16 = node14.isCast();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType21 = node20.getJSType();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap26 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node25);
        boolean boolean27 = node20.isWith();
        node20.setQuotedString();
        com.google.javascript.rhino.Node node29 = node14.useSourceInfoIfMissingFrom(node20);
        com.google.javascript.rhino.InputId inputId30 = node20.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope32 = null;
        com.google.javascript.rhino.jstype.JSType jSType33 = jSTypeRegistry3.createFromTypeNodes(node20, "", jSTypeStaticScope32);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry1.createConstructorType(jSType33, true, jSTypeArray35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable38 = jSTypeRegistry1.getTypesWithProperty("goog.exportProperty");
        com.google.javascript.rhino.Node node40 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.ErrorReporter errorReporter43 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter43);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = jSTypeRegistry44.getEachReferenceTypeWithProperty("Node tree inequality:\nTree1:\nBITXOR 300\n\n\nTree2:\nSTRING hi! 0\n\n\nSubtree1: BITXOR 300\n\n\nSubtree2: STRING hi! 0\n");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType51 = node50.getJSType();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap56 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node50, node55);
        boolean boolean57 = node55.isCast();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType62 = node61.getJSType();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap67 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node61, node66);
        boolean boolean68 = node61.isWith();
        node61.setQuotedString();
        com.google.javascript.rhino.Node node70 = node55.useSourceInfoIfMissingFrom(node61);
        com.google.javascript.rhino.InputId inputId71 = node61.getInputId();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope73 = null;
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry44.createFromTypeNodes(node61, "", jSTypeStaticScope73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry42.createConstructorType(jSType74, true, jSTypeArray76);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList78 = functionType77.getTemplateTypes();
        boolean boolean79 = functionType77.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.StaticSlot staticSlot81 = functionType77.getSlot("hi!");
        com.google.javascript.rhino.jstype.EnumType enumType82 = jSTypeRegistry1.createEnumType("InputId: ", node40, (com.google.javascript.rhino.jstype.JSType) functionType77);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable83 = enumType82.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(objectTypeIterable5);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeMap15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeMap26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(inputId30);
        org.junit.Assert.assertNotNull(jSType33);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(jSTypeIterable38);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(jSType51);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeMap56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(jSType62);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeMap67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(inputId71);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(jSTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNull(staticSlot81);
        org.junit.Assert.assertNotNull(enumType82);
        org.junit.Assert.assertNotNull(objectTypeIterable83);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportPropertyFunction();
        boolean boolean3 = googleCodingConvention0.isValidEnumKey("");
        java.util.Collection<java.lang.String> strCollection4 = googleCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean6 = googleCodingConvention0.isValidEnumKey("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strCollection4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("hi!", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        boolean boolean5 = node3.isCall();
        com.google.javascript.rhino.Node node6 = node3.cloneTree();
        try {
            com.google.javascript.rhino.Node node7 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
    }
}

