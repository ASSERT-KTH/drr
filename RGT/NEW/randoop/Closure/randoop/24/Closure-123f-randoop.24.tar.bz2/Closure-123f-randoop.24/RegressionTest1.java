import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        boolean boolean4 = node0.isArrayLit();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        node5.addChildToFront(node6);
        boolean boolean8 = node5.isFor();
        boolean boolean9 = node5.isExprResult();
        boolean boolean10 = node5.isDefaultCase();
        boolean boolean11 = node5.isCase();
        com.google.javascript.rhino.Node node12 = node5.cloneTree();
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.caseNode(node0, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setAssumeClosuresOnlyCaptureReferences(true);
        compilerOptions0.closurePass = false;
        compilerOptions0.setUnaliasableGlobals("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        compilerOptions0.setAliasAllStrings(false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        com.google.javascript.rhino.JSDocInfo jSDocInfo6 = null;
        com.google.javascript.rhino.Node node7 = node3.setJSDocInfo(jSDocInfo6);
        boolean boolean8 = node3.isTrue();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 37);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        int int7 = node6.getSourceOffset();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        boolean boolean11 = node8.isFor();
        boolean boolean12 = node8.isExprResult();
        boolean boolean13 = node8.isDefaultCase();
        boolean boolean14 = node8.isCase();
        com.google.javascript.rhino.Node node15 = node8.cloneTree();
        try {
            node1.addChildBefore(node6, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, false);
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator5);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceFile6, true);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8);
        com.google.javascript.jscomp.SourceFile sourceFile10 = compilerInput9.getSourceFile();
        com.google.javascript.rhino.InputId inputId11 = compilerInput9.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId11, false);
        java.lang.String str14 = inputId11.getIdName();
        java.lang.String str15 = inputId11.toString();
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertNotNull(inputId11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Not declared as a type name" + "'", str14.equals("Not declared as a type name"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "InputId: Not declared as a type name" + "'", str15.equals("InputId: Not declared as a type name"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean4 = closureCodingConvention0.isConstantKey("Not declared as a type name");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node5, astRoot6);
        boolean boolean8 = node5.isGetterDef();
        int int9 = node5.getSourceOffset();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.string("SCRIPT");
        boolean boolean13 = closureCodingConvention0.isVarArgsParameter(node12);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        boolean boolean11 = node8.isFor();
        boolean boolean12 = node8.isExprResult();
        java.util.List<java.lang.String> strList13 = closureCodingConvention0.identifyTypeDeclarationCall(node8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        boolean boolean20 = node17.isVoid();
        com.google.javascript.rhino.Node node21 = node17.getLastSibling();
        java.util.Map<java.lang.String, java.lang.String> strMap22 = null;
        closureCodingConvention0.checkForCallingConventionDefiningCalls(node21, strMap22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strList13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        node26.addChildToFront(node27);
        boolean boolean29 = node26.isEmpty();
        com.google.javascript.rhino.Node node30 = node23.useSourceInfoIfMissingFrom(node26);
        try {
            java.lang.String str31 = node26.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: THIS is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        compilerOptions0.setAggressiveVarCheck(checkLevel31);
        boolean boolean39 = compilerOptions0.assumeStrictThis();
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean42 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        compilerOptions0.setRecordFunctionInformation(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str11 = compilerOptions10.locale;
        compilerOptions10.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions10.enableExternExports(true);
        compilerOptions10.setRecordFunctionInformation(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean22 = compilerOptions18.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions18.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean28 = compilerOptions24.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions24.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean34 = compilerOptions30.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions30.checkGlobalThisLevel;
        compilerOptions24.setCheckMissingReturn(checkLevel35);
        compilerOptions18.aggressiveVarCheck = checkLevel35;
        compilerOptions10.setCheckProvides(checkLevel35);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str40 = compilerOptions39.locale;
        compilerOptions39.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing43 = null;
        compilerOptions39.setTweakProcessing(tweakProcessing43);
        byte[] byteArray45 = new byte[] {};
        compilerOptions39.setInputVariableMapSerialized(byteArray45);
        compilerOptions10.setInputVariableMapSerialized(byteArray45);
        compilerOptions0.setInputVariableMapSerialized(byteArray45);
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str50 = compilerOptions49.locale;
        compilerOptions49.syntheticBlockStartMarker = "Not declared as a type name";
        boolean boolean53 = compilerOptions49.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray54 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList55 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList55, locationMappingArray54);
        compilerOptions49.setSourceMapLocationMappings((java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList55);
        compilerOptions0.setSourceMapLocationMappings((java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList55);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(byteArray45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(locationMappingArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("Not declared as a constructor");
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromGenerator("D4J_Closure_123_FIXED_VERSION", generator4);
        java.io.File file6 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile7 = builder0.buildFromFile(file6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, (int) '#', 33);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.number((double) 56);
        try {
            com.google.javascript.rhino.Node node7 = node3.removeChildAfter(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str17 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType20 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType18, functionType19, objectType20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportSymbol" + "'", str17.equals("goog.exportSymbol"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        node4.removeProp(0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str6 = compilerOptions5.locale;
        compilerOptions5.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions5.checkControlStructures = false;
        compilerOptions5.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy13 = compilerOptions5.getCheckEventfulObjectDisposalPolicy();
        compilerOptions5.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str17 = compilerOptions16.locale;
        compilerOptions16.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions16.checkControlStructures = false;
        compilerOptions16.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions24.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = null;
        compilerOptions24.setTracer(tracerMode30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions32.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        compilerOptions32.setCheckUnreachableCode(checkLevel43);
        compilerOptions24.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions16.setBrokenClosureRequiresLevel(checkLevel43);
        compilerOptions5.setCheckGlobalThisLevel(checkLevel43);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel43);
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy13 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy13.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setDebugFunctionSideEffectsPath("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        compilerOptions0.labelRenaming = false;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler3.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        compiler3.setOldParseTree("", astRoot7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter9 = compiler3.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck15 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, reverseAbstractInterpreter9, jSTypeRegistry13, checkLevel14);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult20 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node18, astRoot19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.hook(node21, node22, node24);
        java.lang.String str27 = node18.checkTreeEquals(node26);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '#', node26, node29, 2, 100);
        com.google.javascript.rhino.Node node33 = null;
        typeCheck15.visit(nodeTraversal16, node26, node33);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(10);
        boolean boolean37 = node36.isParamList();
        try {
            typeCheck15.check(node36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter9);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str27.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention4, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean8 = closureCodingConvention4.isConstantKey("Not declared as a type name");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot10 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult11 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node9, astRoot10);
        boolean boolean12 = node9.isGetterDef();
        int int13 = node9.getSourceOffset();
        boolean boolean14 = closureCodingConvention4.isOptionalParameter(node9);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.hook(node19, node20, node22);
        java.lang.String str28 = node20.toString(false, true, true);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean33 = node32.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.hook(node29, node30, node32);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node32);
        java.lang.String str36 = closureCodingConvention4.extractClassNameIfProvide(node18, node20);
        boolean boolean37 = node0.hasChild(node20);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "THIS" + "'", str28.equals("THIS"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean25 = compilerOptions0.convertToDottedProperties;
        java.util.Set<java.lang.String> strSet26 = compilerOptions0.stripNameSuffixes;
        com.google.javascript.jscomp.DependencyOptions dependencyOptions27 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean7 = compilerOptions3.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions3.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray13 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel8, diagnosticType11, strArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        int int16 = diagnosticType11.compareTo(diagnosticType15);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType15);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-23) + "'", int16 == (-23));
        org.junit.Assert.assertNotNull(diagnosticGroup17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setAssumeStrictThis(false);
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        compilerOptions0.setDefineToStringLiteral("Not declared as a type name", "THIS");
        boolean boolean9 = compilerOptions0.preferLineBreakAtEndOfFile;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("DiagnosticGroup<checkTypes>(OFF)");
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '#');
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesThis();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = sideEffectFlags2.setAllFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags4 = sideEffectFlags2.setMutatesThis();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertNotNull(sideEffectFlags3);
        org.junit.Assert.assertNotNull(sideEffectFlags4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node27 = node24.srcrefTree(node26);
        boolean boolean28 = node26.isComma();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot30 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult31 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node29, astRoot30);
        node29.detachChildren();
        boolean boolean33 = node26.hasChild(node29);
        boolean boolean34 = node26.mayMutateArguments();
        boolean boolean35 = node26.isComma();
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str37 = compilerOptions36.locale;
        compilerOptions36.aliasAllStrings = true;
        compilerOptions36.setCommonJSModulePathPrefix("hi!");
        java.lang.String str42 = compilerOptions36.checkMissingGetCssNameBlacklist;
        compilerOptions36.checkSymbols = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions45.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray49 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList50 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList50, warningsGuardArray49);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard52 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList50);
        com.google.javascript.jscomp.JSError jSError53 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = composeWarningsGuard52.level(jSError53);
        compilerOptions45.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard52);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.thisNode();
        node56.addChildToFront(node57);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node60 = node57.srcrefTree(node59);
        boolean boolean61 = node59.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions66.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean70 = compilerOptions66.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel71 = compilerOptions66.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray76 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel71, diagnosticType74, strArray76);
        com.google.javascript.jscomp.JSError jSError78 = com.google.javascript.jscomp.JSError.make(node59, diagnosticType62, strArray76);
        java.lang.String str79 = jSError78.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel80 = composeWarningsGuard52.level(jSError78);
        com.google.javascript.jscomp.CheckLevel checkLevel81 = jSError78.getDefaultLevel();
        compilerOptions36.checkGlobalNamesLevel = checkLevel81;
        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.DiagnosticType.error("", "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        java.lang.String[] strArray86 = null;
        com.google.javascript.jscomp.JSError jSError87 = nodeTraversal22.makeError(node26, checkLevel81, diagnosticType85, strArray86);
        com.google.javascript.jscomp.DiagnosticType diagnosticType88 = null;
        try {
            int int89 = diagnosticType85.compareTo(diagnosticType88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(warningsGuardArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(checkLevel54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + checkLevel71 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel71.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertNotNull(jSError78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str79.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel80);
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType85);
        org.junit.Assert.assertNotNull(jSError87);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.labelName("Exceeded max number of optimization iterations: ");
        org.junit.Assert.assertNotNull(node1);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
//        org.junit.Assert.assertNotNull(jSModuleArray0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator7);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceFile8, true);
        com.google.javascript.jscomp.JsAst jsAst11 = new com.google.javascript.jscomp.JsAst(sourceFile8);
        jsAst5.setSourceFile(sourceFile8);
        com.google.javascript.jscomp.SourceFile sourceFile13 = jsAst5.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertNotNull(sourceFile13);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.setInstrumentationTemplate("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions10.setAggressiveVarCheck(checkLevel14);
        java.util.Set<java.lang.String> strSet16 = compilerOptions10.aliasableStrings;
        compilerOptions0.setIdGenerators(strSet16);
        boolean boolean18 = compilerOptions0.exportTestFunctions;
        boolean boolean19 = compilerOptions0.preferLineBreakAtEndOfFile;
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("SCRIPT", charset1);
        boolean boolean3 = sourceFile2.isExtern();
        try {
            java.lang.String str4 = sourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: SCRIPT (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        boolean boolean13 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.checkMissingGetCssNameLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.locale;
        compilerOptions15.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions15.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard28 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup21, checkLevel27);
        compilerOptions15.aggressiveVarCheck = checkLevel27;
        java.util.Set<java.lang.String> strSet30 = compilerOptions15.stripTypePrefixes;
        compilerOptions15.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions15.reportMissingOverride;
        compilerOptions0.checkProvides = checkLevel33;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet30);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt6 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt6);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode8 = compiler0.languageMode();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray9 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str12 = compilerOptions11.locale;
        compilerOptions11.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions11.enableExternExports(true);
        boolean boolean17 = compilerOptions11.extractPrototypeMemberDeclarations;
        compilerOptions11.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.Result result20 = compiler0.compile(jSSourceFileArray9, jSSourceFileArray10, compilerOptions11);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode8.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(jSSourceFileArray9);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setInlineLocalVariables(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node27 = node24.srcrefTree(node26);
        boolean boolean28 = node26.isComma();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot30 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult31 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node29, astRoot30);
        node29.detachChildren();
        boolean boolean33 = node26.hasChild(node29);
        boolean boolean34 = node26.mayMutateArguments();
        boolean boolean35 = node26.isComma();
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str37 = compilerOptions36.locale;
        compilerOptions36.aliasAllStrings = true;
        compilerOptions36.setCommonJSModulePathPrefix("hi!");
        java.lang.String str42 = compilerOptions36.checkMissingGetCssNameBlacklist;
        compilerOptions36.checkSymbols = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions45.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray49 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList50 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList50, warningsGuardArray49);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard52 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList50);
        com.google.javascript.jscomp.JSError jSError53 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = composeWarningsGuard52.level(jSError53);
        compilerOptions45.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard52);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.thisNode();
        node56.addChildToFront(node57);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node60 = node57.srcrefTree(node59);
        boolean boolean61 = node59.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions66 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions66.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean70 = compilerOptions66.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel71 = compilerOptions66.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray76 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel71, diagnosticType74, strArray76);
        com.google.javascript.jscomp.JSError jSError78 = com.google.javascript.jscomp.JSError.make(node59, diagnosticType62, strArray76);
        java.lang.String str79 = jSError78.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel80 = composeWarningsGuard52.level(jSError78);
        com.google.javascript.jscomp.CheckLevel checkLevel81 = jSError78.getDefaultLevel();
        compilerOptions36.checkGlobalNamesLevel = checkLevel81;
        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.DiagnosticType.error("", "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        java.lang.String[] strArray86 = null;
        com.google.javascript.jscomp.JSError jSError87 = nodeTraversal22.makeError(node26, checkLevel81, diagnosticType85, strArray86);
        try {
            com.google.javascript.jscomp.JSModule jSModule88 = nodeTraversal22.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(warningsGuardArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(checkLevel54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(diagnosticType62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + checkLevel71 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel71.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertNotNull(jSError77);
        org.junit.Assert.assertNotNull(jSError78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str79.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel80);
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType85);
        org.junit.Assert.assertNotNull(jSError87);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter9, logger10);
        int int12 = loggerErrorManager11.getWarningCount();
        int int13 = loggerErrorManager11.getErrorCount();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.locale;
        compilerOptions15.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.reportMissingOverride;
        compilerOptions15.setDefineToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", 0.0d);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler23 = compilerOptions15.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler23);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(aliasTransformationHandler23);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.JSError jSError4 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = composeWarningsGuard3.level(jSError4);
        java.lang.String str6 = composeWarningsGuard3.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(checkLevel5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        boolean boolean4 = node3.isTypeOf();
        java.lang.String str8 = node3.toString(true, true, true);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "STRING " + "'", str8.equals("STRING "));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        compilerOptions0.setTweakToStringLiteral("Not declared as a constructor", "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean24 = compilerOptions0.coalesceVariableNames;
        compilerOptions0.deadAssignmentElimination = true;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.ERROR;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setRemoveDeadCode(true);
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        boolean boolean10 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.setLocale("goog.exportProperty");
        com.google.javascript.jscomp.MessageBundle messageBundle13 = null;
        compilerOptions0.messageBundle = messageBundle13;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        boolean boolean6 = node3.isObjectLit();
        boolean boolean7 = node3.isCatch();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        byte[] byteArray6 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray6);
        boolean boolean8 = compilerOptions0.removeUnusedLocalVars;
        compilerOptions0.setComputeFunctionSideEffects(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String str2 = compiler1.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Unknown class name");
        int int3 = sourceFile1.getColumnOfOffset((int) '4');
        int int5 = sourceFile1.getLineOfOffset((int) (short) 1);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setDebugFunctionSideEffectsPath("goog.exportProperty");
        java.util.Set<java.lang.String> strSet18 = compilerOptions0.stripTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        node23.setJSType(jSType26);
        try {
            com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.cast(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        boolean boolean7 = compilerOptions0.ambiguateProperties;
        compilerOptions0.setCollapseAnonymousFunctions(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        try {
            com.google.javascript.jscomp.JSModule jSModule23 = nodeTraversal22.getModule();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str6 = compilerOptions5.locale;
        compilerOptions5.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions5.checkControlStructures = false;
        compilerOptions5.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy13 = compilerOptions5.getCheckEventfulObjectDisposalPolicy();
        compilerOptions5.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str17 = compilerOptions16.locale;
        compilerOptions16.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions16.checkControlStructures = false;
        compilerOptions16.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions24.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = null;
        compilerOptions24.setTracer(tracerMode30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions32.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        compilerOptions32.setCheckUnreachableCode(checkLevel43);
        compilerOptions24.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions16.setBrokenClosureRequiresLevel(checkLevel43);
        compilerOptions5.setCheckGlobalThisLevel(checkLevel43);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel43);
        boolean boolean49 = compilerOptions0.optimizeArgumentsArray;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing50 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setInferTypes(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy13 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy13.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing50 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing50.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.PassConfig passConfig3 = null;
        try {
            compiler0.setPassConfig(passConfig3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions11.setSyntheticBlockStartMarker("Not declared as a type name");
        boolean boolean17 = compilerOptions11.checkControlStructures;
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = compilerOptions11.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat18);
        compilerOptions0.preferLineBreakAtEndOfFile = true;
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(errorFormat18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel18 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        compilerOptions0.setSourceMapDetailLevel(detailLevel18);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(detailLevel18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions2.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = null;
        compilerOptions2.setTracer(tracerMode8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions10.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean20 = compilerOptions16.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.checkGlobalThisLevel;
        compilerOptions10.setCheckUnreachableCode(checkLevel21);
        compilerOptions2.checkMissingGetCssNameLevel = checkLevel21;
        boolean boolean24 = compilerOptions2.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean32 = compilerOptions28.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions28.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel33, diagnosticType36, strArray38);
        compilerOptions2.setAggressiveVarCheck(checkLevel33);
        boolean boolean41 = compilerOptions2.assumeStrictThis();
        compilerOptions2.setRuntimeTypeCheckLogFunction("SCRIPT");
        compiler0.initOptions(compilerOptions2);
        try {
            compiler0.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.JsAst jsAst5 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        com.google.javascript.rhino.InputId inputId6 = jsAst5.getInputId();
        com.google.javascript.rhino.InputId inputId7 = jsAst5.getInputId();
        jsAst5.clearAst();
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.SourceFile sourceFile11 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator10);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(sourceFile11, true);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput13);
        com.google.javascript.jscomp.SourceFile sourceFile15 = compilerInput14.getSourceFile();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        compilerInput14.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler16);
        try {
            com.google.javascript.rhino.Node node19 = jsAst5.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(inputId6);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertNotNull(sourceFile11);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertNull(sourceMap17);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.setRecordFunctionInformation(false);
        boolean boolean8 = compilerOptions0.checkControlStructures;
        boolean boolean9 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        com.google.javascript.rhino.Node node10 = node0.getLastChild();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNull(node10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean7 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setCheckControlStructures(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        node0.setSourceEncodedPositionForTree(43);
        boolean boolean6 = node0.isCase();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.voidNode(node0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        compilerOptions0.setSpecializeInitialModule(true);
        compilerOptions0.renamePrefix = "Not declared as a type name";
        compilerOptions0.setAliasableGlobals("");
        java.lang.String str14 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = compiler0.getTypeRegistry();
        int int4 = compiler0.getErrorCount();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = compiler0.getState();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(jSTypeRegistry3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(intermediateState5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setRemoveUnusedLocalVars(true);
        compilerOptions0.generateExports = false;
        boolean boolean13 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        boolean boolean4 = node1.isFor();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean9 = compilerOptions5.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String[] strArray39 = new java.lang.String[] { "THIS", "this", "hi!", "", "THIS" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("", node1, checkLevel10, diagnosticType17, strArray39);
        int int41 = jSError40.getLineNumber();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.rhino.InputId inputId7 = compilerInput6.getInputId();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(inputId7);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        java.lang.String str6 = compiler0.toSource();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setReplaceStringsReservedStrings(strSet6);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str32 = compilerOptions31.locale;
        compilerOptions31.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions31.checkControlStructures = false;
        compilerOptions31.locale = "";
        compilerOptions31.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler41 = null;
        compilerOptions31.setAliasTransformationHandler(aliasTransformationHandler41);
        compilerOptions31.renamePrefix = "D4J_Closure_123_FIXED_VERSION";
        com.google.javascript.jscomp.CompilerOptions compilerOptions45 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str46 = compilerOptions45.locale;
        compilerOptions45.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions45.checkControlStructures = false;
        compilerOptions45.checkSuspiciousCode = true;
        compilerOptions45.setInstrumentationTemplate("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel59 = null;
        compilerOptions55.setAggressiveVarCheck(checkLevel59);
        java.util.Set<java.lang.String> strSet61 = compilerOptions55.aliasableStrings;
        compilerOptions45.setIdGenerators(strSet61);
        compilerOptions31.setIdGenerators(strSet61);
        compilerOptions0.stripNamePrefixes = strSet61;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(strSet61);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str7 = closureCodingConvention6.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        closureCodingConvention6.applyDelegateRelationship(objectType8, objectType9, objectType10, functionType11, functionType12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        node14.addChildToFront(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node18 = node15.srcrefTree(node17);
        boolean boolean19 = node17.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind21 = closureCodingConvention6.describeFunctionBind(node17, false);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.SourceFile sourceFile24 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator23);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(sourceFile24, true);
        com.google.javascript.jscomp.CompilerInput compilerInput27 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput26);
        java.lang.String str28 = compilerInput26.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.SourceFile sourceFile31 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator30);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(sourceFile31, true);
        compilerInput26.setSourceFile(sourceFile31);
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile31);
        compilerInput5.setSourceFile(sourceFile31);
        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", false);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.global" + "'", str7.equals("goog.global"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(bind21);
        org.junit.Assert.assertNotNull(sourceFile24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Not declared as a type name" + "'", str28.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile31);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        boolean boolean15 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray20 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList21 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList21, warningsGuardArray20);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard23 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList21);
        com.google.javascript.jscomp.JSError jSError24 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = composeWarningsGuard23.level(jSError24);
        compilerOptions16.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard23);
        java.lang.String[] strArray31 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet32 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet32, strArray31);
        compilerOptions16.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet32);
        compilerOptions0.stripTypePrefixes = strSet32;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode36 = compilerOptions0.getTracerMode();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(checkLevel25);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + tracerMode36 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode36.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setMoveFunctionDeclarations(false);
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        node26.addChildToFront(node27);
        boolean boolean29 = node26.isEmpty();
        com.google.javascript.rhino.Node node30 = node23.useSourceInfoIfMissingFrom(node26);
        java.util.Set<java.lang.String> strSet31 = node30.getDirectives();
        boolean boolean32 = node30.isTypeOf();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(strSet31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.hook(node2, node3, node5);
        java.lang.String str11 = node3.toString(false, true, true);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.hook(node12, node13, node15);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap18 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node3, node15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        node19.addChildToFront(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node23 = node20.srcrefTree(node22);
        com.google.javascript.rhino.Node node24 = node15.copyInformationFrom(node20);
        boolean boolean25 = node24.isFalse();
        com.google.javascript.rhino.Node node26 = node1.srcrefTree(node24);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        node24.setJSType(jSType27);
        com.google.javascript.rhino.Node node29 = node0.useSourceInfoFromForTree(node24);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder30 = node24.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "THIS" + "'", str11.equals("THIS"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeMap18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder30);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter4, logger5);
        int int7 = loggerErrorManager6.getErrorCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str9 = compilerOptions8.locale;
        compilerOptions8.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions8.checkControlStructures = false;
        compilerOptions8.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode22 = null;
        compilerOptions16.setTracer(tracerMode22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions24.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean34 = compilerOptions30.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions30.checkGlobalThisLevel;
        compilerOptions24.setCheckUnreachableCode(checkLevel35);
        compilerOptions16.checkMissingGetCssNameLevel = checkLevel35;
        compilerOptions8.setBrokenClosureRequiresLevel(checkLevel35);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.thisNode();
        node39.addChildToFront(node40);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node43 = node40.srcrefTree(node42);
        boolean boolean44 = node42.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions49.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean53 = compilerOptions49.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions49.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray59 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel54, diagnosticType57, strArray59);
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(node42, diagnosticType45, strArray59);
        java.lang.String str62 = jSError61.toString();
        loggerErrorManager6.report(checkLevel35, jSError61);
        int int64 = loggerErrorManager6.getErrorCount();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str62.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean4 = closureCodingConvention0.isConstantKey("Not declared as a type name");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node5, astRoot6);
        boolean boolean8 = node5.isGetterDef();
        int int9 = node5.getSourceOffset();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node15, node16, node18);
        java.lang.String str24 = node16.toString(false, true, true);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean27 = node26.hasChildren();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean29 = node28.hasChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.hook(node25, node26, node28);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap31 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node16, node28);
        java.lang.String str32 = closureCodingConvention0.extractClassNameIfProvide(node14, node16);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot34 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult35 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node33, astRoot34);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean38 = node37.hasChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean40 = node39.hasChildren();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.hook(node36, node37, node39);
        java.lang.String str42 = node33.checkTreeEquals(node41);
        com.google.javascript.rhino.Node node43 = node41.removeChildren();
        com.google.javascript.rhino.Node node44 = null;
        try {
            java.lang.String str45 = closureCodingConvention0.extractClassNameIfProvide(node41, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "THIS" + "'", str24.equals("THIS"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeMap31);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str42.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node43);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        int int5 = compiler0.getWarningCount();
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy6 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal checkEventfulObjectDisposal7 = new com.google.javascript.jscomp.CheckEventfulObjectDisposal((com.google.javascript.jscomp.AbstractCompiler) compiler0, disposalCheckingPolicy6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot10 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult11 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node9, astRoot10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.hook(node12, node13, node15);
        java.lang.String str18 = node9.checkTreeEquals(node17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '#', node17, node20, 2, 100);
        int int24 = node20.getLength();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean29 = node28.hasChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.hook(node27, node28, node30);
        java.lang.String str36 = node28.toString(false, true, true);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean39 = node38.hasChildren();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean41 = node40.hasChildren();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.hook(node37, node38, node40);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap43 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node28, node40);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.thisNode();
        node44.addChildToFront(node45);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node48 = node45.srcrefTree(node47);
        com.google.javascript.rhino.Node node49 = node40.copyInformationFrom(node45);
        boolean boolean50 = node49.isFalse();
        com.google.javascript.rhino.Node node51 = node26.srcrefTree(node49);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        node49.setJSType(jSType52);
        com.google.javascript.rhino.Node node54 = node25.useSourceInfoFromForTree(node49);
        try {
            checkEventfulObjectDisposal7.process(node20, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy6 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy6.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str18.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "THIS" + "'", str36.equals("THIS"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeMap43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node54);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isDefaultCase();
        int int6 = node0.getLineno();
        node0.setSourceEncodedPosition(56);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap12 = compiler11.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler11.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot15 = null;
        compiler11.setOldParseTree("", astRoot15);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter17 = compiler11.getReverseAbstractInterpreter();
        boolean boolean18 = compiler11.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt19);
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter20, logger21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str24 = compilerOptions23.locale;
        compilerOptions23.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.reportMissingOverride;
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        node28.addChildToFront(node29);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node32 = node29.srcrefTree(node31);
        boolean boolean33 = node31.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray48 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel43, diagnosticType46, strArray48);
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(node31, diagnosticType34, strArray48);
        java.lang.String str51 = jSError50.toString();
        loggerErrorManager22.println(checkLevel27, jSError50);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager22);
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(sourceMap12);
        org.junit.Assert.assertNotNull(errorManager13);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str51.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setInlineLocalVariables(false);
        compilerOptions0.setInlineGetters(false);
        org.junit.Assert.assertNotNull(locationMappingList8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.hook(node2, node3, node5);
        boolean boolean8 = node2.isSwitch();
        com.google.javascript.rhino.Node node9 = node2.cloneNode();
        boolean boolean10 = node2.isAnd();
        boolean boolean11 = closureCodingConvention0.isPrototypeAlias(node2);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        node13.addChildToBack(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.returnNode();
        int int18 = node17.getSideEffectFlags();
        java.lang.String str19 = closureCodingConvention0.extractClassNameIfRequire(node14, node17);
        java.lang.String str20 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "goog.exportProperty" + "'", str20.equals("goog.exportProperty"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = compiler0.getTypeRegistry();
        int int4 = compiler0.getErrorCount();
        int int5 = compiler0.getErrorCount();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(jSTypeRegistry3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("SCRIPT");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.regexp(node1);
        boolean boolean4 = node1.getBooleanProp(16);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.setAngularPass(false);
        compilerOptions0.setCollapseObjectLiterals(true);
        boolean boolean16 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.returnNode();
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isCast();
        boolean boolean6 = closureCodingConvention0.isVarArgsParameter(node3);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot8 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult9 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node7, astRoot8);
        com.google.javascript.rhino.Node node10 = parseResult9.ast;
        boolean boolean11 = node10.isQualifiedName();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        node12.addChildToFront(node13);
        boolean boolean15 = node12.isFor();
        boolean boolean16 = node12.isExprResult();
        int int17 = node12.getCharno();
        com.google.javascript.rhino.Node node18 = node10.useSourceInfoIfMissingFrom(node12);
        java.util.Map<java.lang.String, java.lang.String> strMap19 = null;
        closureCodingConvention0.checkForCallingConventionDefiningCalls(node10, strMap19);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        boolean boolean21 = node18.isFor();
        node18.setSourceEncodedPositionForTree((int) '#');
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast24 = closureCodingConvention0.getObjectLiteralCast(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        boolean boolean12 = node6.isNumber();
        java.lang.String str13 = closureCodingConvention0.extractClassNameIfRequire(node5, node6);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType15 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType14, functionType15, objectType16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.cast(node1);
        boolean boolean6 = node1.isGetProp();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        boolean boolean14 = node11.isFor();
        boolean boolean15 = node11.isExprResult();
        boolean boolean16 = node11.isDefaultCase();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node17, node18, node20);
        node11.addChildrenToBack(node22);
        boolean boolean24 = node22.isLocalResultCall();
        com.google.javascript.rhino.Node node25 = null;
        try {
            node3.addChildAfter(node22, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        compilerOptions0.setSpecializeInitialModule(true);
        compilerOptions0.renamePrefix = "Not declared as a type name";
        compilerOptions0.setAliasableGlobals("");
        compilerOptions0.setNameReferenceGraphPath("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "Not declared as a constructor", true);
        try {
            com.google.javascript.jscomp.Region region9 = compilerInput4.getRegion(43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult3 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node1, astRoot2);
        com.google.javascript.rhino.Node node4 = parseResult3.ast;
        boolean boolean5 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        node6.addChildToFront(node7);
        boolean boolean9 = node6.isFor();
        boolean boolean10 = node6.isExprResult();
        int int11 = node6.getCharno();
        com.google.javascript.rhino.Node node12 = node4.useSourceInfoIfMissingFrom(node6);
        com.google.javascript.rhino.Node node13 = node0.copyInformationFromForTree(node6);
        int int14 = node13.getLineno();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOutputCharset("THIS");
        compilerOptions0.setAliasAllStrings(true);
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isPrivate("Not declared as a type name");
        boolean boolean6 = closureCodingConvention0.isExported("goog.global", false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        node7.addChildToFront(node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node11 = node8.srcrefTree(node10);
        boolean boolean12 = node8.isNE();
        com.google.javascript.jscomp.CodingConvention.Bind bind14 = closureCodingConvention0.describeFunctionBind(node8, true);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot16 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult17 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node15, astRoot16);
        boolean boolean18 = node15.isGetterDef();
        int int19 = node15.getSourceOffset();
        com.google.javascript.rhino.Node node20 = node8.useSourceInfoFromForTree(node15);
        com.google.javascript.rhino.Node node21 = null;
        try {
            com.google.javascript.rhino.Node node22 = node8.copyInformationFromForTree(node21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(bind14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing6 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        boolean boolean9 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + tweakProcessing6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing6.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setInlineVariables(true);
        compilerOptions0.checkTypes = false;
        boolean boolean13 = compilerOptions0.lineBreak;
        compilerOptions0.convertToDottedProperties = false;
        boolean boolean16 = compilerOptions0.getCheckDeterminism();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(logger8);
        loggerErrorManager9.generateReport();
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        compilerOptions0.setSpecializeInitialModule(true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str7 = closureCodingConvention6.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        closureCodingConvention6.applyDelegateRelationship(objectType8, objectType9, objectType10, functionType11, functionType12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        node14.addChildToFront(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node18 = node15.srcrefTree(node17);
        boolean boolean19 = node17.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind21 = closureCodingConvention6.describeFunctionBind(node17, false);
        com.google.javascript.jscomp.SourceFile.Generator generator23 = null;
        com.google.javascript.jscomp.SourceFile sourceFile24 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator23);
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(sourceFile24, true);
        com.google.javascript.jscomp.CompilerInput compilerInput27 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput26);
        java.lang.String str28 = compilerInput26.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator30 = null;
        com.google.javascript.jscomp.SourceFile sourceFile31 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator30);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(sourceFile31, true);
        compilerInput26.setSourceFile(sourceFile31);
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile31);
        compilerInput5.setSourceFile(sourceFile31);
        try {
            int int38 = sourceFile31.getLineOfOffset((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.global" + "'", str7.equals("goog.global"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(bind21);
        org.junit.Assert.assertNotNull(sourceFile24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Not declared as a type name" + "'", str28.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile31);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = diagnosticGroups0.forName("hi!");
        org.junit.Assert.assertNull(diagnosticGroup2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        boolean boolean14 = compilerOptions0.getInferTypes();
        compilerOptions0.setCoalesceVariableNames(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.hook(node2, node3, node5);
        boolean boolean8 = node2.isSwitch();
        com.google.javascript.rhino.Node node9 = node2.cloneNode();
        boolean boolean10 = node2.isAnd();
        boolean boolean11 = closureCodingConvention0.isPrototypeAlias(node2);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast16 = closureCodingConvention0.getObjectLiteralCast(node15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setDefineToBooleanLiteral("", true);
        boolean boolean25 = compilerOptions0.rewriteFunctionExpressions;
        java.util.Set<java.lang.String> strSet26 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions23 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        compilerOptions0.setRuntimeTypeCheck(false);
        java.util.Map<java.lang.String, java.lang.Object> strMap33 = null;
        compilerOptions0.setTweakReplacements(strMap33);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy12 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray13 = anonymousFunctionNamingPolicy12.getReservedCharacters();
        compilerOptions0.setAnonymousFunctionNaming(anonymousFunctionNamingPolicy12);
        compilerOptions0.setFlowSensitiveInlineVariables(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy12 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy12.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray13);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.aliasKeywords = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str25 = compilerOptions24.locale;
        compilerOptions24.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions24.checkControlStructures = false;
        compilerOptions24.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy32 = compilerOptions24.getCheckEventfulObjectDisposalPolicy();
        compilerOptions24.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions35 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str36 = compilerOptions35.locale;
        compilerOptions35.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions35.checkControlStructures = false;
        compilerOptions35.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions43.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions43.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode49 = null;
        compilerOptions43.setTracer(tracerMode49);
        com.google.javascript.jscomp.CompilerOptions compilerOptions51 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions51.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions51.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean61 = compilerOptions57.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions57.checkGlobalThisLevel;
        compilerOptions51.setCheckUnreachableCode(checkLevel62);
        compilerOptions43.checkMissingGetCssNameLevel = checkLevel62;
        compilerOptions35.setBrokenClosureRequiresLevel(checkLevel62);
        compilerOptions24.setCheckGlobalThisLevel(checkLevel62);
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel62);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy32 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy32.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean16 = compilerOptions12.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions12.checkGlobalThisLevel;
        compilerOptions6.setCheckMissingReturn(checkLevel17);
        compilerOptions0.aggressiveVarCheck = checkLevel17;
        boolean boolean20 = compilerOptions0.isDisambiguatePrivateProperties();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        boolean boolean4 = node1.isFor();
        boolean boolean5 = node1.isExprResult();
        boolean boolean6 = node1.isDefaultCase();
        boolean boolean7 = node1.isCase();
        com.google.javascript.rhino.Node node8 = node1.cloneTree();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.sub(node0, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        compilerOptions0.setAggressiveVarCheck(checkLevel31);
        boolean boolean39 = compilerOptions0.assumeStrictThis();
        compilerOptions0.setRuntimeTypeCheckLogFunction("SCRIPT");
        boolean boolean42 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap43 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap43);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing6 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.setUnaliasableGlobals("");
        compilerOptions0.setDefineToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", (double) 43);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + tweakProcessing6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing6.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        byte[] byteArray6 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray6);
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy10 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy10 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy10.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isWith();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setLooseTypes(true);
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNotNull(locationMappingList8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setInferTypes(false);
        boolean boolean15 = compilerOptions0.getCheckDeterminism();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.lineBreak = true;
        compilerOptions0.setDisambiguateProperties(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy21 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        boolean boolean22 = compilerOptions0.removeUnusedVars;
        boolean boolean23 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy21 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy21.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions2.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = null;
        compilerOptions2.setTracer(tracerMode8);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions10.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean20 = compilerOptions16.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.checkGlobalThisLevel;
        compilerOptions10.setCheckUnreachableCode(checkLevel21);
        compilerOptions2.checkMissingGetCssNameLevel = checkLevel21;
        boolean boolean24 = compilerOptions2.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean32 = compilerOptions28.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions28.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel33, diagnosticType36, strArray38);
        compilerOptions2.setAggressiveVarCheck(checkLevel33);
        boolean boolean41 = compilerOptions2.assumeStrictThis();
        compilerOptions2.setRuntimeTypeCheckLogFunction("SCRIPT");
        compiler0.initOptions(compilerOptions2);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing45 = compilerOptions2.getTweakProcessing();
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing45 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing45.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isPrivate("Not declared as a type name");
        boolean boolean6 = closureCodingConvention0.isExported("goog.global", false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        node7.addChildToFront(node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node11 = node8.srcrefTree(node10);
        boolean boolean12 = node8.isNE();
        com.google.javascript.jscomp.CodingConvention.Bind bind14 = closureCodingConvention0.describeFunctionBind(node8, true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str16 = closureCodingConvention15.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = null;
        closureCodingConvention15.applyDelegateRelationship(objectType17, objectType18, objectType19, functionType20, functionType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node27 = node24.srcrefTree(node26);
        boolean boolean28 = node26.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind30 = closureCodingConvention15.describeFunctionBind(node26, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection31 = closureCodingConvention15.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection32 = closureCodingConvention15.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        node33.addChildToFront(node34);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node37 = node34.srcrefTree(node36);
        boolean boolean38 = node34.isNE();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot43 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult44 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node42, astRoot43);
        java.lang.String str45 = closureCodingConvention15.extractClassNameIfRequire(node34, node42);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec47 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean49 = node48.hasChildren();
        java.lang.String str50 = node48.getQualifiedName();
        int int51 = node48.getChildCount();
        com.google.javascript.jscomp.Compiler compiler52 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap53 = compiler52.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager54 = compiler52.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = compiler52.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType56 = assertInstanceofSpec47.getAssertedType(node48, jSTypeRegistry55);
        java.lang.String str57 = closureCodingConvention0.extractClassNameIfProvide(node42, node48);
        java.util.Collection<java.lang.String> strCollection58 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(bind14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.global" + "'", str16.equals("goog.global"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(bind30);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection31);
        org.junit.Assert.assertNotNull(strCollection32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "this" + "'", str50.equals("this"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(sourceMap53);
        org.junit.Assert.assertNotNull(errorManager54);
        org.junit.Assert.assertNotNull(jSTypeRegistry55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(strCollection58);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.hook(node5, node6, node8);
        java.lang.String str14 = node6.toString(false, true, true);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node15, node16, node18);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node6, node18);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        node22.addChildToFront(node23);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node26 = node23.srcrefTree(node25);
        com.google.javascript.rhino.Node node27 = node18.copyInformationFrom(node23);
        boolean boolean28 = node27.isFalse();
        com.google.javascript.rhino.Node node29 = node4.srcrefTree(node27);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        node27.setJSType(jSType30);
        com.google.javascript.rhino.Node node32 = node3.useSourceInfoFromForTree(node27);
        com.google.javascript.jscomp.CodingConvention.Bind bind34 = closureCodingConvention0.describeFunctionBind(node3, false);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        try {
            com.google.javascript.rhino.Node node39 = node3.getChildBefore(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "THIS" + "'", str14.equals("THIS"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(bind34);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        compilerOptions0.setGeneratePseudoNames(true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        com.google.javascript.rhino.InputId inputId7 = compilerInput5.getInputId();
        try {
            java.lang.String str8 = compilerInput5.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(inputId7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        boolean boolean15 = compilerOptions0.printInputDelimiter;
        boolean boolean16 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOptimizeParameters(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, false);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState6 = compiler5.getState();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        org.junit.Assert.assertNull(inputId4);
        org.junit.Assert.assertNotNull(intermediateState6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node0.mayMutateArguments();
        boolean boolean11 = node0.isCast();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode5 = compilerOptions0.getLanguageIn();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + languageMode5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode5.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("(goog.exportSymbol)", generator1);
        sourceFile2.setOriginalPath("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str26 = closureCodingConvention25.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType27 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType30 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType31 = null;
        closureCodingConvention25.applyDelegateRelationship(objectType27, objectType28, objectType29, functionType30, functionType31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        node33.addChildToFront(node34);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node37 = node34.srcrefTree(node36);
        boolean boolean38 = node36.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind40 = closureCodingConvention25.describeFunctionBind(node36, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection41 = closureCodingConvention25.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection42 = closureCodingConvention25.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        node43.addChildToFront(node44);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node47 = node44.srcrefTree(node46);
        boolean boolean48 = node44.isNE();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot53 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult54 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node52, astRoot53);
        java.lang.String str55 = closureCodingConvention25.extractClassNameIfRequire(node44, node52);
        node23.addChildrenToBack(node52);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean59 = node58.hasChildren();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean61 = node60.hasChildren();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.hook(node57, node58, node60);
        boolean boolean63 = node57.isSwitch();
        node57.setSourceEncodedPosition(39);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.string("");
        try {
            com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) 10, node52, node57, node67, (-1), 40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "goog.global" + "'", str26.equals("goog.global"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(bind40);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection41);
        org.junit.Assert.assertNotNull(strCollection42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        boolean boolean5 = node1.wasEmptyNode();
        boolean boolean6 = node1.isInc();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckDeterminism(false);
        compilerOptions0.optimizeCalls = false;
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection2 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58", 46, 8);
        boolean boolean8 = node7.isSetterDef();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = closureCodingConvention0.describeFunctionBind(node7, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention13 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str14 = closureCodingConvention13.getGlobalObject();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node15, node16, node18);
        boolean boolean21 = node15.isSwitch();
        com.google.javascript.rhino.Node node22 = node15.cloneNode();
        boolean boolean23 = node15.isAnd();
        boolean boolean24 = closureCodingConvention13.isPrototypeAlias(node15);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58");
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean28 = node27.hasChildren();
        node26.addChildToBack(node27);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.returnNode();
        int int31 = node30.getSideEffectFlags();
        java.lang.String str32 = closureCodingConvention13.extractClassNameIfRequire(node27, node30);
        com.google.javascript.rhino.Node node33 = null;
        try {
            java.lang.String str34 = closureCodingConvention0.extractClassNameIfProvide(node27, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.global" + "'", str12.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "goog.global" + "'", str14.equals("goog.global"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.generateExports = true;
        boolean boolean28 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticType6.level;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType6);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        java.lang.String str16 = node8.toString(false, true, true);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node17, node18, node20);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap23 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node8, node20);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        node24.addChildToFront(node25);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node28 = node25.srcrefTree(node27);
        com.google.javascript.rhino.Node node29 = node20.copyInformationFrom(node25);
        boolean boolean30 = node29.isFalse();
        com.google.javascript.rhino.Node node31 = node6.srcrefTree(node29);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        node29.setJSType(jSType32);
        com.google.javascript.rhino.Node node34 = node5.useSourceInfoFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean37 = node36.hasChildren();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean39 = node38.hasChildren();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.hook(node35, node36, node38);
        boolean boolean41 = node35.isSwitch();
        com.google.javascript.rhino.Node node42 = node35.cloneNode();
        boolean boolean43 = node29.hasChild(node42);
        try {
            com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.sheq(node1, node42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "THIS" + "'", str16.equals("THIS"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeMap23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.cast(node1);
        boolean boolean6 = node1.isLabel();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setSummaryDetailLevel(0);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType1 = com.google.javascript.rhino.jstype.JSType.toMaybeFunctionType(jSType0);
        org.junit.Assert.assertNull(functionType1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.setRemoveDeadCode(true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.setRecordFunctionInformation(false);
        boolean boolean8 = compilerOptions0.checkControlStructures;
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        node10.addChildToFront(node11);
        boolean boolean13 = node10.isFor();
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        node20.addChildToFront(node21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node24 = node21.srcrefTree(node23);
        boolean boolean25 = node23.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions30.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean34 = compilerOptions30.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = compilerOptions30.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray40 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel35, diagnosticType38, strArray40);
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make(node23, diagnosticType26, strArray40);
        java.lang.String[] strArray48 = new java.lang.String[] { "THIS", "this", "hi!", "", "THIS" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", node10, checkLevel19, diagnosticType26, strArray48);
        compilerOptions0.aggressiveVarCheck = checkLevel19;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = compiler0.getOldParseTreeByName("this");
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.locale;
        compilerOptions7.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions7.checkControlStructures = false;
        compilerOptions7.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy15 = compilerOptions7.getCheckEventfulObjectDisposalPolicy();
        compilerOptions7.setAngularPass(true);
        compiler0.initOptions(compilerOptions7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter19 = compiler0.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator21);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceFile22, true);
        com.google.javascript.jscomp.JsAst jsAst25 = new com.google.javascript.jscomp.JsAst(sourceFile22);
        com.google.javascript.rhino.InputId inputId26 = jsAst25.getInputId();
        com.google.javascript.rhino.InputId inputId27 = jsAst25.getInputId();
        jsAst25.clearAst();
        try {
            compiler0.replaceScript(jsAst25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(astRoot6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy15 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy15.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter19);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertNotNull(inputId26);
        org.junit.Assert.assertNotNull(inputId27);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "Not declared as a constructor", true);
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput4.getModule();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isDefaultCase();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        node0.addChildrenToBack(node11);
        boolean boolean13 = node11.isLocalResultCall();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        node14.addChildToFront(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node18 = node15.srcrefTree(node17);
        boolean boolean19 = node17.isComma();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot21 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult22 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node20, astRoot21);
        node20.detachChildren();
        boolean boolean24 = node17.hasChild(node20);
        boolean boolean25 = node20.isSyntheticBlock();
        try {
            com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.regexp(node11, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        java.lang.String str12 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.setAliasKeywords(false);
        compilerOptions0.checkControlStructures = true;
        com.google.javascript.jscomp.CodingConvention codingConvention17 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(codingConvention17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.removeUnusedClassProperties = true;
        boolean boolean11 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setInlineVariables(true);
        boolean boolean11 = compilerOptions0.isRemoveUnusedClassProperties();
        compilerOptions0.checkControlStructures = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        boolean boolean8 = compilerOptions0.preferLineBreakAtEndOfFile;
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray24 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel19, diagnosticType22, strArray24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        node26.addChildToFront(node27);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node30 = node27.srcrefTree(node29);
        boolean boolean31 = node29.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions36.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean40 = compilerOptions36.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions36.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray46 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel41, diagnosticType44, strArray46);
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make(node29, diagnosticType32, strArray46);
        loggerErrorManager10.report(checkLevel19, jSError48);
        compilerOptions0.setCheckRequires(checkLevel19);
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(jSError48);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        boolean boolean1 = node0.hasChildren();
        java.lang.Appendable appendable2 = null;
        try {
            node0.appendStringTree(appendable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean5 = compilerOptions1.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean15 = compilerOptions11.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions11.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray21 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel16, diagnosticType19, strArray21);
        com.google.javascript.jscomp.CheckLevel checkLevel23 = diagnosticGroupWarningsGuard7.level(jSError22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        boolean boolean25 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup24);
        com.google.javascript.jscomp.Compiler compiler26 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap27 = compiler26.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager28 = compiler26.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot30 = null;
        compiler26.setOldParseTree("", astRoot30);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter32 = compiler26.getReverseAbstractInterpreter();
        boolean boolean33 = compiler26.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt34 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter35 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler26, sourceExcerpt34);
        java.util.logging.Logger logger36 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager37 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter35, logger36);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str39 = compilerOptions38.locale;
        compilerOptions38.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions38.reportMissingOverride;
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        node43.addChildToFront(node44);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node47 = node44.srcrefTree(node46);
        boolean boolean48 = node46.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean57 = compilerOptions53.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions53.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray63 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError64 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel58, diagnosticType61, strArray63);
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make(node46, diagnosticType49, strArray63);
        java.lang.String str66 = jSError65.toString();
        loggerErrorManager37.println(checkLevel42, jSError65);
        com.google.javascript.jscomp.CheckLevel checkLevel68 = diagnosticGroupWarningsGuard7.level(jSError65);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNull(checkLevel23);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(sourceMap27);
        org.junit.Assert.assertNotNull(errorManager28);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str66.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel68);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        boolean boolean11 = node3.mayMutateArguments();
        boolean boolean12 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node13 = node3.removeFirstChild();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean23 = compilerOptions0.lineBreak;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.setRenamePrefix("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString(10, "this", 0, (-1));
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.comma(node0, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("(Unknown class name)", generator1);
        java.lang.Class<?> wildcardClass3 = sourceFile2.getClass();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.lineBreak = true;
        compilerOptions0.setSourceMapOutputPath("goog.abstractMethod");
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy12 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF;
        compilerOptions0.setCheckEventfulObjectDisposalPolicy(disposalCheckingPolicy12);
        java.util.Set<java.lang.String> strSet14 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy12 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy12.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        boolean boolean4 = node0.isString();
        boolean boolean5 = node0.isThrow();
        java.lang.String str9 = node0.toString(true, false, false);
        int int10 = node0.getLength();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        boolean boolean21 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.String str22 = compilerOptions0.renamePrefixNamespace;
        boolean boolean23 = compilerOptions0.isDisambiguatePrivateProperties();
        compilerOptions0.devirtualizePrototypeMethods = false;
        boolean boolean26 = compilerOptions0.optimizeParameters;
        compilerOptions0.setRemoveClosureAsserts(false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isEmpty();
        java.lang.Object obj7 = node0.getProp(49);
        int int8 = node0.getSideEffectFlags();
        boolean boolean9 = node0.isGetProp();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel11, diagnosticType14, strArray16);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        boolean boolean23 = node21.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean32 = compilerOptions28.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions28.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel33, diagnosticType36, strArray38);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(node21, diagnosticType24, strArray38);
        loggerErrorManager2.report(checkLevel11, jSError40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = jSError40.getType();
        boolean boolean43 = diagnosticGroup0.matches(diagnosticType42);
        java.lang.String str44 = diagnosticType42.toString();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup45 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType42);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertNotNull(diagnosticGroup45);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkRequires;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.setSyntheticBlockStartMarker("hi!");
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = parseResult2.ast;
        boolean boolean4 = node3.isQualifiedName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        node5.addChildToFront(node6);
        boolean boolean8 = node5.isFor();
        boolean boolean9 = node5.isExprResult();
        int int10 = node5.getCharno();
        com.google.javascript.rhino.Node node11 = node3.useSourceInfoIfMissingFrom(node5);
        boolean boolean12 = node11.isLocalResultCall();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.setRemoveClosureAsserts(false);
        boolean boolean12 = compilerOptions0.collapseProperties;
        boolean boolean13 = compilerOptions0.recordFunctionInformation;
        boolean boolean14 = compilerOptions0.inlineConstantVars;
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList15 = compilerOptions0.sourceMapLocationMappings;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(locationMappingList15);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isLocalResultCall();
        com.google.javascript.rhino.Node node4 = node1.removeFirstChild();
        try {
            com.google.javascript.rhino.Node node5 = node4.getNext();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setGroupVariableDeclarations(true);
        java.lang.String str5 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.setCommonJSModulePathPrefix("D4J_Closure_123_FIXED_VERSION");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.fromString("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        int int16 = node11.getSourceOffset();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray6 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0, diagnosticType1, diagnosticType4, diagnosticType5 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray6);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticTypeArray6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.syntheticBlockStartMarker = "2019/06/13 15:58";
        compilerOptions0.setRemoveUnusedVars(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<java.lang.String> strCollection16 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        java.lang.String str17 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(strCollection16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportProperty" + "'", str17.equals("goog.exportProperty"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        compilerOptions0.setOutputCharset("SCRIPT");
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str25 = compilerOptions24.locale;
        compilerOptions24.aliasAllStrings = true;
        compilerOptions24.setCheckTypes(false);
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing30 = compilerOptions24.getTweakProcessing();
        com.google.javascript.jscomp.CompilerOptions.Reach reach31 = com.google.javascript.jscomp.CompilerOptions.Reach.NONE;
        compilerOptions24.setInlineVariables(reach31);
        compilerOptions0.setInlineVariables(reach31);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + tweakProcessing30 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing30.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + reach31 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.NONE + "'", reach31.equals(com.google.javascript.jscomp.CompilerOptions.Reach.NONE));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.Node node27 = node26.getLastSibling();
        boolean boolean28 = node26.isGetElem();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        node29.addChildToFront(node30);
        boolean boolean32 = node29.isEmpty();
        com.google.javascript.rhino.Node node33 = node29.getLastChild();
        try {
            typeCheck21.process(node26, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.VariableMap variableMap6 = null;
        compilerOptions0.setReplaceStringsInputMap(variableMap6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.level;
        compilerOptions0.setCheckMissingReturn(checkLevel11);
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("Not declared as a constructor");
        com.google.javascript.jscomp.SourceFile.Generator generator4 = null;
        com.google.javascript.jscomp.SourceFile sourceFile5 = builder0.buildFromGenerator("D4J_Closure_123_FIXED_VERSION", generator4);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile8 = builder0.buildFromCode("", "(Unknown class name)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        com.google.javascript.rhino.Node node10 = node0.cloneNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        com.google.javascript.rhino.Node node17 = node10.useSourceInfoIfMissingFrom(node14);
        node14.removeProp(56);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        boolean boolean4 = node1.isFor();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean9 = compilerOptions5.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String[] strArray39 = new java.lang.String[] { "THIS", "this", "hi!", "", "THIS" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("", node1, checkLevel10, diagnosticType17, strArray39);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str42 = compilerOptions41.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions43.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray47 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList48 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList48, warningsGuardArray47);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard50 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList48);
        com.google.javascript.jscomp.JSError jSError51 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel52 = composeWarningsGuard50.level(jSError51);
        compilerOptions43.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard50);
        java.lang.String[] strArray58 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet59 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet59, strArray58);
        compilerOptions43.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet59);
        compilerOptions41.aliasableStrings = strSet59;
        compilerOptions41.setIdeMode(false);
        compilerOptions41.lineBreak = false;
        compilerOptions41.setTightenTypes(true);
        boolean boolean69 = diagnosticType17.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(warningsGuardArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(checkLevel52);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.lineBreak = false;
        compilerOptions0.setCollapseProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str29 = compilerOptions28.locale;
        compilerOptions28.aliasAllStrings = true;
        compilerOptions28.setCheckTypes(false);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions28.checkRequires;
        compilerOptions0.checkProvides = checkLevel34;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        compilerOptions0.errorFormat = errorFormat8;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(errorFormat8);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        compiler0.setOldParseTree("Exceeded max number of optimization iterations: ", astRoot11);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        compilerOptions0.setComputeFunctionSideEffects(true);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        boolean boolean20 = node17.isFor();
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node27.addChildToFront(node28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node31 = node28.srcrefTree(node30);
        boolean boolean32 = node30.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean41 = compilerOptions37.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray47 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel42, diagnosticType45, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make(node30, diagnosticType33, strArray47);
        java.lang.String[] strArray55 = new java.lang.String[] { "THIS", "this", "hi!", "", "THIS" };
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("", node17, checkLevel26, diagnosticType33, strArray55);
        compilerOptions0.checkGlobalThisLevel = checkLevel26;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, false);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(inputId4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.setMoveFunctionDeclarations(true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        compilerOptions0.setReportPath("DiagnosticGroup<checkTypes>(OFF)");
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.locale;
        compilerOptions6.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions6.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean17 = compilerOptions13.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel18);
        compilerOptions6.aggressiveVarCheck = checkLevel18;
        compiler0.initOptions(compilerOptions6);
        com.google.javascript.jscomp.CodingConvention codingConvention22 = compiler0.getCodingConvention();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(codingConvention22);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        boolean boolean8 = compilerOptions0.isDisambiguatePrivateProperties();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getTweakReplacements();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions14.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean24 = compilerOptions20.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions20.checkGlobalThisLevel;
        compilerOptions14.setCheckUnreachableCode(checkLevel25);
        compilerOptions0.checkUnreachableCode = checkLevel25;
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("SCRIPT", charset1);
        boolean boolean3 = sourceFile2.isExtern();
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot17 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult18 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node16, astRoot17);
        boolean boolean19 = node16.isGetterDef();
        java.lang.String str20 = node16.getQualifiedName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention21 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str22 = closureCodingConvention21.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection23 = closureCodingConvention21.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        node25.addChildToFront(node26);
        com.google.javascript.rhino.Node node28 = node24.useSourceInfoFrom(node26);
        com.google.javascript.jscomp.CodingConvention.Bind bind30 = closureCodingConvention21.describeFunctionBind(node24, false);
        java.lang.String str31 = closureCodingConvention0.extractClassNameIfProvide(node16, node24);
        node24.putBooleanProp(39, true);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "goog.global" + "'", str22.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNull(bind30);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        boolean boolean15 = compilerOptions0.printInputDelimiter;
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        boolean boolean11 = node3.mayMutateArguments();
        boolean boolean12 = node3.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        node13.addChildToFront(node14);
        boolean boolean16 = node14.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec18 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean20 = node19.hasChildren();
        java.lang.String str21 = node19.getQualifiedName();
        int int22 = node19.getChildCount();
        com.google.javascript.jscomp.Compiler compiler23 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap24 = compiler23.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager25 = compiler23.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = compiler23.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType27 = assertInstanceofSpec18.getAssertedType(node19, jSTypeRegistry26);
        com.google.javascript.rhino.jstype.JSType jSType29 = jSType27.getRestrictedTypeGivenToBooleanOutcome(true);
        node14.setJSType(jSType27);
        boolean boolean31 = node14.isAdd();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention32 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str33 = closureCodingConvention32.getGlobalObject();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean36 = node35.hasChildren();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean38 = node37.hasChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node34, node35, node37);
        boolean boolean40 = node34.isSwitch();
        com.google.javascript.rhino.Node node41 = node34.cloneNode();
        boolean boolean42 = node34.isAnd();
        boolean boolean43 = closureCodingConvention32.isPrototypeAlias(node34);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("this");
        java.lang.String str46 = com.google.javascript.jscomp.NodeUtil.getSourceName(node45);
        com.google.javascript.jscomp.CodingConvention.Bind bind48 = closureCodingConvention32.describeFunctionBind(node45, true);
        try {
            com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.forIn(node3, node14, node45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "this" + "'", str21.equals("this"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(sourceMap24);
        org.junit.Assert.assertNotNull(errorManager25);
        org.junit.Assert.assertNotNull(jSTypeRegistry26);
        org.junit.Assert.assertNotNull(jSType27);
        org.junit.Assert.assertNotNull(jSType29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.global" + "'", str33.equals("goog.global"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNull(bind48);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        boolean boolean23 = node3.isNE();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean26 = node25.hasChildren();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean28 = node27.hasChildren();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.hook(node24, node25, node27);
        java.lang.String str33 = node25.toString(false, true, true);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean36 = node35.hasChildren();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean38 = node37.hasChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node34, node35, node37);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap40 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node25, node37);
        node37.putIntProp((int) ' ', (int) (short) 10);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot45 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult46 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node44, astRoot45);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot48 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult49 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node47, astRoot48);
        com.google.javascript.rhino.Node node50 = parseResult49.ast;
        boolean boolean51 = node50.isQualifiedName();
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.thisNode();
        node52.addChildToFront(node53);
        boolean boolean55 = node52.isFor();
        boolean boolean56 = node52.isExprResult();
        int int57 = node52.getCharno();
        com.google.javascript.rhino.Node node58 = node50.useSourceInfoIfMissingFrom(node52);
        boolean boolean59 = node58.isLocalResultCall();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean62 = node61.hasChildren();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean64 = node63.hasChildren();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.IR.hook(node60, node61, node63);
        java.lang.String str69 = node61.toString(false, true, true);
        com.google.javascript.rhino.Node[] nodeArray70 = new com.google.javascript.rhino.Node[] { node37, node44, node58, node61 };
        try {
            com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.call(node3, nodeArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "THIS" + "'", str33.equals("THIS"));
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeMap40);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "THIS" + "'", str69.equals("THIS"));
        org.junit.Assert.assertNotNull(nodeArray70);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.locale;
        compilerOptions6.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions6.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean17 = compilerOptions13.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel18);
        compilerOptions6.aggressiveVarCheck = checkLevel18;
        compiler0.initOptions(compilerOptions6);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder22 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.returnNode();
        int int25 = node24.getSideEffectFlags();
        boolean boolean26 = node24.isCast();
        compiler0.toSource(codeBuilder22, 0, node24);
        double double28 = compiler0.getProgress();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSType10.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec14 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        java.lang.String str17 = node15.getQualifiedName();
        int int18 = node15.getChildCount();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler19.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler19.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = compiler19.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType23 = assertInstanceofSpec14.getAssertedType(node15, jSTypeRegistry22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSType23.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean26 = jSType12.isEquivalentTo(jSType23);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        java.util.List<java.lang.String> strList28 = simpleErrorReporter27.warnings();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope29 = null;
        com.google.javascript.rhino.jstype.JSType jSType30 = jSType23.resolve((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, jSTypeStaticScope29);
        jSType30.clearResolved();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "this" + "'", str17.equals("this"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(sourceMap20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(jSTypeRegistry22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(strList28);
        org.junit.Assert.assertNotNull(jSType30);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.setCoalesceVariableNames(false);
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean17 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean18 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.isNumber();
        com.google.javascript.rhino.Node node7 = node0.cloneTree();
        boolean boolean8 = node0.isOptionalArg();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean25 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.returnNode();
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isCast();
        boolean boolean6 = closureCodingConvention0.isVarArgsParameter(node3);
        boolean boolean8 = closureCodingConvention0.isConstant("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        node9.addChildToFront(node10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node13 = node10.srcrefTree(node12);
        boolean boolean14 = node12.isComma();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str16 = compilerOptions15.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray21 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList22 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList22, warningsGuardArray21);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard24 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList22);
        com.google.javascript.jscomp.JSError jSError25 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = composeWarningsGuard24.level(jSError25);
        compilerOptions17.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard24);
        java.lang.String[] strArray32 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet33 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet33, strArray32);
        compilerOptions17.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet33);
        compilerOptions15.aliasableStrings = strSet33;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions38.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode44 = null;
        compilerOptions38.setTracer(tracerMode44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions46.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions52 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions52.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean56 = compilerOptions52.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions52.checkGlobalThisLevel;
        compilerOptions46.setCheckUnreachableCode(checkLevel57);
        compilerOptions38.checkMissingGetCssNameLevel = checkLevel57;
        compilerOptions15.setWarningLevel(diagnosticGroup37, checkLevel57);
        java.util.Set<java.lang.String> strSet61 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions15.stripNameSuffixes = strSet61;
        node12.setDirectives(strSet61);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean67 = node66.hasChildren();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean69 = node68.hasChildren();
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.IR.hook(node65, node66, node68);
        java.lang.String str74 = node66.toString(false, true, true);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean77 = node76.hasChildren();
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean79 = node78.hasChildren();
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.IR.hook(node75, node76, node78);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap81 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node66, node78);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.IR.thisNode();
        node82.addChildToFront(node83);
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node86 = node83.srcrefTree(node85);
        com.google.javascript.rhino.Node node87 = node78.copyInformationFrom(node83);
        boolean boolean88 = node87.isFalse();
        com.google.javascript.rhino.Node node89 = node64.srcrefTree(node87);
        com.google.javascript.rhino.Node node90 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.IR.thisNode();
        node90.addChildToFront(node91);
        boolean boolean93 = node90.isEmpty();
        com.google.javascript.rhino.Node node94 = node87.useSourceInfoIfMissingFrom(node90);
        java.lang.String str95 = closureCodingConvention0.extractClassNameIfProvide(node12, node87);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(warningsGuardArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(checkLevel26);
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet61);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "THIS" + "'", str74.equals("THIS"));
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(nodeMap81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNull(str95);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        int int17 = node1.getLength();
        boolean boolean18 = node1.isThis();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean20 = node19.hasChildren();
        java.lang.String str21 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node19);
        boolean boolean22 = node1.hasChild(node19);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        boolean boolean7 = sourceFile2.isExtern();
        java.lang.String str8 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Not declared as a type name" + "'", str8.equals("Not declared as a type name"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        java.util.Set<java.lang.String> strSet11 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions0.setStripNameSuffixes(strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str14 = compilerOptions13.locale;
        compilerOptions13.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing17 = null;
        compilerOptions13.setTweakProcessing(tweakProcessing17);
        byte[] byteArray19 = new byte[] {};
        compilerOptions13.setInputVariableMapSerialized(byteArray19);
        compilerOptions13.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str24 = compilerOptions23.locale;
        compilerOptions23.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions23.setFoldConstants(false);
        compilerOptions23.optimizeCalls = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy31 = compilerOptions23.variableRenaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy32 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions13.setRenamingPolicy(variableRenamingPolicy31, propertyRenamingPolicy32);
        compilerOptions0.variableRenaming = variableRenamingPolicy31;
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy31 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy31.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy32.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.setReserveRawExports(false);
        compilerOptions0.inlineLocalFunctions = false;
        compilerOptions0.enableExternExports(false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSType10.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec14 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        java.lang.String str17 = node15.getQualifiedName();
        int int18 = node15.getChildCount();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler19.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler19.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = compiler19.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType23 = assertInstanceofSpec14.getAssertedType(node15, jSTypeRegistry22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSType23.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec27 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean29 = node28.hasChildren();
        java.lang.String str30 = node28.getQualifiedName();
        int int31 = node28.getChildCount();
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap33 = compiler32.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager34 = compiler32.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = compiler32.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType36 = assertInstanceofSpec27.getAssertedType(node28, jSTypeRegistry35);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSType36.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean39 = jSType25.isEquivalentTo(jSType36);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        java.util.List<java.lang.String> strList41 = simpleErrorReporter40.warnings();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope42 = null;
        com.google.javascript.rhino.jstype.JSType jSType43 = jSType36.resolve((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, jSTypeStaticScope42);
        boolean boolean44 = jSType10.canTestForShallowEqualityWith(jSType43);
        boolean boolean45 = jSType43.isResolved();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        java.util.List<java.lang.String> strList47 = simpleErrorReporter46.warnings();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope48 = null;
        com.google.javascript.rhino.jstype.JSType jSType49 = jSType43.forceResolve((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, jSTypeStaticScope48);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "this" + "'", str17.equals("this"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(sourceMap20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(jSTypeRegistry22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "this" + "'", str30.equals("this"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(sourceMap33);
        org.junit.Assert.assertNotNull(errorManager34);
        org.junit.Assert.assertNotNull(jSTypeRegistry35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(strList41);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(strList47);
        org.junit.Assert.assertNotNull(jSType49);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isPrivate("Not declared as a type name");
        boolean boolean6 = closureCodingConvention0.isExported("goog.global", false);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        node7.addChildToFront(node8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node11 = node8.srcrefTree(node10);
        boolean boolean12 = node8.isNE();
        com.google.javascript.jscomp.CodingConvention.Bind bind14 = closureCodingConvention0.describeFunctionBind(node8, true);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str16 = closureCodingConvention15.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType21 = null;
        closureCodingConvention15.applyDelegateRelationship(objectType17, objectType18, objectType19, functionType20, functionType21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node27 = node24.srcrefTree(node26);
        boolean boolean28 = node26.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind30 = closureCodingConvention15.describeFunctionBind(node26, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection31 = closureCodingConvention15.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection32 = closureCodingConvention15.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        node33.addChildToFront(node34);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node37 = node34.srcrefTree(node36);
        boolean boolean38 = node34.isNE();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot43 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult44 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node42, astRoot43);
        java.lang.String str45 = closureCodingConvention15.extractClassNameIfRequire(node34, node42);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec47 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean49 = node48.hasChildren();
        java.lang.String str50 = node48.getQualifiedName();
        int int51 = node48.getChildCount();
        com.google.javascript.jscomp.Compiler compiler52 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap53 = compiler52.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager54 = compiler52.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = compiler52.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType56 = assertInstanceofSpec47.getAssertedType(node48, jSTypeRegistry55);
        java.lang.String str57 = closureCodingConvention0.extractClassNameIfProvide(node42, node48);
        boolean boolean59 = closureCodingConvention0.isExported("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(bind14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.global" + "'", str16.equals("goog.global"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(bind30);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection31);
        org.junit.Assert.assertNotNull(strCollection32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "this" + "'", str50.equals("this"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(sourceMap53);
        org.junit.Assert.assertNotNull(errorManager54);
        org.junit.Assert.assertNotNull(jSTypeRegistry55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setCollapseObjectLiterals(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        boolean boolean11 = node8.isFor();
        boolean boolean12 = node8.isExprResult();
        java.util.List<java.lang.String> strList13 = closureCodingConvention0.identifyTypeDeclarationCall(node8);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention14 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str15 = closureCodingConvention14.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention14.getAssertionFunctions();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.hook(node19, node20, node22);
        java.lang.String str28 = node20.toString(false, true, true);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean33 = node32.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.hook(node29, node30, node32);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node32);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        node36.addChildToFront(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node40 = node37.srcrefTree(node39);
        com.google.javascript.rhino.Node node41 = node32.copyInformationFrom(node37);
        boolean boolean42 = node41.isFalse();
        com.google.javascript.rhino.Node node43 = node18.srcrefTree(node41);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        node41.setJSType(jSType44);
        com.google.javascript.rhino.Node node46 = node17.useSourceInfoFromForTree(node41);
        com.google.javascript.jscomp.CodingConvention.Bind bind48 = closureCodingConvention14.describeFunctionBind(node17, false);
        try {
            java.util.List<java.lang.String> strList49 = closureCodingConvention0.identifyTypeDeclarationCall(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strList13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "goog.global" + "'", str15.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "THIS" + "'", str28.equals("THIS"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNull(bind48);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions11.setSyntheticBlockStartMarker("Not declared as a type name");
        boolean boolean17 = compilerOptions11.checkControlStructures;
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = compilerOptions11.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat18);
        boolean boolean20 = compilerOptions0.inlineVariables;
        compilerOptions0.setTweakToBooleanLiteral("goog.exportSymbol", false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(errorFormat18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.hook(node2, node3, node5);
        boolean boolean8 = node2.isSwitch();
        com.google.javascript.rhino.Node node9 = node2.cloneNode();
        boolean boolean10 = node2.isAnd();
        boolean boolean11 = closureCodingConvention0.isPrototypeAlias(node2);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        node13.addChildToBack(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.returnNode();
        int int18 = node17.getSideEffectFlags();
        java.lang.String str19 = closureCodingConvention0.extractClassNameIfRequire(node14, node17);
        boolean boolean21 = closureCodingConvention0.isSuperClassReference("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isPrivate("Not declared as a type name");
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType6 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType4, objectType5, objectType6, functionType7, functionType8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean9 = compilerOptions5.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel10, diagnosticType13, strArray15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        boolean boolean22 = node20.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean31 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions27.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel32, diagnosticType35, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make(node20, diagnosticType23, strArray37);
        loggerErrorManager1.report(checkLevel10, jSError39);
        int int41 = jSError39.getLineNumber();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean4 = closureCodingConvention0.isConstantKey("Not declared as a type name");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node5, astRoot6);
        boolean boolean8 = node5.isGetterDef();
        int int9 = node5.getSourceOffset();
        boolean boolean10 = closureCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.hook(node12, node13, node15);
        java.lang.String str21 = node13.toString(false, true, true);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean24 = node23.hasChildren();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean26 = node25.hasChildren();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.hook(node22, node23, node25);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap28 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node13, node25);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        node29.addChildToFront(node30);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node33 = node30.srcrefTree(node32);
        com.google.javascript.rhino.Node node34 = node25.copyInformationFrom(node30);
        boolean boolean35 = node34.isFalse();
        com.google.javascript.rhino.Node node36 = node11.srcrefTree(node34);
        boolean boolean37 = node36.isScript();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot39 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult40 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node38, astRoot39);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean43 = node42.hasChildren();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean45 = node44.hasChildren();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.hook(node41, node42, node44);
        java.lang.String str47 = node38.checkTreeEquals(node46);
        com.google.javascript.rhino.Node node48 = node46.removeChildren();
        com.google.javascript.rhino.Node node49 = node36.copyInformationFrom(node48);
        com.google.javascript.rhino.InputId inputId50 = node48.getInputId();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast51 = closureCodingConvention0.getObjectLiteralCast(node48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "THIS" + "'", str21.equals("THIS"));
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeMap28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str47.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNull(inputId50);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        compilerOptions0.setRuntimeTypeCheck(true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        com.google.javascript.rhino.Node node4 = node0.getLastChild();
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node5.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.markNoSideEffectCalls = false;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing9 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        compilerOptions0.setTweakProcessing(tweakProcessing9);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing9.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        boolean boolean11 = node6.isSyntheticBlock();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot18 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult19 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node17, astRoot18);
        com.google.javascript.rhino.Node node20 = parseResult19.ast;
        boolean boolean21 = node20.isQualifiedName();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        node22.addChildToFront(node23);
        boolean boolean25 = node22.isFor();
        boolean boolean26 = node22.isExprResult();
        int int27 = node22.getCharno();
        com.google.javascript.rhino.Node node28 = node20.useSourceInfoIfMissingFrom(node22);
        com.google.javascript.rhino.Node node29 = node16.copyInformationFromForTree(node22);
        int int30 = node16.getLineno();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot32 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult33 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node31, astRoot32);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean36 = node35.hasChildren();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean38 = node37.hasChildren();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node34, node35, node37);
        java.lang.String str40 = node31.checkTreeEquals(node39);
        com.google.javascript.rhino.Node node41 = node39.removeChildren();
        com.google.javascript.rhino.Node node42 = node16.srcrefTree(node41);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean45 = node44.hasChildren();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean47 = node46.hasChildren();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.hook(node43, node44, node46);
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = null;
        com.google.javascript.rhino.Node node50 = node46.setJSDocInfo(jSDocInfo49);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention51 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str52 = closureCodingConvention51.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection53 = closureCodingConvention51.getAssertionFunctions();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean58 = node57.hasChildren();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean60 = node59.hasChildren();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.hook(node56, node57, node59);
        java.lang.String str65 = node57.toString(false, true, true);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean68 = node67.hasChildren();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean70 = node69.hasChildren();
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.IR.hook(node66, node67, node69);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap72 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node57, node69);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.thisNode();
        node73.addChildToFront(node74);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node77 = node74.srcrefTree(node76);
        com.google.javascript.rhino.Node node78 = node69.copyInformationFrom(node74);
        boolean boolean79 = node78.isFalse();
        com.google.javascript.rhino.Node node80 = node55.srcrefTree(node78);
        com.google.javascript.rhino.jstype.JSType jSType81 = null;
        node78.setJSType(jSType81);
        com.google.javascript.rhino.Node node83 = node54.useSourceInfoFromForTree(node78);
        com.google.javascript.jscomp.CodingConvention.Bind bind85 = closureCodingConvention51.describeFunctionBind(node54, false);
        com.google.javascript.rhino.Node[] nodeArray86 = new com.google.javascript.rhino.Node[] { node6, node15, node42, node50, node54 };
        try {
            com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.IR.objectlit(nodeArray86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str40.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "goog.global" + "'", str52.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "THIS" + "'", str65.equals("THIS"));
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(nodeMap72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNull(bind85);
        org.junit.Assert.assertNotNull(nodeArray86);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        java.util.Set<java.lang.String> strSet11 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions0.setStripNameSuffixes(strSet11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions13.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode19 = null;
        compilerOptions13.setTracer(tracerMode19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions21.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean31 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions27.checkGlobalThisLevel;
        compilerOptions21.setCheckUnreachableCode(checkLevel32);
        compilerOptions13.checkMissingGetCssNameLevel = checkLevel32;
        compilerOptions0.setCheckRequires(checkLevel32);
        com.google.javascript.jscomp.CompilerOptions compilerOptions36 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions36.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray40 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList41 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList41, warningsGuardArray40);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard43 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList41);
        com.google.javascript.jscomp.JSError jSError44 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = composeWarningsGuard43.level(jSError44);
        compilerOptions36.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard43);
        java.lang.String[] strArray51 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet52 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet52, strArray51);
        compilerOptions36.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet52);
        compilerOptions36.inlineConstantVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean61 = compilerOptions57.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions57.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions63.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean67 = compilerOptions63.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions63.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions69 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions69.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean73 = compilerOptions69.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel74 = compilerOptions69.checkGlobalThisLevel;
        compilerOptions63.setCheckMissingReturn(checkLevel74);
        compilerOptions57.aggressiveVarCheck = checkLevel74;
        compilerOptions36.setReportMissingOverride(checkLevel74);
        compilerOptions0.setCheckMissingGetCssNameLevel(checkLevel74);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strSet11);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(checkLevel45);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + checkLevel74 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel74.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.fromString("STRING ");
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setGatherCssNames(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean4 = closureCodingConvention0.isConstantKey("Not declared as a type name");
        java.lang.String str5 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportSymbol" + "'", str5.equals("goog.exportSymbol"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isTypeOf();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult20 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node18, astRoot19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.hook(node21, node22, node24);
        java.lang.String str27 = node18.checkTreeEquals(node26);
        com.google.javascript.rhino.Node node28 = node18.cloneNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean33 = node32.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.hook(node29, node30, node32);
        com.google.javascript.rhino.Node node35 = node28.useSourceInfoIfMissingFrom(node32);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot37 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult38 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node36, astRoot37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean41 = node40.hasChildren();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean43 = node42.hasChildren();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.hook(node39, node40, node42);
        java.lang.String str45 = node36.checkTreeEquals(node44);
        boolean boolean46 = node44.isOnlyModifiesThisCall();
        java.lang.String str47 = closureCodingConvention0.extractClassNameIfRequire(node32, node44);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str27.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str45.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(40, nodeArray1, 53, 16);
        node4.setLength((int) '#');
        org.junit.Assert.assertNotNull(nodeArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setInlineVariables(true);
        compilerOptions0.inlineFunctions = false;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        node13.addChildToFront(node14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node17 = node14.srcrefTree(node16);
        boolean boolean18 = node16.isComma();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str20 = compilerOptions19.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray25 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList26 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList26, warningsGuardArray25);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard28 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList26);
        com.google.javascript.jscomp.JSError jSError29 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = composeWarningsGuard28.level(jSError29);
        compilerOptions21.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard28);
        java.lang.String[] strArray36 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet37 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet37, strArray36);
        compilerOptions21.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet37);
        compilerOptions19.aliasableStrings = strSet37;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup41 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions42.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions42.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode48 = null;
        compilerOptions42.setTracer(tracerMode48);
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions50.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions56.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean60 = compilerOptions56.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = compilerOptions56.checkGlobalThisLevel;
        compilerOptions50.setCheckUnreachableCode(checkLevel61);
        compilerOptions42.checkMissingGetCssNameLevel = checkLevel61;
        compilerOptions19.setWarningLevel(diagnosticGroup41, checkLevel61);
        java.util.Set<java.lang.String> strSet65 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions19.stripNameSuffixes = strSet65;
        node16.setDirectives(strSet65);
        compilerOptions0.setReplaceStringsReservedStrings(strSet65);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(warningsGuardArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(checkLevel30);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup41);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet65);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        boolean boolean23 = node19.isNE();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        java.lang.String str30 = closureCodingConvention0.extractClassNameIfRequire(node19, node27);
        boolean boolean32 = closureCodingConvention0.isValidEnumKey("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        boolean boolean11 = jSType10.isNullable();
        boolean boolean12 = jSType10.isGlobalThisType();
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec14 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        java.lang.String str17 = node15.getQualifiedName();
        int int18 = node15.getChildCount();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler19.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler19.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = compiler19.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType23 = assertInstanceofSpec14.getAssertedType(node15, jSTypeRegistry22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSType23.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair26 = jSType10.getTypesUnderShallowEquality(jSType25);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "this" + "'", str17.equals("this"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(sourceMap20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(jSTypeRegistry22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(typePair26);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean1 = node0.hasChildren();
        java.lang.String str2 = node0.getQualifiedName();
        int int3 = node0.getChildCount();
        com.google.javascript.rhino.Node node5 = node0.getAncestor(57);
        try {
            boolean boolean6 = node5.isName();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "this" + "'", str2.equals("this"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean1 = node0.hasChildren();
        java.lang.String str2 = node0.getQualifiedName();
        boolean boolean3 = node0.isExprResult();
        boolean boolean4 = node0.isGetterDef();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "this" + "'", str2.equals("this"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.Node node4 = node3.getLastSibling();
        boolean boolean5 = node4.isBlock();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isOnlyModifiesThisCall();
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec5 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        java.lang.String str8 = node6.getQualifiedName();
        int int9 = node6.getChildCount();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType14 = assertInstanceofSpec5.getAssertedType(node6, jSTypeRegistry13);
        com.google.javascript.rhino.jstype.JSType jSType16 = jSType14.getRestrictedTypeGivenToBooleanOutcome(true);
        node1.setJSType(jSType14);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec19 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        java.lang.String str22 = node20.getQualifiedName();
        int int23 = node20.getChildCount();
        com.google.javascript.jscomp.Compiler compiler24 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap25 = compiler24.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager26 = compiler24.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = compiler24.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType28 = assertInstanceofSpec19.getAssertedType(node20, jSTypeRegistry27);
        com.google.javascript.rhino.jstype.JSType jSType30 = jSType28.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec32 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        java.lang.String str35 = node33.getQualifiedName();
        int int36 = node33.getChildCount();
        com.google.javascript.jscomp.Compiler compiler37 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap38 = compiler37.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager39 = compiler37.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = compiler37.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType41 = assertInstanceofSpec32.getAssertedType(node33, jSTypeRegistry40);
        com.google.javascript.rhino.jstype.JSType jSType43 = jSType41.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean44 = jSType30.isEquivalentTo(jSType41);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair45 = jSType14.getTypesUnderEquality(jSType41);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "this" + "'", str8.equals("this"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(jSType14);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "this" + "'", str22.equals("this"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(sourceMap25);
        org.junit.Assert.assertNotNull(errorManager26);
        org.junit.Assert.assertNotNull(jSTypeRegistry27);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "this" + "'", str35.equals("this"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNull(sourceMap38);
        org.junit.Assert.assertNotNull(errorManager39);
        org.junit.Assert.assertNotNull(jSTypeRegistry40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(typePair45);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        compilerOptions0.coalesceVariableNames = true;
        com.google.javascript.jscomp.VariableMap variableMap24 = null;
        compilerOptions0.setInputPropertyMap(variableMap24);
        compilerOptions0.setRemoveDeadCode(true);
        boolean boolean28 = compilerOptions0.generatePseudoNames;
        compilerOptions0.setReplaceMessagesWithChromeI18n(false, "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        com.google.javascript.rhino.JSDocInfo jSDocInfo1 = node0.getJSDocInfo();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(jSDocInfo1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSType10.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec14 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        java.lang.String str17 = node15.getQualifiedName();
        int int18 = node15.getChildCount();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler19.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler19.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = compiler19.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType23 = assertInstanceofSpec14.getAssertedType(node15, jSTypeRegistry22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSType23.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean26 = jSType12.isEquivalentTo(jSType23);
        boolean boolean27 = jSType12.isEnumElementType();
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec29 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        java.lang.String str32 = node30.getQualifiedName();
        int int33 = node30.getChildCount();
        com.google.javascript.jscomp.Compiler compiler34 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap35 = compiler34.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager36 = compiler34.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = compiler34.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType38 = assertInstanceofSpec29.getAssertedType(node30, jSTypeRegistry37);
        boolean boolean39 = jSType12.isInvariant(jSType38);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "this" + "'", str17.equals("this"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(sourceMap20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(jSTypeRegistry22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "this" + "'", str32.equals("this"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(sourceMap35);
        org.junit.Assert.assertNotNull(errorManager36);
        org.junit.Assert.assertNotNull(jSTypeRegistry37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.setProcessCommonJSModules(false);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.aggressiveVarCheck;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setDebugFunctionSideEffectsPath("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy17 = compilerOptions0.variableRenaming;
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy17.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node4.isParamList();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        boolean boolean7 = node4.isFor();
        boolean boolean8 = node4.isExprResult();
        boolean boolean9 = node4.isDefaultCase();
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        node13.addChildToFront(node14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node17 = node14.srcrefTree(node16);
        boolean boolean18 = node16.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean27 = compilerOptions23.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions23.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray33 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel28, diagnosticType31, strArray33);
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(node16, diagnosticType19, strArray33);
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("", node4, diagnosticType12, strArray33);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.thisNode();
        node38.addChildToFront(node39);
        boolean boolean41 = node38.isFor();
        boolean boolean42 = node38.isExprResult();
        boolean boolean43 = node38.isDefaultCase();
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.thisNode();
        node47.addChildToFront(node48);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node51 = node48.srcrefTree(node50);
        boolean boolean52 = node50.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean61 = compilerOptions57.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions57.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray67 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel62, diagnosticType65, strArray67);
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make(node50, diagnosticType53, strArray67);
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("", node38, diagnosticType46, strArray67);
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", 56, 38, diagnosticType12, strArray67);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(strArray67);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNotNull(jSError69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(jSError71);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(40, nodeArray1, 53, 16);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.arraylit(nodeArray1);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.setFoldConstants(false);
        boolean boolean20 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        int int11 = node6.getSourceOffset();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.enableRuntimeTypeCheck("goog.exportProperty");
        compilerOptions0.setRemoveDeadCode(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions10.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean20 = compilerOptions16.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.checkGlobalThisLevel;
        compilerOptions10.setCheckUnreachableCode(checkLevel21);
        boolean boolean23 = compilerOptions10.ideMode;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions10.checkMissingGetCssNameLevel;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel24;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58", 46, 8);
        node3.setCharno((int) (short) 1);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap12 = compiler11.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager13 = compiler11.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot15 = null;
        compiler11.setOldParseTree("", astRoot15);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter17 = compiler11.getReverseAbstractInterpreter();
        boolean boolean18 = compiler11.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt19 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter20 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, sourceExcerpt19);
        java.util.logging.Logger logger21 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager22 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter20, logger21);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str24 = compilerOptions23.locale;
        compilerOptions23.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions23.reportMissingOverride;
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        node28.addChildToFront(node29);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node32 = node29.srcrefTree(node31);
        boolean boolean33 = node31.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray48 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel43, diagnosticType46, strArray48);
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make(node31, diagnosticType34, strArray48);
        java.lang.String str51 = jSError50.toString();
        loggerErrorManager22.println(checkLevel27, jSError50);
        com.google.javascript.jscomp.CheckLevel checkLevel53 = composeWarningsGuard7.level(jSError50);
        java.lang.String str54 = jSError50.sourceName;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNull(sourceMap12);
        org.junit.Assert.assertNotNull(errorManager13);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str51.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel53);
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        boolean boolean12 = node6.isNumber();
        java.lang.String str13 = closureCodingConvention0.extractClassNameIfRequire(node5, node6);
        com.google.javascript.rhino.Node node14 = null;
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.tryFinally(node6, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = sideEffectFlags0.setReturnsTainted();
        boolean boolean2 = sideEffectFlags1.areAllFlagsSet();
        org.junit.Assert.assertNotNull(sideEffectFlags1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        boolean boolean7 = node4.isVoid();
        com.google.javascript.rhino.Node node8 = node4.getLastSibling();
        boolean boolean9 = node4.wasEmptyNode();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention10 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str11 = closureCodingConvention10.getGlobalObject();
        boolean boolean13 = closureCodingConvention10.isPrivate("Not declared as a type name");
        boolean boolean16 = closureCodingConvention10.isExported("goog.global", false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        boolean boolean22 = node18.isNE();
        com.google.javascript.jscomp.CodingConvention.Bind bind24 = closureCodingConvention10.describeFunctionBind(node18, true);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot26 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult27 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node25, astRoot26);
        boolean boolean28 = node25.isGetterDef();
        int int29 = node25.getSourceOffset();
        com.google.javascript.rhino.Node node30 = node18.useSourceInfoFromForTree(node25);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention31 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node33 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention31, "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean35 = closureCodingConvention31.isConstantKey("Not declared as a type name");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot37 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult38 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node36, astRoot37);
        boolean boolean39 = node36.isGetterDef();
        int int40 = node36.getSourceOffset();
        boolean boolean41 = closureCodingConvention31.isOptionalParameter(node36);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean48 = node47.hasChildren();
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean50 = node49.hasChildren();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.hook(node46, node47, node49);
        java.lang.String str55 = node47.toString(false, true, true);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean58 = node57.hasChildren();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean60 = node59.hasChildren();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.hook(node56, node57, node59);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap62 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node47, node59);
        java.lang.String str63 = closureCodingConvention31.extractClassNameIfProvide(node45, node47);
        try {
            com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((int) (short) 10, node4, node18, node45, 55, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "goog.global" + "'", str11.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(bind24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "THIS" + "'", str55.equals("THIS"));
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeMap62);
        org.junit.Assert.assertNull(str63);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        java.util.Set<java.lang.String> strSet6 = null;
        compilerOptions0.setStripNameSuffixes(strSet6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setCollapseObjectLiterals(false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel1, "Not declared as a type name");
        java.lang.String str4 = diagnosticType3.key;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Not declared as a type name" + "'", str4.equals("Not declared as a type name"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        boolean boolean6 = node3.isNew();
        boolean boolean7 = node3.isString();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        boolean boolean3 = node0.isGetterDef();
        java.lang.String str4 = node0.getQualifiedName();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node0.getJsDocBuilderForNode();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        com.google.javascript.rhino.Node node10 = node0.cloneNode();
        com.google.javascript.rhino.Node node11 = node10.cloneNode();
        boolean boolean12 = node11.isName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        boolean boolean23 = node3.isDo();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter9, logger10);
        int int12 = loggerErrorManager11.getWarningCount();
        loggerErrorManager11.generateReport();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.setSyntheticBlockStartMarker("hi!");
        compilerOptions0.setCollapseVariableDeclarations(false);
        compilerOptions0.setTrustedStrings(false);
        compilerOptions0.setRenamePrefix("STRING ");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        compilerOptions0.setOptimizeReturns(false);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy13;
        compilerOptions0.setCheckSymbols(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(40, (int) (short) -1, 53);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSType10.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec14 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        java.lang.String str17 = node15.getQualifiedName();
        int int18 = node15.getChildCount();
        com.google.javascript.jscomp.Compiler compiler19 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler19.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager21 = compiler19.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = compiler19.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType23 = assertInstanceofSpec14.getAssertedType(node15, jSTypeRegistry22);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSType23.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec27 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean29 = node28.hasChildren();
        java.lang.String str30 = node28.getQualifiedName();
        int int31 = node28.getChildCount();
        com.google.javascript.jscomp.Compiler compiler32 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap33 = compiler32.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager34 = compiler32.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = compiler32.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType36 = assertInstanceofSpec27.getAssertedType(node28, jSTypeRegistry35);
        com.google.javascript.rhino.jstype.JSType jSType38 = jSType36.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean39 = jSType25.isEquivalentTo(jSType36);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        java.util.List<java.lang.String> strList41 = simpleErrorReporter40.warnings();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope42 = null;
        com.google.javascript.rhino.jstype.JSType jSType43 = jSType36.resolve((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, jSTypeStaticScope42);
        boolean boolean44 = jSType10.canTestForShallowEqualityWith(jSType43);
        boolean boolean45 = jSType43.isBooleanObjectType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "this" + "'", str17.equals("this"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(sourceMap20);
        org.junit.Assert.assertNotNull(errorManager21);
        org.junit.Assert.assertNotNull(jSTypeRegistry22);
        org.junit.Assert.assertNotNull(jSType23);
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "this" + "'", str30.equals("this"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(sourceMap33);
        org.junit.Assert.assertNotNull(errorManager34);
        org.junit.Assert.assertNotNull(jSTypeRegistry35);
        org.junit.Assert.assertNotNull(jSType36);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(strList41);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.jstype.JSType jSType12 = jSType10.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean13 = jSType12.isNoType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        compilerOptions0.setExternExportsPath("");
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkGlobalNamesLevel;
        compilerOptions0.markAsCompiled = false;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4, "Not declared as a constructor", true);
        com.google.javascript.jscomp.SourceAst sourceAst8 = compilerInput7.getAst();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceAst8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("hi!");
        node1.setLength(48);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        compilerOptions0.setRenamePrefixNamespace("");
        compilerOptions0.setCrossModuleCodeMotion(true);
        compilerOptions0.setRemoveClosureAsserts(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        boolean boolean3 = node2.isParamList();
        node2.setIsSyntheticBlock(true);
        boolean boolean6 = node2.wasEmptyNode();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(37, node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        compilerOptions0.setCrossModuleMethodMotion(false);
        boolean boolean9 = compilerOptions0.prettyPrint;
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        compilerOptions0.optimizeReturns = false;
        compilerOptions0.setCrossModuleCodeMotion(false);
        compilerOptions0.setExportTestFunctions(true);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType14.level;
        compilerOptions0.setCheckGlobalNamesLevel(checkLevel15);
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        compilerOptions0.removeTryCatchFinally = true;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        compilerOptions0.checkSymbols = false;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        boolean boolean8 = compilerOptions0.isDisambiguatePrivateProperties();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap9 = compilerOptions0.getTweakReplacements();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(false);
        compilerOptions0.setLineBreak(false);
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strMap9);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.hook(node2, node3, node5);
        boolean boolean8 = node2.isSwitch();
        com.google.javascript.rhino.Node node9 = node2.cloneNode();
        boolean boolean10 = node2.isAnd();
        boolean boolean11 = closureCodingConvention0.isPrototypeAlias(node2);
        java.util.Collection<java.lang.String> strCollection12 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        java.lang.String str13 = closureCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(strCollection12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.global" + "'", str13.equals("goog.global"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("DiagnosticGroup<undefinedNames>(OFF)");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        java.lang.String str4 = node2.getQualifiedName();
        int int5 = node2.getChildCount();
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = compiler6.getTypeRegistry();
        com.google.javascript.rhino.jstype.JSType jSType10 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.Node node15 = node14.getLastSibling();
        com.google.javascript.rhino.Node node16 = assertInstanceofSpec1.getAssertedParam(node15);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "this" + "'", str4.equals("this"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNotNull(jSTypeRegistry9);
        org.junit.Assert.assertNotNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11);
        com.google.javascript.jscomp.SourceFile sourceFile13 = compilerInput12.getSourceFile();
        com.google.javascript.rhino.InputId inputId14 = compilerInput12.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, inputId14, true);
        com.google.javascript.jscomp.JSModule jSModule17 = null;
        compilerInput6.setModule(jSModule17);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile13);
        org.junit.Assert.assertNotNull(inputId14);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler3.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        compiler3.setOldParseTree("", astRoot7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter9 = compiler3.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck15 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, reverseAbstractInterpreter9, jSTypeRegistry13, checkLevel14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        node16.addChildToFront(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node20 = node17.srcrefTree(node19);
        boolean boolean21 = node19.isComma();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot23 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult24 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node22, astRoot23);
        node22.detachChildren();
        boolean boolean26 = node19.hasChild(node22);
        boolean boolean27 = node22.isSyntheticBlock();
        com.google.javascript.rhino.Node node28 = node22.getLastChild();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention29 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        node30.addChildToFront(node31);
        boolean boolean33 = node30.isFor();
        boolean boolean34 = node30.isExprResult();
        com.google.javascript.jscomp.CodingConvention.Bind bind35 = closureCodingConvention29.describeFunctionBind(node30);
        try {
            com.google.javascript.jscomp.Scope scope36 = typeCheck15.processForTesting(node28, node30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter9);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(bind35);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        boolean boolean21 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.String str22 = compilerOptions0.renamePrefixNamespace;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.removeUnusedClassProperties = false;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }
}

