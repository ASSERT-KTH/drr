import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.not(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.var(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy1 = null;
        try {
            com.google.javascript.jscomp.CheckEventfulObjectDisposal checkEventfulObjectDisposal2 = new com.google.javascript.jscomp.CheckEventfulObjectDisposal(abstractCompiler0, disposalCheckingPolicy1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.eq(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.rhino.Node node0 = null;
        try {
            boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isLValue(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) 100, node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) (byte) -1, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Not declared as a type name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.ifNode(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.defaultCase(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JsAst jsAst2 = null;
        try {
            compiler0.replaceScript(jsAst2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.returnNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = null;
        try {
            java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap2 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!", "hi!", "Not declared as a type name", "" };
        try {
            com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make("hi!", node1, diagnosticType2, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(strArray8);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        com.google.javascript.jscomp.JSModule jSModule0 = null;
//        com.google.javascript.jscomp.JSModule[] jSModuleArray1 = new com.google.javascript.jscomp.JSModule[] { jSModule0 };
//        try {
//            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph2 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSModuleArray1);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JsAst jsAst1 = null;
        try {
            compiler0.addNewScript(jsAst1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        try {
            node1.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.getelem(node1, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node2, callback7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSError jSError2 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel3 = compiler0.getErrorLevel(jSError2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        try {
            java.lang.String[] strArray1 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.isSwitch();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.cast(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        node3.addChildToFront(node4);
        boolean boolean6 = node3.isFor();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        boolean boolean13 = node10.isVoid();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean22 = node21.hasChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean24 = node23.hasChildren();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.hook(node20, node21, node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean28 = node27.hasChildren();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean30 = node29.hasChildren();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.hook(node26, node27, node29);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node1, node3, node10, node14, node23, node31 };
        try {
            com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.script(nodeArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.JSError jSError1 = null;
        try {
            boolean boolean2 = diagnosticGroup0.matches(jSError1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VIOLATED_MODULE_DEP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.PassConfig passConfig1 = null;
        try {
            compiler0.setPassConfig(passConfig1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        boolean boolean7 = node4.isFor();
        boolean boolean8 = node4.isExprResult();
        com.google.javascript.rhino.Node node9 = null;
        try {
            node0.addChildBefore(node4, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The existing child node of the parent should not be null.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node10, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.hook(node13, node14, node16);
        java.lang.String str22 = node14.toString(false, true, true);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean24 = node23.hasChildren();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot26 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult27 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node25, astRoot26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean30 = node29.hasChildren();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.hook(node28, node29, node31);
        boolean boolean34 = node28.isSwitch();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        node35.addChildToFront(node36);
        boolean boolean38 = node35.isFor();
        node35.setSourceEncodedPositionForTree((int) '#');
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node10, node14, node23, node25, node28, node35 };
        try {
            com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.switchNode(node1, nodeArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "THIS" + "'", str22.equals("THIS"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(nodeArray41);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node3.isVoid();
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.throwNode(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node[] nodeArray9 = new com.google.javascript.rhino.Node[] { node0, node4, node7 };
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.objectlit(nodeArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(nodeArray9);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseDate();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "2019/06/13 15:58" + "'", str0.equals("2019/06/13 15:58"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        int int1 = codeBuilder0.getLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator2);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray10 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList11 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList11, warningsGuardArray10);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard13 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList11);
        com.google.javascript.jscomp.JSError jSError14 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = composeWarningsGuard13.level(jSError14);
        compilerOptions6.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard13);
        java.lang.String[] strArray21 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet22 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet22, strArray21);
        compilerOptions6.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet22);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy25 = compilerOptions6.variableRenaming;
        try {
            com.google.javascript.jscomp.Result result26 = compiler0.compile(sourceFile3, jSSourceFileArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(warningsGuardArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(checkLevel15);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy25.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.optimizeCalls = true;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] {};
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.call(node13, nodeArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(nodeArray17);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult5 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        java.lang.String str12 = node3.checkTreeEquals(node11);
        boolean boolean13 = node11.isOnlyModifiesThisCall();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.and(node1, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str12.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot12 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult13 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node11, astRoot12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        java.lang.String str20 = node11.checkTreeEquals(node19);
        boolean boolean21 = node19.isOnlyModifiesThisCall();
        try {
            node1.replaceChild(node10, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str20.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node5 = node2.srcrefTree(node4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.hook(node9, node10, node12);
        java.lang.String str15 = node6.checkTreeEquals(node14);
        boolean boolean16 = node14.isOnlyModifiesThisCall();
        try {
            com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 0, node5, node14, 4095, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str15.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        com.google.javascript.rhino.Node node22 = node13.copyInformationFrom(node18);
        int int23 = node18.getSourceOffset();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        node0.setSourceEncodedPositionForTree((int) '#');
        try {
            node0.setString("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: THIS 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        try {
            java.util.Collection<java.lang.String> strCollection5 = compilerInput4.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        com.google.javascript.rhino.Node node22 = node13.copyInformationFrom(node18);
        try {
            com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.cast(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node3.isVoid();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot8 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult9 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node7, astRoot8);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.lang.String str16 = node7.checkTreeEquals(node15);
        boolean boolean17 = node15.isIf();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node[] nodeArray23 = new com.google.javascript.rhino.Node[] { node3, node15, node22 };
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.paramList(nodeArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str16.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray23);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        try {
            com.google.javascript.rhino.Node node9 = compilerInput5.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        com.google.javascript.rhino.Node node22 = node13.copyInformationFrom(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        try {
            com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.label(node18, node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        node2.addChildToFront(node3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node6 = node3.srcrefTree(node5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.hook(node13, node14, node16);
        java.lang.String str22 = node14.toString(false, true, true);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean27 = node26.hasChildren();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.hook(node23, node24, node26);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap29 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node14, node26);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        node30.addChildToFront(node31);
        boolean boolean33 = node30.isFor();
        boolean boolean34 = node30.isExprResult();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean37 = node36.hasChildren();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean39 = node38.hasChildren();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.hook(node35, node36, node38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.thisNode();
        node41.addChildToFront(node42);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node45 = node42.srcrefTree(node44);
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node3, node10, node26, node30, node36, node44 };
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler0, callback1, nodeArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "THIS" + "'", str22.equals("THIS"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(nodeMap29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node[] nodeArray3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.call(node0, nodeArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.INFERRED_FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            compiler0.report(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isLocalResultCall();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        java.lang.String str6 = node4.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node7 = node1.removeChildAfter(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "this" + "'", str6.equals("this"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        node13.putIntProp((int) ' ', (int) (short) 10);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags21 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '#');
        try {
            node13.setSideEffectFlags(sideEffectFlags21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got THIS");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.rhino.Node node2 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "2019/06/13 15:58");
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long long0 = com.google.javascript.rhino.InputId.serialVersionUID;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        com.google.javascript.jscomp.JsAst jsAst5 = null;
        try {
            compiler0.replaceScript(jsAst5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        try {
            node0.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node4, astRoot5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        java.lang.String str13 = node4.checkTreeEquals(node12);
        boolean boolean14 = node12.isIf();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        node15.addChildToFront(node16);
        boolean boolean18 = node16.isLocalResultCall();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        node19.addChildToFront(node20);
        boolean boolean22 = node19.isEmpty();
        try {
            com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(40, node1, node12, node16, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str13.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean1 = node0.hasChildren();
        node0.setVarArgs(true);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        boolean boolean13 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode14 = compilerOptions0.getLanguageOut();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(languageMode14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean1 = node0.hasChildren();
        try {
            node0.setString("this");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: THIS is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator7);
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceFile8, true);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput10);
        com.google.javascript.jscomp.SourceFile sourceFile12 = compilerInput11.getSourceFile();
        com.google.javascript.jscomp.SourceFile.Generator generator14 = null;
        com.google.javascript.jscomp.SourceFile sourceFile15 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator14);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(sourceFile15, true);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput17);
        com.google.javascript.jscomp.SourceFile sourceFile19 = compilerInput18.getSourceFile();
        com.google.javascript.jscomp.SourceFile.Generator generator21 = null;
        com.google.javascript.jscomp.SourceFile sourceFile22 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator21);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceFile22, true);
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput24);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray26 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput5, compilerInput11, compilerInput18, compilerInput24 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList27 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList27, dependencyInfoArray26);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies29 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertNotNull(sourceFile12);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertNotNull(sourceFile22);
        org.junit.Assert.assertNotNull(dependencyInfoArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.devirtualizePrototypeMethods = true;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Not declared as a constructor", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        com.google.javascript.jscomp.CompilerOptions.Reach reach8 = null;
        try {
            compilerOptions0.setRemoveUnusedVariable(reach8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node5 = node2.srcrefTree(node4);
        boolean boolean6 = node4.isComma();
        boolean boolean7 = node4.isObjectLit();
        try {
            boolean boolean8 = closureCodingConvention0.isPropertyTestFunction(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DISPOSE_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        boolean boolean3 = node0.isGetterDef();
        java.lang.String str4 = node0.getQualifiedName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.hook(node5, node6, node8);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        try {
            node0.replaceChildAfter(node8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node8.isRegExp();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.lang.String str20 = node12.toString(false, true, true);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.hook(node21, node22, node24);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap27 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node12, node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        node28.addChildToFront(node29);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node32 = node29.srcrefTree(node31);
        com.google.javascript.rhino.Node node33 = node24.copyInformationFrom(node29);
        boolean boolean34 = node33.isFalse();
        try {
            node8.addChildToBack(node33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "THIS" + "'", str20.equals("THIS"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeMap27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        java.lang.String str19 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        try {
            java.util.Collection<java.lang.String> strCollection7 = compilerInput5.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        try {
            int int4 = sourceFile2.getLineOffset(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapseObjectLiterals(true);
        boolean boolean8 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseVersion();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "D4J_Closure_123_FIXED_VERSION" + "'", str0.equals("D4J_Closure_123_FIXED_VERSION"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray2 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile1 };
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] { jSModule3 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions5.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode11 = null;
        compilerOptions5.setTracer(tracerMode11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions13.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean23 = compilerOptions19.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions19.checkGlobalThisLevel;
        compilerOptions13.setCheckUnreachableCode(checkLevel24);
        compilerOptions5.checkMissingGetCssNameLevel = checkLevel24;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap27 = compilerOptions5.customPasses;
        compilerOptions5.inlineConstantVars = false;
        boolean boolean30 = compilerOptions5.convertToDottedProperties;
        try {
            com.google.javascript.jscomp.Result result31 = compiler0.compile(jSSourceFileArray2, jSModuleArray4, compilerOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray2);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray5 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList6 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList6, locationMappingArray5);
        compilerOptions1.sourceMapLocationMappings = locationMappingList6;
        try {
            java.lang.String str9 = com.google.javascript.rhino.SimpleErrorReporter.getMessage1("hi!", (java.lang.Object) compilerOptions1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(locationMappingArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = null;
        com.google.javascript.jscomp.JSModule jSModule7 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] { jSModule7 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str10 = compilerOptions9.locale;
        compilerOptions9.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions9.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean20 = compilerOptions16.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions16.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel21);
        compilerOptions9.aggressiveVarCheck = checkLevel21;
        java.util.Set<java.lang.String> strSet24 = compilerOptions9.stripTypePrefixes;
        try {
            com.google.javascript.jscomp.Result result25 = compiler0.compile(jSSourceFile6, jSModuleArray8, compilerOptions9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.resetWarningsGuard();
        boolean boolean32 = compilerOptions0.getInferTypes();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.isNumber();
        try {
            boolean boolean7 = com.google.javascript.jscomp.NodeUtil.isLValue(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        boolean boolean14 = compilerOptions0.getInferTypes();
        boolean boolean15 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.NodeTraversal.FunctionCallback functionCallback2 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseChangedFunctions((com.google.javascript.jscomp.AbstractCompiler) compiler0, functionCallback2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.isSwitch();
        boolean boolean7 = node0.isExprResult();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel1, "Not declared as a type name");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.level;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertNull(checkLevel4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = com.google.javascript.rhino.Node.CHANGE_TIME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType1, functionType2, objectType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        compilerInput5.setModule(jSModule6);
        try {
            java.util.Collection<java.lang.String> strCollection8 = compilerInput5.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setAliasableGlobals("this");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        try {
            int int7 = compilerInput4.getNumLines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        boolean boolean6 = compilerOptions0.ambiguateProperties;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        java.lang.String str7 = compiler0.getAstDotGraph();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        boolean boolean14 = compilerOptions0.getInferTypes();
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean19 = compilerOptions15.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions15.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions21.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean31 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions27.checkGlobalThisLevel;
        compilerOptions21.setCheckUnreachableCode(checkLevel32);
        compilerOptions15.checkMissingReturn = checkLevel32;
        compilerOptions0.checkRequires = checkLevel32;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        node5.addChildToFront(node6);
        boolean boolean8 = node5.isFor();
        node5.setSourceEncodedPositionForTree((int) '#');
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.forIn(node3, node4, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        com.google.javascript.rhino.InputId inputId7 = compilerInput5.getInputId();
        try {
            int int9 = compilerInput5.getLineOffset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(inputId7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        org.junit.Assert.assertNotNull(detailLevel0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.breakNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromInputStream("Not declared as a constructor", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        boolean boolean15 = compilerOptions0.preferLineBreakAtEndOfFile;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        compilerOptions0.setAggressiveVarCheck(checkLevel31);
        compilerOptions0.setLineBreak(false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.exprResult(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.inlineFunctions = true;
        boolean boolean8 = compilerOptions0.ideMode;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        sourceFile2.setOriginalPath("2019/06/13 15:58");
        try {
            int int10 = sourceFile2.getColumnOfOffset((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        try {
            java.util.Collection<java.lang.String> strCollection6 = compilerInput5.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult3 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node1, astRoot2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node4, node5, node7);
        java.lang.String str10 = node1.checkTreeEquals(node9);
        boolean boolean11 = node9.isRegExp();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node9.getStaticSourceFile();
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.var(node0, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str10.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("2019/06/13 15:58", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder2 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node4 = null;
        try {
            compiler0.toSource(codeBuilder2, 37, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = compiler0.tracker;
        com.google.javascript.jscomp.JSModule jSModule9 = null;
        try {
            java.lang.String[] strArray10 = compiler0.toSourceArray(jSModule9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(performanceTracker8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = parseResult2.ast;
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = parseResult2.oldAst;
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(astRoot4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("this");
        java.lang.String str3 = com.google.javascript.jscomp.NodeUtil.getSourceName(node2);
        try {
            boolean boolean4 = closureCodingConvention0.isPropertyTestFunction(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter4, logger5);
        int int7 = loggerErrorManager6.getWarningCount();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter4, logger5);
        com.google.javascript.jscomp.JSError[] jSErrorArray7 = loggerErrorManager6.getErrors();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(messageFormatter4);
        org.junit.Assert.assertNotNull(jSErrorArray7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        boolean boolean3 = node0.isStringKey();
        java.lang.String str7 = node0.toString(false, true, false);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "SCRIPT" + "'", str7.equals("SCRIPT"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        compilerOptions0.setGroupVariableDeclarations(true);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isScript();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.hook(node30, node31, node33);
        java.lang.String str36 = node27.checkTreeEquals(node35);
        com.google.javascript.rhino.Node node37 = node35.removeChildren();
        com.google.javascript.rhino.Node node38 = node25.copyInformationFrom(node37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        node37.setJSType(jSType39);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str36.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean7 = compilerOptions0.prettyPrint;
        compilerOptions0.setDefineToBooleanLiteral("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_RETURN;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("this");
        java.lang.String str2 = com.google.javascript.jscomp.NodeUtil.getSourceName(node1);
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node4, node5, node7);
        java.lang.String str13 = node5.toString(false, true, true);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node17);
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.tryCatchFinally(node1, node3, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "THIS" + "'", str13.equals("THIS"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.setInstrumentationTemplate("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        boolean boolean10 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setReplaceIdGenerators(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isScript();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.hook(node30, node31, node33);
        java.lang.String str36 = node27.checkTreeEquals(node35);
        com.google.javascript.rhino.Node node37 = node35.removeChildren();
        com.google.javascript.rhino.Node node38 = node25.copyInformationFrom(node37);
        try {
            com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.cast(node38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str36.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        loggerErrorManager1.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        int int17 = node1.getLength();
        boolean boolean18 = node1.isIf();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        node26.addChildToFront(node27);
        boolean boolean29 = node26.isEmpty();
        com.google.javascript.rhino.Node node30 = node23.useSourceInfoIfMissingFrom(node26);
        java.lang.Object obj32 = node30.getProp(4);
        com.google.javascript.rhino.Node node33 = null;
        try {
            com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.eq(node30, node33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(obj32);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node0.mayMutateArguments();
        com.google.javascript.rhino.InputId inputId11 = node0.getInputId();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(inputId11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.hook(node19, node20, node22);
        java.lang.String str28 = node20.toString(false, true, true);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean33 = node32.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.hook(node29, node30, node32);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap35 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node20, node32);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        node36.addChildToFront(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node40 = node37.srcrefTree(node39);
        com.google.javascript.rhino.Node node41 = node32.copyInformationFrom(node37);
        boolean boolean42 = node41.isFalse();
        com.google.javascript.rhino.Node node43 = node18.srcrefTree(node41);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.thisNode();
        node44.addChildToFront(node45);
        boolean boolean47 = node44.isEmpty();
        com.google.javascript.rhino.Node node48 = node41.useSourceInfoIfMissingFrom(node44);
        java.lang.Object obj50 = node48.getProp(4);
        try {
            com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, node14, node48, 43, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "THIS" + "'", str28.equals("THIS"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeMap35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNull(obj50);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Unknown class name");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Unknown class name)" + "'", str1.equals("(Unknown class name)"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel4, "Not declared as a type name");
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.make("Not declared as a type name", checkLevel8, "Not declared as a type name");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray11 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType6, diagnosticType10 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray11);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray11);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticTypeArray11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        boolean boolean6 = node3.isNew();
        try {
            java.lang.String str7 = node3.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SCRIPT is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue1 = com.google.javascript.jscomp.NodeUtil.isStrWhiteSpaceChar((int) ' ');
        org.junit.Assert.assertNotNull(ternaryValue1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isLocalResultCall();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node8 = node5.srcrefTree(node7);
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.doNode(node1, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = node0.useSourceInfoFrom(node2);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.hook(node9, node10, node12);
        java.lang.String str15 = node6.checkTreeEquals(node14);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) '#', node14, node17, 2, 100);
        int int21 = node17.getLength();
        try {
            com.google.javascript.rhino.Node node22 = node0.getChildBefore(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str15.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean5 = compilerOptions1.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel6);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup8 = com.google.javascript.jscomp.DiagnosticGroups.MISPLACED_TYPE_ANNOTATION;
        boolean boolean9 = diagnosticGroupWarningsGuard7.disables(diagnosticGroup8);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        compilerInput4.setSourceFile(sourceFile9);
        try {
            int int14 = sourceFile9.getColumnOfOffset(10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.exportTestFunctions = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap10 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap10);
        com.google.javascript.jscomp.CompilerOptions.Reach reach12 = null;
        try {
            compilerOptions0.setRemoveUnusedVariable(reach12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        boolean boolean12 = node6.isNumber();
        java.lang.String str13 = closureCodingConvention0.extractClassNameIfRequire(node5, node6);
        boolean boolean14 = node6.isAnd();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        try {
            java.io.Reader reader5 = sourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        boolean boolean6 = node3.isObjectLit();
        java.lang.Appendable appendable7 = null;
        try {
            node3.appendStringTree(appendable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        node13.putIntProp((int) ' ', (int) (short) 10);
        boolean boolean20 = node13.isFromExterns();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = compiler0.getOldParseTreeByName("this");
        com.google.javascript.jscomp.NodeTraversal.FunctionCallback functionCallback7 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseChangedFunctions((com.google.javascript.jscomp.AbstractCompiler) compiler0, functionCallback7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(astRoot6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        boolean boolean8 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 55, 39);
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo4 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        boolean boolean24 = compilerOptions0.assumeStrictThis();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        compilerOptions0.setCheckSymbols(true);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("Not declared as a constructor");
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder0.withCharset(charset3);
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(builder4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        try {
            int int5 = compilerInput4.getNumLines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        compilerOptions0.reserveRawExports = false;
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy21 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setInlineProperties(true);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy21 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy21.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.string("");
        boolean boolean3 = node2.isInstanceOf();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node4, astRoot5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        java.lang.String str13 = node4.checkTreeEquals(node12);
        boolean boolean14 = node4.mayMutateArguments();
        com.google.javascript.rhino.InputId inputId15 = node4.getInputId();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot17 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult18 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node16, astRoot17);
        boolean boolean19 = node16.isGetterDef();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean22 = node21.hasChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean24 = node23.hasChildren();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.hook(node20, node21, node23);
        boolean boolean26 = node23.isVoid();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node27.addChildToFront(node28);
        boolean boolean30 = node27.isFor();
        boolean boolean31 = node27.isExprResult();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot33 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult34 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node32, astRoot33);
        boolean boolean35 = node32.isStringKey();
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] { node2, node4, node16, node23, node27, node32 };
        try {
            com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node((-1), nodeArray36, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str13.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(inputId15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(nodeArray36);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node0.mayMutateArguments();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        boolean boolean17 = node14.isVoid();
        com.google.javascript.rhino.Node node18 = node14.getLastSibling();
        try {
            com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.eq(node0, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.setDefineToDoubleLiteral("Exceeded max number of optimization iterations: ", (double) 32);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        boolean boolean7 = compilerInput5.isExtern();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        com.google.javascript.rhino.Node node10 = node0.cloneNode();
        try {
            java.lang.String str11 = node10.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SCRIPT is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        java.lang.String[] strArray25 = new java.lang.String[] { "2019/06/13 15:58", "2019/06/13 15:58", "", "hi!", "2019/06/13 15:58", "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", "THIS", "this", "" };
        java.util.ArrayList<java.lang.String> strList26 = new java.util.ArrayList<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList26, strArray25);
        compilerOptions0.setReplaceStringsConfiguration("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", (java.util.List<java.lang.String>) strList26);
        compilerOptions0.inputDelimiter = "D4J_Closure_123_FIXED_VERSION";
        boolean boolean31 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        try {
            java.lang.String str7 = sourceFile6.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node8.isIf();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.pos(node8);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.string("");
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.add(node0, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNotNull(format9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) '#', "", 43, (int) (short) 0);
        boolean boolean5 = com.google.javascript.jscomp.NodeUtil.isLValue(node4);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        java.lang.String str23 = jSError22.description;
        int int24 = jSError22.getCharno();
        int int25 = jSError22.lineNumber;
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str23.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.rhino.head.ErrorReporter errorReporter3 = null;
        java.util.logging.Logger logger4 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult5 = com.google.javascript.jscomp.parsing.ParserRunner.parse(staticSourceFile0, "", config2, errorReporter3, logger4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.inputDelimiter = "THIS";
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCommonJSModulePathPrefix("hi!");
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.checkSymbols = false;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput11);
        com.google.javascript.jscomp.SourceFile sourceFile13 = compilerInput12.getSourceFile();
        com.google.javascript.rhino.InputId inputId14 = compilerInput12.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, inputId14, true);
        com.google.javascript.jscomp.SourceFile.Generator generator18 = null;
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator18);
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(sourceFile19, true);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(sourceFile19, false);
        com.google.javascript.jscomp.SourceFile.Generator generator25 = null;
        com.google.javascript.jscomp.SourceFile sourceFile26 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator25);
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(sourceFile26, true);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput28);
        com.google.javascript.jscomp.SourceFile sourceFile30 = compilerInput29.getSourceFile();
        com.google.javascript.rhino.InputId inputId31 = compilerInput29.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput23, inputId31, true);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray34 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput6, compilerInput23 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList35 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList35, dependencyInfoArray34);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies37 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertNotNull(sourceFile13);
        org.junit.Assert.assertNotNull(inputId14);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertNotNull(sourceFile26);
        org.junit.Assert.assertNotNull(sourceFile30);
        org.junit.Assert.assertNotNull(inputId31);
        org.junit.Assert.assertNotNull(dependencyInfoArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.flowSensitiveInlineVariables = true;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = parseResult2.ast;
        boolean boolean4 = node3.isQualifiedName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        node5.addChildToFront(node6);
        boolean boolean8 = node5.isFor();
        boolean boolean9 = node5.isExprResult();
        int int10 = node5.getCharno();
        com.google.javascript.rhino.Node node11 = node3.useSourceInfoIfMissingFrom(node5);
        com.google.javascript.rhino.Node node12 = node3.getNext();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.aliasKeywords = false;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = null;
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray9 = new com.google.javascript.jscomp.JSModule[] { jSModule8 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray14 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList15 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList15, locationMappingArray14);
        compilerOptions10.sourceMapLocationMappings = locationMappingList15;
        boolean boolean18 = compilerOptions10.isDisambiguatePrivateProperties();
        try {
            com.google.javascript.jscomp.Result result19 = compiler0.compile(jSSourceFile7, jSModuleArray9, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertNotNull(jSModuleArray9);
        org.junit.Assert.assertNotNull(locationMappingArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setColorizeErrorOutput(false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        boolean boolean23 = node3.isFromExterns();
        try {
            double double24 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: SCRIPT is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        sourceFile2.setOriginalPath("2019/06/13 15:58");
        java.lang.String str9 = sourceFile2.getName();
        java.lang.String str10 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Not declared as a type name" + "'", str9.equals("Not declared as a type name"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Not declared as a type name" + "'", str10.equals("Not declared as a type name"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.level;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticGroup4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        char[] charArray2 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        com.google.javascript.rhino.Node node22 = node13.copyInformationFrom(node18);
        boolean boolean23 = node13.isBreak();
        int int24 = node13.getLineno();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.locale;
        compilerOptions6.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions6.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean17 = compilerOptions13.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel18);
        compilerOptions6.aggressiveVarCheck = checkLevel18;
        compiler0.initOptions(compilerOptions6);
        java.util.logging.Logger logger22 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager23 = new com.google.javascript.jscomp.LoggerErrorManager(logger22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean31 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions27.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel32, diagnosticType35, strArray37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.thisNode();
        node39.addChildToFront(node40);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node43 = node40.srcrefTree(node42);
        boolean boolean44 = node42.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions49 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions49.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean53 = compilerOptions49.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions49.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray59 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel54, diagnosticType57, strArray59);
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(node42, diagnosticType45, strArray59);
        loggerErrorManager23.report(checkLevel32, jSError61);
        compiler0.report(jSError61);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setDefineToStringLiteral("", "hi!");
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setAngularPass(true);
        boolean boolean11 = compilerOptions0.checkSymbols;
        java.lang.String str12 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            java.lang.String[] strArray6 = compiler1.toSourceArray(jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(messageFormatter4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        int int4 = node3.getChildCount();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.hook(node5, node6, node8);
        java.lang.String str14 = node6.toString(false, true, true);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean17 = node16.hasChildren();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node15, node16, node18);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap21 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node6, node18);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        node22.addChildToFront(node23);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node26 = node23.srcrefTree(node25);
        com.google.javascript.rhino.Node node27 = node18.copyInformationFrom(node23);
        boolean boolean28 = node27.isFalse();
        try {
            com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.tryCatch(node3, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "THIS" + "'", str14.equals("THIS"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeMap21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setRemoveDeadCode(true);
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        compilerOptions0.setCheckControlStructures(true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        try {
            node1.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String str34 = jSError33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = composeWarningsGuard7.level(jSError33);
        com.google.javascript.jscomp.CheckLevel checkLevel36 = jSError33.getDefaultLevel();
        int int37 = jSError33.getCharno();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str34.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection2 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node3 = null;
        try {
            java.util.List<java.lang.String> strList4 = closureCodingConvention0.identifyTypeDeclarationCall(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection2);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCommonJSModulePathPrefix("hi!");
        compilerOptions0.setExternExports(false);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        boolean boolean3 = node0.isGetterDef();
        int int4 = node0.getSourceOffset();
        boolean boolean5 = node0.isOr();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean5 = node0.getBooleanProp((int) (short) 0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention6 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str7 = closureCodingConvention6.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType11 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        closureCodingConvention6.applyDelegateRelationship(objectType8, objectType9, objectType10, functionType11, functionType12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        node14.addChildToFront(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node18 = node15.srcrefTree(node17);
        boolean boolean19 = node17.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind21 = closureCodingConvention6.describeFunctionBind(node17, false);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot23 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult24 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node22, astRoot23);
        boolean boolean25 = node22.isGetterDef();
        java.lang.String str26 = node22.getQualifiedName();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention27 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str28 = closureCodingConvention27.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection29 = closureCodingConvention27.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        node31.addChildToFront(node32);
        com.google.javascript.rhino.Node node34 = node30.useSourceInfoFrom(node32);
        com.google.javascript.jscomp.CodingConvention.Bind bind36 = closureCodingConvention27.describeFunctionBind(node30, false);
        java.lang.String str37 = closureCodingConvention6.extractClassNameIfProvide(node22, node30);
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.sheq(node0, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.global" + "'", str7.equals("goog.global"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(bind21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "goog.global" + "'", str28.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNull(bind36);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '#');
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesThis();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = sideEffectFlags1.setMutatesArguments();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags4 = sideEffectFlags3.setMutatesGlobalState();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertNotNull(sideEffectFlags3);
        org.junit.Assert.assertNotNull(sideEffectFlags4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        compilerOptions0.optimizeReturns = false;
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setComputeFunctionSideEffects(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.aliasKeywords = true;
        boolean boolean24 = compilerOptions0.assumeStrictThis();
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str26 = compilerOptions25.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray31 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList32 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32, warningsGuardArray31);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard34 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32);
        com.google.javascript.jscomp.JSError jSError35 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = composeWarningsGuard34.level(jSError35);
        compilerOptions27.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard34);
        java.lang.String[] strArray42 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet43 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet43, strArray42);
        compilerOptions27.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet43);
        compilerOptions25.aliasableStrings = strSet43;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup47 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions48.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode54 = null;
        compilerOptions48.setTracer(tracerMode54);
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions56.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions56.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions62.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean66 = compilerOptions62.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel67 = compilerOptions62.checkGlobalThisLevel;
        compilerOptions56.setCheckUnreachableCode(checkLevel67);
        compilerOptions48.checkMissingGetCssNameLevel = checkLevel67;
        compilerOptions25.setWarningLevel(diagnosticGroup47, checkLevel67);
        compilerOptions0.checkProvides = checkLevel67;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(warningsGuardArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(checkLevel36);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup47);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        byte[] byteArray6 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray6);
        com.google.javascript.jscomp.SourceMap.Format format8 = com.google.javascript.jscomp.SourceMap.Format.V3;
        compilerOptions0.sourceMapFormat = format8;
        compilerOptions0.setSourceMapOutputPath("");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(format8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        node7.addChildToFront(node8);
        boolean boolean10 = node7.isEmpty();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = null;
        node7.addChildrenAfter(node11, node12);
        com.google.javascript.rhino.Node node14 = null;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot16 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult17 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node15, astRoot16);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean20 = node19.hasChildren();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean22 = node21.hasChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.hook(node18, node19, node21);
        java.lang.String str24 = node15.checkTreeEquals(node23);
        com.google.javascript.rhino.Node node25 = node15.cloneNode();
        try {
            com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(10, node6, node12, node14, node15, 1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str24.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceFile sourceFile6 = compilerInput5.getSourceFile();
        com.google.javascript.rhino.InputId inputId7 = compilerInput5.getInputId();
        java.lang.Object obj8 = null;
        boolean boolean9 = inputId7.equals(obj8);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceFile6);
        org.junit.Assert.assertNotNull(inputId7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("this");
        com.google.javascript.jscomp.parsing.Config config3 = null;
        com.google.javascript.rhino.head.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile1, "goog.global", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray4 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList5, locationMappingArray4);
        compilerOptions0.sourceMapLocationMappings = locationMappingList5;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertNotNull(locationMappingArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setPrintInputDelimiter(true);
        boolean boolean35 = compilerOptions0.inlineGetters;
        compilerOptions0.syntheticBlockStartMarker = "";
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.markNoSideEffectCalls = false;
        boolean boolean9 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = com.google.javascript.rhino.Node.REFLECTED_OBJECT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("SCRIPT");
        boolean boolean2 = node1.isLabelName();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node4, node5, node7);
        java.lang.String str13 = node5.toString(false, true, true);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap20 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node5, node17);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        node21.addChildToFront(node22);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node25 = node22.srcrefTree(node24);
        com.google.javascript.rhino.Node node26 = node17.copyInformationFrom(node22);
        boolean boolean27 = node26.isFalse();
        com.google.javascript.rhino.Node node28 = node3.srcrefTree(node26);
        boolean boolean29 = node28.isScript();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot31 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult32 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node30, astRoot31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean35 = node34.hasChildren();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean37 = node36.hasChildren();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.hook(node33, node34, node36);
        java.lang.String str39 = node30.checkTreeEquals(node38);
        com.google.javascript.rhino.Node node40 = node38.removeChildren();
        com.google.javascript.rhino.Node node41 = node28.copyInformationFrom(node40);
        com.google.javascript.rhino.Node node42 = node40.cloneNode();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.thisNode();
        node43.addChildToFront(node44);
        int int46 = node44.getType();
        boolean boolean47 = node44.isBlock();
        try {
            node1.addChildAfter(node42, node44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "THIS" + "'", str13.equals("THIS"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeMap20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str39.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 42 + "'", int46 == 42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.lineBreak = false;
        compilerOptions0.setTightenTypes(true);
        boolean boolean28 = compilerOptions0.shouldColorizeErrorOutput();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        boolean boolean8 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        compilerInput5.setModule(jSModule6);
        compilerInput5.clearAst();
        try {
            java.util.Collection<java.lang.String> strCollection9 = compilerInput5.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.caseNode(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.reserveRawExports = false;
        java.lang.String str33 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = node0.useSourceInfoFrom(node2);
        boolean boolean5 = node4.isLocalResultCall();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler1.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler1.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = null;
        compiler1.tracker = performanceTracker4;
        java.lang.String str6 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.locale;
        compilerOptions7.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions7.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel19);
        compilerOptions7.aggressiveVarCheck = checkLevel19;
        compiler1.initOptions(compilerOptions7);
        com.google.javascript.jscomp.MessageFormatter messageFormatter24 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, true);
        com.google.javascript.jscomp.CodingConvention codingConvention25 = compiler1.getCodingConvention();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(diagnosticGroup13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(messageFormatter24);
        org.junit.Assert.assertNotNull(codingConvention25);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot14 = null;
        compiler10.setOldParseTree("", astRoot14);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter16 = compiler10.getReverseAbstractInterpreter();
        boolean boolean17 = compiler10.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler10, sourceExcerpt18);
        java.util.logging.Logger logger20 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager21 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter19, logger20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str23 = compilerOptions22.locale;
        compilerOptions22.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions22.reportMissingOverride;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        node27.addChildToFront(node28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node31 = node28.srcrefTree(node30);
        boolean boolean32 = node30.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean41 = compilerOptions37.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType45 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray47 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel42, diagnosticType45, strArray47);
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make(node30, diagnosticType33, strArray47);
        java.lang.String str50 = jSError49.toString();
        loggerErrorManager21.println(checkLevel26, jSError49);
        int int52 = jSError49.getNodeLength();
        try {
            java.lang.String str53 = lightweightMessageFormatter9.formatError(jSError49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType45);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str50.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        boolean boolean11 = node8.isFor();
        boolean boolean12 = node8.isExprResult();
        java.util.List<java.lang.String> strList13 = closureCodingConvention0.identifyTypeDeclarationCall(node8);
        node8.setVarArgs(true);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strList13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.setLooseTypes(true);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isThis();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        boolean boolean17 = node13.mayMutateArguments();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        boolean boolean2 = node1.isOnlyModifiesArgumentsCall();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str2 = closureCodingConvention1.getGlobalObject();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean11 = node10.hasChildren();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.hook(node7, node8, node10);
        boolean boolean13 = node7.isNumber();
        java.lang.String str14 = closureCodingConvention1.extractClassNameIfRequire(node6, node7);
        node7.setVarArgs(true);
        boolean boolean17 = detailLevel0.apply(node7);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.global" + "'", str2.equals("goog.global"));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions.Reach reach20 = null;
        try {
            compilerOptions0.setInlineFunctions(reach20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean5 = compilerOptions1.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions1.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel6);
        java.lang.String str8 = diagnosticGroupWarningsGuard7.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagnosticGroup<checkTypes>(OFF)" + "'", str8.equals("DiagnosticGroup<checkTypes>(OFF)"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        sourceFile2.setOriginalPath("2019/06/13 15:58");
        try {
            int int10 = sourceFile2.getColumnOfOffset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setManageClosureDependencies(false);
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        com.google.javascript.jscomp.Scope scope10 = compiler0.getTopScope();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(scope10);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(charArray1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions23.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode29 = null;
        compilerOptions23.setTracer(tracerMode29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions31.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean41 = compilerOptions37.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.checkGlobalThisLevel;
        compilerOptions31.setCheckUnreachableCode(checkLevel42);
        compilerOptions23.checkMissingGetCssNameLevel = checkLevel42;
        compilerOptions0.setWarningLevel(diagnosticGroup22, checkLevel42);
        java.util.Set<java.lang.String> strSet46 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions0.stripNameSuffixes = strSet46;
        boolean boolean48 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.aliasKeywords = true;
        boolean boolean24 = compilerOptions0.prettyPrint;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str26 = compilerOptions25.locale;
        compilerOptions25.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions25.checkControlStructures = false;
        compilerOptions25.checkSuspiciousCode = true;
        boolean boolean33 = compilerOptions25.crossModuleMethodMotion;
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions34.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean38 = compilerOptions34.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions34.checkGlobalThisLevel;
        compilerOptions25.checkGlobalNamesLevel = checkLevel39;
        compilerOptions0.setCheckUnreachableCode(checkLevel39);
        compilerOptions0.setAppNameStr("goog.exportProperty");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode7 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        com.google.javascript.jscomp.parsing.Config config9 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode7, false);
        com.google.javascript.rhino.head.ErrorReporter errorReporter10 = null;
        java.util.logging.Logger logger11 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile2, "D4J_Closure_123_FIXED_VERSION", config9, errorReporter10, logger11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + languageMode7 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode7.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(config9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        compilerOptions0.setAggressiveVarCheck(checkLevel31);
        boolean boolean39 = compilerOptions0.assumeStrictThis();
        compilerOptions0.setRuntimeTypeCheckLogFunction("SCRIPT");
        boolean boolean42 = compilerOptions0.exportTestFunctions;
        compilerOptions0.setSummaryDetailLevel(57);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFalse();
        boolean boolean4 = node0.isNE();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setSourceMapOutputPath("Exceeded max number of optimization iterations: ");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) 10.0f);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("Unknown class name", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean25 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.setDefineToBooleanLiteral("", false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        compilerOptions0.setRenamePrefixNamespace("");
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray21 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList22 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList22, locationMappingArray21);
        compilerOptions17.sourceMapLocationMappings = locationMappingList22;
        boolean boolean25 = compilerOptions17.isDisambiguatePrivateProperties();
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap26 = compilerOptions17.getTweakReplacements();
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy27 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions17.propertyRenaming = propertyRenamingPolicy27;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy27);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(locationMappingArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strMap26);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy27 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy27.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.setInstrumentationTemplate("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions10.setAggressiveVarCheck(checkLevel14);
        java.util.Set<java.lang.String> strSet16 = compilerOptions10.aliasableStrings;
        compilerOptions0.setIdGenerators(strSet16);
        java.lang.String str18 = compilerOptions0.locale;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setTightenTypes(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        boolean boolean4 = node3.hasOneChild();
        boolean boolean5 = node3.isCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        boolean boolean21 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.String str22 = compilerOptions0.renamePrefixNamespace;
        compilerOptions0.setReserveRawExports(false);
        compilerOptions0.setProcessObjectPropertyString(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy27 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy27 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy27.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        boolean boolean8 = compilerOptions0.removeUnusedLocalVars;
        java.lang.String str9 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.setCollapseObjectLiterals(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.fromString("D4J_Closure_123_FIXED_VERSION");
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        com.google.javascript.rhino.Node node10 = null;
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.doNode(node0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node4.isNull();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray7 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList8 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8, warningsGuardArray7);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList8);
        compilerOptions0.setWarningsGuard(composeWarningsGuard10);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        int int4 = node3.getChildCount();
        node3.setLineno((int) (short) 0);
        boolean boolean7 = node3.isDebugger();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node3.isVoid();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.hook(node8, node9, node11);
        boolean boolean14 = node11.isVoid();
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.and(node7, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: first new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("Not declared as a constructor");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile4 = builder0.buildFromFile("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFalse();
        boolean boolean4 = node0.isFalse();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean9 = node8.hasChildren();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.hook(node5, node6, node8);
        com.google.javascript.rhino.JSDocInfo jSDocInfo11 = null;
        com.google.javascript.rhino.Node node12 = node8.setJSDocInfo(jSDocInfo11);
        try {
            node0.addChildToFront(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = compiler0.tracker;
        com.google.javascript.rhino.Node node9 = compiler0.getRoot();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(performanceTracker8);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        try {
            com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.throwNode(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        boolean boolean23 = node19.isNE();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        java.lang.String str30 = closureCodingConvention0.extractClassNameIfRequire(node19, node27);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean33 = node32.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean35 = node34.hasChildren();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.hook(node31, node32, node34);
        try {
            boolean boolean37 = closureCodingConvention0.isPropertyTestFunction(node31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        boolean boolean3 = node0.isGetterDef();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags5 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '#');
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags6 = sideEffectFlags5.setMutatesThis();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags7 = sideEffectFlags5.setMutatesArguments();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags8 = sideEffectFlags7.setThrows();
        try {
            node0.setSideEffectFlags(sideEffectFlags7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got SCRIPT");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(sideEffectFlags6);
        org.junit.Assert.assertNotNull(sideEffectFlags7);
        org.junit.Assert.assertNotNull(sideEffectFlags8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        boolean boolean3 = closureCodingConvention0.isSuperClassReference("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        java.util.Set<java.lang.String> strSet22 = compilerOptions0.stripTypePrefixes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.locale;
        compilerOptions6.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions6.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean17 = compilerOptions13.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel18);
        compilerOptions6.aggressiveVarCheck = checkLevel18;
        compiler0.initOptions(compilerOptions6);
        com.google.javascript.jscomp.Scope scope22 = compiler0.getTopScope();
        boolean boolean23 = compiler0.isTypeCheckingEnabled();
        try {
            compiler0.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(scope22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult5 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot4);
        com.google.javascript.rhino.Node node6 = parseResult5.ast;
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        compilerOptions0.optimizeReturns = false;
        compilerOptions0.setInlineGetters(false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        boolean boolean12 = node6.isNumber();
        java.lang.String str13 = closureCodingConvention0.extractClassNameIfRequire(node5, node6);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean18 = node17.hasChildren();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node14, node15, node17);
        java.lang.String str20 = com.google.javascript.jscomp.NodeUtil.getSourceName(node14);
        com.google.javascript.rhino.Node node21 = node14.removeFirstChild();
        try {
            com.google.javascript.jscomp.CodingConvention.Bind bind23 = closureCodingConvention0.describeFunctionBind(node21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        boolean boolean31 = compilerOptions0.checkTypes;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = sideEffectFlags0.setThrows();
        org.junit.Assert.assertNotNull(sideEffectFlags1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCommonJSModulePathPrefix("hi!");
        java.lang.String str6 = compilerOptions0.checkMissingGetCssNameBlacklist;
        java.lang.String[] strArray9 = new java.lang.String[] { "goog.global" };
        java.util.ArrayList<java.lang.String> strList10 = new java.util.ArrayList<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList10, strArray9);
        compilerOptions0.setReplaceStringsConfiguration("this", (java.util.List<java.lang.String>) strList10);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) '#', "", 43, (int) (short) 0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node5, astRoot6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.hook(node8, node9, node11);
        java.lang.String str14 = node5.checkTreeEquals(node13);
        com.google.javascript.rhino.Node node15 = node5.cloneNode();
        node5.setSourceEncodedPosition((int) 'a');
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.eq(node4, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str14.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap2 = compiler1.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager3 = compiler1.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = null;
        compiler1.tracker = performanceTracker4;
        java.lang.String str6 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str8 = compilerOptions7.locale;
        compilerOptions7.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions7.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard20 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup13, checkLevel19);
        compilerOptions7.aggressiveVarCheck = checkLevel19;
        compiler1.initOptions(compilerOptions7);
        com.google.javascript.jscomp.MessageFormatter messageFormatter24 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray26 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setMoveFunctionDeclarations(true);
        compilerOptions27.setOutputJsStringUsage(false);
        compilerOptions27.inlineFunctions = false;
        try {
            com.google.javascript.jscomp.Result result34 = compiler1.compile(jSSourceFile25, jSModuleArray26, compilerOptions27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNull(sourceMap2);
        org.junit.Assert.assertNotNull(errorManager3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(diagnosticGroup13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(messageFormatter24);
        org.junit.Assert.assertNotNull(jSModuleArray26);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy12 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray13 = anonymousFunctionNamingPolicy12.getReservedCharacters();
        compilerOptions0.setAnonymousFunctionNaming(anonymousFunctionNamingPolicy12);
        char[] charArray15 = anonymousFunctionNamingPolicy12.getReservedCharacters();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy12 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy12.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray13);
        org.junit.Assert.assertNotNull(charArray15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        boolean boolean14 = compilerOptions0.getInferTypes();
        com.google.javascript.jscomp.CodingConvention codingConvention15 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(codingConvention15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node0.isQuotedString();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node1.isGetterDef();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        node16.addChildToFront(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node20 = node17.srcrefTree(node19);
        boolean boolean21 = node19.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make(node19, diagnosticType22, strArray36);
        com.google.javascript.jscomp.CheckLevel checkLevel39 = diagnosticType22.level;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel39;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        compilerInput4.setSourceFile(sourceFile9);
        try {
            java.util.Collection<java.lang.String> strCollection13 = compilerInput4.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Not declared as a type name");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String str34 = jSError33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = composeWarningsGuard7.level(jSError33);
        com.google.javascript.jscomp.CheckLevel checkLevel36 = jSError33.getDefaultLevel();
        int int37 = jSError33.getNodeSourceOffset();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str34.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setDebugFunctionSideEffectsPath("goog.exportProperty");
        compilerOptions0.setPrettyPrint(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt6 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, true);
        com.google.javascript.jscomp.JsAst jsAst13 = new com.google.javascript.jscomp.JsAst(sourceFile10);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile14 };
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker19 = null;
        compiler16.tracker = performanceTracker19;
        com.google.javascript.rhino.head.ast.AstRoot astRoot22 = compiler16.getOldParseTreeByName("this");
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str24 = compilerOptions23.locale;
        compilerOptions23.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions23.checkControlStructures = false;
        compilerOptions23.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy31 = compilerOptions23.getCheckEventfulObjectDisposalPolicy();
        compilerOptions23.setAngularPass(true);
        compiler16.initOptions(compilerOptions23);
        try {
            com.google.javascript.jscomp.Result result35 = compiler0.compile(sourceFile10, jSSourceFileArray15, compilerOptions23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNull(astRoot22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy31 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy31.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.setReserveRawExports(false);
        boolean boolean33 = compilerOptions0.generateExports;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType2, objectType3, objectType4, functionType5, functionType6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        node8.addChildToFront(node9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = node9.srcrefTree(node11);
        boolean boolean13 = node11.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind15 = closureCodingConvention0.describeFunctionBind(node11, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection16 = closureCodingConvention0.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection17 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        boolean boolean23 = node19.isNE();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        java.lang.String str30 = closureCodingConvention0.extractClassNameIfRequire(node19, node27);
        java.lang.String str34 = node19.toString(true, false, false);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(bind15);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection16);
        org.junit.Assert.assertNotNull(strCollection17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "THIS" + "'", str34.equals("THIS"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection2 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        java.lang.String str3 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.abstractMethod" + "'", str3.equals("goog.abstractMethod"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setRemoveTryCatchFinally(true);
        compilerOptions0.setSpecializeInitialModule(false);
        com.google.javascript.jscomp.MessageBundle messageBundle19 = null;
        compilerOptions0.setMessageBundle(messageBundle19);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        compilerInput4.setSourceFile(sourceFile9);
        try {
            int int14 = sourceFile9.getLineOffset((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        compilerInput4.setSourceFile(sourceFile9);
        try {
            int int14 = sourceFile9.getLineOffset(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isEmpty();
        java.lang.Object obj7 = node0.getProp(49);
        node0.detachChildren();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean25 = compilerOptions0.convertToDottedProperties;
        java.util.Set<java.lang.String> strSet26 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.inlineVariables = false;
        compilerOptions0.jqueryPass = false;
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        compilerOptions0.optimizeReturns = true;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Unknown class name");
        int int3 = sourceFile1.getColumnOfOffset((int) '4');
        sourceFile1.clearCachedSource();
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setDefineToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", 0.0d);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.setInlineProperties(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        boolean boolean11 = node3.mayMutateArguments();
        boolean boolean12 = node3.hasMoreThanOneChild();
        boolean boolean13 = node3.isQualifiedName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.ErrorFormat errorFormat26 = compilerOptions0.errorFormat;
        compilerOptions0.setDefineToStringLiteral("Exceeded max number of optimization iterations: ", "this");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(errorFormat26);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler3.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        compiler3.setOldParseTree("", astRoot7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter9 = compiler3.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck15 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, reverseAbstractInterpreter9, jSTypeRegistry13, checkLevel14);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = null;
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        boolean boolean20 = node17.isEmpty();
        boolean boolean21 = node17.isString();
        boolean boolean22 = node17.isThrow();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        node23.addChildToFront(node24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node27 = node24.srcrefTree(node26);
        boolean boolean28 = node26.isComma();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot30 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult31 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node29, astRoot30);
        node29.detachChildren();
        boolean boolean33 = node26.hasChild(node29);
        try {
            typeCheck15.visit(nodeTraversal16, node17, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter9);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str6 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile7 = node0.getStaticSourceFile();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(staticSourceFile7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput4.getSourceAst();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(sourceAst6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setPrintInputDelimiter(true);
        boolean boolean35 = compilerOptions0.labelRenaming;
        compilerOptions0.setPrettyPrint(true);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str7 = compilerOptions6.locale;
        compilerOptions6.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions6.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean17 = compilerOptions13.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions13.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard19 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel18);
        compilerOptions6.aggressiveVarCheck = checkLevel18;
        compiler0.initOptions(compilerOptions6);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder22 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.returnNode();
        int int25 = node24.getSideEffectFlags();
        boolean boolean26 = node24.isCast();
        compiler0.toSource(codeBuilder22, 0, node24);
        com.google.javascript.rhino.Node node28 = node24.removeChildren();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(node28);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = null;
        com.google.javascript.jscomp.JSModule jSModule11 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule11 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str14 = compilerOptions13.locale;
        try {
            com.google.javascript.jscomp.Result result15 = compiler0.compile(jSSourceFileArray10, jSModuleArray12, compilerOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSModuleArray12);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        boolean boolean22 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean30 = compilerOptions26.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions26.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray36 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel31, diagnosticType34, strArray36);
        compilerOptions0.setAggressiveVarCheck(checkLevel31);
        boolean boolean39 = compilerOptions0.assumeStrictThis();
        compilerOptions0.setInstrumentMemoryAllocations(false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.recordFunctionInformation = true;
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode15 = null;
        compilerOptions0.setLanguageIn(languageMode15);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, (int) '#', 33);
        boolean boolean4 = node3.isStringKey();
        boolean boolean5 = node3.isCast();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("(Unknown class name)", generator1);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode5 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        com.google.javascript.jscomp.parsing.Config config7 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode5, false);
        com.google.javascript.rhino.head.ErrorReporter errorReporter8 = null;
        java.util.logging.Logger logger9 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult10 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile2, "goog.abstractMethod", config7, errorReporter8, logger9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + languageMode5 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode5.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
        org.junit.Assert.assertNotNull(config7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("SCRIPT");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray16 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel11, diagnosticType14, strArray16);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        boolean boolean23 = node21.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions28.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean32 = compilerOptions28.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions28.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray38 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel33, diagnosticType36, strArray38);
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make(node21, diagnosticType24, strArray38);
        loggerErrorManager2.report(checkLevel11, jSError40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = jSError40.getType();
        boolean boolean43 = diagnosticGroup0.matches(diagnosticType42);
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions44.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray51 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet52 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet52, strArray51);
        compilerOptions44.stripNamePrefixes = strSet52;
        java.util.Set<java.lang.String> strSet55 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions44.setStripNameSuffixes(strSet55);
        com.google.javascript.jscomp.CompilerOptions compilerOptions57 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions57.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions57.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode63 = null;
        compilerOptions57.setTracer(tracerMode63);
        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions65.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions65.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions71 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions71.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean75 = compilerOptions71.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel76 = compilerOptions71.checkGlobalThisLevel;
        compilerOptions65.setCheckUnreachableCode(checkLevel76);
        compilerOptions57.checkMissingGetCssNameLevel = checkLevel76;
        compilerOptions44.setCheckRequires(checkLevel76);
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard80 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel76);
        java.lang.String str81 = diagnosticGroupWarningsGuard80.toString();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(strArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(strSet55);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + checkLevel76 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel76.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "DiagnosticGroup<undefinedNames>(OFF)" + "'", str81.equals("DiagnosticGroup<undefinedNames>(OFF)"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        compilerOptions0.removeTryCatchFinally = true;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile26 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node25);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(staticSourceFile26);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("(Unknown class name)");
        try {
            java.lang.String str3 = sourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: (Unknown class name) (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        boolean boolean20 = compilerOptions0.labelRenaming;
        boolean boolean21 = compilerOptions0.removeUnusedPrototypeProperties;
        java.lang.String str22 = compilerOptions0.renamePrefixNamespace;
        compilerOptions0.setReserveRawExports(false);
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.computeFunctionSideEffects = false;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        boolean boolean23 = node3.isNE();
        java.lang.String str24 = node3.getSourceFileName();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean27 = node26.hasChildren();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean29 = node28.hasChildren();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.hook(node25, node26, node28);
        java.lang.String str31 = com.google.javascript.jscomp.NodeUtil.getSourceName(node25);
        try {
            com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.or(node3, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        boolean boolean4 = node1.isFor();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean9 = compilerOptions5.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String[] strArray39 = new java.lang.String[] { "THIS", "this", "hi!", "", "THIS" };
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("", node1, checkLevel10, diagnosticType17, strArray39);
        boolean boolean41 = node1.isGetElem();
        boolean boolean42 = node1.isDefaultCase();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.inlineConstantVars = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.isSwitch();
        com.google.javascript.rhino.Node node7 = node0.cloneNode();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.pos(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult8 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node6, astRoot7);
        node6.detachChildren();
        boolean boolean10 = node3.hasChild(node6);
        boolean boolean11 = node3.mayMutateArguments();
        boolean boolean12 = node3.isComma();
        boolean boolean13 = node3.isName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        com.google.javascript.rhino.InputId inputId7 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput8 = compiler0.getInput(inputId7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String str34 = jSError33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = composeWarningsGuard7.level(jSError33);
        java.lang.String str36 = composeWarningsGuard7.toString();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str34.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        boolean boolean15 = compilerOptions0.printInputDelimiter;
        boolean boolean16 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean17 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode18 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5;
        compilerOptions0.setLanguageOut(languageMode18);
        compilerOptions0.coalesceVariableNames = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + languageMode18 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5 + "'", languageMode18.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.setShadowVariables(true);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = null;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str15 = compilerOptions14.locale;
        compilerOptions14.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing18 = null;
        compilerOptions14.setTweakProcessing(tweakProcessing18);
        byte[] byteArray20 = new byte[] {};
        compilerOptions14.setInputVariableMapSerialized(byteArray20);
        compilerOptions14.gatherCssNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str25 = compilerOptions24.locale;
        compilerOptions24.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions24.setFoldConstants(false);
        compilerOptions24.optimizeCalls = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy32 = compilerOptions24.variableRenaming;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy33 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        compilerOptions14.setRenamingPolicy(variableRenamingPolicy32, propertyRenamingPolicy33);
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy33);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy32.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy33 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy33.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isScript();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.hook(node30, node31, node33);
        java.lang.String str36 = node27.checkTreeEquals(node35);
        com.google.javascript.rhino.Node node37 = node35.removeChildren();
        com.google.javascript.rhino.Node node38 = node25.copyInformationFrom(node37);
        com.google.javascript.rhino.Node node39 = node37.cloneNode();
        boolean boolean40 = node37.isHook();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str36.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setProtectHiddenSideEffects(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean19 = node18.hasChildren();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node17, node18, node20);
        boolean boolean23 = node17.isSwitch();
        com.google.javascript.rhino.Node node24 = node17.cloneNode();
        com.google.javascript.jscomp.SourceFile.Generator generator27 = null;
        com.google.javascript.jscomp.SourceFile sourceFile28 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator27);
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(sourceFile28, true);
        com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput30);
        com.google.javascript.jscomp.SourceFile sourceFile32 = compilerInput31.getSourceFile();
        com.google.javascript.jscomp.Compiler compiler33 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap34 = compiler33.getSourceMap();
        compilerInput31.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler33);
        try {
            com.google.javascript.jscomp.NodeUtil.verifyScopeChanges(nodeMap16, node17, true, (com.google.javascript.jscomp.AbstractCompiler) compiler33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(sourceFile28);
        org.junit.Assert.assertNotNull(sourceFile32);
        org.junit.Assert.assertNull(sourceMap34);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        int int17 = node1.getLength();
        node1.setCharno(0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        boolean boolean7 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setManageClosureDependencies(false);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode22 = compilerOptions0.getLanguageIn();
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + languageMode22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode22.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        node1.addChildToBack(node2);
        boolean boolean5 = node1.isReturn();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.setRemoveTryCatchFinally(true);
        boolean boolean17 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.VariableMap variableMap6 = null;
        compilerOptions0.setReplaceStringsInputMap(variableMap6);
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setDebugFunctionSideEffectsPath("goog.exportProperty");
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isScript();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.hook(node30, node31, node33);
        java.lang.String str36 = node27.checkTreeEquals(node35);
        com.google.javascript.rhino.Node node37 = node35.removeChildren();
        com.google.javascript.rhino.Node node38 = node25.copyInformationFrom(node37);
        boolean boolean39 = node37.mayMutateGlobalStateOrThrow();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str36.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        com.google.javascript.rhino.Node node22 = node13.copyInformationFrom(node18);
        node13.setCharno(0);
        boolean boolean25 = node13.isQuotedString();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(49, "goog.abstractMethod", 8, 39);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        compilerOptions0.setInstrumentationTemplate("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions10.setAggressiveVarCheck(checkLevel14);
        java.util.Set<java.lang.String> strSet16 = compilerOptions10.aliasableStrings;
        compilerOptions0.setIdGenerators(strSet16);
        boolean boolean18 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = parseResult2.ast;
        boolean boolean4 = node3.isQualifiedName();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        node5.addChildToFront(node6);
        boolean boolean8 = node5.isFor();
        boolean boolean9 = node5.isExprResult();
        boolean boolean10 = node5.isEmpty();
        int int11 = node5.getSourcePosition();
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.tryCatch(node3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setRemoveDeadCode(true);
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        compilerOptions0.optimizeReturns = false;
        compilerOptions0.setNameReferenceReportPath("Exceeded max number of optimization iterations: ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        java.lang.String str9 = node1.toString(false, true, true);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap16 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node1, node13);
        node13.putIntProp((int) ' ', (int) (short) 10);
        boolean boolean20 = node13.isDebugger();
        try {
            com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.neg(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "THIS" + "'", str9.equals("THIS"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeMap16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy8 = compilerOptions0.getCheckEventfulObjectDisposalPolicy();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str12 = compilerOptions11.locale;
        compilerOptions11.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions11.checkControlStructures = false;
        compilerOptions11.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions19.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode25 = null;
        compilerOptions19.setTracer(tracerMode25);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions27.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean37 = compilerOptions33.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions33.checkGlobalThisLevel;
        compilerOptions27.setCheckUnreachableCode(checkLevel38);
        compilerOptions19.checkMissingGetCssNameLevel = checkLevel38;
        compilerOptions11.setBrokenClosureRequiresLevel(checkLevel38);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel38);
        java.util.Set<java.lang.String> strSet43 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy8 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy8.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet43);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler3.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        compiler3.setOldParseTree("", astRoot7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter9 = compiler3.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck15 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, reverseAbstractInterpreter9, jSTypeRegistry13, checkLevel14);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult20 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node18, astRoot19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.hook(node21, node22, node24);
        java.lang.String str27 = node18.checkTreeEquals(node26);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '#', node26, node29, 2, 100);
        com.google.javascript.rhino.Node node33 = null;
        typeCheck15.visit(nodeTraversal16, node26, node33);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal35 = null;
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        node36.addChildToFront(node37);
        int int39 = node37.getType();
        boolean boolean40 = node37.isBlock();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention41 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str42 = closureCodingConvention41.getGlobalObject();
        com.google.javascript.rhino.jstype.ObjectType objectType43 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType46 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType47 = null;
        closureCodingConvention41.applyDelegateRelationship(objectType43, objectType44, objectType45, functionType46, functionType47);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.thisNode();
        node49.addChildToFront(node50);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node53 = node50.srcrefTree(node52);
        boolean boolean54 = node52.isRegExp();
        com.google.javascript.jscomp.CodingConvention.Bind bind56 = closureCodingConvention41.describeFunctionBind(node52, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection57 = closureCodingConvention41.getAssertionFunctions();
        java.util.Collection<java.lang.String> strCollection58 = closureCodingConvention41.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.thisNode();
        node59.addChildToFront(node60);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node63 = node60.srcrefTree(node62);
        boolean boolean64 = node60.isNE();
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.head.ast.AstRoot astRoot69 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult70 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node68, astRoot69);
        java.lang.String str71 = closureCodingConvention41.extractClassNameIfRequire(node60, node68);
        try {
            typeCheck15.visit(nodeTraversal35, node37, node68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter9);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str27.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 42 + "'", int39 == 42);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "goog.global" + "'", str42.equals("goog.global"));
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(bind56);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection57);
        org.junit.Assert.assertNotNull(strCollection58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot1 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult2 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node0, astRoot1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean7 = node6.hasChildren();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.hook(node3, node4, node6);
        java.lang.String str9 = node0.checkTreeEquals(node8);
        boolean boolean10 = node8.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult14 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node12, astRoot13);
        com.google.javascript.rhino.Node node15 = parseResult14.ast;
        boolean boolean16 = node15.isQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        boolean boolean20 = node17.isFor();
        boolean boolean21 = node17.isExprResult();
        int int22 = node17.getCharno();
        com.google.javascript.rhino.Node node23 = node15.useSourceInfoIfMissingFrom(node17);
        com.google.javascript.rhino.Node node24 = node11.copyInformationFromForTree(node17);
        int int25 = node11.getLineno();
        try {
            com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.eq(node8, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str9.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.JSModule jSModule7 = compilerInput6.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst8 = compilerInput6.getSourceAst();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(jSModule7);
        org.junit.Assert.assertNotNull(sourceAst8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        boolean boolean8 = compilerOptions0.inlineConstantVars;
        compilerOptions0.setCommonJSModulePathPrefix("Not declared as a type name");
        java.lang.String str11 = compilerOptions0.renamePrefix;
        java.lang.String str12 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.RenamingMap renamingMap0 = com.google.javascript.jscomp.CompilerOptions.UNIQUE_ID_GENERATOR;
        org.junit.Assert.assertNotNull(renamingMap0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.setInlineLocalFunctions(false);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions0.sourceMapLocationMappings;
        boolean boolean9 = compilerOptions0.assumeStrictThis();
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = compilerOptions0.errorFormat;
        org.junit.Assert.assertNotNull(locationMappingList8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(errorFormat10);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList8 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.setLooseTypes(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap11);
        org.junit.Assert.assertNotNull(locationMappingList8);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Unknown class name");
        int int3 = sourceFile1.getColumnOfOffset(39);
        org.junit.Assert.assertNotNull(sourceFile1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 39 + "'", int3 == 39);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.string("SCRIPT");
        int int3 = node2.getSourceOffset();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node8 = node5.srcrefTree(node7);
        boolean boolean9 = node7.isComma();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node10, astRoot11);
        node10.detachChildren();
        boolean boolean14 = node7.hasChild(node10);
        boolean boolean15 = node7.mayMutateArguments();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(43, node2, node7);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.setRemoveTryCatchFinally(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        compilerOptions0.instrumentationTemplate = "this";
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = node0.useSourceInfoFrom(node2);
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.breakNode(node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt8 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt8);
        com.google.javascript.jscomp.ErrorManager errorManager10 = compiler0.getErrorManager();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorManager10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList();
        boolean boolean2 = node1.isEmpty();
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.tryFinally(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        boolean boolean1 = node0.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node2 = node0.cloneNode();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isParamList();
        node1.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.cast(node1);
        boolean boolean6 = node5.isThis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap5;
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isGetterDef();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode6 = null;
        compilerOptions0.setTracer(tracerMode6);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean18 = compilerOptions14.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions14.checkGlobalThisLevel;
        compilerOptions8.setCheckUnreachableCode(checkLevel19);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel19;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap22 = compilerOptions0.customPasses;
        compilerOptions0.inlineConstantVars = false;
        boolean boolean25 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.computeFunctionSideEffects = false;
        boolean boolean28 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setRemoveDeadCode(true);
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        com.google.javascript.jscomp.CompilerOptions.Reach reach10 = null;
        try {
            compilerOptions0.setRemoveUnusedVariables(reach10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        compilerOptions0.coalesceVariableNames = true;
        com.google.javascript.jscomp.VariableMap variableMap24 = null;
        compilerOptions0.setInputPropertyMap(variableMap24);
        compilerOptions0.setRemoveDeadCode(true);
        compilerOptions0.generateExports = false;
        boolean boolean30 = compilerOptions0.exportTestFunctions;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        com.google.javascript.jscomp.CompilerOptions.Reach reach3 = null;
        try {
            compilerOptions0.setRemoveUnusedVariables(reach3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String str34 = jSError33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = composeWarningsGuard7.level(jSError33);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean43 = compilerOptions39.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions39.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray49 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel44, diagnosticType47, strArray49);
        com.google.javascript.jscomp.CheckLevel checkLevel51 = composeWarningsGuard7.level(jSError50);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str34.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertNull(checkLevel51);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        java.lang.String str10 = node2.toString(false, true, true);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean13 = node12.hasChildren();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean15 = node14.hasChildren();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node11, node12, node14);
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node2, node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        node18.addChildToFront(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node22 = node19.srcrefTree(node21);
        com.google.javascript.rhino.Node node23 = node14.copyInformationFrom(node19);
        boolean boolean24 = node23.isFalse();
        com.google.javascript.rhino.Node node25 = node0.srcrefTree(node23);
        boolean boolean26 = node25.isScript();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot28 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult29 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node27, astRoot28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean34 = node33.hasChildren();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.hook(node30, node31, node33);
        java.lang.String str36 = node27.checkTreeEquals(node35);
        com.google.javascript.rhino.Node node37 = node35.removeChildren();
        com.google.javascript.rhino.Node node38 = node25.copyInformationFrom(node37);
        com.google.javascript.rhino.Node node39 = node37.cloneNode();
        try {
            node37.setString("InputId: Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: THIS is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "THIS" + "'", str10.equals("THIS"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(nodeMap17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str36.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node3.isVoid();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        boolean boolean8 = node7.isTypeOf();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.hook(node10, node11, node13);
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.tryCatchFinally(node7, node9, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.setCollapseObjectLiterals(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        compilerOptions0.lineBreak = true;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap10 = compilerOptions0.customPasses;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("Not declared as a constructor");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setDefineToDoubleLiteral("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", 0.0d);
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition10 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation11 = aliasTransformationHandler8.logAliasTransformation("", aliasTransformationSourcePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean9 = compilerOptions5.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions5.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray15 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel10, diagnosticType13, strArray15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        node17.addChildToFront(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node21 = node18.srcrefTree(node20);
        boolean boolean22 = node20.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean31 = compilerOptions27.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions27.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray37 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel32, diagnosticType35, strArray37);
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make(node20, diagnosticType23, strArray37);
        loggerErrorManager1.report(checkLevel10, jSError39);
        com.google.javascript.jscomp.JSError[] jSErrorArray41 = loggerErrorManager1.getErrors();
        int int42 = loggerErrorManager1.getErrorCount();
        int int43 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(jSError39);
        org.junit.Assert.assertNotNull(jSErrorArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (short) -1, (int) (byte) 100);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.hook(node6, node7, node9);
        boolean boolean12 = node6.isNumber();
        java.lang.String str13 = closureCodingConvention0.extractClassNameIfRequire(node5, node6);
        boolean boolean14 = node6.isNot();
        boolean boolean15 = node6.isQuotedString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy0 = com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.ON;
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy0 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.ON + "'", disposalCheckingPolicy0.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.ON));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        boolean boolean2 = node1.isInstanceOf();
        node1.setLineno(43);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult3 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node1, astRoot2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node4, node5, node7);
        java.lang.String str10 = node1.checkTreeEquals(node9);
        boolean boolean11 = node9.isRegExp();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile12 = node9.getStaticSourceFile();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        node13.addChildToFront(node14);
        boolean boolean16 = node13.isFor();
        boolean boolean17 = node13.isExprResult();
        boolean boolean18 = node13.isDefaultCase();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean21 = node20.hasChildren();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.hook(node19, node20, node22);
        node13.addChildrenToBack(node24);
        boolean boolean26 = node24.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(33, node9, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str10.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(staticSourceFile12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.setPreferLineBreakAtEndOfFile(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckMissingReturn(checkLevel11);
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        compilerOptions0.setIdeMode(false);
        compilerOptions0.lineBreak = false;
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setCheckTypes(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        boolean boolean24 = compilerOptions0.printInputDelimiter;
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str26 = compilerOptions25.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions27.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray31 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList32 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32, warningsGuardArray31);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard34 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32);
        com.google.javascript.jscomp.JSError jSError35 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = composeWarningsGuard34.level(jSError35);
        compilerOptions27.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard34);
        java.lang.String[] strArray42 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet43 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet43, strArray42);
        compilerOptions27.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet43);
        compilerOptions25.aliasableStrings = strSet43;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup47 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions48.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode54 = null;
        compilerOptions48.setTracer(tracerMode54);
        com.google.javascript.jscomp.CompilerOptions compilerOptions56 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions56.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions56.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions62.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean66 = compilerOptions62.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel67 = compilerOptions62.checkGlobalThisLevel;
        compilerOptions56.setCheckUnreachableCode(checkLevel67);
        compilerOptions48.checkMissingGetCssNameLevel = checkLevel67;
        compilerOptions25.setWarningLevel(diagnosticGroup47, checkLevel67);
        compilerOptions0.setCheckRequires(checkLevel67);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(warningsGuardArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(checkLevel36);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup47);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + checkLevel67 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel67.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray7 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet8 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet8, strArray7);
        compilerOptions0.stripNamePrefixes = strSet8;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions11.setSyntheticBlockStartMarker("Not declared as a type name");
        boolean boolean17 = compilerOptions11.checkControlStructures;
        com.google.javascript.jscomp.ErrorFormat errorFormat18 = compilerOptions11.errorFormat;
        compilerOptions0.setErrorFormat(errorFormat18);
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(errorFormat18);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isFor();
        boolean boolean4 = node0.isExprResult();
        boolean boolean5 = node0.isEmpty();
        int int6 = node0.getSourcePosition();
        com.google.javascript.rhino.Node node7 = node0.getFirstChild();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        compilerOptions0.setCheckTypes(false);
        com.google.javascript.jscomp.MessageBundle messageBundle6 = null;
        compilerOptions0.messageBundle = messageBundle6;
        compilerOptions0.setSpecializeInitialModule(true);
        compilerOptions0.renamePrefix = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.Reach reach12 = null;
        try {
            compilerOptions0.setRemoveUnusedVariable(reach12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str6 = compilerOptions5.locale;
        compilerOptions5.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions5.checkControlStructures = false;
        compilerOptions5.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy13 = compilerOptions5.getCheckEventfulObjectDisposalPolicy();
        compilerOptions5.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str17 = compilerOptions16.locale;
        compilerOptions16.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions16.checkControlStructures = false;
        compilerOptions16.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions24.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = null;
        compilerOptions24.setTracer(tracerMode30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions32.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        compilerOptions32.setCheckUnreachableCode(checkLevel43);
        compilerOptions24.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions16.setBrokenClosureRequiresLevel(checkLevel43);
        compilerOptions5.setCheckGlobalThisLevel(checkLevel43);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel43);
        boolean boolean49 = compilerOptions0.optimizeArgumentsArray;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing50 = compilerOptions0.getTweakProcessing();
        boolean boolean51 = tweakProcessing50.shouldStrip();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy13 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy13.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing50 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing50.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        compilerOptions0.setCrossModuleMethodMotion(false);
        com.google.javascript.jscomp.CompilerOptions.Reach reach9 = null;
        try {
            compilerOptions0.setInlineVariables(reach9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, true);
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput4);
        java.lang.String str6 = compilerInput4.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator8 = null;
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator8);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile9, true);
        compilerInput4.setSourceFile(sourceFile9);
        java.lang.String str13 = sourceFile9.getName();
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode16 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        compilerOptions18.setAggressiveVarCheck(checkLevel22);
        java.util.Set<java.lang.String> strSet24 = compilerOptions18.aliasableStrings;
        com.google.javascript.jscomp.parsing.Config config25 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode16, false, strSet24);
        com.google.javascript.rhino.head.ErrorReporter errorReporter26 = null;
        java.util.logging.Logger logger27 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult28 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile9, "THIS", config25, errorReporter26, logger27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Not declared as a type name" + "'", str6.equals("Not declared as a type name"));
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Not declared as a type name" + "'", str13.equals("Not declared as a type name"));
        org.junit.Assert.assertTrue("'" + languageMode16 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode16.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5_STRICT));
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertNotNull(config25);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.aliasAllStrings = true;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.setRemoveAbstractMethods(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setPrintInputDelimiter(true);
        compilerOptions0.setRuntimeTypeCheck(false);
        java.lang.String str37 = compilerOptions0.instrumentationTemplate;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt6 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt6);
        lightweightMessageFormatter7.setColorize(false);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        com.google.javascript.rhino.Node node4 = node0.getLastChild();
        com.google.javascript.rhino.Node node5 = node4.getParent();
        boolean boolean6 = node4.isContinue();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setRemoveUnusedLocalVars(true);
        boolean boolean11 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt6 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter7 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt6);
        com.google.javascript.jscomp.SourceFile.Generator generator9 = null;
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator9);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, true);
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, false);
        com.google.javascript.jscomp.SourceFile.Generator generator16 = null;
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromGenerator("Not declared as a type name", generator16);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(sourceFile17, true);
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput19);
        com.google.javascript.jscomp.SourceFile sourceFile21 = compilerInput20.getSourceFile();
        com.google.javascript.rhino.InputId inputId22 = compilerInput20.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput14, inputId22, true);
        java.lang.String str25 = inputId22.toString();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput26 = compiler0.getInput(inputId22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertNotNull(sourceFile21);
        org.junit.Assert.assertNotNull(inputId22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "InputId: Not declared as a type name" + "'", str25.equals("InputId: Not declared as a type name"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        com.google.javascript.rhino.Node node4 = node0.useSourceInfoFrom(node2);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot6 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult7 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node5, astRoot6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean10 = node9.hasChildren();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean12 = node11.hasChildren();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.hook(node8, node9, node11);
        java.lang.String str14 = node5.checkTreeEquals(node13);
        boolean boolean15 = node13.isRegExp();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.label(node2, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str14.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection2 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.returnNode();
        int int4 = node3.getSideEffectFlags();
        boolean boolean5 = node3.isCast();
        boolean boolean6 = closureCodingConvention0.isVarArgsParameter(node3);
        com.google.javascript.rhino.Node node7 = null;
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot10 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult11 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node9, astRoot10);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean14 = node13.hasChildren();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean16 = node15.hasChildren();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.hook(node12, node13, node15);
        java.lang.String str18 = node9.checkTreeEquals(node17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) '#', node17, node20, 2, 100);
        java.lang.String str24 = closureCodingConvention0.extractClassNameIfRequire(node7, node23);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str18.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions0.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean10 = compilerOptions6.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions6.checkGlobalThisLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel11);
        boolean boolean13 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.checkMissingGetCssNameLevel;
        java.lang.String str15 = compilerOptions0.locale;
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.setFoldConstants(false);
        compilerOptions0.optimizeCalls = false;
        boolean boolean8 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean9 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot4 = null;
        compiler0.setOldParseTree("", astRoot4);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter6 = compiler0.getReverseAbstractInterpreter();
        boolean boolean7 = compiler0.isIdeMode();
        java.lang.String str8 = compiler0.toSource();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing4 = null;
        compilerOptions0.setTweakProcessing(tweakProcessing4);
        byte[] byteArray6 = new byte[] {};
        compilerOptions0.setInputVariableMapSerialized(byteArray6);
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.setOptimizeCalls(true);
        compilerOptions0.setOutputCharset("");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        node1.addChildToBack(node2);
        boolean boolean5 = node1.isBreak();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        node1.addChildToFront(node2);
        boolean boolean4 = node1.isFor();
        boolean boolean5 = node1.isExprResult();
        com.google.javascript.jscomp.CodingConvention.Bind bind6 = closureCodingConvention0.describeFunctionBind(node1);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = null;
        try {
            closureCodingConvention0.applySingletonGetter(functionType7, functionType8, objectType9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(bind6);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult3 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node1, astRoot2);
        com.google.javascript.rhino.Node node4 = parseResult3.ast;
        boolean boolean5 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        node6.addChildToFront(node7);
        boolean boolean9 = node6.isFor();
        boolean boolean10 = node6.isExprResult();
        int int11 = node6.getCharno();
        com.google.javascript.rhino.Node node12 = node4.useSourceInfoIfMissingFrom(node6);
        com.google.javascript.rhino.Node node13 = node0.copyInformationFromForTree(node6);
        int int14 = node0.getLineno();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot16 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult17 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node15, astRoot16);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean20 = node19.hasChildren();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean22 = node21.hasChildren();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.hook(node18, node19, node21);
        java.lang.String str24 = node15.checkTreeEquals(node23);
        com.google.javascript.rhino.Node node25 = node23.removeChildren();
        com.google.javascript.rhino.Node node26 = node0.srcrefTree(node25);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str24.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        compilerOptions0.setRecordFunctionInformation(false);
        compilerOptions0.setShadowVariables(true);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        boolean boolean8 = compilerOptions0.inlineConstantVars;
        boolean boolean9 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setInstrumentationTemplate("hi!");
        boolean boolean12 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) '#');
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags2 = sideEffectFlags1.setMutatesThis();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = sideEffectFlags1.setMutatesArguments();
        int int4 = sideEffectFlags3.valueOf();
        boolean boolean5 = sideEffectFlags3.areAllFlagsSet();
        int int6 = sideEffectFlags3.valueOf();
        org.junit.Assert.assertNotNull(sideEffectFlags2);
        org.junit.Assert.assertNotNull(sideEffectFlags3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 33 + "'", int6 == 33);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str6 = compilerOptions5.locale;
        compilerOptions5.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions5.checkControlStructures = false;
        compilerOptions5.checkSuspiciousCode = true;
        com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy disposalCheckingPolicy13 = compilerOptions5.getCheckEventfulObjectDisposalPolicy();
        compilerOptions5.setAngularPass(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str17 = compilerOptions16.locale;
        compilerOptions16.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions16.checkControlStructures = false;
        compilerOptions16.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions24.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode30 = null;
        compilerOptions24.setTracer(tracerMode30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions32.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean42 = compilerOptions38.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions38.checkGlobalThisLevel;
        compilerOptions32.setCheckUnreachableCode(checkLevel43);
        compilerOptions24.checkMissingGetCssNameLevel = checkLevel43;
        compilerOptions16.setBrokenClosureRequiresLevel(checkLevel43);
        compilerOptions5.setCheckGlobalThisLevel(checkLevel43);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel43);
        boolean boolean49 = compilerOptions0.optimizeArgumentsArray;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing50 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setReplaceStringsPlaceholderToken("hi!");
        boolean boolean53 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + disposalCheckingPolicy13 + "' != '" + com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF + "'", disposalCheckingPolicy13.equals(com.google.javascript.jscomp.CheckEventfulObjectDisposal.DisposalCheckingPolicy.OFF));
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing50 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing50.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        compilerOptions0.setExternExportsPath("");
        java.lang.String[] strArray22 = new java.lang.String[] { "THIS", "", "THIS", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", "Not declared as a type name", "this", "THIS", "hi!" };
        java.util.ArrayList<java.lang.String> strList23 = new java.util.ArrayList<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList23, strArray22);
        compilerOptions0.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList23);
        boolean boolean26 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.JSError jSError10 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = composeWarningsGuard9.level(jSError10);
        compilerOptions2.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard9);
        java.lang.String[] strArray17 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet18 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet18, strArray17);
        compilerOptions2.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet18);
        compilerOptions0.aliasableStrings = strSet18;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.REPORT_UNKNOWN_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions23.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode29 = null;
        compilerOptions23.setTracer(tracerMode29);
        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions31.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions31.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean41 = compilerOptions37.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel42 = compilerOptions37.checkGlobalThisLevel;
        compilerOptions31.setCheckUnreachableCode(checkLevel42);
        compilerOptions23.checkMissingGetCssNameLevel = checkLevel42;
        compilerOptions0.setWarningLevel(diagnosticGroup22, checkLevel42);
        java.util.Set<java.lang.String> strSet46 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions0.stripNameSuffixes = strSet46;
        com.google.javascript.jscomp.CompilerOptions compilerOptions48 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions48.setMoveFunctionDeclarations(true);
        java.lang.String[] strArray55 = new java.lang.String[] { "this", "2019/06/13 15:58", "hi!", "this" };
        java.util.LinkedHashSet<java.lang.String> strSet56 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet56, strArray55);
        compilerOptions48.stripNamePrefixes = strSet56;
        java.util.Set<java.lang.String> strSet59 = com.google.javascript.jscomp.parsing.ParserRunner.getReservedVars();
        compilerOptions48.setStripNameSuffixes(strSet59);
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions61.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions61.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode67 = null;
        compilerOptions61.setTracer(tracerMode67);
        com.google.javascript.jscomp.CompilerOptions compilerOptions69 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions69.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions69.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions75 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions75.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean79 = compilerOptions75.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel80 = compilerOptions75.checkGlobalThisLevel;
        compilerOptions69.setCheckUnreachableCode(checkLevel80);
        compilerOptions61.checkMissingGetCssNameLevel = checkLevel80;
        compilerOptions48.setCheckRequires(checkLevel80);
        compilerOptions0.brokenClosureRequiresLevel = checkLevel80;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(checkLevel11);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel42 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel42.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet46);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(strSet59);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + checkLevel80 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel80.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node4 = node1.srcrefTree(node3);
        boolean boolean5 = node3.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean14 = compilerOptions10.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray20 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel15, diagnosticType18, strArray20);
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make(node3, diagnosticType6, strArray20);
        java.lang.String str23 = jSError22.description;
        int int24 = jSError22.getNodeLength();
        int int25 = jSError22.lineNumber;
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str23.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.setOptimizeCalls(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray17 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList18 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList18, locationMappingArray17);
        compilerOptions13.sourceMapLocationMappings = locationMappingList18;
        compilerOptions0.sourceMapLocationMappings = locationMappingList18;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(locationMappingArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (byte) -1, 33, (int) (short) 0);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        boolean boolean6 = node5.isParamList();
        node5.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.cast(node5);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.or(node3, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(goog.exportSymbol)" + "'", str1.equals("(goog.exportSymbol)"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.setPrintInputDelimiter(true);
        boolean boolean35 = compilerOptions0.inlineGetters;
        compilerOptions0.setReserveRawExports(false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.setInlineProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions8.setSyntheticBlockStartMarker("Not declared as a type name");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode14 = null;
        compilerOptions8.setTracer(tracerMode14);
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions16.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions22.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean26 = compilerOptions22.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = compilerOptions22.checkGlobalThisLevel;
        compilerOptions16.setCheckUnreachableCode(checkLevel27);
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel27;
        compilerOptions0.setBrokenClosureRequiresLevel(checkLevel27);
        compilerOptions0.enableRuntimeTypeCheck("THIS");
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str34 = compilerOptions33.locale;
        compilerOptions33.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions33.enableExternExports(true);
        compilerOptions33.setRecordFunctionInformation(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean45 = compilerOptions41.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel46 = compilerOptions41.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean51 = compilerOptions47.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel52 = compilerOptions47.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions53.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean57 = compilerOptions53.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel58 = compilerOptions53.checkGlobalThisLevel;
        compilerOptions47.setCheckMissingReturn(checkLevel58);
        compilerOptions41.aggressiveVarCheck = checkLevel58;
        compilerOptions33.setCheckProvides(checkLevel58);
        com.google.javascript.jscomp.CompilerOptions compilerOptions62 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str63 = compilerOptions62.locale;
        compilerOptions62.syntheticBlockStartMarker = "Not declared as a type name";
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing66 = null;
        compilerOptions62.setTweakProcessing(tweakProcessing66);
        byte[] byteArray68 = new byte[] {};
        compilerOptions62.setInputVariableMapSerialized(byteArray68);
        compilerOptions33.setInputVariableMapSerialized(byteArray68);
        compilerOptions0.setInputVariableMapSerialized(byteArray68);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + checkLevel46 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel46.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(byteArray68);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.setAngularPass(false);
        compilerOptions0.setGenerateExports(true);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.VariableMap variableMap6 = null;
        compilerOptions0.setReplaceStringsInputMap(variableMap6);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.level;
        compilerOptions0.setCheckMissingReturn(checkLevel11);
        java.util.Map<java.lang.String, com.google.javascript.jscomp.CheckLevel> strMap13 = null;
        try {
            compilerOptions0.setPropertyInvalidationErrors(strMap13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        try {
            compiler0.check();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy19 = compilerOptions0.variableRenaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray22 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList23 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23, warningsGuardArray22);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard25 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList23);
        com.google.javascript.jscomp.JSError jSError26 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel27 = composeWarningsGuard25.level(jSError26);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        boolean boolean29 = composeWarningsGuard25.disables(diagnosticGroup28);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard25);
        compilerOptions0.resetWarningsGuard();
        compilerOptions0.setInputDelimiter("InputId: Not declared as a type name");
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy19 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy19.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(warningsGuardArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(checkLevel27);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean4 = node0.getBooleanProp((int) 'a');
        boolean boolean5 = node0.isLabelName();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.setAngularPass(false);
        com.google.javascript.jscomp.SourceMap.Format format14 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setAliasExternals(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format14);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node1.isOnlyModifiesThisCall();
        boolean boolean4 = node1.isArrayLit();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean11 = compilerOptions7.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup6, checkLevel12);
        compilerOptions0.aggressiveVarCheck = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions0.stripTypePrefixes;
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions0.reportMissingOverride;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.locale = "";
        boolean boolean8 = compilerOptions0.inlineConstantVars;
        compilerOptions0.optimizeParameters = true;
        com.google.javascript.jscomp.MessageBundle messageBundle11 = null;
        compilerOptions0.setMessageBundle(messageBundle11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str14 = compilerOptions13.locale;
        compilerOptions13.aliasAllStrings = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions17.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        compilerOptions17.setAliasExternals(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean27 = compilerOptions23.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions23.checkGlobalThisLevel;
        compilerOptions17.setCheckUnreachableCode(checkLevel28);
        compilerOptions17.rewriteFunctionExpressions = true;
        compilerOptions17.setRemoveTryCatchFinally(true);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions17.checkMissingGetCssNameLevel;
        compilerOptions13.setCheckUnreachableCode(checkLevel34);
        compilerOptions0.setCheckMissingGetCssNameLevel(checkLevel34);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.setAggressiveVarCheck(checkLevel4);
        java.util.Set<java.lang.String> strSet6 = compilerOptions0.aliasableStrings;
        compilerOptions0.collapseVariableDeclarations = true;
        boolean boolean9 = compilerOptions0.disambiguateProperties;
        compilerOptions0.disambiguateProperties = true;
        boolean boolean12 = compilerOptions0.disambiguateProperties;
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.inlineFunctions = true;
        java.lang.String[] strArray15 = new java.lang.String[] { "Not declared as a type name", "Not declared as a type name", "this", "goog.global", "SCRIPT", "(Unknown class name)", "hi!" };
        java.util.ArrayList<java.lang.String> strList16 = new java.util.ArrayList<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList16, strArray15);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList16);
        compilerOptions0.setRenamePrefix("goog.exportProperty");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.checkControlStructures = false;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean8 = compilerOptions0.crossModuleMethodMotion;
        compilerOptions0.setClosurePass(true);
        java.util.Map<java.lang.String, java.lang.Object> strMap11 = null;
        compilerOptions0.setDefineReplacements(strMap11);
        compilerOptions0.setOptimizeCalls(false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        node0.addChildToFront(node1);
        boolean boolean3 = node0.isEmpty();
        boolean boolean4 = node0.isArrayLit();
        boolean boolean5 = node0.isCatch();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((-1.0d), 2, (int) (byte) 0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        boolean boolean7 = node4.isFor();
        boolean boolean8 = node4.isExprResult();
        boolean boolean9 = node4.isEmpty();
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.getprop(node3, node4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        compilerOptions0.setExternExportsPath("");
        java.lang.String[] strArray22 = new java.lang.String[] { "THIS", "", "THIS", "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)", "Not declared as a type name", "this", "THIS", "hi!" };
        java.util.ArrayList<java.lang.String> strList23 = new java.util.ArrayList<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList23, strArray22);
        compilerOptions0.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList23);
        boolean boolean26 = compilerOptions0.closurePass;
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node3.isVoid();
        com.google.javascript.rhino.Node node7 = node3.getLastSibling();
        int int8 = node7.getCharno();
        java.lang.String str9 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node7);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot2 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult3 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node1, astRoot2);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean6 = node5.hasChildren();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean8 = node7.hasChildren();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node4, node5, node7);
        java.lang.String str10 = node1.checkTreeEquals(node9);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) '#', node9, node12, 2, 100);
        boolean boolean16 = node15.isThrow();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str10.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        node11.addChildToFront(node12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node15 = node12.srcrefTree(node14);
        boolean boolean16 = node14.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions21.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean25 = compilerOptions21.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions21.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray31 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel26, diagnosticType29, strArray31);
        com.google.javascript.jscomp.JSError jSError33 = com.google.javascript.jscomp.JSError.make(node14, diagnosticType17, strArray31);
        java.lang.String str34 = jSError33.toString();
        com.google.javascript.jscomp.CheckLevel checkLevel35 = composeWarningsGuard7.level(jSError33);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.thisNode();
        node36.addChildToFront(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.Node node40 = node37.srcrefTree(node39);
        boolean boolean41 = node39.isRegExp();
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions46.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean50 = compilerOptions46.ambiguateProperties;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions46.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.DiagnosticType.warning("", "THIS");
        java.lang.String[] strArray56 = new java.lang.String[] { "" };
        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("2019/06/13 15:58", 0, 10, checkLevel51, diagnosticType54, strArray56);
        com.google.javascript.jscomp.JSError jSError58 = com.google.javascript.jscomp.JSError.make(node39, diagnosticType42, strArray56);
        java.lang.String str59 = jSError58.description;
        int int60 = jSError58.getNodeLength();
        com.google.javascript.jscomp.CompilerOptions compilerOptions61 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions61.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray65 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList66 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean67 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList66, locationMappingArray65);
        compilerOptions61.sourceMapLocationMappings = locationMappingList66;
        boolean boolean69 = compilerOptions61.preferLineBreakAtEndOfFile;
        compilerOptions61.setLocale("2019/06/13 15:58");
        boolean boolean72 = jSError58.equals((java.lang.Object) "2019/06/13 15:58");
        com.google.javascript.jscomp.CheckLevel checkLevel73 = composeWarningsGuard7.level(jSError58);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(jSError33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)" + "'", str34.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations:  at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertNull(checkLevel35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(diagnosticType42);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray56);
        org.junit.Assert.assertNotNull(jSError57);
        org.junit.Assert.assertNotNull(jSError58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str59.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(locationMappingArray65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(checkLevel73);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean2 = node1.hasChildren();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean4 = node3.hasChildren();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.hook(node0, node1, node3);
        boolean boolean6 = node0.hasChildren();
        boolean boolean7 = node0.isThrow();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setMoveFunctionDeclarations(true);
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean5 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.VariableMap variableMap6 = null;
        compilerOptions0.setReplaceStringsInputMap(variableMap6);
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        com.google.javascript.jscomp.JSError jSError8 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = composeWarningsGuard7.level(jSError8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        java.lang.String[] strArray15 = new java.lang.String[] { "THIS", "Not declared as a type name", "THIS", "" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        compilerOptions0.setStripTypePrefixes((java.util.Set<java.lang.String>) strSet16);
        compilerOptions0.inlineConstantVars = false;
        boolean boolean21 = compilerOptions0.jqueryPass;
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(checkLevel9);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.returnNode();
        int int1 = node0.getSideEffectFlags();
        boolean boolean2 = node0.isCast();
        boolean boolean3 = node0.isNE();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.thisNode();
        node4.addChildToFront(node5);
        boolean boolean7 = node4.isEmpty();
        com.google.javascript.rhino.Node node8 = node4.getLastChild();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str10 = closureCodingConvention9.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection11 = closureCodingConvention9.getIndirectlyDeclaredProperties();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.thisNode();
        node13.addChildToFront(node14);
        com.google.javascript.rhino.Node node16 = node12.useSourceInfoFrom(node14);
        com.google.javascript.jscomp.CodingConvention.Bind bind18 = closureCodingConvention9.describeFunctionBind(node12, false);
        try {
            node0.replaceChildAfter(node8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.global" + "'", str10.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(bind18);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean3 = node2.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean5 = node4.hasChildren();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.hook(node1, node2, node4);
        boolean boolean7 = node1.isFalse();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.regexp(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("this");
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo2 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker3 = null;
        compiler0.tracker = performanceTracker3;
        java.lang.String str5 = compiler0.getAstDotGraph();
        try {
            java.lang.String[] strArray6 = compiler0.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager2 = compiler0.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager5 = compiler3.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = null;
        compiler3.setOldParseTree("", astRoot7);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter9 = compiler3.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap11 = compiler10.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager12 = compiler10.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = compiler10.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck15 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler0, reverseAbstractInterpreter9, jSTypeRegistry13, checkLevel14);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal16 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult20 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node18, astRoot19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean23 = node22.hasChildren();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.thisNode();
        boolean boolean25 = node24.hasChildren();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.hook(node21, node22, node24);
        java.lang.String str27 = node18.checkTreeEquals(node26);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.name("this");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '#', node26, node29, 2, 100);
        com.google.javascript.rhino.Node node33 = null;
        typeCheck15.visit(nodeTraversal16, node26, node33);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.script();
        com.google.javascript.rhino.head.ast.AstRoot astRoot36 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult37 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node35, astRoot36);
        node35.detachChildren();
        boolean boolean39 = node35.isHook();
        try {
            typeCheck15.check(node35, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(errorManager2);
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(errorManager5);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter9);
        org.junit.Assert.assertNull(sourceMap11);
        org.junit.Assert.assertNotNull(errorManager12);
        org.junit.Assert.assertNotNull(jSTypeRegistry13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n" + "'", str27.equals("Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n"));
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getGlobalObject();
        java.util.Collection<java.lang.String> strCollection2 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString("2019/06/13 15:58", 46, 8);
        boolean boolean8 = node7.isSetterDef();
        com.google.javascript.jscomp.CodingConvention.Bind bind10 = closureCodingConvention0.describeFunctionBind(node7, false);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection11 = closureCodingConvention0.getAssertionFunctions();
        java.lang.String str12 = closureCodingConvention0.getGlobalObject();
        java.lang.String str13 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.global" + "'", str1.equals("goog.global"));
        org.junit.Assert.assertNotNull(strCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(bind10);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "goog.global" + "'", str12.equals("goog.global"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "goog.abstractMethod" + "'", str13.equals("goog.abstractMethod"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState1 = compiler0.getState();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        compiler0.setState(intermediateState4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap7 = compiler6.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager8 = compiler6.getErrorManager();
        com.google.javascript.jscomp.Compiler compiler9 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler9.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager11 = compiler9.getErrorManager();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        compiler9.setOldParseTree("", astRoot13);
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter15 = compiler9.getReverseAbstractInterpreter();
        com.google.javascript.jscomp.Compiler compiler16 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap17 = compiler16.getSourceMap();
        com.google.javascript.jscomp.ErrorManager errorManager18 = compiler16.getErrorManager();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = compiler16.getTypeRegistry();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.TypeCheck typeCheck21 = new com.google.javascript.jscomp.TypeCheck((com.google.javascript.jscomp.AbstractCompiler) compiler6, reverseAbstractInterpreter15, jSTypeRegistry19, checkLevel20);
        com.google.javascript.jscomp.NodeTraversal nodeTraversal22 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, (com.google.javascript.jscomp.NodeTraversal.Callback) typeCheck21);
        com.google.javascript.rhino.Node node23 = null;
        com.google.javascript.rhino.Node node24 = null;
        try {
            typeCheck21.process(node23, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState1);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap7);
        org.junit.Assert.assertNotNull(errorManager8);
        org.junit.Assert.assertNull(sourceMap10);
        org.junit.Assert.assertNotNull(errorManager11);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter15);
        org.junit.Assert.assertNull(sourceMap17);
        org.junit.Assert.assertNotNull(errorManager18);
        org.junit.Assert.assertNotNull(jSTypeRegistry19);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.markNoSideEffectCalls;
        compilerOptions0.setAngularPass(false);
        com.google.javascript.jscomp.SourceMap.Format format14 = compilerOptions0.sourceMapFormat;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(format14);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToNumberLiteral("hi!", (int) (byte) 0);
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        boolean boolean5 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.locale;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a type name";
        compilerOptions0.enableExternExports(true);
        boolean boolean6 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.syntheticBlockStartMarker = "Node tree inequality:\nTree1:\nSCRIPT\n\n\nTree2:\nHOOK\n    THIS\n    THIS\n    THIS\n\n\nSubtree1: SCRIPT\n\n\nSubtree2: HOOK\n    THIS\n    THIS\n    THIS\n";
        compilerOptions0.setNameReferenceReportPath("Not declared as a type name");
        boolean boolean11 = compilerOptions0.aliasAllStrings;
        compilerOptions0.setSourceMapOutputPath("SCRIPT");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

