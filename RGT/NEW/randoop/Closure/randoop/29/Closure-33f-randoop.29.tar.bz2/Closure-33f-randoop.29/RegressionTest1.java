import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createFunctionTypeWithVarArgs(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        boolean boolean15 = jSTypeRegistry1.declareType("module$hi!", jSType10);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType24 = functionType23.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType25 = functionType23.getTypeOfThis();
        boolean boolean26 = functionType23.isNativeObjectType();
        jSTypeRegistry1.unregisterPropertyOnType("function (): {1967438542}", (com.google.javascript.rhino.jstype.JSType) functionType23);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder28 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        jSTypeRegistry1.clearTemplateTypeName();
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder30 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry1.createNamedType("BITXOR Not declared as a type name 0", "Named type with empty name component", 2, 0);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSType35);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) 0L);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean8 = node7.isObjectLit();
        java.lang.String str9 = node7.toString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node14 = node11.clonePropsFrom(node13);
        node11.putBooleanProp(10, false);
        boolean boolean18 = node11.isQuotedString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean24 = node23.isTrue();
        com.google.javascript.rhino.Node node25 = node11.useSourceInfoFromForTree(node23);
        boolean boolean26 = node11.isAdd();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node31 = node28.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(45, node7, node11, node28, 50, 51);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node39 = node36.clonePropsFrom(node38);
        node36.putBooleanProp(10, false);
        boolean boolean43 = node36.isQuotedString();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean49 = node48.isTrue();
        com.google.javascript.rhino.Node node50 = node36.useSourceInfoFromForTree(node48);
        boolean boolean51 = node36.isAdd();
        com.google.javascript.rhino.Node node52 = node11.srcref(node36);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile53 = node36.getStaticSourceFile();
        boolean boolean54 = node36.isReturn();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId61 = new com.google.javascript.rhino.InputId("");
        node59.setInputId(inputId61);
        node36.setInputId(inputId61);
        node1.setInputId(inputId61);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str9.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNull(staticSourceFile53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList7 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList7, jSTypeArray6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry4.createFunctionTypeWithVarArgs(jSType5, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        com.google.javascript.jscomp.CodingConvention codingConvention10 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention11 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean17 = node16.isObjectLit();
        boolean boolean18 = googleCodingConvention11.isOptionalParameter(node16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
        googleCodingConvention11.applySubclassRelationship(functionType19, functionType20, subclassType21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        com.google.javascript.rhino.jstype.JSType jSType30 = functionType29.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry32.createFunctionTypeWithVarArgs(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.jstype.JSType jSType38 = functionType37.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList43 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList43, jSTypeArray42);
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry40.createFunctionTypeWithVarArgs(jSType41, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList43);
        googleCodingConvention11.applySingletonGetter(functionType29, functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType45);
        boolean boolean47 = functionType37.isOrdinaryFunction();
        boolean boolean48 = functionType9.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType37);
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry1.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType37, "hi!", "(EXPR_RESULT)", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = functionType37.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo55 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean56 = jSDocInfo55.isConstructor();
        java.util.Set<java.lang.String> strSet57 = jSDocInfo55.getParameterNames();
        boolean boolean58 = jSDocInfo55.isNoShadow();
        boolean boolean59 = jSDocInfo55.hasBaseType();
        functionType37.setJSDocInfo(jSDocInfo55);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable61 = functionType37.getOwnImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertNotNull(codingConvention10);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strSet57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable61);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "(EXPR_RESULT)", true);
        com.google.javascript.rhino.InputId inputId4 = compilerInput3.getInputId();
        org.junit.Assert.assertNotNull(inputId4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray2 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray2);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard5 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray4);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray6);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard1, composeWarningsGuard3, composeWarningsGuard5, composeWarningsGuard7 };
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard10 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray8);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        boolean boolean12 = composeWarningsGuard10.disables(diagnosticGroup11);
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup11;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(warningsGuardArray2);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isOrdinaryFunction();
        boolean boolean38 = functionType27.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType39 = functionType27.getParameterType();
        boolean boolean40 = functionType27.matchesNumberContext();
        com.google.javascript.rhino.jstype.JSType jSType41 = functionType27.unboxesTo();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(jSType41);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int1 = com.google.javascript.jscomp.NodeUtil.getInverseOperator(45);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler7 = null;
        jSModule6.sortInputsByDeps(compiler7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList9 = jSModule6.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler14 = null;
        jSModule13.sortInputsByDeps(compiler14);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList16 = jSModule13.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler19 = null;
        jSModule18.sortInputsByDeps(compiler19);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList21 = jSModule18.getDependencies();
        jSModule13.addDependency(jSModule18);
        com.google.javascript.jscomp.Compiler compiler23 = null;
        jSModule18.sortInputsByDeps(compiler23);
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler27 = null;
        jSModule26.sortInputsByDeps(compiler27);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList29 = jSModule26.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler32 = null;
        jSModule31.sortInputsByDeps(compiler32);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList34 = jSModule31.getDependencies();
        jSModule26.addDependency(jSModule31);
        com.google.javascript.jscomp.JSModule jSModule37 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.JSModule[] jSModuleArray38 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule6, jSModule11, jSModule18, jSModule31, jSModule37 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph39 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray38);
        com.google.javascript.jscomp.DependencyOptions dependencyOptions40 = null;
        com.google.javascript.jscomp.SourceAst sourceAst41 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(sourceAst41, "(EXPR_RESULT)", true);
        com.google.javascript.rhino.InputId inputId45 = compilerInput44.getInputId();
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray46 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput44 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList47 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList47, compilerInputArray46);
        try {
            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList49 = jSModuleGraph39.manageDependencies(dependencyOptions40, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: (EXPR_RESULT)");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList9);
        org.junit.Assert.assertNotNull(jSModuleList16);
        org.junit.Assert.assertNotNull(jSModuleList21);
        org.junit.Assert.assertNotNull(jSModuleList29);
        org.junit.Assert.assertNotNull(jSModuleList34);
        org.junit.Assert.assertNotNull(jSModuleArray38);
        org.junit.Assert.assertNotNull(inputId45);
        org.junit.Assert.assertNotNull(compilerInputArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) -1, "", 100, (int) '4');
        boolean boolean5 = node4.isIf();
        boolean boolean6 = node4.isThrow();
        com.google.javascript.rhino.JSDocInfo jSDocInfo7 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean8 = jSDocInfo7.isConstructor();
        java.util.Set<java.lang.String> strSet9 = jSDocInfo7.getParameterNames();
        node4.setDirectives(strSet9);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.jscomp.CodingConvention codingConvention4 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention4);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean11 = node10.isObjectLit();
        java.lang.String str12 = node10.toString();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node17 = node14.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node18 = node10.srcref(node14);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.switchNode(node14, nodeArray19);
        java.util.List<java.lang.String> strList21 = googleCodingConvention5.identifyTypeDeclarationCall(node14);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node26 = node23.clonePropsFrom(node25);
        boolean boolean27 = node25.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap28 = null;
        googleCodingConvention5.checkForCallingConventionDefiningCalls(node25, strMap28);
        boolean boolean30 = node25.isRegExp();
        com.google.javascript.rhino.Node node31 = functionParamBuilder3.newParameterFromNode(node25);
        com.google.javascript.jscomp.CodingConvention codingConvention32 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean39 = node38.isObjectLit();
        boolean boolean40 = googleCodingConvention33.isOptionalParameter(node38);
        java.lang.String str41 = googleCodingConvention33.getExportPropertyFunction();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean47 = node46.isObjectLit();
        java.lang.String str48 = node46.toString();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node53 = node50.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node54 = node46.srcref(node50);
        boolean boolean55 = googleCodingConvention33.isOptionalParameter(node50);
        com.google.javascript.jscomp.CodingConvention codingConvention56 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention57 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean63 = node62.isObjectLit();
        boolean boolean64 = googleCodingConvention57.isOptionalParameter(node62);
        boolean boolean65 = node62.isVoid();
        int int66 = node62.getLength();
        java.util.Map<java.lang.String, java.lang.String> strMap67 = null;
        googleCodingConvention33.checkForCallingConventionDefiningCalls(node62, strMap67);
        com.google.javascript.jscomp.CodingConvention codingConvention69 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention70 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention69);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean76 = node75.isObjectLit();
        boolean boolean77 = googleCodingConvention70.isOptionalParameter(node75);
        boolean boolean78 = node75.isVoid();
        boolean boolean80 = node75.getBooleanProp((int) (byte) -1);
        try {
            com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (short) -1, node31, node62, node75, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str12.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(strList21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(codingConvention32);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str48.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(codingConvention56);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(codingConvention69);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = diagnosticGroups0.forName("NAME hi!\n");
        org.junit.Assert.assertNull(diagnosticGroup2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node1.isIf();
        com.google.javascript.rhino.jstype.JSType jSType6 = node1.getJSType();
        boolean boolean7 = node1.isInstanceOf();
        boolean boolean8 = node1.isSyntheticBlock();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = node10.clonePropsFrom(node12);
        node10.putBooleanProp(10, false);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.neg(node10);
        com.google.javascript.rhino.Node node18 = node1.clonePropsFrom(node10);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isSymmetricOperation(node18);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        java.lang.String str9 = compilerInput5.toString();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId16 = new com.google.javascript.rhino.InputId("");
        node14.setInputId(inputId16);
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, inputId16, false);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean46 = functionType6.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection13 = googleCodingConvention1.getAssertionFunctions();
        boolean boolean16 = googleCodingConvention1.isExported("hi!", false);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        boolean boolean2 = jSDocInfo0.isDefine();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = jSDocInfo0.getEnumParameterType();
        boolean boolean4 = jSDocInfo0.isIdGenerator();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSTypeExpression3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable2 = diagnosticGroup0.getTypes();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.jscomp.CodingConvention codingConvention1 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention1);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean8 = node7.isObjectLit();
        boolean boolean9 = googleCodingConvention2.isOptionalParameter(node7);
        boolean boolean10 = node7.isVoid();
        boolean boolean11 = node7.isSyntheticBlock();
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.doNode(node0, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        node18.putBooleanProp(10, false);
        boolean boolean25 = node18.isQuotedString();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean31 = node30.isTrue();
        com.google.javascript.rhino.Node node32 = node18.useSourceInfoFromForTree(node30);
        boolean boolean33 = node18.isAdd();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = node35.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(45, node14, node18, node35, 50, 51);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        node43.putBooleanProp(10, false);
        boolean boolean50 = node43.isQuotedString();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean56 = node55.isTrue();
        com.google.javascript.rhino.Node node57 = node43.useSourceInfoFromForTree(node55);
        boolean boolean58 = node43.isAdd();
        com.google.javascript.rhino.Node node59 = node18.srcref(node43);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile60 = node43.getStaticSourceFile();
        boolean boolean61 = node43.isReturn();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId68 = new com.google.javascript.rhino.InputId("");
        node66.setInputId(inputId68);
        node43.setInputId(inputId68);
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, inputId68, false);
        try {
            java.util.Collection<java.lang.String> strCollection73 = compilerInput72.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: ");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(staticSourceFile60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable1 = diagnosticGroup0.getTypes();
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean7 = closureCodingConvention5.isSuperClassReference("EXPR_RESULT");
        boolean boolean9 = closureCodingConvention5.isSuperClassReference("BITXOR Not declared as a type name 0");
        java.lang.String str10 = closureCodingConvention5.getExportPropertyFunction();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.empty();
        boolean boolean12 = closureCodingConvention5.isVarArgsParameter(node11);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.getelem(node4, node11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "goog.exportProperty" + "'", str10.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.String str46 = functionType6.getNormalizedReferenceName();
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        boolean boolean55 = googleCodingConvention48.isOptionalParameter(node53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        googleCodingConvention48.applySubclassRelationship(functionType56, functionType57, subclassType58);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType74.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList80 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList80, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry77.createFunctionTypeWithVarArgs(jSType78, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList80);
        googleCodingConvention48.applySingletonGetter(functionType66, functionType74, (com.google.javascript.rhino.jstype.ObjectType) functionType82);
        boolean boolean84 = functionType6.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType82);
        com.google.javascript.rhino.jstype.ObjectType.Property property86 = functionType82.getSlot("EXPR_RESULT");
        com.google.javascript.rhino.jstype.ObjectType objectType87 = functionType82.getParentScope();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNull(property86);
        org.junit.Assert.assertNotNull(objectType87);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Not declared as a type name");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = null;
        try {
            jSModule1.addFirst(compilerInput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        node18.putBooleanProp(10, false);
        boolean boolean25 = node18.isQuotedString();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean31 = node30.isTrue();
        com.google.javascript.rhino.Node node32 = node18.useSourceInfoFromForTree(node30);
        boolean boolean33 = node18.isAdd();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = node35.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(45, node14, node18, node35, 50, 51);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        node43.putBooleanProp(10, false);
        boolean boolean50 = node43.isQuotedString();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean56 = node55.isTrue();
        com.google.javascript.rhino.Node node57 = node43.useSourceInfoFromForTree(node55);
        boolean boolean58 = node43.isAdd();
        com.google.javascript.rhino.Node node59 = node18.srcref(node43);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile60 = node43.getStaticSourceFile();
        boolean boolean61 = node43.isReturn();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId68 = new com.google.javascript.rhino.InputId("");
        node66.setInputId(inputId68);
        node43.setInputId(inputId68);
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, inputId68, false);
        try {
            compilerInput72.removeRequire("Exceeded max number of optimization iterations: EXPR_RESULT");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: ");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(staticSourceFile60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node3.isDec();
        boolean boolean6 = node3.isThrow();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.Node node46 = functionType6.getParametersNode();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(10, 29, 38);
        try {
            com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.and(node46, node50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(node46);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("");
        java.lang.String str2 = inputId1.getIdName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "BITXOR Not declared as a type name 0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        java.lang.String str3 = jSDocInfo0.getDeprecationReason();
        boolean boolean4 = jSDocInfo0.isExpose();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createFunctionTypeWithVarArgs(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        boolean boolean15 = jSTypeRegistry1.declareType("module$hi!", jSType10);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType24 = functionType23.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType25 = functionType23.getTypeOfThis();
        boolean boolean26 = functionType23.isNativeObjectType();
        jSTypeRegistry1.unregisterPropertyOnType("function (): {1967438542}", (com.google.javascript.rhino.jstype.JSType) functionType23);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder28 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node34 = node31.clonePropsFrom(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean40 = node39.isObjectLit();
        java.lang.String str41 = node39.toString();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node47 = node39.srcref(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node52 = node49.clonePropsFrom(node51);
        node49.putBooleanProp(10, false);
        boolean boolean56 = node49.isQuotedString();
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean62 = node61.isTrue();
        com.google.javascript.rhino.Node node63 = node49.useSourceInfoFromForTree(node61);
        boolean boolean64 = node49.isAdd();
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean70 = node69.isObjectLit();
        java.lang.String str71 = node69.toString();
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node76 = node73.clonePropsFrom(node75);
        com.google.javascript.rhino.Node node77 = node69.srcref(node73);
        com.google.javascript.rhino.Node node78 = com.google.javascript.jscomp.NodeUtil.newExpr(node73);
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(38, node31, node39, node49, node78, 4095, 29);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder82 = functionBuilder28.withSourceNode(node39);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str41.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str71.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(functionBuilder82);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.String str46 = functionType6.getNormalizedReferenceName();
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        boolean boolean55 = googleCodingConvention48.isOptionalParameter(node53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        googleCodingConvention48.applySubclassRelationship(functionType56, functionType57, subclassType58);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType74.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList80 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList80, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry77.createFunctionTypeWithVarArgs(jSType78, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList80);
        googleCodingConvention48.applySingletonGetter(functionType66, functionType74, (com.google.javascript.rhino.jstype.ObjectType) functionType82);
        boolean boolean84 = functionType6.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType6.isUnknownType();
        com.google.javascript.rhino.jstype.ObjectType.Property property87 = functionType6.getOwnSlot("");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(property87);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList7 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList7, jSTypeArray6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry4.createFunctionTypeWithVarArgs(jSType5, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        com.google.javascript.jscomp.CodingConvention codingConvention10 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention11 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean17 = node16.isObjectLit();
        boolean boolean18 = googleCodingConvention11.isOptionalParameter(node16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
        googleCodingConvention11.applySubclassRelationship(functionType19, functionType20, subclassType21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        com.google.javascript.rhino.jstype.JSType jSType30 = functionType29.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry32.createFunctionTypeWithVarArgs(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.jstype.JSType jSType38 = functionType37.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList43 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList43, jSTypeArray42);
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry40.createFunctionTypeWithVarArgs(jSType41, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList43);
        googleCodingConvention11.applySingletonGetter(functionType29, functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType45);
        boolean boolean47 = functionType37.isOrdinaryFunction();
        boolean boolean48 = functionType9.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType37);
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry1.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType37, "hi!", "(EXPR_RESULT)", 0, 0);
        com.google.javascript.rhino.jstype.JSType jSType54 = functionType37.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo55 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean56 = jSDocInfo55.isConstructor();
        java.util.Set<java.lang.String> strSet57 = jSDocInfo55.getParameterNames();
        boolean boolean58 = jSDocInfo55.isNoShadow();
        boolean boolean59 = jSDocInfo55.hasBaseType();
        functionType37.setJSDocInfo(jSDocInfo55);
        java.lang.Iterable iterable61 = functionType37.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertNotNull(codingConvention10);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(strSet57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(iterable61);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList2 = jSDocInfo0.getExtendedInterfaces();
        jSDocInfo0.addSuppression("goog.exportProperty");
        boolean boolean5 = jSDocInfo0.hasTypedefType();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertNotNull(jSTypeExpressionList2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.nullNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        boolean boolean3 = jSDocInfo0.hasType();
        boolean boolean4 = jSDocInfo0.isHidden();
        boolean boolean6 = jSDocInfo0.hasParameterType("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        node18.putBooleanProp(10, false);
        boolean boolean25 = node18.isQuotedString();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean31 = node30.isTrue();
        com.google.javascript.rhino.Node node32 = node18.useSourceInfoFromForTree(node30);
        boolean boolean33 = node18.isAdd();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = node35.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(45, node14, node18, node35, 50, 51);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        node43.putBooleanProp(10, false);
        boolean boolean50 = node43.isQuotedString();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean56 = node55.isTrue();
        com.google.javascript.rhino.Node node57 = node43.useSourceInfoFromForTree(node55);
        boolean boolean58 = node43.isAdd();
        com.google.javascript.rhino.Node node59 = node18.srcref(node43);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile60 = node43.getStaticSourceFile();
        boolean boolean61 = node43.isReturn();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId68 = new com.google.javascript.rhino.InputId("");
        node66.setInputId(inputId68);
        node43.setInputId(inputId68);
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, inputId68, false);
        com.google.javascript.jscomp.JSModule jSModule73 = compilerInput72.getModule();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(staticSourceFile60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNull(jSModule73);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.jscomp.CodingConvention codingConvention1 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention2 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention1);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean8 = node7.isObjectLit();
        boolean boolean9 = googleCodingConvention2.isOptionalParameter(node7);
        java.lang.String str10 = googleCodingConvention2.getExportPropertyFunction();
        boolean boolean12 = googleCodingConvention2.isSuperClassReference("");
        com.google.javascript.jscomp.CodingConvention codingConvention13 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean20 = node19.isObjectLit();
        java.lang.String str21 = node19.toString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node26 = node23.clonePropsFrom(node25);
        com.google.javascript.rhino.Node node27 = node19.srcref(node23);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.switchNode(node23, nodeArray28);
        java.util.List<java.lang.String> strList30 = googleCodingConvention14.identifyTypeDeclarationCall(node23);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = node32.clonePropsFrom(node34);
        boolean boolean36 = node34.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap37 = null;
        googleCodingConvention14.checkForCallingConventionDefiningCalls(node34, strMap37);
        boolean boolean39 = node34.isRegExp();
        boolean boolean40 = node34.isNot();
        java.util.List<java.lang.String> strList41 = googleCodingConvention2.identifyTypeDeclarationCall(node34);
        boolean boolean42 = detailLevel0.apply(node34);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(codingConvention1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(codingConvention13);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str21.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(strList30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(strList41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        boolean boolean4 = node3.isNot();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.String str46 = functionType6.getNormalizedReferenceName();
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        boolean boolean55 = googleCodingConvention48.isOptionalParameter(node53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        googleCodingConvention48.applySubclassRelationship(functionType56, functionType57, subclassType58);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType74.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList80 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList80, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry77.createFunctionTypeWithVarArgs(jSType78, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList80);
        googleCodingConvention48.applySingletonGetter(functionType66, functionType74, (com.google.javascript.rhino.jstype.ObjectType) functionType82);
        boolean boolean84 = functionType6.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType82);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection86 = jSDocInfo85.getMarkers();
        functionType6.setJSDocInfo(jSDocInfo85);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(markerCollection86);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray10 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel4, diagnosticType5, strArray10);
        java.lang.String str12 = jSError11.description;
        boolean boolean13 = diagnosticGroup0.matches(jSError11);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Exceeded max number of optimization iterations: EXPR_RESULT" + "'", str12.equals("Exceeded max number of optimization iterations: EXPR_RESULT"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        java.lang.String str2 = jSModule1.toString();
        try {
            java.lang.String str3 = jSModule1.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node7 = node4.clonePropsFrom(node6);
        node4.putBooleanProp(10, false);
        boolean boolean11 = node4.isQuotedString();
        boolean boolean12 = node4.isFor();
        node4.setQuotedString();
        boolean boolean14 = node4.isReturn();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
        java.lang.String str17 = closureCodingConvention2.extractClassNameIfProvide(node4, node16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node22 = node19.clonePropsFrom(node21);
        node19.putBooleanProp(10, false);
        boolean boolean26 = node19.isQuotedString();
        com.google.javascript.rhino.Node node27 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        com.google.javascript.jscomp.CodingConvention codingConvention28 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention29 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean35 = node34.isObjectLit();
        boolean boolean36 = googleCodingConvention29.isOptionalParameter(node34);
        java.lang.String str37 = googleCodingConvention29.getExportPropertyFunction();
        boolean boolean39 = googleCodingConvention29.isSuperClassReference("");
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node44 = node41.clonePropsFrom(node43);
        boolean boolean45 = node43.isDec();
        boolean boolean46 = googleCodingConvention29.isOptionalParameter(node43);
        node43.setString("");
        java.lang.String str49 = closureCodingConvention2.extractClassNameIfRequire(node19, node43);
        com.google.javascript.rhino.Node node50 = node43.getParent();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(codingConvention28);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNull(node50);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        boolean boolean2 = node1.isRegExp();
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.script(nodeArray3);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.switchNode(node1, nodeArray3);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.script(nodeArray3);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
//        org.junit.Assert.assertNull(diagnosticGroup0);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "BITXOR Not declared as a type name 0");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel6, diagnosticType7, strArray12);
        diagnosticType2.level = checkLevel6;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType2.level;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray26 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel20, diagnosticType21, strArray26);
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType16, strArray26);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = diagnosticType16.defaultLevel;
        diagnosticType2.level = checkLevel29;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(jSError27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        java.lang.String str3 = jSDocInfo0.getDeprecationReason();
        boolean boolean4 = jSDocInfo0.isConstructor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("module$hi!");
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler4 = null;
        jSModule3.sortInputsByDeps(compiler4);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList6 = jSModule3.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler9 = null;
        jSModule8.sortInputsByDeps(compiler9);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList11 = jSModule8.getDependencies();
        jSModule3.addDependency(jSModule8);
        com.google.javascript.jscomp.Compiler compiler13 = null;
        jSModule8.sortInputsByDeps(compiler13);
        java.nio.charset.Charset charset16 = null;
        com.google.javascript.jscomp.SourceFile sourceFile17 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset16);
        java.lang.String str18 = sourceFile17.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput20 = new com.google.javascript.jscomp.CompilerInput(sourceFile17, false);
        com.google.javascript.jscomp.SourceAst sourceAst21 = compilerInput20.getAst();
        jSModule8.addFirst(compilerInput20);
        try {
            jSModule1.add(compilerInput20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleList6);
        org.junit.Assert.assertNotNull(jSModuleList11);
        org.junit.Assert.assertNotNull(sourceFile17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst21);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList2 = jSDocInfo0.getExtendedInterfaces();
        java.lang.String str3 = jSDocInfo0.getVersion();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertNotNull(jSTypeExpressionList2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean6 = node5.isObjectLit();
        java.lang.String str7 = node5.toString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = node9.clonePropsFrom(node11);
        node9.putBooleanProp(10, false);
        boolean boolean16 = node9.isQuotedString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean22 = node21.isTrue();
        com.google.javascript.rhino.Node node23 = node9.useSourceInfoFromForTree(node21);
        boolean boolean24 = node9.isAdd();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node29 = node26.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(45, node5, node9, node26, 50, 51);
        node26.setCharno(0);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str7.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel0 = com.google.javascript.jscomp.SourceMap.DetailLevel.SYMBOLS;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        int int2 = node1.getCharno();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node7 = node4.clonePropsFrom(node6);
        node4.putBooleanProp(10, false);
        boolean boolean11 = node4.isQuotedString();
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node13 = node1.copyInformationFromForTree(node12);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile14 = node12.getStaticSourceFile();
        boolean boolean15 = node12.isReturn();
        node12.detachChildren();
        boolean boolean17 = detailLevel0.apply(node12);
        org.junit.Assert.assertNotNull(detailLevel0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(staticSourceFile14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        typePosition0.setPositionInformation(10, (int) (byte) 10, 49, (int) (short) 0);
        int int6 = typePosition0.getEndLine();
        boolean boolean7 = typePosition0.hasBrackets();
        int int8 = typePosition0.getStartLine();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = node10.clonePropsFrom(node12);
        boolean boolean14 = node10.isInc();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.sheq(node10, node15);
        typePosition0.setItem(node15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 49 + "'", int6 == 49);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder5 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry4);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        java.lang.String str15 = node13.toString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = node17.clonePropsFrom(node19);
        node17.putBooleanProp(10, false);
        boolean boolean24 = node17.isQuotedString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isTrue();
        com.google.javascript.rhino.Node node31 = node17.useSourceInfoFromForTree(node29);
        boolean boolean32 = node17.isAdd();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = node34.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(45, node13, node17, node34, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder41 = recordTypeBuilder5.addProperty("", jSType7, node40);
        boolean boolean42 = node3.hasChild(node40);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean44 = jSDocInfo43.isConstructor();
        java.util.Set<java.lang.String> strSet45 = jSDocInfo43.getParameterNames();
        node3.setDirectives(strSet45);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression48 = new com.google.javascript.rhino.JSTypeExpression(node3, "EXPR_RESULT");
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList53 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList53, jSTypeArray52);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry50.createFunctionTypeWithVarArgs(jSType51, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList53);
        com.google.javascript.rhino.jstype.JSType jSType56 = functionType55.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType57 = functionType55.getTypeOfThis();
        boolean boolean58 = functionType55.isNativeObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        jSTypeRegistry60.forwardDeclareType("goog.exportProperty");
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeExpression48.evaluate((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType55, jSTypeRegistry60);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression69 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression48);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression70 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression69);
        com.google.javascript.rhino.Node node71 = jSTypeExpression70.getRoot();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str15.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(recordTypeBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertNotNull(jSTypeExpression69);
        org.junit.Assert.assertNotNull(jSTypeExpression70);
        org.junit.Assert.assertNotNull(node71);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        boolean boolean2 = jSDocInfo0.isExterns();
        java.lang.String str3 = jSDocInfo0.getTemplateTypeName();
        int int4 = jSDocInfo0.getExtendedInterfacesCount();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.jstype.JSType jSType1 = node0.getJSType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(jSType1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList7 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList7, jSTypeArray6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry4.createFunctionTypeWithVarArgs(jSType5, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        com.google.javascript.rhino.Node node10 = jSTypeRegistry1.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        jSTypeRegistry1.setTemplateTypeName("Named type with empty name component");
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList18 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList18, jSTypeArray17);
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry15.createFunctionTypeWithVarArgs(jSType16, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList18);
        com.google.javascript.rhino.jstype.JSType jSType21 = functionType20.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType22 = functionType20.getTypeOfThis();
        boolean boolean23 = jSTypeRegistry1.declareType("BITXOR Not declared as a type name 0", (com.google.javascript.rhino.jstype.JSType) functionType20);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable24 = functionType20.getParameters();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertNull(jSType21);
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(nodeIterable24);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("Unknown class name");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("Exceeded max number of optimization iterations: EXPR_RESULT");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node1.isInc();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.thisNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.sheq(node1, node6);
        com.google.javascript.rhino.Node node8 = node1.getParent();
        int int9 = node1.getChildCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, false);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        int int6 = loggerErrorManager5.getWarningCount();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) 0L);
        node1.setOptionalArg(true);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.continueNode();
        int int5 = node4.getCharno();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node10 = node7.clonePropsFrom(node9);
        node7.putBooleanProp(10, false);
        boolean boolean14 = node7.isQuotedString();
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newExpr(node7);
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        com.google.javascript.rhino.Node node17 = node4.cloneTree();
        com.google.javascript.rhino.InputId inputId18 = com.google.javascript.jscomp.NodeUtil.getInputId(node4);
        com.google.javascript.rhino.Node node19 = node1.srcref(node4);
        boolean boolean20 = node4.isQualifiedName();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(inputId18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean10 = node9.isObjectLit();
        java.lang.String str11 = node9.toString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node17 = node9.srcref(node13);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.switchNode(node13, nodeArray18);
        java.util.List<java.lang.String> strList20 = googleCodingConvention4.identifyTypeDeclarationCall(node13);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node25 = node22.clonePropsFrom(node24);
        boolean boolean26 = node24.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap27 = null;
        googleCodingConvention4.checkForCallingConventionDefiningCalls(node24, strMap27);
        boolean boolean29 = node24.isRegExp();
        com.google.javascript.rhino.Node node30 = functionParamBuilder2.newParameterFromNode(node24);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = node32.clonePropsFrom(node34);
        boolean boolean36 = node32.isIf();
        com.google.javascript.rhino.Node node37 = functionParamBuilder2.newParameterFromNode(node32);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean44 = node43.isObjectLit();
        java.lang.String str45 = node43.toString();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node50 = node47.clonePropsFrom(node49);
        node47.putBooleanProp(10, false);
        boolean boolean54 = node47.isQuotedString();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean60 = node59.isTrue();
        com.google.javascript.rhino.Node node61 = node47.useSourceInfoFromForTree(node59);
        boolean boolean62 = node47.isAdd();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node67 = node64.clonePropsFrom(node66);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(45, node43, node47, node64, 50, 51);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node75 = node72.clonePropsFrom(node74);
        node72.putBooleanProp(10, false);
        boolean boolean79 = node72.isQuotedString();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean85 = node84.isTrue();
        com.google.javascript.rhino.Node node86 = node72.useSourceInfoFromForTree(node84);
        boolean boolean87 = node72.isAdd();
        com.google.javascript.rhino.Node node88 = node47.srcref(node72);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile89 = node72.getStaticSourceFile();
        boolean boolean90 = node72.isReturn();
        com.google.javascript.rhino.Node node91 = functionParamBuilder2.newParameterFromNode(node72);
        com.google.javascript.rhino.Node node92 = functionParamBuilder2.build();
        java.lang.String str93 = node92.getQualifiedName();
        try {
            com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.IR.breakNode(node92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str11.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(strList20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str45.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNull(staticSourceFile89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNull(str93);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) -1, "", 100, (int) '4');
        boolean boolean5 = node4.isScript();
        com.google.javascript.rhino.InputId inputId6 = null;
        node4.setInputId(inputId6);
        boolean boolean8 = node4.isFromExterns();
        node4.putIntProp(35, (int) (short) 100);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean17 = node16.isObjectLit();
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.getprop(node4, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node3.isDec();
        int int7 = node3.getIntProp(48);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        java.lang.String str15 = node13.toString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = node17.clonePropsFrom(node19);
        node17.putBooleanProp(10, false);
        boolean boolean24 = node17.isQuotedString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isTrue();
        com.google.javascript.rhino.Node node31 = node17.useSourceInfoFromForTree(node29);
        boolean boolean32 = node17.isAdd();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = node34.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(45, node13, node17, node34, 50, 51);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = node42.clonePropsFrom(node44);
        node42.putBooleanProp(10, false);
        boolean boolean49 = node42.isQuotedString();
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean55 = node54.isTrue();
        com.google.javascript.rhino.Node node56 = node42.useSourceInfoFromForTree(node54);
        boolean boolean57 = node42.isAdd();
        com.google.javascript.rhino.Node node58 = node17.srcref(node42);
        try {
            com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.add(node3, node17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str15.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        java.lang.String str9 = googleCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node22 = node14.srcref(node18);
        boolean boolean23 = googleCodingConvention1.isOptionalParameter(node18);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable24 = node18.getAncestors();
        boolean boolean25 = node18.isIf();
        boolean boolean26 = node18.isLabel();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(ancestorIterable24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        int int1 = node0.getCharno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = node3.clonePropsFrom(node5);
        node3.putBooleanProp(10, false);
        boolean boolean10 = node3.isQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node12 = node0.copyInformationFromForTree(node11);
        com.google.javascript.rhino.Node node13 = node11.getLastSibling();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder19 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry18);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean28 = node27.isObjectLit();
        java.lang.String str29 = node27.toString();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node34 = node31.clonePropsFrom(node33);
        node31.putBooleanProp(10, false);
        boolean boolean38 = node31.isQuotedString();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean44 = node43.isTrue();
        com.google.javascript.rhino.Node node45 = node31.useSourceInfoFromForTree(node43);
        boolean boolean46 = node31.isAdd();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node51 = node48.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(45, node27, node31, node48, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder55 = recordTypeBuilder19.addProperty("", jSType21, node54);
        boolean boolean56 = node17.hasChild(node54);
        boolean boolean57 = node11.isEquivalentTo(node17);
        com.google.javascript.rhino.Node node58 = node11.removeFirstChild();
        boolean boolean59 = node11.isFunction();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str29.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(recordTypeBuilder55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isDateType();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = functionType27.getOwnerFunction();
        com.google.javascript.jscomp.CodingConvention codingConvention39 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention40 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean46 = node45.isObjectLit();
        boolean boolean47 = googleCodingConvention40.isOptionalParameter(node45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType49 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType50 = null;
        googleCodingConvention40.applySubclassRelationship(functionType48, functionType49, subclassType50);
        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52);
        com.google.javascript.rhino.jstype.JSType jSType54 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList56 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean57 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList56, jSTypeArray55);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry53.createFunctionTypeWithVarArgs(jSType54, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList56);
        com.google.javascript.rhino.jstype.JSType jSType59 = functionType58.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        googleCodingConvention40.applySingletonGetter(functionType58, functionType66, (com.google.javascript.rhino.jstype.ObjectType) functionType74);
        functionType66.clearResolved();
        boolean boolean77 = functionType27.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        com.google.javascript.rhino.jstype.EnumType enumType78 = functionType27.toMaybeEnumType();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(functionType38);
        org.junit.Assert.assertNotNull(codingConvention39);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(jSTypeArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(functionType58);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNull(enumType78);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        java.lang.String str9 = compilerInput5.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isOrdinaryFunction();
        boolean boolean38 = functionType27.isConstructor();
        com.google.javascript.rhino.jstype.JSType jSType39 = functionType27.getParameterType();
        boolean boolean41 = functionType27.hasProperty("module$hi!");
        com.google.javascript.rhino.jstype.JSType jSType42 = functionType27.getReturnType();
        boolean boolean43 = jSType42.isVoidType();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.jstype.JSType jSType7 = functionType6.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = functionType6.getTypeOfThis();
        boolean boolean9 = functionType6.isInterface();
        java.lang.String str10 = functionType6.getDisplayName();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isDateType();
        com.google.javascript.rhino.jstype.FunctionType functionType38 = functionType27.getOwnerFunction();
        try {
            boolean boolean39 = functionType38.isNullable();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(functionType38);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("function (): {476650047}", "NAME hi!\n");
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel12, diagnosticType13, strArray18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean25 = node24.isObjectLit();
        java.lang.String str26 = node24.toString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node31 = node28.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node32 = node24.srcref(node28);
        com.google.javascript.rhino.Node[] nodeArray33 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.switchNode(node28, nodeArray33);
        boolean boolean35 = node34.isTrue();
        boolean boolean36 = diagnosticType13.equals((java.lang.Object) boolean35);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup37 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node47 = node44.clonePropsFrom(node46);
        boolean boolean48 = node47.isGetElem();
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel53 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType54 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray59 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel53, diagnosticType54, strArray59);
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make(diagnosticType49, strArray59);
        com.google.javascript.jscomp.CheckLevel checkLevel62 = diagnosticType49.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType65 = com.google.javascript.jscomp.DiagnosticType.disabled("", "BITXOR Not declared as a type name 0");
        java.lang.String[] strArray68 = new java.lang.String[] { "BITXOR Not declared as a type name 0", "EXPR_RESULT" };
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make("BITXOR Not declared as a type name 0", node47, checkLevel62, diagnosticType65, strArray68);
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("", 0, 31, diagnosticType41, strArray68);
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("NAME hi!", 0, 100, diagnosticType13, strArray68);
        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<globalThis>", 53, 30, diagnosticType5, strArray68);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str26.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(nodeArray33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup37);
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertTrue("'" + checkLevel53 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel53.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType54);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType65);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertNotNull(jSError69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(jSError71);
        org.junit.Assert.assertNotNull(jSError72);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node1.isIf();
        com.google.javascript.jscomp.CodingConvention codingConvention6 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention7 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention6);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean13 = node12.isObjectLit();
        boolean boolean14 = googleCodingConvention7.isOptionalParameter(node12);
        java.lang.String str15 = googleCodingConvention7.getExportPropertyFunction();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean21 = node20.isObjectLit();
        java.lang.String str22 = node20.toString();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node27 = node24.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node28 = node20.srcref(node24);
        boolean boolean29 = googleCodingConvention7.isOptionalParameter(node24);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable30 = node24.getAncestors();
        com.google.javascript.rhino.Node node31 = node1.useSourceInfoFromForTree(node24);
        int int32 = node31.getType();
        int int33 = node31.getSideEffectFlags();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(codingConvention6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str22.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(ancestorIterable30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 38 + "'", int32 == 38);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean47 = functionType34.hasOwnProperty("hi!");
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean50 = jSDocInfo49.isConstructor();
        java.util.Set<java.lang.String> strSet51 = jSDocInfo49.getParameterNames();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection52 = jSDocInfo49.getTypeNodes();
        functionType34.setPropertyJSDocInfo("", jSDocInfo49);
        java.lang.String str54 = jSDocInfo49.getBlockDescription();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(strSet51);
        org.junit.Assert.assertNotNull(nodeCollection52);
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("DiagnosticGroup<globalThis>", charset1);
        java.lang.String str3 = sourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DiagnosticGroup<globalThis>" + "'", str3.equals("DiagnosticGroup<globalThis>"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider1 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = errorFormat0.toFormatter(sourceExcerptProvider1, false);
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        double double6 = loggerErrorManager5.getTypedPercent();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        java.lang.String str9 = googleCodingConvention1.getExportPropertyFunction();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node22 = node14.srcref(node18);
        boolean boolean23 = googleCodingConvention1.isOptionalParameter(node18);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable24 = node18.getAncestors();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isObjectLit();
        java.lang.String str31 = node29.toString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = node33.clonePropsFrom(node35);
        com.google.javascript.rhino.Node node37 = node29.srcref(node33);
        com.google.javascript.rhino.Node[] nodeArray38 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.switchNode(node33, nodeArray38);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.arraylit(nodeArray38);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.call(node18, nodeArray38);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(ancestorIterable24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str31.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(nodeArray38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        boolean boolean2 = jSDocInfo0.isExterns();
        java.lang.String str3 = jSDocInfo0.getTemplateTypeName();
        boolean boolean4 = jSDocInfo0.isNoTypeCheck();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        jSTypeRegistry1.forwardDeclareType("goog.exportProperty");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList13 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList13, jSTypeArray12);
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry10.createFunctionTypeWithVarArgs(jSType11, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList13);
        com.google.javascript.rhino.jstype.JSType jSType16 = functionType15.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType17 = functionType15.getTypeOfThis();
        java.util.Set<java.lang.String> strSet18 = objectType17.getOwnPropertyNames();
        com.google.javascript.rhino.jstype.JSType jSType20 = jSTypeRegistry1.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) objectType17, "BITXOR Not declared as a type name 0");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(strSet18);
        org.junit.Assert.assertNotNull(jSType20);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        int int1 = node0.getCharno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = node3.clonePropsFrom(node5);
        node3.putBooleanProp(10, false);
        boolean boolean10 = node3.isQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node12 = node0.copyInformationFromForTree(node11);
        boolean boolean13 = node0.isAssign();
        java.lang.String str14 = com.google.javascript.jscomp.NodeUtil.getSourceName(node0);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        java.lang.String str4 = nodeTraversal2.getSourceName();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean10 = node9.isObjectLit();
        java.lang.String str11 = node9.toString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node17 = node9.srcref(node13);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.switchNode(node13, nodeArray18);
        try {
            nodeTraversal2.traverse(node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str11.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node4.isGetterDef();
        boolean boolean6 = node4.isHook();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList12 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList12, jSTypeArray11);
        com.google.javascript.rhino.jstype.FunctionType functionType14 = jSTypeRegistry9.createFunctionTypeWithVarArgs(jSType10, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList12);
        boolean boolean15 = jSTypeRegistry1.declareType("module$hi!", jSType10);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList21 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList21, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createFunctionTypeWithVarArgs(jSType19, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList21);
        com.google.javascript.rhino.jstype.JSType jSType24 = functionType23.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType25 = functionType23.getTypeOfThis();
        boolean boolean26 = functionType23.isNativeObjectType();
        jSTypeRegistry1.unregisterPropertyOnType("function (): {1967438542}", (com.google.javascript.rhino.jstype.JSType) functionType23);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder28 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        jSTypeRegistry1.clearTemplateTypeName();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder32 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry31);
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList37 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList37, jSTypeArray36);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry34.createFunctionTypeWithVarArgs(jSType35, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        com.google.javascript.rhino.Node node40 = jSTypeRegistry31.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList37);
        jSTypeRegistry31.setTemplateTypeName("Named type with empty name component");
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry31.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry1.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) objectType43, "goog.exportSymbol");
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean51 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList50, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry47.createFunctionTypeWithVarArgs(jSType48, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList50);
        com.google.javascript.rhino.jstype.JSType jSType53 = functionType52.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType54 = functionType52.getTypeOfThis();
        boolean boolean55 = functionType52.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType56 = functionType52.getPrototype();
        com.google.javascript.rhino.jstype.JSType jSType57 = jSType45.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) objectType56);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(functionType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNull(jSType24);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNull(jSType53);
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(objectType56);
        org.junit.Assert.assertNotNull(jSType57);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        boolean boolean3 = jSDocInfo0.isNoShadow();
        boolean boolean4 = jSDocInfo0.isNoCompile();
        boolean boolean5 = jSDocInfo0.isDeprecated();
        java.util.Collection<java.lang.String> strCollection6 = jSDocInfo0.getReferences();
        boolean boolean7 = jSDocInfo0.isNoShadow();
        boolean boolean8 = jSDocInfo0.hasFileOverview();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strCollection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        boolean boolean2 = jSDocInfo0.isDefine();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getThrownTypes();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getParameterType("function (): {1967438542}");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression6 = jSDocInfo0.getBaseType();
        boolean boolean7 = jSDocInfo0.isConstant();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertNull(jSTypeExpression5);
        org.junit.Assert.assertNull(jSTypeExpression6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel7, diagnosticType8, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = jSError14.getDefaultLevel();
        diagnosticType3.level = checkLevel15;
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node22 = node19.clonePropsFrom(node21);
        boolean boolean23 = node19.isArrayLit();
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel28, diagnosticType29, strArray34);
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray34);
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        boolean boolean47 = node46.isGetElem();
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel52 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType53 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray58 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel52, diagnosticType53, strArray58);
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make(diagnosticType48, strArray58);
        com.google.javascript.jscomp.CheckLevel checkLevel61 = diagnosticType48.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType64 = com.google.javascript.jscomp.DiagnosticType.disabled("", "BITXOR Not declared as a type name 0");
        java.lang.String[] strArray67 = new java.lang.String[] { "BITXOR Not declared as a type name 0", "EXPR_RESULT" };
        com.google.javascript.jscomp.JSError jSError68 = com.google.javascript.jscomp.JSError.make("BITXOR Not declared as a type name 0", node46, checkLevel61, diagnosticType64, strArray67);
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make("", 0, 31, diagnosticType40, strArray67);
        com.google.javascript.jscomp.JSError jSError70 = com.google.javascript.jscomp.JSError.make("", node19, diagnosticType24, strArray67);
        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("Node tree inequality:\nTree1:\nNAME hi!\n\n\nTree2:\nERROR  100\n\n\nSubtree1: NAME hi!\n\n\nSubtree2: ERROR  100\n", (int) (byte) -1, 10, diagnosticType3, strArray67);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertTrue("'" + checkLevel52 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel52.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType53);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertNotNull(jSError59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType64);
        org.junit.Assert.assertNotNull(strArray67);
        org.junit.Assert.assertNotNull(jSError68);
        org.junit.Assert.assertNotNull(jSError69);
        org.junit.Assert.assertNotNull(jSError70);
        org.junit.Assert.assertNotNull(jSError71);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        java.lang.String str37 = functionType19.getDisplayName();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        java.lang.String str8 = node6.toString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = node10.clonePropsFrom(node12);
        node10.putBooleanProp(10, false);
        boolean boolean17 = node10.isQuotedString();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean23 = node22.isTrue();
        com.google.javascript.rhino.Node node24 = node10.useSourceInfoFromForTree(node22);
        boolean boolean25 = node10.isAdd();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node30 = node27.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(45, node6, node10, node27, 50, 51);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = node35.clonePropsFrom(node37);
        node35.putBooleanProp(10, false);
        boolean boolean42 = node35.isQuotedString();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean48 = node47.isTrue();
        com.google.javascript.rhino.Node node49 = node35.useSourceInfoFromForTree(node47);
        boolean boolean50 = node35.isAdd();
        com.google.javascript.rhino.Node node51 = node10.srcref(node35);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile52 = node35.getStaticSourceFile();
        com.google.javascript.jscomp.CodingConvention codingConvention53 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention54 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean60 = node59.isObjectLit();
        boolean boolean61 = googleCodingConvention54.isOptionalParameter(node59);
        boolean boolean62 = node59.isVoid();
        java.lang.String str63 = node59.toString();
        com.google.javascript.rhino.Node node64 = null;
        try {
            com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(15, node35, node59, node64, 42, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str8.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNull(staticSourceFile52);
        org.junit.Assert.assertNotNull(codingConvention53);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str63.equals("BITXOR Not declared as a type name 0"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        boolean boolean2 = jSDocInfo0.isDefine();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getThrownTypes();
        boolean boolean4 = jSDocInfo0.isHidden();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition0.setPositionInformation(0, 50, 50, 47);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        node3.setSourceEncodedPositionForTree(409652);
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.SourceFile sourceFile8 = com.google.javascript.jscomp.SourceFile.fromFile("BITXOR Not declared as a type name 0", charset7);
        java.lang.String str9 = sourceFile8.getName();
        node3.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile8);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(sourceFile8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str9.equals("BITXOR Not declared as a type name 0"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        boolean boolean5 = node1.isCall();
        int int6 = node1.getCharno();
        boolean boolean7 = node1.isObjectLit();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.String str46 = functionType6.getNormalizedReferenceName();
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        boolean boolean55 = googleCodingConvention48.isOptionalParameter(node53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        googleCodingConvention48.applySubclassRelationship(functionType56, functionType57, subclassType58);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType74.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList80 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList80, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry77.createFunctionTypeWithVarArgs(jSType78, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList80);
        googleCodingConvention48.applySingletonGetter(functionType66, functionType74, (com.google.javascript.rhino.jstype.ObjectType) functionType82);
        boolean boolean84 = functionType6.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType82);
        com.google.javascript.rhino.jstype.ObjectType.Property property86 = functionType82.getSlot("EXPR_RESULT");
        boolean boolean87 = functionType82.isNoType();
        java.lang.String str88 = functionType82.getDisplayName();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNull(property86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNull(str88);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.jstype.JSType jSType7 = functionType6.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = functionType6.getTypeOfThis();
        boolean boolean9 = functionType6.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType10 = functionType6.getPrototype();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList15 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList15, jSTypeArray14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry12.createFunctionTypeWithVarArgs(jSType13, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList15);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList23 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList23, jSTypeArray22);
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createFunctionTypeWithVarArgs(jSType21, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList23);
        boolean boolean26 = jSTypeRegistry12.declareType("module$hi!", jSType21);
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType36 = functionType34.getTypeOfThis();
        boolean boolean37 = functionType34.isNativeObjectType();
        jSTypeRegistry12.unregisterPropertyOnType("function (): {1967438542}", (com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder39 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry12);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder41 = functionBuilder39.setIsConstructor(true);
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList46, jSTypeArray45);
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry43.createFunctionTypeWithVarArgs(jSType44, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList46);
        com.google.javascript.rhino.jstype.JSType jSType49 = functionType48.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType50 = functionType48.getTypeOfThis();
        com.google.javascript.jscomp.CodingConvention codingConvention51 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention52 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean58 = node57.isObjectLit();
        boolean boolean59 = googleCodingConvention52.isOptionalParameter(node57);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType61 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType62 = null;
        googleCodingConvention52.applySubclassRelationship(functionType60, functionType61, subclassType62);
        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64);
        com.google.javascript.rhino.jstype.JSType jSType66 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray67 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList68 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList68, jSTypeArray67);
        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry65.createFunctionTypeWithVarArgs(jSType66, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList68);
        com.google.javascript.rhino.jstype.JSType jSType71 = functionType70.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72);
        com.google.javascript.rhino.jstype.JSType jSType74 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList76 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList76, jSTypeArray75);
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry73.createFunctionTypeWithVarArgs(jSType74, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList76);
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType78.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter80);
        com.google.javascript.rhino.jstype.JSType jSType82 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray83 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList84 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean85 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList84, jSTypeArray83);
        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry81.createFunctionTypeWithVarArgs(jSType82, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList84);
        googleCodingConvention52.applySingletonGetter(functionType70, functionType78, (com.google.javascript.rhino.jstype.ObjectType) functionType86);
        boolean boolean88 = functionType78.isDateType();
        com.google.javascript.rhino.jstype.FunctionType functionType89 = functionType78.getOwnerFunction();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair90 = functionType48.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) functionType78);
        com.google.javascript.rhino.jstype.FunctionType functionType91 = functionType78.toMaybeFunctionType();
        functionType91.clearCachedValues();
        boolean boolean93 = functionType91.isInstanceType();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder94 = functionBuilder39.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionType91);
        boolean boolean95 = functionType6.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType91);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(objectType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(functionBuilder41);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertNull(jSType49);
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(codingConvention51);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(jSTypeArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(functionType70);
        org.junit.Assert.assertNull(jSType71);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNull(jSType79);
        org.junit.Assert.assertNotNull(jSTypeArray83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(functionType86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNull(functionType89);
        org.junit.Assert.assertNotNull(typePair90);
        org.junit.Assert.assertNotNull(functionType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(functionBuilder94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList7 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList7, jSTypeArray6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry4.createFunctionTypeWithVarArgs(jSType5, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        com.google.javascript.jscomp.CodingConvention codingConvention10 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention11 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean17 = node16.isObjectLit();
        boolean boolean18 = googleCodingConvention11.isOptionalParameter(node16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType20 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType21 = null;
        googleCodingConvention11.applySubclassRelationship(functionType19, functionType20, subclassType21);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList27 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList27, jSTypeArray26);
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry24.createFunctionTypeWithVarArgs(jSType25, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList27);
        com.google.javascript.rhino.jstype.JSType jSType30 = functionType29.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList35 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList35, jSTypeArray34);
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry32.createFunctionTypeWithVarArgs(jSType33, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList35);
        com.google.javascript.rhino.jstype.JSType jSType38 = functionType37.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList43 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean44 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList43, jSTypeArray42);
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry40.createFunctionTypeWithVarArgs(jSType41, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList43);
        googleCodingConvention11.applySingletonGetter(functionType29, functionType37, (com.google.javascript.rhino.jstype.ObjectType) functionType45);
        boolean boolean47 = functionType37.isOrdinaryFunction();
        boolean boolean48 = functionType9.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType37);
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry1.getType((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType37, "hi!", "(EXPR_RESULT)", 0, 0);
        java.lang.String str54 = functionType37.toString();
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertNotNull(codingConvention10);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertNull(jSType30);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "function (): ?" + "'", str54.equals("function (): ?"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        node1.putBooleanProp(10, false);
        boolean boolean8 = node1.isQuotedString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isTrue();
        com.google.javascript.rhino.Node node15 = node1.useSourceInfoFromForTree(node13);
        boolean boolean16 = node13.isNumber();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel5, diagnosticType6, strArray11);
        boolean boolean13 = diagnosticGroup0.matches(jSError12);
        java.lang.Object obj14 = null;
        boolean boolean15 = jSError12.equals(obj14);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError12.level;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean46 = functionType34.matchesUint32Context();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.jstype.JSType jSType7 = functionType6.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = functionType6.getTypeOfThis();
        com.google.javascript.jscomp.CodingConvention codingConvention9 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention10 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean16 = node15.isObjectLit();
        boolean boolean17 = googleCodingConvention10.isOptionalParameter(node15);
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType19 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
        googleCodingConvention10.applySubclassRelationship(functionType18, functionType19, subclassType20);
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList26 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList26, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry23.createFunctionTypeWithVarArgs(jSType24, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList26);
        com.google.javascript.rhino.jstype.JSType jSType29 = functionType28.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList34 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList34, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry31.createFunctionTypeWithVarArgs(jSType32, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList34);
        com.google.javascript.rhino.jstype.JSType jSType37 = functionType36.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList42 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList42, jSTypeArray41);
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createFunctionTypeWithVarArgs(jSType40, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList42);
        googleCodingConvention10.applySingletonGetter(functionType28, functionType36, (com.google.javascript.rhino.jstype.ObjectType) functionType44);
        boolean boolean46 = functionType36.isDateType();
        com.google.javascript.rhino.jstype.FunctionType functionType47 = functionType36.getOwnerFunction();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair48 = functionType6.getTypesUnderShallowEquality((com.google.javascript.rhino.jstype.JSType) functionType36);
        com.google.javascript.rhino.jstype.FunctionType functionType49 = functionType36.toMaybeFunctionType();
        boolean boolean50 = functionType36.isEnumType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertNotNull(codingConvention9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertNull(jSType29);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNull(jSType37);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(functionType47);
        org.junit.Assert.assertNotNull(typePair48);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isDateType();
        java.lang.String str38 = functionType27.getNormalizedReferenceName();
        boolean boolean39 = functionType27.matchesNumberContext();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.Node node46 = functionType6.getParametersNode();
        node46.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(node46);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script(nodeArray0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.block(nodeArray0);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler7 = null;
        jSModule6.sortInputsByDeps(compiler7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList9 = jSModule6.getDependencies();
        jSModule1.addDependency(jSModule6);
        java.util.List<java.lang.String> strList11 = jSModule6.getProvides();
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler14 = null;
        jSModule13.sortInputsByDeps(compiler14);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList16 = jSModule13.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler19 = null;
        jSModule18.sortInputsByDeps(compiler19);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList21 = jSModule18.getDependencies();
        jSModule13.addDependency(jSModule18);
        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler25 = null;
        jSModule24.sortInputsByDeps(compiler25);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList27 = jSModule24.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule29 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler30 = null;
        jSModule29.sortInputsByDeps(compiler30);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList32 = jSModule29.getDependencies();
        jSModule24.addDependency(jSModule29);
        com.google.javascript.jscomp.Compiler compiler34 = null;
        jSModule29.sortInputsByDeps(compiler34);
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.SourceFile sourceFile38 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset37);
        jSModule29.addFirst(sourceFile38);
        jSModule13.add(sourceFile38);
        int int41 = jSModule13.getDepth();
        jSModule6.addDependency(jSModule13);
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList9);
        org.junit.Assert.assertNotNull(strList11);
        org.junit.Assert.assertNotNull(jSModuleList16);
        org.junit.Assert.assertNotNull(jSModuleList21);
        org.junit.Assert.assertNotNull(jSModuleList27);
        org.junit.Assert.assertNotNull(jSModuleList32);
        org.junit.Assert.assertNotNull(sourceFile38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        int int3 = nodeTraversal2.getLineNumber();
        com.google.javascript.rhino.Node node4 = nodeTraversal2.getCurrentNode();
        com.google.javascript.jscomp.Scope scope5 = nodeTraversal2.getScope();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(scope5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.DependencyOptions dependencyOptions0 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray4 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList5 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList5, jSTypeArray4);
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createFunctionTypeWithVarArgs(jSType3, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList5);
        com.google.javascript.jscomp.CodingConvention codingConvention8 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention9 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention8);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        boolean boolean16 = googleCodingConvention9.isOptionalParameter(node14);
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType18 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType19 = null;
        googleCodingConvention9.applySubclassRelationship(functionType17, functionType18, subclassType19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.jstype.JSType jSType36 = functionType35.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList41, jSTypeArray40);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createFunctionTypeWithVarArgs(jSType39, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList41);
        googleCodingConvention9.applySingletonGetter(functionType27, functionType35, (com.google.javascript.rhino.jstype.ObjectType) functionType43);
        boolean boolean45 = functionType35.isOrdinaryFunction();
        boolean boolean46 = functionType7.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType35);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType35.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet48 = functionType35.getPropertyNames();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions49 = dependencyOptions0.setEntryPoints((java.util.Collection<java.lang.String>) strSet48);
        org.junit.Assert.assertNotNull(jSTypeArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(codingConvention8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNotNull(strSet48);
        org.junit.Assert.assertNotNull(dependencyOptions49);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        node1.putBooleanProp(10, false);
        boolean boolean8 = node1.isQuotedString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.neg(node1);
        com.google.javascript.rhino.JSDocInfo jSDocInfo10 = node9.getJSDocInfo();
        boolean boolean11 = node9.isQuotedString();
        boolean boolean12 = node9.isAssignAdd();
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNull(jSDocInfo10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        boolean boolean14 = googleCodingConvention1.isPrivate("module$hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node19 = node16.clonePropsFrom(node18);
        boolean boolean20 = node19.isGetterDef();
        java.util.Map<java.lang.String, java.lang.String> strMap21 = null;
        googleCodingConvention1.checkForCallingConventionDefiningCalls(node19, strMap21);
        boolean boolean23 = node19.isFromExterns();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler7 = null;
        compilerInput5.setCompiler(abstractCompiler7);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean15 = node14.isObjectLit();
        java.lang.String str16 = node14.toString();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = node18.clonePropsFrom(node20);
        node18.putBooleanProp(10, false);
        boolean boolean25 = node18.isQuotedString();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean31 = node30.isTrue();
        com.google.javascript.rhino.Node node32 = node18.useSourceInfoFromForTree(node30);
        boolean boolean33 = node18.isAdd();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = node35.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(45, node14, node18, node35, 50, 51);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        node43.putBooleanProp(10, false);
        boolean boolean50 = node43.isQuotedString();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean56 = node55.isTrue();
        com.google.javascript.rhino.Node node57 = node43.useSourceInfoFromForTree(node55);
        boolean boolean58 = node43.isAdd();
        com.google.javascript.rhino.Node node59 = node18.srcref(node43);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile60 = node43.getStaticSourceFile();
        boolean boolean61 = node43.isReturn();
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        com.google.javascript.rhino.InputId inputId68 = new com.google.javascript.rhino.InputId("");
        node66.setInputId(inputId68);
        node43.setInputId(inputId68);
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, inputId68, false);
        com.google.javascript.jscomp.SourceFile sourceFile73 = compilerInput5.getSourceFile();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str16.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNull(staticSourceFile60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(sourceFile73);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler7 = null;
        jSModule6.sortInputsByDeps(compiler7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList9 = jSModule6.getDependencies();
        jSModule1.addDependency(jSModule6);
        com.google.javascript.jscomp.Compiler compiler11 = null;
        jSModule6.sortInputsByDeps(compiler11);
        java.nio.charset.Charset charset14 = null;
        com.google.javascript.jscomp.SourceFile sourceFile15 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset14);
        java.lang.String str16 = sourceFile15.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceFile15, false);
        com.google.javascript.jscomp.SourceAst sourceAst19 = compilerInput18.getAst();
        jSModule6.addFirst(compilerInput18);
        jSModule6.setDepth(35);
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList9);
        org.junit.Assert.assertNotNull(sourceFile15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst19);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        boolean boolean3 = jSDocInfo0.hasFileOverview();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition0.setItem("BITXOR Not declared as a type name 0");
        stringPosition0.setItem("");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node5 = node2.clonePropsFrom(node4);
        boolean boolean6 = node2.isArrayLit();
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel11, diagnosticType12, strArray17);
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray17);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node29 = node26.clonePropsFrom(node28);
        boolean boolean30 = node29.isGetElem();
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType36 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray41 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel35, diagnosticType36, strArray41);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make(diagnosticType31, strArray41);
        com.google.javascript.jscomp.CheckLevel checkLevel44 = diagnosticType31.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.disabled("", "BITXOR Not declared as a type name 0");
        java.lang.String[] strArray50 = new java.lang.String[] { "BITXOR Not declared as a type name 0", "EXPR_RESULT" };
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("BITXOR Not declared as a type name 0", node29, checkLevel44, diagnosticType47, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("", 0, 31, diagnosticType23, strArray50);
        com.google.javascript.jscomp.JSError jSError53 = com.google.javascript.jscomp.JSError.make("", node2, diagnosticType7, strArray50);
        int int54 = jSError53.lineNumber;
        java.lang.String str55 = jSError53.toString();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType36);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertNotNull(jSError53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR. BITXOR Not declared as a type name 0 at (unknown source) line (unknown line) : (unknown column)" + "'", str55.equals("JSC_NODE_TRAVERSAL_ERROR. BITXOR Not declared as a type name 0 at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.jstype.JSType jSType7 = functionType6.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = functionType6.getTypeOfThis();
        int int9 = functionType6.getMaxArguments();
        boolean boolean10 = functionType6.isEnumElementType();
        boolean boolean11 = functionType6.isEnumElementType();
        com.google.javascript.rhino.jstype.FunctionType functionType12 = functionType6.toMaybeFunctionType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable13 = functionType6.getCtorExtendedInterfaces();
        boolean boolean14 = functionType6.isEnumType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertNotNull(objectTypeIterable13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        int int3 = node2.getCharno();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node8 = node5.clonePropsFrom(node7);
        node5.putBooleanProp(10, false);
        boolean boolean12 = node5.isQuotedString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        com.google.javascript.rhino.Node node14 = node2.copyInformationFromForTree(node13);
        com.google.javascript.rhino.Node node15 = node13.getLastSibling();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder21 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry20);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isObjectLit();
        java.lang.String str31 = node29.toString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = node33.clonePropsFrom(node35);
        node33.putBooleanProp(10, false);
        boolean boolean40 = node33.isQuotedString();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean46 = node45.isTrue();
        com.google.javascript.rhino.Node node47 = node33.useSourceInfoFromForTree(node45);
        boolean boolean48 = node33.isAdd();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node53 = node50.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(45, node29, node33, node50, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder57 = recordTypeBuilder21.addProperty("", jSType23, node56);
        boolean boolean58 = node19.hasChild(node56);
        boolean boolean59 = node13.isEquivalentTo(node19);
        com.google.javascript.rhino.Node node60 = node13.removeFirstChild();
        com.google.javascript.rhino.Node node61 = null;
        try {
            java.lang.String str62 = closureCodingConvention0.extractClassNameIfProvide(node13, node61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str31.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(recordTypeBuilder57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node60);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineGetters = false;
        compilerOptions0.setTightenTypes(false);
        compilerOptions0.setTweakToDoubleLiteral("module$Node tree inequality:\nTree1:\nSTRING \n\n\nTree2:\nNAME hi!\n\n\nSubtree1: STRING \n\n\nSubtree2: NAME hi!\n", (double) 54);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = functionType6.getImplementedInterfaces();
        functionType6.clearCachedValues();
        boolean boolean48 = functionType6.isNumber();
        boolean boolean49 = functionType6.isRegexpType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        java.lang.String str9 = googleCodingConvention1.getExportPropertyFunction();
        boolean boolean11 = googleCodingConvention1.isSuperClassReference("");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        boolean boolean17 = node15.isDec();
        boolean boolean18 = googleCodingConvention1.isOptionalParameter(node15);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 49, 51);
        java.util.List<java.lang.String> strList23 = googleCodingConvention1.identifyTypeDeclarationCall(node22);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isObjectLit();
        java.lang.String str31 = node29.toString();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = node33.clonePropsFrom(node35);
        node33.putBooleanProp(10, false);
        boolean boolean40 = node33.isQuotedString();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean46 = node45.isTrue();
        com.google.javascript.rhino.Node node47 = node33.useSourceInfoFromForTree(node45);
        boolean boolean48 = node33.isAdd();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node53 = node50.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(45, node29, node33, node50, 50, 51);
        boolean boolean57 = googleCodingConvention1.isVarArgsParameter(node29);
        boolean boolean58 = node29.isHook();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str31.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.matchesNumberContext();
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = functionType27.getOwnPropertyJSDocInfo("Exceeded max number of optimization iterations: EXPR_RESULT");
        boolean boolean40 = functionType27.isBooleanValueType();
        boolean boolean41 = functionType27.isRegexpType();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(jSDocInfo39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        java.lang.String str8 = node6.toString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = node10.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node14 = node6.srcref(node10);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.switchNode(node10, nodeArray15);
        java.util.List<java.lang.String> strList17 = googleCodingConvention1.identifyTypeDeclarationCall(node10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node22 = node19.clonePropsFrom(node21);
        boolean boolean23 = node21.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap24 = null;
        googleCodingConvention1.checkForCallingConventionDefiningCalls(node21, strMap24);
        java.lang.String str26 = googleCodingConvention1.getExportSymbolFunction();
        boolean boolean29 = googleCodingConvention1.isExported("Named type with empty name component", false);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str8.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(strList17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node7 = node4.clonePropsFrom(node6);
        node4.putBooleanProp(10, false);
        boolean boolean11 = node4.isQuotedString();
        boolean boolean12 = node4.isFor();
        node4.setQuotedString();
        boolean boolean14 = node4.isReturn();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString("Named type with empty name component");
        java.lang.String str17 = closureCodingConvention2.extractClassNameIfProvide(node4, node16);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention18 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention2);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 49, 51);
        node3.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        int int1 = node0.getCharno();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node6 = node3.clonePropsFrom(node5);
        node3.putBooleanProp(10, false);
        boolean boolean10 = node3.isQuotedString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node12 = node0.copyInformationFromForTree(node11);
        boolean boolean13 = node0.isInstanceOf();
        boolean boolean14 = node0.isAssignAdd();
        boolean boolean15 = node0.isAssign();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput5.getSourceFile();
        java.lang.String str8 = sourceFile7.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        boolean boolean3 = composeWarningsGuard1.disables(diagnosticGroup2);
        com.google.javascript.jscomp.DiagnosticGroups.CONST = diagnosticGroup2;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset1);
        java.lang.String str3 = sourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceFile2, false);
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput5.getAst();
        com.google.javascript.jscomp.SourceFile sourceFile7 = compilerInput5.getSourceFile();
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromFile("hi!", charset9);
        java.lang.String str11 = sourceFile10.toString();
        java.lang.String str13 = sourceFile10.getLine(49);
        compilerInput5.setSourceFile(sourceFile10);
        try {
            java.lang.String str15 = sourceFile10.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: hi! (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceAst6);
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        boolean boolean3 = jSDocInfo0.isNoShadow();
        boolean boolean4 = jSDocInfo0.isNoCompile();
        java.lang.String str5 = jSDocInfo0.getLendsName();
        boolean boolean6 = jSDocInfo0.hasTypedefType();
        java.util.Set<java.lang.String> strSet7 = jSDocInfo0.getModifies();
        int int8 = jSDocInfo0.getImplementedInterfaceCount();
        int int9 = jSDocInfo0.getImplementedInterfaceCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) (short) 10, 49, 51);
        boolean boolean5 = node4.isName();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node4, callback6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("hi!");
        java.lang.String str3 = node2.getString();
        com.google.javascript.jscomp.NodeTraversal.Callback callback4 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node2, callback4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection1 = jSDocInfo0.getMarkers();
        jSDocInfo0.setLicense("Named type with empty name component");
        boolean boolean4 = jSDocInfo0.isJavaDispatch();
        org.junit.Assert.assertNotNull(markerCollection1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineGetters = false;
        compilerOptions0.setTightenTypes(false);
        compilerOptions0.setAcceptConstKeyword(false);
        compilerOptions0.setSummaryDetailLevel(15);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean8 = node7.isObjectLit();
        java.lang.String str9 = node7.toString();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node14 = node11.clonePropsFrom(node13);
        node11.putBooleanProp(10, false);
        boolean boolean18 = node11.isQuotedString();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean24 = node23.isTrue();
        com.google.javascript.rhino.Node node25 = node11.useSourceInfoFromForTree(node23);
        boolean boolean26 = node11.isAdd();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node31 = node28.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(45, node7, node11, node28, 50, 51);
        boolean boolean35 = googleCodingConvention1.isPrototypeAlias(node34);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention36 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention1);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node41 = node38.clonePropsFrom(node40);
        boolean boolean42 = node38.isIf();
        com.google.javascript.rhino.jstype.JSType jSType43 = node38.getJSType();
        boolean boolean44 = node38.isInstanceOf();
        boolean boolean45 = node38.isSyntheticBlock();
        com.google.javascript.jscomp.CodingConvention.Bind bind46 = googleCodingConvention1.describeFunctionBind(node38);
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str9.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(jSType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(bind46);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.trueNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node5 = node2.clonePropsFrom(node4);
        node2.putBooleanProp(10, false);
        boolean boolean9 = node2.isQuotedString();
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newExpr(node2);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder16 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry15);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean25 = node24.isObjectLit();
        java.lang.String str26 = node24.toString();
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node31 = node28.clonePropsFrom(node30);
        node28.putBooleanProp(10, false);
        boolean boolean35 = node28.isQuotedString();
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean41 = node40.isTrue();
        com.google.javascript.rhino.Node node42 = node28.useSourceInfoFromForTree(node40);
        boolean boolean43 = node28.isAdd();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node48 = node45.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(45, node24, node28, node45, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder52 = recordTypeBuilder16.addProperty("", jSType18, node51);
        boolean boolean53 = node14.hasChild(node51);
        boolean boolean54 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node14);
        boolean boolean55 = node14.isDo();
        com.google.javascript.rhino.Node node56 = node10.useSourceInfoIfMissingFromForTree(node14);
        try {
            com.google.javascript.rhino.Node node57 = node0.removeChildAfter(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str26.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(recordTypeBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineGetters = false;
        boolean boolean3 = compilerOptions0.foldConstants;
        compilerOptions0.setRemoveTryCatchFinally(true);
        compilerOptions0.setDevirtualizePrototypeMethods(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkRequires;
        compilerOptions0.setInferTypes(false);
        compilerOptions0.setConvertToDottedProperties(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node4 = node1.clonePropsFrom(node3);
        node1.putBooleanProp(10, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newExpr(node1);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node13 = node10.clonePropsFrom(node12);
        boolean boolean14 = node10.isCall();
        boolean boolean15 = node10.isThrow();
        com.google.javascript.rhino.Node node16 = node1.copyInformationFromForTree(node10);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap1 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap1;
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList7 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList7, jSTypeArray6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry4.createFunctionTypeWithVarArgs(jSType5, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        com.google.javascript.rhino.Node node10 = jSTypeRegistry1.createParametersWithVarArgs((java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList7);
        jSTypeRegistry1.setLastGeneration(false);
        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry1.getType("NAME hi!");
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler7 = null;
        jSModule6.sortInputsByDeps(compiler7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList9 = jSModule6.getDependencies();
        jSModule1.addDependency(jSModule6);
        java.lang.String str11 = jSModule1.toString();
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList12 = jSModule1.getDependencies();
        java.util.List<java.lang.String> strList13 = jSModule1.getProvides();
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(jSModuleList12);
        org.junit.Assert.assertNotNull(strList13);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean10 = node9.isObjectLit();
        java.lang.String str11 = node9.toString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node17 = node9.srcref(node13);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.switchNode(node13, nodeArray18);
        java.util.List<java.lang.String> strList20 = googleCodingConvention4.identifyTypeDeclarationCall(node13);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node25 = node22.clonePropsFrom(node24);
        boolean boolean26 = node24.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap27 = null;
        googleCodingConvention4.checkForCallingConventionDefiningCalls(node24, strMap27);
        boolean boolean29 = node24.isRegExp();
        com.google.javascript.rhino.Node node30 = functionParamBuilder2.newParameterFromNode(node24);
        boolean boolean31 = node30.isComma();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = node33.clonePropsFrom(node35);
        node33.putBooleanProp(10, false);
        boolean boolean40 = node33.isQuotedString();
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.IR.neg(node33);
        com.google.javascript.rhino.JSDocInfo jSDocInfo42 = node41.getJSDocInfo();
        boolean boolean43 = node41.isDefaultCase();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder46 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry45);
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        java.lang.String str55 = node53.toString();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node60 = node57.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node61 = node53.srcref(node57);
        com.google.javascript.rhino.Node[] nodeArray62 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.switchNode(node57, nodeArray62);
        java.util.List<java.lang.String> strList64 = googleCodingConvention48.identifyTypeDeclarationCall(node57);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node69 = node66.clonePropsFrom(node68);
        boolean boolean70 = node68.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap71 = null;
        googleCodingConvention48.checkForCallingConventionDefiningCalls(node68, strMap71);
        boolean boolean73 = node68.isRegExp();
        com.google.javascript.rhino.Node node74 = functionParamBuilder46.newParameterFromNode(node68);
        int int75 = node68.getSideEffectFlags();
        int int76 = node41.getIndexOfChild(node68);
        com.google.javascript.rhino.Node node77 = node30.useSourceInfoIfMissingFromForTree(node68);
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str11.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(strList20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNull(jSDocInfo42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str55.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeArray62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(strList64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNotNull(node77);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        jSDocInfoBuilder1.markText("NAME hi!\n", (int) ' ', (int) (byte) 1, (int) 'a', 32);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.jscomp.CodingConvention codingConvention3 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean10 = node9.isObjectLit();
        java.lang.String str11 = node9.toString();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node17 = node9.srcref(node13);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.switchNode(node13, nodeArray18);
        java.util.List<java.lang.String> strList20 = googleCodingConvention4.identifyTypeDeclarationCall(node13);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node25 = node22.clonePropsFrom(node24);
        boolean boolean26 = node24.isDec();
        java.util.Map<java.lang.String, java.lang.String> strMap27 = null;
        googleCodingConvention4.checkForCallingConventionDefiningCalls(node24, strMap27);
        boolean boolean29 = node24.isRegExp();
        com.google.javascript.rhino.Node node30 = functionParamBuilder2.newParameterFromNode(node24);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node35 = node32.clonePropsFrom(node34);
        boolean boolean36 = node32.isIf();
        com.google.javascript.rhino.Node node37 = functionParamBuilder2.newParameterFromNode(node32);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean44 = node43.isObjectLit();
        java.lang.String str45 = node43.toString();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node50 = node47.clonePropsFrom(node49);
        node47.putBooleanProp(10, false);
        boolean boolean54 = node47.isQuotedString();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean60 = node59.isTrue();
        com.google.javascript.rhino.Node node61 = node47.useSourceInfoFromForTree(node59);
        boolean boolean62 = node47.isAdd();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node67 = node64.clonePropsFrom(node66);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(45, node43, node47, node64, 50, 51);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node75 = node72.clonePropsFrom(node74);
        node72.putBooleanProp(10, false);
        boolean boolean79 = node72.isQuotedString();
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean85 = node84.isTrue();
        com.google.javascript.rhino.Node node86 = node72.useSourceInfoFromForTree(node84);
        boolean boolean87 = node72.isAdd();
        com.google.javascript.rhino.Node node88 = node47.srcref(node72);
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile89 = node72.getStaticSourceFile();
        boolean boolean90 = node72.isReturn();
        com.google.javascript.rhino.Node node91 = functionParamBuilder2.newParameterFromNode(node72);
        boolean boolean92 = node91.isCase();
        boolean boolean93 = node91.isOptionalArg();
        org.junit.Assert.assertNotNull(codingConvention3);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str11.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(strList20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str45.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNull(staticSourceFile89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        boolean boolean3 = jSDocInfo0.isNoShadow();
        boolean boolean4 = jSDocInfo0.isNoCompile();
        java.lang.String str5 = jSDocInfo0.getLendsName();
        boolean boolean6 = jSDocInfo0.hasType();
        boolean boolean8 = jSDocInfo0.hasParameter("Unknown class name");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("EXPR_RESULT");
        boolean boolean4 = closureCodingConvention0.isConstantKey("Exceeded max number of optimization iterations: EXPR_RESULT");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("hi!");
        boolean boolean7 = node6.isDebugger();
        java.lang.String str8 = closureCodingConvention0.getSingletonGetterClassName(node6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node11 = node6.useSourceInfoFrom(node10);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable12 = node10.children();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(nodeIterable12);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.jscomp.NodeTraversal.Callback callback1 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal2 = new com.google.javascript.jscomp.NodeTraversal(abstractCompiler0, callback1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.string("");
        boolean boolean5 = node4.isRegExp();
        com.google.javascript.rhino.Node[] nodeArray6 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.script(nodeArray6);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.switchNode(node4, nodeArray6);
        nodeTraversal2.traverseRoots(nodeArray6);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.continueNode();
        int int11 = node10.getCharno();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node16 = node13.clonePropsFrom(node15);
        node13.putBooleanProp(10, false);
        boolean boolean20 = node13.isQuotedString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node13);
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node23 = node21.getLastSibling();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray33 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel27, diagnosticType28, strArray33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean40 = node39.isObjectLit();
        java.lang.String str41 = node39.toString();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node46 = node43.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node47 = node39.srcref(node43);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.IR.switchNode(node43, nodeArray48);
        boolean boolean50 = node49.isTrue();
        boolean boolean51 = diagnosticType28.equals((java.lang.Object) boolean50);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup52 = com.google.javascript.jscomp.DiagnosticGroup.forType(diagnosticType28);
        com.google.javascript.jscomp.CheckLevel checkLevel56 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray62 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel56, diagnosticType57, strArray62);
        com.google.javascript.jscomp.JSError jSError64 = nodeTraversal2.makeError(node23, diagnosticType28, strArray62);
        int int65 = jSError64.lineNumber;
        int int66 = jSError64.getCharno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(nodeArray6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str41.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup52);
        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertNotNull(jSError64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean6 = node5.isObjectLit();
        java.lang.String str7 = node5.toString();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node12 = node9.clonePropsFrom(node11);
        node9.putBooleanProp(10, false);
        boolean boolean16 = node9.isQuotedString();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean22 = node21.isTrue();
        com.google.javascript.rhino.Node node23 = node9.useSourceInfoFromForTree(node21);
        boolean boolean24 = node9.isAdd();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node29 = node26.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(45, node5, node9, node26, 50, 51);
        boolean boolean33 = node26.isWhile();
        int int34 = node26.getLength();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str7.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.rhino.jstype.JSType jSType7 = functionType6.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType8 = functionType6.getTypeOfThis();
        int int9 = functionType6.getMaxArguments();
        boolean boolean10 = functionType6.isEnumElementType();
        boolean boolean11 = functionType6.isEnumElementType();
        com.google.javascript.rhino.jstype.FunctionType functionType12 = functionType6.toMaybeFunctionType();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType13 = functionType12.getSuperClassConstructor();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(functionType12);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckTypes(true);
        compilerOptions0.locale = "Not declared as a constructor";
        compilerOptions0.setInlineGetters(false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getParameterNames();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection3 = jSDocInfo0.getTypeNodes();
        java.lang.String str4 = jSDocInfo0.getMeaning();
        int int5 = jSDocInfo0.getParameterCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertNotNull(nodeCollection3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Node tree inequality:\nTree1:\nNAME hi!\n\n\nTree2:\nERROR  100\n\n\nSubtree1: NAME hi!\n\n\nSubtree2: ERROR  100\n", "function (): {476650047}");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        jSTypeRegistry1.forwardDeclareType("goog.exportProperty");
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        try {
            jSTypeRegistry1.overwriteDeclaredType("EXPR_RESULT", jSType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.lang.String str46 = functionType6.getNormalizedReferenceName();
        com.google.javascript.jscomp.CodingConvention codingConvention47 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean54 = node53.isObjectLit();
        boolean boolean55 = googleCodingConvention48.isOptionalParameter(node53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType57 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType58 = null;
        googleCodingConvention48.applySubclassRelationship(functionType56, functionType57, subclassType58);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList64 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList64, jSTypeArray63);
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry61.createFunctionTypeWithVarArgs(jSType62, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList64);
        com.google.javascript.rhino.jstype.JSType jSType67 = functionType66.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter68 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter68);
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList72 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList72, jSTypeArray71);
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry69.createFunctionTypeWithVarArgs(jSType70, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList72);
        com.google.javascript.rhino.jstype.JSType jSType75 = functionType74.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry77 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76);
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray79 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList80 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList80, jSTypeArray79);
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry77.createFunctionTypeWithVarArgs(jSType78, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList80);
        googleCodingConvention48.applySingletonGetter(functionType66, functionType74, (com.google.javascript.rhino.jstype.ObjectType) functionType82);
        boolean boolean84 = functionType6.canAssignTo((com.google.javascript.rhino.jstype.JSType) functionType82);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean87 = jSDocInfo86.isConstructor();
        java.util.Set<java.lang.String> strSet88 = jSDocInfo86.getParameterNames();
        boolean boolean89 = jSDocInfo86.isNoShadow();
        boolean boolean90 = jSDocInfo86.isNoCompile();
        java.lang.String str91 = jSDocInfo86.getLendsName();
        functionType82.setPropertyJSDocInfo("module$hi!", jSDocInfo86);
        boolean boolean94 = functionType82.isPropertyTypeDeclared("");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(codingConvention47);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertNull(jSType67);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(jSType75);
        org.junit.Assert.assertNotNull(jSTypeArray79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(strSet88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNull(str91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkRequires;
        boolean boolean2 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder5 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry4);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        java.lang.String str15 = node13.toString();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node20 = node17.clonePropsFrom(node19);
        node17.putBooleanProp(10, false);
        boolean boolean24 = node17.isQuotedString();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean30 = node29.isTrue();
        com.google.javascript.rhino.Node node31 = node17.useSourceInfoFromForTree(node29);
        boolean boolean32 = node17.isAdd();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node37 = node34.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(45, node13, node17, node34, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder41 = recordTypeBuilder5.addProperty("", jSType7, node40);
        boolean boolean42 = node3.hasChild(node40);
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean44 = jSDocInfo43.isConstructor();
        java.util.Set<java.lang.String> strSet45 = jSDocInfo43.getParameterNames();
        node3.setDirectives(strSet45);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression48 = new com.google.javascript.rhino.JSTypeExpression(node3, "EXPR_RESULT");
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList53 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean54 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList53, jSTypeArray52);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry50.createFunctionTypeWithVarArgs(jSType51, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList53);
        com.google.javascript.rhino.jstype.JSType jSType56 = functionType55.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType57 = functionType55.getTypeOfThis();
        boolean boolean58 = functionType55.isNativeObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        jSTypeRegistry60.forwardDeclareType("goog.exportProperty");
        com.google.javascript.rhino.jstype.JSType jSType68 = jSTypeExpression48.evaluate((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType55, jSTypeRegistry60);
        boolean boolean69 = jSType68.isVoidType();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str15.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(recordTypeBuilder41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNull(jSType56);
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNotNull(jSType68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getExportPropertyFunction();
        java.lang.String str2 = closureCodingConvention0.getExportPropertyFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection3 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "EXPR_RESULT", "EXPR_RESULT", "hi!", "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("Named type with empty name component", 50, 35, checkLevel7, diagnosticType8, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = jSError14.getDefaultLevel();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = jSError14.level;
        int int17 = jSError14.lineNumber;
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList22 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList22, jSTypeArray21);
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry19.createFunctionTypeWithVarArgs(jSType20, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList22);
        com.google.javascript.rhino.jstype.JSType jSType25 = functionType24.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType26 = functionType24.getTypeOfThis();
        int int27 = functionType24.getMaxArguments();
        boolean boolean28 = jSError14.equals((java.lang.Object) functionType24);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList41 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean42 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList41, jSTypeArray40);
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry38.createFunctionTypeWithVarArgs(jSType39, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList41);
        boolean boolean44 = jSTypeRegistry30.declareType("module$hi!", jSType39);
        com.google.javascript.jscomp.CodingConvention codingConvention46 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention47 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean53 = node52.isObjectLit();
        boolean boolean54 = googleCodingConvention47.isOptionalParameter(node52);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType56 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType57 = null;
        googleCodingConvention47.applySubclassRelationship(functionType55, functionType56, subclassType57);
        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59);
        com.google.javascript.rhino.jstype.JSType jSType61 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList63 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList63, jSTypeArray62);
        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry60.createFunctionTypeWithVarArgs(jSType61, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList63);
        com.google.javascript.rhino.jstype.JSType jSType66 = functionType65.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67);
        com.google.javascript.rhino.jstype.JSType jSType69 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList71 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList71, jSTypeArray70);
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry68.createFunctionTypeWithVarArgs(jSType69, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList71);
        com.google.javascript.rhino.jstype.JSType jSType74 = functionType73.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter75 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry76 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter75);
        com.google.javascript.rhino.jstype.JSType jSType77 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList79 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean80 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList79, jSTypeArray78);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry76.createFunctionTypeWithVarArgs(jSType77, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList79);
        googleCodingConvention47.applySingletonGetter(functionType65, functionType73, (com.google.javascript.rhino.jstype.ObjectType) functionType81);
        functionType73.clearResolved();
        jSTypeRegistry30.unregisterPropertyOnType("Not declared as a type name", (com.google.javascript.rhino.jstype.JSType) functionType73);
        com.google.javascript.rhino.jstype.EnumElementType enumElementType85 = functionType73.toMaybeEnumElementType();
        java.util.Set<java.lang.String> strSet86 = functionType73.getOwnPropertyNames();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType87 = null;
        closureCodingConvention0.applySubclassRelationship(functionType24, functionType73, subclassType87);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportProperty" + "'", str1.equals("goog.exportProperty"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "goog.exportProperty" + "'", str2.equals("goog.exportProperty"));
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection3);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 50 + "'", int17 == 50);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(codingConvention46);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(functionType65);
        org.junit.Assert.assertNull(jSType66);
        org.junit.Assert.assertNotNull(jSTypeArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(functionType73);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertNull(enumElementType85);
        org.junit.Assert.assertNotNull(strSet86);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineGetters = false;
        boolean boolean3 = compilerOptions0.foldConstants;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(errorFormat4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString("", (int) (byte) 100, 44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = null;
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder7 = new com.google.javascript.rhino.jstype.RecordTypeBuilder(jSTypeRegistry6);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean16 = node15.isObjectLit();
        java.lang.String str17 = node15.toString();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node22 = node19.clonePropsFrom(node21);
        node19.putBooleanProp(10, false);
        boolean boolean26 = node19.isQuotedString();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean32 = node31.isTrue();
        com.google.javascript.rhino.Node node33 = node19.useSourceInfoFromForTree(node31);
        boolean boolean34 = node19.isAdd();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.name("hi!");
        com.google.javascript.rhino.Node node39 = node36.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(45, node15, node19, node36, 50, 51);
        com.google.javascript.rhino.jstype.RecordTypeBuilder recordTypeBuilder43 = recordTypeBuilder7.addProperty("", jSType9, node42);
        boolean boolean44 = node5.hasChild(node42);
        com.google.javascript.rhino.JSDocInfo jSDocInfo45 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean46 = jSDocInfo45.isConstructor();
        java.util.Set<java.lang.String> strSet47 = jSDocInfo45.getParameterNames();
        node5.setDirectives(strSet47);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression50 = new com.google.javascript.rhino.JSTypeExpression(node5, "EXPR_RESULT");
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList55 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList55, jSTypeArray54);
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry52.createFunctionTypeWithVarArgs(jSType53, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList55);
        com.google.javascript.rhino.jstype.JSType jSType58 = functionType57.getIndexType();
        com.google.javascript.rhino.jstype.ObjectType objectType59 = functionType57.getTypeOfThis();
        boolean boolean60 = functionType57.isNativeObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61);
        com.google.javascript.rhino.jstype.JSType jSType63 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList65 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean66 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList65, jSTypeArray64);
        com.google.javascript.rhino.jstype.FunctionType functionType67 = jSTypeRegistry62.createFunctionTypeWithVarArgs(jSType63, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList65);
        jSTypeRegistry62.forwardDeclareType("goog.exportProperty");
        com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeExpression50.evaluate((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType57, jSTypeRegistry62);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression71 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression50);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression72 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression71);
        boolean boolean73 = jSDocInfoBuilder1.recordEnumParameterType(jSTypeExpression71);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "BITXOR Not declared as a type name 0" + "'", str17.equals("BITXOR Not declared as a type name 0"));
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(recordTypeBuilder43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strSet47);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNull(jSType58);
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(jSTypeArray64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(functionType67);
        org.junit.Assert.assertNotNull(jSType70);
        org.junit.Assert.assertNotNull(jSTypeExpression71);
        org.junit.Assert.assertNotNull(jSTypeExpression72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean7 = node6.isObjectLit();
        boolean boolean8 = googleCodingConvention1.isOptionalParameter(node6);
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        googleCodingConvention1.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList17 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList17, jSTypeArray16);
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createFunctionTypeWithVarArgs(jSType15, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType19.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList25 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList25, jSTypeArray24);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry22.createFunctionTypeWithVarArgs(jSType23, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList25);
        com.google.javascript.rhino.jstype.JSType jSType28 = functionType27.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList33 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList33, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createFunctionTypeWithVarArgs(jSType31, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList33);
        googleCodingConvention1.applySingletonGetter(functionType19, functionType27, (com.google.javascript.rhino.jstype.ObjectType) functionType35);
        boolean boolean37 = functionType27.isOrdinaryFunction();
        boolean boolean38 = functionType27.isConstructor();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable39 = functionType27.getExtendedInterfaces();
        boolean boolean40 = functionType27.hasCachedValues();
        org.junit.Assert.assertNotNull(codingConvention0);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNull(jSType20);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertNull(jSType28);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.JSDocInfo.NamePosition namePosition0 = new com.google.javascript.rhino.JSDocInfo.NamePosition();
        int int1 = namePosition0.getPositionOnStartLine();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler2 = null;
        jSModule1.sortInputsByDeps(compiler2);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler7 = null;
        jSModule6.sortInputsByDeps(compiler7);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList9 = jSModule6.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler14 = null;
        jSModule13.sortInputsByDeps(compiler14);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList16 = jSModule13.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler19 = null;
        jSModule18.sortInputsByDeps(compiler19);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList21 = jSModule18.getDependencies();
        jSModule13.addDependency(jSModule18);
        com.google.javascript.jscomp.Compiler compiler23 = null;
        jSModule18.sortInputsByDeps(compiler23);
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler27 = null;
        jSModule26.sortInputsByDeps(compiler27);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList29 = jSModule26.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule31 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.Compiler compiler32 = null;
        jSModule31.sortInputsByDeps(compiler32);
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList34 = jSModule31.getDependencies();
        jSModule26.addDependency(jSModule31);
        com.google.javascript.jscomp.JSModule jSModule37 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.JSModule[] jSModuleArray38 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule6, jSModule11, jSModule18, jSModule31, jSModule37 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph39 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray38);
        jSModuleGraph39.coalesceDuplicateFiles();
        com.google.javascript.jscomp.JSModule jSModule42 = new com.google.javascript.jscomp.JSModule("");
        com.google.javascript.jscomp.JSModule jSModule44 = new com.google.javascript.jscomp.JSModule("module$hi!");
        java.lang.String str45 = jSModule44.getName();
        boolean boolean46 = jSModuleGraph39.dependsOn(jSModule42, jSModule44);
        java.util.List<java.lang.String> strList47 = jSModule44.getProvides();
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList9);
        org.junit.Assert.assertNotNull(jSModuleList16);
        org.junit.Assert.assertNotNull(jSModuleList21);
        org.junit.Assert.assertNotNull(jSModuleList29);
        org.junit.Assert.assertNotNull(jSModuleList34);
        org.junit.Assert.assertNotNull(jSModuleArray38);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "module$hi!" + "'", str45.equals("module$hi!"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(strList47);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOptimizeReturns(true);
        compilerOptions0.renamePrefixNamespace = "hi!";
        compilerOptions0.setPreferLineBreakAtEndOfFile(false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("Exceeded max number of optimization iterations: EXPR_RESULT");
        int int2 = node1.getChildCount();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList4 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList4, jSTypeArray3);
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList4);
        com.google.javascript.jscomp.CodingConvention codingConvention7 = com.google.javascript.jscomp.CodingConventions.getDefault();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention7);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "Not declared as a type name", 0, (int) (byte) 10);
        boolean boolean14 = node13.isObjectLit();
        boolean boolean15 = googleCodingConvention8.isOptionalParameter(node13);
        com.google.javascript.rhino.jstype.FunctionType functionType16 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType17 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType18 = null;
        googleCodingConvention8.applySubclassRelationship(functionType16, functionType17, subclassType18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList24 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList24, jSTypeArray23);
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createFunctionTypeWithVarArgs(jSType22, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList24);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType26.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList32 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList32, jSTypeArray31);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createFunctionTypeWithVarArgs(jSType30, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList32);
        com.google.javascript.rhino.jstype.JSType jSType35 = functionType34.getIndexType();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.JSType> jSTypeList40 = new java.util.ArrayList<com.google.javascript.rhino.jstype.JSType>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.JSType>) jSTypeList40, jSTypeArray39);
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createFunctionTypeWithVarArgs(jSType38, (java.util.List<com.google.javascript.rhino.jstype.JSType>) jSTypeList40);
        googleCodingConvention8.applySingletonGetter(functionType26, functionType34, (com.google.javascript.rhino.jstype.ObjectType) functionType42);
        boolean boolean44 = functionType34.isOrdinaryFunction();
        boolean boolean45 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean47 = functionType34.hasOwnProperty("hi!");
        java.lang.Object obj48 = null;
        boolean boolean49 = functionType34.equals(obj48);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(codingConvention7);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNull(jSType27);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNull(jSType35);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }
}

