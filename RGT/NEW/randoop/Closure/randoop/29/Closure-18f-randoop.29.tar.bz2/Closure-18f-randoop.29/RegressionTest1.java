import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        boolean boolean2 = jSDocInfo0.containsDeclaration();
        java.lang.String str3 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(jSTypeExpression4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        boolean boolean4 = googleCodingConvention0.isExported("function (): {632444925}", true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        boolean boolean4 = jSDocInfo0.hasDescriptionForParameter("function (): {1466090035}");
        boolean boolean5 = jSDocInfo0.isIdGenerator();
        java.util.Collection<java.lang.String> strCollection6 = jSDocInfo0.getAuthors();
        int int7 = jSDocInfo0.getImplementedInterfaceCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(strCollection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node7 = node4.getLastSibling();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable8 = node4.getAncestors();
        boolean boolean9 = node4.isRegExp();
        boolean boolean10 = node4.isFunction();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(ancestorIterable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        boolean boolean7 = googleCodingConvention0.isConstantKey("hi!");
        boolean boolean10 = googleCodingConvention0.isExported(": hi!", true);
        boolean boolean12 = googleCodingConvention0.isConstantKey("(): hi!");
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
//        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
//        boolean boolean20 = node12.isBreak();
//        node12.addSuppression("goog.exportSymbol");
//        boolean boolean23 = closureCodingConvention0.isOptionalParameter(node12);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        jSTypeRegistry26.incrementGeneration();
//        jSTypeRegistry26.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = googleCodingConvention31.getDelegateRelationship(node35);
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention41 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = googleCodingConvention41.getDelegateRelationship(node45);
//        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.hook(node35, node40, node45);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        boolean boolean56 = functionType55.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry59.createFunctionType(jSType60, false, jSTypeArray62);
//        java.lang.String str64 = functionType63.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType63.unboxesTo();
//        boolean boolean67 = functionType63.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType68 = null;
//        closureCodingConvention48.applySubclassRelationship(functionType55, functionType63, subclassType68);
//        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry72.createFunctionType(jSType73, false, jSTypeArray75);
//        boolean boolean77 = functionType55.hasEqualCallType(functionType76);
//        com.google.javascript.rhino.jstype.EnumType enumType78 = jSTypeRegistry26.createEnumType("function (): {677104072}", node35, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79, true);
//        com.google.javascript.rhino.jstype.JSType jSType82 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry81.createFunctionType(jSType82, false, jSTypeArray84);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType86 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType55, functionType85, subclassType86);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean89 = jSDocInfo88.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection90 = jSDocInfo88.getMarkers();
//        functionType55.setJSDocInfo(jSDocInfo88);
//        boolean boolean92 = functionType55.canBeCalled();
//        functionType55.clearCachedValues();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNull(delegateRelationship18);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(delegateRelationship36);
//        org.junit.Assert.assertNull(delegateRelationship46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "function (): {1833890682}" + "'", str64.equals("function (): {1833890682}"));
//        org.junit.Assert.assertNull(jSType65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray75);
//        org.junit.Assert.assertNotNull(functionType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(enumType78);
//        org.junit.Assert.assertNotNull(jSTypeArray84);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(markerCollection90);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable8 = functionType6.getOwnImplementedInterfaces();
//        boolean boolean9 = functionType6.matchesUint32Context();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {1658052688}" + "'", str7.equals("function (): {1658052688}"));
//        org.junit.Assert.assertNotNull(objectTypeIterable8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
//        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable2 = diagnosticGroup0.getTypes();
//        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable3 = diagnosticGroup0.getTypes();
//        java.lang.String str4 = diagnosticGroup0.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticTypeIterable2);
//        org.junit.Assert.assertNotNull(diagnosticTypeIterable3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DiagnosticGroup<function (): {1062485636}>" + "'", str4.equals("DiagnosticGroup<function (): {1062485636}>"));
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        java.lang.String str7 = com.google.javascript.jscomp.NodeUtil.getSourceName(node4);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = googleCodingConvention8.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder14 = node12.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node15 = node12.getLastSibling();
        com.google.javascript.rhino.Node node16 = node4.useSourceInfoFromForTree(node15);
        boolean boolean17 = node16.hasChildren();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("function (): {273651779}", "function (): {729410073}");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        boolean boolean12 = functionType11.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        java.lang.String str20 = functionType19.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType21 = functionType19.unboxesTo();
//        boolean boolean23 = functionType19.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
//        closureCodingConvention4.applySubclassRelationship(functionType11, functionType19, subclassType24);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
//        com.google.javascript.rhino.jstype.JSType jSType29 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry28.createFunctionType(jSType29, false, jSTypeArray31);
//        boolean boolean33 = functionType11.hasEqualCallType(functionType32);
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry36.createFunctionType(jSType37, false, jSTypeArray39);
//        java.lang.String str41 = functionType40.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType42 = functionType40.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = functionType40.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType44 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType32, (com.google.javascript.rhino.jstype.JSType) functionType40);
//        boolean boolean45 = parameterizedType44.isInterface();
//        boolean boolean46 = parameterizedType44.matchesStringContext();
//        boolean boolean47 = parameterizedType44.isNoType();
//        boolean boolean48 = parameterizedType44.hasReferenceName();
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (): {691804383}" + "'", str20.equals("function (): {691804383}"));
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray31);
//        org.junit.Assert.assertNotNull(functionType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertNotNull(functionType40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "function (): {1150599043}" + "'", str41.equals("function (): {1150599043}"));
//        org.junit.Assert.assertNull(jSType42);
//        org.junit.Assert.assertNotNull(objectTypeIterable43);
//        org.junit.Assert.assertNotNull(parameterizedType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
//        com.google.javascript.rhino.jstype.JSType jSType10 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry9.createFunctionType(jSType10, false, jSTypeArray12);
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry2.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType13);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
//        com.google.javascript.rhino.jstype.JSType jSType19 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry18.createFunctionType(jSType19, false, jSTypeArray21);
//        boolean boolean23 = functionType22.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        com.google.javascript.rhino.jstype.JSType jSType27 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry26.createFunctionType(jSType27, false, jSTypeArray29);
//        java.lang.String str31 = functionType30.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType32 = functionType30.unboxesTo();
//        boolean boolean34 = functionType30.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
//        closureCodingConvention15.applySubclassRelationship(functionType22, functionType30, subclassType35);
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, true);
//        com.google.javascript.rhino.jstype.JSType jSType40 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry39.createFunctionType(jSType40, false, jSTypeArray42);
//        boolean boolean44 = functionType22.hasEqualCallType(functionType43);
//        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
//        com.google.javascript.rhino.jstype.JSType jSType48 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry47.createFunctionType(jSType48, false, jSTypeArray50);
//        java.lang.String str52 = functionType51.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType53 = functionType51.unboxesTo();
//        boolean boolean55 = functionType51.isPropertyInExterns(": hi!");
//        int int56 = functionType51.getMaxArguments();
//        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry2.createFunctionTypeWithNewReturnType(functionType43, (com.google.javascript.rhino.jstype.JSType) functionType51);
//        com.google.javascript.rhino.ErrorReporter errorReporter58 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter58, true);
//        com.google.javascript.rhino.jstype.JSType jSType61 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry60.createFunctionType(jSType61, false, jSTypeArray63);
//        java.lang.String str65 = functionType64.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType66 = functionType64.unboxesTo();
//        boolean boolean68 = functionType64.isPropertyInExterns(": hi!");
//        int int69 = functionType64.getMaxArguments();
//        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType64);
//        boolean boolean71 = functionType64.isOrdinaryFunction();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(functionType13);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(functionType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray29);
//        org.junit.Assert.assertNotNull(functionType30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): {1597928186}" + "'", str31.equals("function (): {1597928186}"));
//        org.junit.Assert.assertNull(jSType32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray42);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray50);
//        org.junit.Assert.assertNotNull(functionType51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "function (): {980341756}" + "'", str52.equals("function (): {980341756}"));
//        org.junit.Assert.assertNull(jSType53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(functionType57);
//        org.junit.Assert.assertNotNull(jSTypeArray63);
//        org.junit.Assert.assertNotNull(functionType64);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "function (): {1166336251}" + "'", str65.equals("function (): {1166336251}"));
//        org.junit.Assert.assertNull(jSType66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PROTECTED));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        double double8 = compiler6.getProgress();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter9 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6);
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention10 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = googleCodingConvention10.getDelegateRelationship(node14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node4, node9, node14);
        boolean boolean17 = node16.wasEmptyNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention18 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = googleCodingConvention18.getDelegateRelationship(node22);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention28 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship33 = googleCodingConvention28.getDelegateRelationship(node32);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.hook(node22, node27, node32);
        int int35 = node27.getSourceOffset();
        node27.setType(10);
        node27.addSuppression("()");
        try {
            com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.IR.and(node16, node27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNull(delegateRelationship33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention1.isSuperClassReference("()");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = googleCodingConvention4.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = googleCodingConvention14.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node8, node13, node18);
        boolean boolean21 = node13.isBreak();
        node13.addSuppression("goog.exportSymbol");
        boolean boolean24 = closureCodingConvention1.isOptionalParameter(node13);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node26 = node25.cloneTree();
        boolean boolean27 = node25.isParamList();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.pos(node31);
        java.lang.String str33 = closureCodingConvention1.extractClassNameIfRequire(node25, node32);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention34 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship39 = googleCodingConvention34.getDelegateRelationship(node38);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention40 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship45 = googleCodingConvention40.getDelegateRelationship(node44);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention50 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship55 = googleCodingConvention50.getDelegateRelationship(node54);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.hook(node44, node49, node54);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention57 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship62 = googleCodingConvention57.getDelegateRelationship(node61);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention67 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship72 = googleCodingConvention67.getDelegateRelationship(node71);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.hook(node61, node66, node71);
        java.lang.String str74 = googleCodingConvention34.extractClassNameIfRequire(node54, node73);
        boolean boolean75 = node73.isWhile();
        com.google.javascript.rhino.Node node76 = node73.removeChildren();
        node73.putBooleanProp((int) (short) 1, false);
        boolean boolean80 = node73.isBlock();
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(4, node25, node73);
        try {
            node73.setSideEffectFlags(49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got HOOK");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship39);
        org.junit.Assert.assertNull(delegateRelationship45);
        org.junit.Assert.assertNull(delegateRelationship55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(delegateRelationship62);
        org.junit.Assert.assertNull(delegateRelationship72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("goog.exportSymbol");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray13 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray22 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray22);
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("function (): {138273163}", node2, diagnosticType5, strArray22);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.returnNode(node2);
        boolean boolean27 = node26.isFor();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        boolean boolean1 = com.google.javascript.jscomp.NodeUtil.isValidQualifiedName("function (): {1225874924}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        jSTypeRegistry2.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention7 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship12 = googleCodingConvention7.getDelegateRelationship(node11);
//        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention17 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = googleCodingConvention17.getDelegateRelationship(node21);
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.hook(node11, node16, node21);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention24 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25, true);
//        com.google.javascript.rhino.jstype.JSType jSType28 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry27.createFunctionType(jSType28, false, jSTypeArray30);
//        boolean boolean32 = functionType31.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType36 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry35.createFunctionType(jSType36, false, jSTypeArray38);
//        java.lang.String str40 = functionType39.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType41 = functionType39.unboxesTo();
//        boolean boolean43 = functionType39.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType44 = null;
//        closureCodingConvention24.applySubclassRelationship(functionType31, functionType39, subclassType44);
//        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, true);
//        com.google.javascript.rhino.jstype.JSType jSType49 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry48.createFunctionType(jSType49, false, jSTypeArray51);
//        boolean boolean53 = functionType31.hasEqualCallType(functionType52);
//        com.google.javascript.rhino.jstype.EnumType enumType54 = jSTypeRegistry2.createEnumType("function (): {677104072}", node11, (com.google.javascript.rhino.jstype.JSType) functionType31);
//        java.lang.String str55 = node11.toStringTree();
//        try {
//            com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.defaultCase(node11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNull(delegateRelationship12);
//        org.junit.Assert.assertNull(delegateRelationship22);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(jSTypeArray30);
//        org.junit.Assert.assertNotNull(functionType31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray38);
//        org.junit.Assert.assertNotNull(functionType39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "function (): {932572092}" + "'", str40.equals("function (): {932572092}"));
//        org.junit.Assert.assertNull(jSType41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray51);
//        org.junit.Assert.assertNotNull(functionType52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(enumType54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "OR\n" + "'", str55.equals("OR\n"));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.DependencyOptions dependencyOptions0 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = dependencyOptions0.setDependencySorting(false);
        org.junit.Assert.assertNotNull(dependencyOptions2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard4 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = node0.cloneTree();
        java.lang.String str2 = com.google.javascript.jscomp.NodeUtil.getSourceName(node1);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(str2);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        int int11 = functionType6.getMaxArguments();
//        boolean boolean12 = functionType6.isInstanceType();
//        com.google.javascript.rhino.jstype.ObjectType.Property property14 = functionType6.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, true);
//        jSTypeRegistry17.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry22.createFunctionType(jSType23, false, jSTypeArray25);
//        boolean boolean27 = functionType26.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, true);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry30.createFunctionType(jSType31, false, jSTypeArray33);
//        java.lang.String str35 = functionType34.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType36 = functionType34.unboxesTo();
//        boolean boolean38 = functionType34.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType39 = null;
//        closureCodingConvention19.applySubclassRelationship(functionType26, functionType34, subclassType39);
//        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, true);
//        com.google.javascript.rhino.jstype.JSType jSType44 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry43.createFunctionType(jSType44, false, jSTypeArray46);
//        boolean boolean48 = functionType26.hasEqualCallType(functionType47);
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        java.lang.String str56 = functionType55.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType57 = functionType55.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = functionType55.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType59 = jSTypeRegistry17.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType47, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60, true);
//        com.google.javascript.rhino.jstype.JSType jSType63 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry62.createFunctionType(jSType63, false, jSTypeArray65);
//        java.lang.String str67 = functionType66.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType68 = functionType66.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable69 = functionType66.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ObjectType.Property property71 = functionType66.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.rhino.jstype.TernaryValue ternaryValue72 = parameterizedType59.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType66);
//        boolean boolean73 = parameterizedType59.isNoObjectType();
//        boolean boolean74 = functionType6.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) parameterizedType59);
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {595345387}" + "'", str7.equals("function (): {595345387}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(property14);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(functionType34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "function (): {1948168020}" + "'", str35.equals("function (): {1948168020}"));
//        org.junit.Assert.assertNull(jSType36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray46);
//        org.junit.Assert.assertNotNull(functionType47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "function (): {492583535}" + "'", str56.equals("function (): {492583535}"));
//        org.junit.Assert.assertNull(jSType57);
//        org.junit.Assert.assertNotNull(objectTypeIterable58);
//        org.junit.Assert.assertNotNull(parameterizedType59);
//        org.junit.Assert.assertNotNull(jSTypeArray65);
//        org.junit.Assert.assertNotNull(functionType66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "function (): {1396997211}" + "'", str67.equals("function (): {1396997211}"));
//        org.junit.Assert.assertNull(jSType68);
//        org.junit.Assert.assertNotNull(objectTypeIterable69);
//        org.junit.Assert.assertNull(property71);
//        org.junit.Assert.assertNotNull(ternaryValue72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray7 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError8 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray7);
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray16 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make(diagnosticType11, strArray16);
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray16);
        int int19 = jSError18.lineNumber;
        java.lang.String str20 = jSError18.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(jSError8);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "(). hi! at (unknown source) line (unknown line) : (unknown column)" + "'", str20.equals("(). hi! at (unknown source) line (unknown line) : (unknown column)"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        boolean boolean4 = jSDocInfo0.hasDescriptionForParameter("function (): {1466090035}");
        boolean boolean5 = jSDocInfo0.hasBaseType();
        java.lang.String str6 = jSDocInfo0.toString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JSDocInfo" + "'", str6.equals("JSDocInfo"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordInterface();
        boolean boolean4 = jSDocInfoBuilder1.hasParameter("function (): {377837821}");
        boolean boolean5 = jSDocInfoBuilder1.recordHiddenness();
        boolean boolean6 = jSDocInfoBuilder1.isJavaDispatch();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder8 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean9 = jSDocInfoBuilder8.recordInterface();
        boolean boolean11 = jSDocInfoBuilder8.recordLends("function (): {1720726686}");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention12 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship17 = googleCodingConvention12.getDelegateRelationship(node16);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention22 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship27 = googleCodingConvention22.getDelegateRelationship(node26);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.hook(node16, node21, node26);
        boolean boolean29 = node21.isBreak();
        node21.addSuppression("goog.exportSymbol");
        boolean boolean32 = node21.isIf();
        boolean boolean33 = node21.isOnlyModifiesThisCall();
        boolean boolean34 = node21.isInstanceOf();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression36 = new com.google.javascript.rhino.JSTypeExpression(node21, "function (): {1373043384}");
        com.google.javascript.rhino.Node node37 = jSTypeExpression36.getRoot();
        boolean boolean38 = jSDocInfoBuilder8.recordBaseType(jSTypeExpression36);
        boolean boolean39 = jSDocInfoBuilder1.recordTypedef(jSTypeExpression36);
        boolean boolean40 = jSTypeExpression36.isOptionalArg();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(delegateRelationship17);
        org.junit.Assert.assertNull(delegateRelationship27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node7 = node4.getLastSibling();
        java.lang.String str8 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node7);
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
//        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
//        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
//        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
//        java.lang.String str41 = googleCodingConvention0.getExportSymbolFunction();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, true);
//        com.google.javascript.rhino.jstype.JSType jSType45 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry44.createFunctionType(jSType45, false, jSTypeArray47);
//        java.lang.String str49 = functionType48.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType50 = functionType48.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = functionType48.getExtendedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
//        com.google.javascript.rhino.jstype.JSType jSType55 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry54.createFunctionType(jSType55, false, jSTypeArray57);
//        java.lang.String str59 = functionType58.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType60 = functionType58.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable61 = functionType58.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ObjectType.Property property63 = functionType58.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention64 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType68 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry67.createFunctionType(jSType68, false, jSTypeArray70);
//        boolean boolean72 = functionType71.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73, true);
//        com.google.javascript.rhino.jstype.JSType jSType76 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry75.createFunctionType(jSType76, false, jSTypeArray78);
//        java.lang.String str80 = functionType79.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType81 = functionType79.unboxesTo();
//        boolean boolean83 = functionType79.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType84 = null;
//        closureCodingConvention64.applySubclassRelationship(functionType71, functionType79, subclassType84);
//        boolean boolean86 = functionType58.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType71);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType87 = null;
//        googleCodingConvention0.applySubclassRelationship(functionType48, functionType71, subclassType87);
//        com.google.javascript.rhino.ErrorReporter errorReporter89 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry91 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter89, true);
//        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter92 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry91);
//        org.junit.Assert.assertNull(delegateRelationship5);
//        org.junit.Assert.assertNull(delegateRelationship11);
//        org.junit.Assert.assertNull(delegateRelationship21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(delegateRelationship28);
//        org.junit.Assert.assertNull(delegateRelationship38);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "goog.exportSymbol" + "'", str41.equals("goog.exportSymbol"));
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertNotNull(functionType48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "function (): {1925140703}" + "'", str49.equals("function (): {1925140703}"));
//        org.junit.Assert.assertNull(jSType50);
//        org.junit.Assert.assertNotNull(objectTypeIterable51);
//        org.junit.Assert.assertNotNull(jSTypeArray57);
//        org.junit.Assert.assertNotNull(functionType58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "function (): {1444422442}" + "'", str59.equals("function (): {1444422442}"));
//        org.junit.Assert.assertNull(jSType60);
//        org.junit.Assert.assertNotNull(objectTypeIterable61);
//        org.junit.Assert.assertNull(property63);
//        org.junit.Assert.assertNotNull(jSTypeArray70);
//        org.junit.Assert.assertNotNull(functionType71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray78);
//        org.junit.Assert.assertNotNull(functionType79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "function (): {1623976618}" + "'", str80.equals("function (): {1623976618}"));
//        org.junit.Assert.assertNull(jSType81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, true);
//        com.google.javascript.rhino.jstype.JSType jSType4 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry3.createFunctionType(jSType4, false, jSTypeArray6);
//        boolean boolean8 = functionType7.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
//        com.google.javascript.rhino.jstype.JSType jSType12 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry11.createFunctionType(jSType12, false, jSTypeArray14);
//        java.lang.String str16 = functionType15.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType17 = functionType15.unboxesTo();
//        boolean boolean19 = functionType15.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType7, functionType15, subclassType20);
//        boolean boolean22 = functionType15.isFunctionType();
//        boolean boolean23 = functionType15.canBeCalled();
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(functionType7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray14);
//        org.junit.Assert.assertNotNull(functionType15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "function (): {1130672252}" + "'", str16.equals("function (): {1130672252}"));
//        org.junit.Assert.assertNull(jSType17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("function (): {436583239}");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        boolean boolean4 = jSDocInfo0.hasDescriptionForParameter("function (): {1466090035}");
        boolean boolean5 = jSDocInfo0.isIdGenerator();
        java.lang.String str6 = jSDocInfo0.getOriginalCommentString();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup("function (): {1062485636}", diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup6;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES = diagnosticGroup6;
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "function (): {1795068108}");
        java.util.Collection<java.lang.String> strCollection5 = closureCodingConvention0.getIndirectlyDeclaredProperties();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(strCollection5);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        boolean boolean7 = functionType6.matchesInt32Context();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean10 = jSDocInfo9.isConstructor();
//        boolean boolean11 = jSDocInfo9.containsDeclaration();
//        java.lang.String str12 = jSDocInfo9.getBlockDescription();
//        functionType6.setPropertyJSDocInfo("function (): {353378097}", jSDocInfo9);
//        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, true);
//        com.google.javascript.rhino.jstype.JSType jSType17 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry16.createFunctionType(jSType17, false, jSTypeArray19);
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
//        com.google.javascript.rhino.jstype.JSType jSType24 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry23.createFunctionType(jSType24, false, jSTypeArray26);
//        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry16.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType27);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention29 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30, true);
//        com.google.javascript.rhino.jstype.JSType jSType33 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry32.createFunctionType(jSType33, false, jSTypeArray35);
//        boolean boolean37 = functionType36.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, true);
//        com.google.javascript.rhino.jstype.JSType jSType41 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry40.createFunctionType(jSType41, false, jSTypeArray43);
//        java.lang.String str45 = functionType44.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType46 = functionType44.unboxesTo();
//        boolean boolean48 = functionType44.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType49 = null;
//        closureCodingConvention29.applySubclassRelationship(functionType36, functionType44, subclassType49);
//        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51, true);
//        com.google.javascript.rhino.jstype.JSType jSType54 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry53.createFunctionType(jSType54, false, jSTypeArray56);
//        boolean boolean58 = functionType36.hasEqualCallType(functionType57);
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, true);
//        com.google.javascript.rhino.jstype.JSType jSType62 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry61.createFunctionType(jSType62, false, jSTypeArray64);
//        java.lang.String str66 = functionType65.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType67 = functionType65.unboxesTo();
//        boolean boolean69 = functionType65.isPropertyInExterns(": hi!");
//        int int70 = functionType65.getMaxArguments();
//        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry16.createFunctionTypeWithNewReturnType(functionType57, (com.google.javascript.rhino.jstype.JSType) functionType65);
//        com.google.javascript.rhino.ErrorReporter errorReporter72 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry74 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter72, true);
//        com.google.javascript.rhino.jstype.JSType jSType75 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry74.createFunctionType(jSType75, false, jSTypeArray77);
//        java.lang.String str79 = functionType78.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType80 = functionType78.unboxesTo();
//        boolean boolean82 = functionType78.isPropertyInExterns(": hi!");
//        int int83 = functionType78.getMaxArguments();
//        jSTypeRegistry16.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType78);
//        boolean boolean85 = functionType6.canTestForEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType78);
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(jSTypeArray19);
//        org.junit.Assert.assertNotNull(functionType20);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(functionType27);
//        org.junit.Assert.assertNotNull(jSType28);
//        org.junit.Assert.assertNotNull(jSTypeArray35);
//        org.junit.Assert.assertNotNull(functionType36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray43);
//        org.junit.Assert.assertNotNull(functionType44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "function (): {1751122080}" + "'", str45.equals("function (): {1751122080}"));
//        org.junit.Assert.assertNull(jSType46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray56);
//        org.junit.Assert.assertNotNull(functionType57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray64);
//        org.junit.Assert.assertNotNull(functionType65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "function (): {1193901100}" + "'", str66.equals("function (): {1193901100}"));
//        org.junit.Assert.assertNull(jSType67);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(functionType71);
//        org.junit.Assert.assertNotNull(jSTypeArray77);
//        org.junit.Assert.assertNotNull(functionType78);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "function (): {1905799812}" + "'", str79.equals("function (): {1905799812}"));
//        org.junit.Assert.assertNull(jSType80);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, true);
//        com.google.javascript.rhino.jstype.JSType jSType4 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry3.createFunctionType(jSType4, false, jSTypeArray6);
//        boolean boolean8 = functionType7.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9, true);
//        com.google.javascript.rhino.jstype.JSType jSType12 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry11.createFunctionType(jSType12, false, jSTypeArray14);
//        java.lang.String str16 = functionType15.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType17 = functionType15.unboxesTo();
//        boolean boolean19 = functionType15.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType20 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType7, functionType15, subclassType20);
//        com.google.javascript.rhino.jstype.UnionType unionType22 = functionType15.toMaybeUnionType();
//        com.google.javascript.rhino.jstype.ObjectType objectType23 = functionType15.getImplicitPrototype();
//        java.lang.Class<?> wildcardClass24 = objectType23.getClass();
//        boolean boolean25 = objectType23.isNumber();
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
//        jSTypeRegistry28.incrementGeneration();
//        jSTypeRegistry28.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder32 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry28);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        jSTypeRegistry35.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention37 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38, true);
//        com.google.javascript.rhino.jstype.JSType jSType41 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry40.createFunctionType(jSType41, false, jSTypeArray43);
//        boolean boolean45 = functionType44.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46, true);
//        com.google.javascript.rhino.jstype.JSType jSType49 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry48.createFunctionType(jSType49, false, jSTypeArray51);
//        java.lang.String str53 = functionType52.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType54 = functionType52.unboxesTo();
//        boolean boolean56 = functionType52.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType57 = null;
//        closureCodingConvention37.applySubclassRelationship(functionType44, functionType52, subclassType57);
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, true);
//        com.google.javascript.rhino.jstype.JSType jSType62 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray64 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType65 = jSTypeRegistry61.createFunctionType(jSType62, false, jSTypeArray64);
//        boolean boolean66 = functionType44.hasEqualCallType(functionType65);
//        com.google.javascript.rhino.ErrorReporter errorReporter67 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter67, true);
//        com.google.javascript.rhino.jstype.JSType jSType70 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray72 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry69.createFunctionType(jSType70, false, jSTypeArray72);
//        java.lang.String str74 = functionType73.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType75 = functionType73.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable76 = functionType73.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType77 = jSTypeRegistry35.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType65, (com.google.javascript.rhino.jstype.JSType) functionType73);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder78 = functionBuilder32.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionType65);
//        boolean boolean79 = functionType65.matchesObjectContext();
//        com.google.javascript.rhino.jstype.JSType jSType80 = objectType23.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType65);
//        org.junit.Assert.assertNotNull(jSTypeArray6);
//        org.junit.Assert.assertNotNull(functionType7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray14);
//        org.junit.Assert.assertNotNull(functionType15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "function (): {2017963023}" + "'", str16.equals("function (): {2017963023}"));
//        org.junit.Assert.assertNull(jSType17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(unionType22);
//        org.junit.Assert.assertNotNull(objectType23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray43);
//        org.junit.Assert.assertNotNull(functionType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray51);
//        org.junit.Assert.assertNotNull(functionType52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "function (): {2043241037}" + "'", str53.equals("function (): {2043241037}"));
//        org.junit.Assert.assertNull(jSType54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray64);
//        org.junit.Assert.assertNotNull(functionType65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray72);
//        org.junit.Assert.assertNotNull(functionType73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "function (): {2119056617}" + "'", str74.equals("function (): {2119056617}"));
//        org.junit.Assert.assertNull(jSType75);
//        org.junit.Assert.assertNotNull(objectTypeIterable76);
//        org.junit.Assert.assertNotNull(parameterizedType77);
//        org.junit.Assert.assertNotNull(functionBuilder78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(jSType80);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder3 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean4 = jSDocInfoBuilder3.recordInterface();
        boolean boolean6 = jSDocInfoBuilder3.hasParameter("function (): {377837821}");
        boolean boolean7 = jSDocInfoBuilder3.recordHiddenness();
        boolean boolean8 = jSDocInfoBuilder3.isJavaDispatch();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder10 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean11 = jSDocInfoBuilder10.recordInterface();
        boolean boolean13 = jSDocInfoBuilder10.recordLends("function (): {1720726686}");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = googleCodingConvention14.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention24 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = googleCodingConvention24.getDelegateRelationship(node28);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.IR.hook(node18, node23, node28);
        boolean boolean31 = node23.isBreak();
        node23.addSuppression("goog.exportSymbol");
        boolean boolean34 = node23.isIf();
        boolean boolean35 = node23.isOnlyModifiesThisCall();
        boolean boolean36 = node23.isInstanceOf();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression38 = new com.google.javascript.rhino.JSTypeExpression(node23, "function (): {1373043384}");
        com.google.javascript.rhino.Node node39 = jSTypeExpression38.getRoot();
        boolean boolean40 = jSDocInfoBuilder10.recordBaseType(jSTypeExpression38);
        boolean boolean41 = jSDocInfoBuilder3.recordTypedef(jSTypeExpression38);
        boolean boolean42 = jSDocInfoBuilder1.recordReturnType(jSTypeExpression38);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("function (): {149787914}", ": hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray13 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray22 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray22);
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("function (): {1609272738}", 16, 98, diagnosticType5, strArray22);
        java.lang.Object obj26 = null;
        boolean boolean27 = jSError25.equals(obj26);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        boolean boolean5 = compilerInput3.isExtern();
        try {
            com.google.javascript.jscomp.Region region7 = compilerInput3.getRegion(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getOriginalCommentString();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility3 = com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE;
        jSDocInfo0.setVisibility(visibility3);
        boolean boolean5 = jSDocInfo0.isExport();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + visibility3 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE + "'", visibility3.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable4 = jSTypeRegistry2.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        java.lang.String str12 = functionType11.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType13 = functionType11.unboxesTo();
//        boolean boolean15 = functionType11.isPropertyInExterns(": hi!");
//        int int16 = functionType11.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType20 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry19.createFunctionType(jSType20, false, jSTypeArray22);
//        java.lang.String str24 = functionType23.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType25 = functionType23.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] { functionType11, functionType23 };
//        com.google.javascript.rhino.Node node27 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray26);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder29 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
//        boolean boolean30 = functionParamBuilder29.hasVarArgs();
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = jSTypeRegistry33.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
//        com.google.javascript.rhino.jstype.JSType jSType39 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry38.createFunctionType(jSType39, false, jSTypeArray41);
//        java.lang.String str43 = functionType42.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType44 = functionType42.unboxesTo();
//        boolean boolean46 = functionType42.isPropertyInExterns(": hi!");
//        int int47 = functionType42.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry50.createFunctionType(jSType51, false, jSTypeArray53);
//        java.lang.String str55 = functionType54.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType56 = functionType54.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] { functionType42, functionType54 };
//        com.google.javascript.rhino.Node node58 = jSTypeRegistry33.createParametersWithVarArgs(jSTypeArray57);
//        com.google.javascript.rhino.ErrorReporter errorReporter59 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter59, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable63 = jSTypeRegistry61.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, true);
//        com.google.javascript.rhino.jstype.JSType jSType67 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry66.createFunctionType(jSType67, false, jSTypeArray69);
//        java.lang.String str71 = functionType70.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType72 = functionType70.unboxesTo();
//        boolean boolean74 = functionType70.isPropertyInExterns(": hi!");
//        int int75 = functionType70.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter76, true);
//        com.google.javascript.rhino.jstype.JSType jSType79 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry78.createFunctionType(jSType79, false, jSTypeArray81);
//        java.lang.String str83 = functionType82.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType84 = functionType82.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] { functionType70, functionType82 };
//        com.google.javascript.rhino.Node node86 = jSTypeRegistry61.createParametersWithVarArgs(jSTypeArray85);
//        com.google.javascript.rhino.Node node87 = jSTypeRegistry33.createParameters(jSTypeArray85);
//        boolean boolean88 = functionParamBuilder29.addRequiredParams(jSTypeArray85);
//        boolean boolean89 = functionParamBuilder29.hasVarArgs();
//        org.junit.Assert.assertNotNull(objectTypeIterable4);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "function (): {2076609801}" + "'", str12.equals("function (): {2076609801}"));
//        org.junit.Assert.assertNull(jSType13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray22);
//        org.junit.Assert.assertNotNull(functionType23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "function (): {1208135041}" + "'", str24.equals("function (): {1208135041}"));
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable35);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "function (): {1215213029}" + "'", str43.equals("function (): {1215213029}"));
//        org.junit.Assert.assertNull(jSType44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(functionType54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "function (): {522356263}" + "'", str55.equals("function (): {522356263}"));
//        org.junit.Assert.assertNull(jSType56);
//        org.junit.Assert.assertNotNull(jSTypeArray57);
//        org.junit.Assert.assertNotNull(node58);
//        org.junit.Assert.assertNotNull(objectTypeIterable63);
//        org.junit.Assert.assertNotNull(jSTypeArray69);
//        org.junit.Assert.assertNotNull(functionType70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "function (): {860612689}" + "'", str71.equals("function (): {860612689}"));
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray81);
//        org.junit.Assert.assertNotNull(functionType82);
//        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "function (): {2112218948}" + "'", str83.equals("function (): {2112218948}"));
//        org.junit.Assert.assertNull(jSType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertNotNull(node86);
//        org.junit.Assert.assertNotNull(node87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        jSTypeRegistry2.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
//        jSTypeRegistry9.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention11 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, true);
//        com.google.javascript.rhino.jstype.JSType jSType15 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry14.createFunctionType(jSType15, false, jSTypeArray17);
//        boolean boolean19 = functionType18.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry22.createFunctionType(jSType23, false, jSTypeArray25);
//        java.lang.String str27 = functionType26.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType28 = functionType26.unboxesTo();
//        boolean boolean30 = functionType26.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType31 = null;
//        closureCodingConvention11.applySubclassRelationship(functionType18, functionType26, subclassType31);
//        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33, true);
//        com.google.javascript.rhino.jstype.JSType jSType36 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry35.createFunctionType(jSType36, false, jSTypeArray38);
//        boolean boolean40 = functionType18.hasEqualCallType(functionType39);
//        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41, true);
//        com.google.javascript.rhino.jstype.JSType jSType44 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType47 = jSTypeRegistry43.createFunctionType(jSType44, false, jSTypeArray46);
//        java.lang.String str48 = functionType47.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType49 = functionType47.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable50 = functionType47.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType51 = jSTypeRegistry9.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType39, (com.google.javascript.rhino.jstype.JSType) functionType47);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder52 = functionBuilder6.withInferredReturnType((com.google.javascript.rhino.jstype.JSType) functionType39);
//        boolean boolean53 = functionType39.matchesObjectContext();
//        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54, true);
//        com.google.javascript.rhino.jstype.JSType jSType57 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry56.createFunctionType(jSType57, false, jSTypeArray59);
//        java.lang.String str61 = functionType60.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType62 = functionType60.unboxesTo();
//        boolean boolean64 = functionType60.isPropertyInExterns(": hi!");
//        int int65 = functionType60.getMaxArguments();
//        com.google.javascript.rhino.jstype.EnumElementType enumElementType66 = functionType60.toMaybeEnumElementType();
//        functionType39.matchConstraint((com.google.javascript.rhino.jstype.ObjectType) functionType60);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable68 = functionType39.getCtorExtendedInterfaces();
//        org.junit.Assert.assertNotNull(jSTypeArray17);
//        org.junit.Assert.assertNotNull(functionType18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "function (): {2076234349}" + "'", str27.equals("function (): {2076234349}"));
//        org.junit.Assert.assertNull(jSType28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray38);
//        org.junit.Assert.assertNotNull(functionType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray46);
//        org.junit.Assert.assertNotNull(functionType47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "function (): {1413160649}" + "'", str48.equals("function (): {1413160649}"));
//        org.junit.Assert.assertNull(jSType49);
//        org.junit.Assert.assertNotNull(objectTypeIterable50);
//        org.junit.Assert.assertNotNull(parameterizedType51);
//        org.junit.Assert.assertNotNull(functionBuilder52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray59);
//        org.junit.Assert.assertNotNull(functionType60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "function (): {1765806990}" + "'", str61.equals("function (): {1765806990}"));
//        org.junit.Assert.assertNull(jSType62);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNull(enumElementType66);
//        org.junit.Assert.assertNotNull(objectTypeIterable68);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("function (): {677047761}");
        boolean boolean2 = node1.isBreak();
        boolean boolean3 = node1.wasEmptyNode();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        boolean boolean7 = googleCodingConvention0.isConstantKey("hi!");
        boolean boolean10 = googleCodingConvention0.isExported(": hi!", true);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention11 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = googleCodingConvention11.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder17 = node15.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node18 = node15.getLastSibling();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node20 = node19.cloneTree();
        boolean boolean21 = node19.isLabel();
        boolean boolean22 = node18.isEquivalentToTyped(node19);
        boolean boolean23 = node19.isDelProp();
        try {
            com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast24 = googleCodingConvention0.getObjectLiteralCast(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isPrivate(": hi!");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node7.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node10 = node7.getLastSibling();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node12 = node11.cloneTree();
        boolean boolean13 = node11.isLabel();
        boolean boolean14 = node10.isEquivalentToTyped(node11);
        boolean boolean15 = closureCodingConvention0.isOptionalParameter(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) closureCodingConvention0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(delegateRelationship8);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        boolean boolean5 = compilerInput4.isExtern();
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        int int1 = typePosition0.getPositionOnEndLine();
        int int2 = typePosition0.getEndLine();
        typePosition0.setPositionInformation((int) (byte) 1, 10, 37, (int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.jscomp.AstValidator astValidator0 = new com.google.javascript.jscomp.AstValidator();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship6 = googleCodingConvention1.getDelegateRelationship(node5);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention11 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship16 = googleCodingConvention11.getDelegateRelationship(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.hook(node5, node10, node15);
        boolean boolean18 = node10.isBreak();
        node10.addSuppression("goog.exportSymbol");
        boolean boolean21 = node10.isIf();
        try {
            astValidator0.validateStatement(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected statement but was OR. Reference node OR [jsdoc_info: JSDocInfo]");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(delegateRelationship6);
        org.junit.Assert.assertNull(delegateRelationship16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback5);
        java.lang.String str7 = nodeTraversal6.getSourceName();
        java.lang.String str8 = nodeTraversal6.getSourceName();
        com.google.javascript.rhino.Node node9 = null;
        try {
            nodeTraversal6.traverse(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.paramList();
        boolean boolean1 = node0.isOptionalArg();
        boolean boolean2 = node0.isEmpty();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
        com.google.javascript.rhino.Node node20 = node0.srcref(node17);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention21 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship26 = googleCodingConvention21.getDelegateRelationship(node25);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node25.getJsDocBuilderForNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention28 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship33 = googleCodingConvention28.getDelegateRelationship(node32);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention34 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship39 = googleCodingConvention34.getDelegateRelationship(node38);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention44 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship49 = googleCodingConvention44.getDelegateRelationship(node48);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.hook(node38, node43, node48);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention51 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship56 = googleCodingConvention51.getDelegateRelationship(node55);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention61 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = googleCodingConvention61.getDelegateRelationship(node65);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.hook(node55, node60, node65);
        java.lang.String str68 = googleCodingConvention28.extractClassNameIfRequire(node48, node67);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.IR.eq(node25, node67);
        com.google.javascript.rhino.Node node71 = node67.getChildAtIndex((int) (short) 0);
        node71.setSourceEncodedPosition((int) 'a');
        boolean boolean74 = node71.isSwitch();
        com.google.javascript.rhino.Node node75 = node20.useSourceInfoFromForTree(node71);
        boolean boolean76 = node75.isHook();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(delegateRelationship8);
        org.junit.Assert.assertNull(delegateRelationship18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNull(delegateRelationship26);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder27);
        org.junit.Assert.assertNull(delegateRelationship33);
        org.junit.Assert.assertNull(delegateRelationship39);
        org.junit.Assert.assertNull(delegateRelationship49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNull(delegateRelationship56);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        int int11 = functionType6.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        java.lang.String str20 = functionType19.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType21 = functionType19.unboxesTo();
//        boolean boolean23 = functionType19.isPropertyInExterns(": hi!");
//        int int24 = functionType19.getMaxArguments();
//        com.google.javascript.rhino.jstype.JSType jSType25 = functionType6.resolve(errorReporter12, (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType19);
//        boolean boolean26 = functionType19.matchesNumberContext();
//        boolean boolean28 = functionType19.removeProperty("function (): {1399996466}");
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {142407702}" + "'", str7.equals("function (): {142407702}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (): {819257729}" + "'", str20.equals("function (): {819257729}"));
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(jSType25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_RESOLVED_TYPE));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("function (): {1833890682}", "goog.exportSymbol");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.script(nodeArray0);
        boolean boolean2 = node1.isCatch();
        boolean boolean3 = node1.isThrow();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.objectlit(nodeArray0);
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("function (): {677047761}");
        boolean boolean2 = node1.isInstanceOf();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
        com.google.javascript.jscomp.SourceFile.Builder builder41 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile44 = builder41.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        node39.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile44);
        com.google.javascript.jscomp.JsAst jsAst46 = new com.google.javascript.jscomp.JsAst(sourceFile44);
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst46, "function (): {735754071}", true);
        com.google.javascript.jscomp.SourceAst sourceAst50 = compilerInput49.getSourceAst();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(delegateRelationship28);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(builder41);
        org.junit.Assert.assertNotNull(sourceFile44);
        org.junit.Assert.assertNotNull(sourceAst50);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromGenerator("()", generator2);
        java.nio.charset.Charset charset4 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder5 = builder0.withCharset(charset4);
        com.google.javascript.jscomp.SourceFile.Generator generator7 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile8 = builder5.buildFromGenerator("", generator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(builder5);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        jSModule1.setDepth(47);
        com.google.javascript.jscomp.SourceFile sourceFile5 = new com.google.javascript.jscomp.SourceFile(": hi!");
        sourceFile5.setOriginalPath("hi!");
        jSModule1.addFirst(sourceFile5);
        java.lang.String str9 = sourceFile5.getName();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + ": hi!" + "'", str9.equals(": hi!"));
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        boolean boolean12 = functionType11.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        java.lang.String str20 = functionType19.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType21 = functionType19.unboxesTo();
//        boolean boolean23 = functionType19.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
//        closureCodingConvention4.applySubclassRelationship(functionType11, functionType19, subclassType24);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
//        com.google.javascript.rhino.jstype.JSType jSType29 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry28.createFunctionType(jSType29, false, jSTypeArray31);
//        boolean boolean33 = functionType11.hasEqualCallType(functionType32);
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry36.createFunctionType(jSType37, false, jSTypeArray39);
//        java.lang.String str41 = functionType40.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType42 = functionType40.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = functionType40.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType44 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType32, (com.google.javascript.rhino.jstype.JSType) functionType40);
//        boolean boolean45 = parameterizedType44.isNominalConstructor();
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (): {832609748}" + "'", str20.equals("function (): {832609748}"));
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray31);
//        org.junit.Assert.assertNotNull(functionType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertNotNull(functionType40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "function (): {2086815274}" + "'", str41.equals("function (): {2086815274}"));
//        org.junit.Assert.assertNull(jSType42);
//        org.junit.Assert.assertNotNull(objectTypeIterable43);
//        org.junit.Assert.assertNotNull(parameterizedType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        com.google.javascript.rhino.jstype.ObjectType.Property property12 = functionType6.getOwnSlot("module$");
//        com.google.common.collect.ImmutableList<java.lang.String> strList13 = functionType6.getTemplateTypeNames();
//        boolean boolean14 = functionType6.isNumberValueType();
//        boolean boolean15 = functionType6.isNumberObjectType();
//        boolean boolean16 = functionType6.isVoidType();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean19 = jSDocInfo18.isConstructor();
//        java.lang.String str20 = jSDocInfo18.getOriginalCommentString();
//        boolean boolean21 = jSDocInfo18.isNoShadow();
//        functionType6.setPropertyJSDocInfo("function (): {117062102}", jSDocInfo18);
//        boolean boolean23 = functionType6.hasImplementedInterfaces();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {579834950}" + "'", str7.equals("function (): {579834950}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(property12);
//        org.junit.Assert.assertNotNull(strList13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
        com.google.javascript.jscomp.SourceFile.Builder builder41 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile44 = builder41.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        node39.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile44);
        com.google.javascript.jscomp.JsAst jsAst46 = new com.google.javascript.jscomp.JsAst(sourceFile44);
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst46, "function (): {735754071}", true);
        com.google.javascript.rhino.InputId inputId50 = jsAst46.getInputId();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(delegateRelationship28);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(builder41);
        org.junit.Assert.assertNotNull(sourceFile44);
        org.junit.Assert.assertNotNull(inputId50);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        com.google.javascript.rhino.jstype.ObjectType.Property property12 = functionType6.getOwnSlot("module$");
//        com.google.common.collect.ImmutableList<java.lang.String> strList13 = functionType6.getTemplateTypeNames();
//        boolean boolean14 = functionType6.isNumberValueType();
//        boolean boolean15 = functionType6.isNumberObjectType();
//        boolean boolean16 = functionType6.isVoidType();
//        try {
//            com.google.javascript.rhino.jstype.ObjectType objectType18 = functionType6.getTopMostDefiningType("function (): {733123017}");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {310382713}" + "'", str7.equals("function (): {310382713}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(property12);
//        org.junit.Assert.assertNotNull(strList13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.AstValidator astValidator0 = new com.google.javascript.jscomp.AstValidator();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList();
        boolean boolean2 = node1.isOptionalArg();
        boolean boolean3 = node1.isEmpty();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = googleCodingConvention4.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = googleCodingConvention14.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node8, node13, node18);
        com.google.javascript.rhino.Node node21 = node1.srcref(node18);
        try {
            astValidator0.validateRoot(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BLOCK but was OR Reference node OR");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        boolean boolean12 = functionType6.hasOwnProperty("function (): {1434977422}");
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry22.createFunctionType(jSType23, false, jSTypeArray25);
//        com.google.javascript.rhino.jstype.JSType jSType27 = jSTypeRegistry15.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType26);
//        boolean boolean28 = functionType26.isNominalConstructor();
//        boolean boolean29 = functionType6.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType26);
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {308933048}" + "'", str7.equals("function (): {308933048}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertNotNull(jSType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        double double8 = compiler6.getProgress();
        compiler6.disableThreads();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt10 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter11 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler6, sourceExcerpt10);
        try {
            boolean boolean12 = compiler6.isIdeMode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention10 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship15 = googleCodingConvention10.getDelegateRelationship(node14);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.hook(node4, node9, node14);
        boolean boolean17 = node9.isBreak();
        node9.addSuppression("goog.exportSymbol");
        node9.setWasEmptyNode(false);
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.rhino.InputId inputId1 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, inputId1, true);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler6);
        double double8 = compiler6.getProgress();
        compiler6.disableThreads();
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = null;
        try {
            compiler6.initOptions(compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceAst4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        jSTypeRegistry2.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder6.withName("function (): {1172842042}");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder10 = functionBuilder8.withName("");
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
//        com.google.javascript.rhino.jstype.JSType jSType14 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry13.createFunctionType(jSType14, false, jSTypeArray16);
//        java.lang.String str18 = functionType17.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType19 = functionType17.unboxesTo();
//        boolean boolean21 = functionType17.isPropertyInExterns(": hi!");
//        int int22 = functionType17.getMaxArguments();
//        boolean boolean23 = functionType17.isInstanceType();
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder24 = functionBuilder8.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionType17);
//        com.google.javascript.rhino.jstype.FunctionType functionType25 = functionBuilder24.build();
//        boolean boolean26 = functionType25.hasCachedValues();
//        org.junit.Assert.assertNotNull(functionBuilder8);
//        org.junit.Assert.assertNotNull(functionBuilder10);
//        org.junit.Assert.assertNotNull(jSTypeArray16);
//        org.junit.Assert.assertNotNull(functionType17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "function (): {1512879212}" + "'", str18.equals("function (): {1512879212}"));
//        org.junit.Assert.assertNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(functionBuilder24);
//        org.junit.Assert.assertNotNull(functionType25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.DependencyOptions dependencyOptions0 = new com.google.javascript.jscomp.DependencyOptions();
        com.google.javascript.jscomp.DependencyOptions dependencyOptions2 = dependencyOptions0.setMoocherDropping(false);
        org.junit.Assert.assertNotNull(dependencyOptions2);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
//        jSTypeRegistry13.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
//        com.google.javascript.rhino.jstype.JSType jSType19 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry18.createFunctionType(jSType19, false, jSTypeArray21);
//        boolean boolean23 = functionType22.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        com.google.javascript.rhino.jstype.JSType jSType27 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry26.createFunctionType(jSType27, false, jSTypeArray29);
//        java.lang.String str31 = functionType30.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType32 = functionType30.unboxesTo();
//        boolean boolean34 = functionType30.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
//        closureCodingConvention15.applySubclassRelationship(functionType22, functionType30, subclassType35);
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, true);
//        com.google.javascript.rhino.jstype.JSType jSType40 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry39.createFunctionType(jSType40, false, jSTypeArray42);
//        boolean boolean44 = functionType22.hasEqualCallType(functionType43);
//        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
//        com.google.javascript.rhino.jstype.JSType jSType48 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry47.createFunctionType(jSType48, false, jSTypeArray50);
//        java.lang.String str52 = functionType51.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType53 = functionType51.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType51.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType55 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType43, (com.google.javascript.rhino.jstype.JSType) functionType51);
//        boolean boolean56 = parameterizedType55.isInterface();
//        boolean boolean57 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) parameterizedType55);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = parameterizedType55.getCtorExtendedInterfaces();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo60 = new com.google.javascript.rhino.JSDocInfo();
//        parameterizedType55.setPropertyJSDocInfo("goog.abstractMethod", jSDocInfo60);
//        com.google.javascript.rhino.jstype.JSType jSType63 = parameterizedType55.findPropertyType("function (): {579834950}");
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {2131468737}" + "'", str7.equals("function (): {2131468737}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(functionType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray29);
//        org.junit.Assert.assertNotNull(functionType30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): {1589081311}" + "'", str31.equals("function (): {1589081311}"));
//        org.junit.Assert.assertNull(jSType32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray42);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray50);
//        org.junit.Assert.assertNotNull(functionType51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "function (): {250918305}" + "'", str52.equals("function (): {250918305}"));
//        org.junit.Assert.assertNull(jSType53);
//        org.junit.Assert.assertNotNull(objectTypeIterable54);
//        org.junit.Assert.assertNotNull(parameterizedType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(objectTypeIterable58);
//        org.junit.Assert.assertNull(jSType63);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("function (): {149787914}", ": hi!");
        boolean boolean4 = diagnosticType2.equals((java.lang.Object) "function (): {1314806271}");
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        boolean boolean11 = functionType6.isFunctionPrototypeType();
//        boolean boolean12 = functionType6.isOrdinaryFunction();
//        boolean boolean13 = functionType6.isFunctionPrototypeType();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {1258752938}" + "'", str7.equals("function (): {1258752938}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList2 = jSModule1.getInputs();
        com.google.javascript.jscomp.SourceFile.Builder builder3 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile6 = builder3.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceFile6);
        compilerInput7.clearAst();
        jSModule1.add(compilerInput7);
        org.junit.Assert.assertNotNull(compilerInputList2);
        org.junit.Assert.assertNotNull(builder3);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable4 = jSTypeRegistry2.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        java.lang.String str12 = functionType11.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType13 = functionType11.unboxesTo();
//        boolean boolean15 = functionType11.isPropertyInExterns(": hi!");
//        int int16 = functionType11.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType20 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry19.createFunctionType(jSType20, false, jSTypeArray22);
//        java.lang.String str24 = functionType23.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType25 = functionType23.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] { functionType11, functionType23 };
//        com.google.javascript.rhino.Node node27 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray26);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder29 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
//        boolean boolean30 = functionParamBuilder29.hasVarArgs();
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable35 = jSTypeRegistry33.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36, true);
//        com.google.javascript.rhino.jstype.JSType jSType39 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry38.createFunctionType(jSType39, false, jSTypeArray41);
//        java.lang.String str43 = functionType42.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType44 = functionType42.unboxesTo();
//        boolean boolean46 = functionType42.isPropertyInExterns(": hi!");
//        int int47 = functionType42.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter48 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter48, true);
//        com.google.javascript.rhino.jstype.JSType jSType51 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry50.createFunctionType(jSType51, false, jSTypeArray53);
//        java.lang.String str55 = functionType54.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType56 = functionType54.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] { functionType42, functionType54 };
//        com.google.javascript.rhino.Node node58 = jSTypeRegistry33.createParametersWithVarArgs(jSTypeArray57);
//        jSTypeRegistry33.incrementGeneration();
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder60 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry33);
//        com.google.javascript.rhino.ErrorReporter errorReporter61 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter61, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable65 = jSTypeRegistry63.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66, true);
//        com.google.javascript.rhino.jstype.JSType jSType69 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry68.createFunctionType(jSType69, false, jSTypeArray71);
//        java.lang.String str73 = functionType72.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType74 = functionType72.unboxesTo();
//        boolean boolean76 = functionType72.isPropertyInExterns(": hi!");
//        int int77 = functionType72.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry80 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78, true);
//        com.google.javascript.rhino.jstype.JSType jSType81 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray83 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType84 = jSTypeRegistry80.createFunctionType(jSType81, false, jSTypeArray83);
//        java.lang.String str85 = functionType84.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType86 = functionType84.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray87 = new com.google.javascript.rhino.jstype.JSType[] { functionType72, functionType84 };
//        com.google.javascript.rhino.Node node88 = jSTypeRegistry63.createParametersWithVarArgs(jSTypeArray87);
//        com.google.javascript.rhino.ErrorReporter errorReporter89 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry91 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter89, true);
//        com.google.javascript.rhino.jstype.JSType jSType92 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray94 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType95 = jSTypeRegistry91.createFunctionType(jSType92, false, jSTypeArray94);
//        com.google.javascript.rhino.Node node96 = jSTypeRegistry63.createOptionalParameters(jSTypeArray94);
//        boolean boolean97 = functionParamBuilder60.addOptionalParams(jSTypeArray94);
//        boolean boolean98 = functionParamBuilder29.addRequiredParams(jSTypeArray94);
//        org.junit.Assert.assertNotNull(objectTypeIterable4);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "function (): {1466467132}" + "'", str12.equals("function (): {1466467132}"));
//        org.junit.Assert.assertNull(jSType13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray22);
//        org.junit.Assert.assertNotNull(functionType23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "function (): {1943017495}" + "'", str24.equals("function (): {1943017495}"));
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable35);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "function (): {466403068}" + "'", str43.equals("function (): {466403068}"));
//        org.junit.Assert.assertNull(jSType44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray53);
//        org.junit.Assert.assertNotNull(functionType54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "function (): {1779166914}" + "'", str55.equals("function (): {1779166914}"));
//        org.junit.Assert.assertNull(jSType56);
//        org.junit.Assert.assertNotNull(jSTypeArray57);
//        org.junit.Assert.assertNotNull(node58);
//        org.junit.Assert.assertNotNull(objectTypeIterable65);
//        org.junit.Assert.assertNotNull(jSTypeArray71);
//        org.junit.Assert.assertNotNull(functionType72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "function (): {192553894}" + "'", str73.equals("function (): {192553894}"));
//        org.junit.Assert.assertNull(jSType74);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray83);
//        org.junit.Assert.assertNotNull(functionType84);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "function (): {371501237}" + "'", str85.equals("function (): {371501237}"));
//        org.junit.Assert.assertNull(jSType86);
//        org.junit.Assert.assertNotNull(jSTypeArray87);
//        org.junit.Assert.assertNotNull(node88);
//        org.junit.Assert.assertNotNull(jSTypeArray94);
//        org.junit.Assert.assertNotNull(functionType95);
//        org.junit.Assert.assertNotNull(node96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordInterface();
        boolean boolean4 = jSDocInfoBuilder1.recordLends("function (): {1720726686}");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship10 = googleCodingConvention5.getDelegateRelationship(node9);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention15 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship20 = googleCodingConvention15.getDelegateRelationship(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.hook(node9, node14, node19);
        boolean boolean22 = node14.isBreak();
        node14.addSuppression("goog.exportSymbol");
        boolean boolean25 = node14.isIf();
        boolean boolean26 = node14.isOnlyModifiesThisCall();
        boolean boolean27 = node14.isInstanceOf();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression29 = new com.google.javascript.rhino.JSTypeExpression(node14, "function (): {1373043384}");
        com.google.javascript.rhino.Node node30 = jSTypeExpression29.getRoot();
        boolean boolean31 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression29);
        jSDocInfoBuilder1.markText("function (): {1096699469}", 42, 0, 0, (int) (short) -1);
        boolean boolean38 = jSDocInfoBuilder1.isJavaDispatch();
        boolean boolean39 = jSDocInfoBuilder1.isPopulated();
        boolean boolean40 = jSDocInfoBuilder1.recordNoTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(delegateRelationship10);
        org.junit.Assert.assertNull(delegateRelationship20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable9 = functionType6.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ObjectType.Property property11 = functionType6.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention12 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        boolean boolean20 = functionType19.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
//        com.google.javascript.rhino.jstype.JSType jSType24 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry23.createFunctionType(jSType24, false, jSTypeArray26);
//        java.lang.String str28 = functionType27.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType29 = functionType27.unboxesTo();
//        boolean boolean31 = functionType27.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType32 = null;
//        closureCodingConvention12.applySubclassRelationship(functionType19, functionType27, subclassType32);
//        boolean boolean34 = functionType6.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType19);
//        boolean boolean35 = functionType19.hasReferenceName();
//        java.lang.Iterable iterable36 = functionType19.getCtorImplementedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, true);
//        jSTypeRegistry39.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention41 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, true);
//        com.google.javascript.rhino.jstype.JSType jSType45 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry44.createFunctionType(jSType45, false, jSTypeArray47);
//        boolean boolean49 = functionType48.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, true);
//        com.google.javascript.rhino.jstype.JSType jSType53 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry52.createFunctionType(jSType53, false, jSTypeArray55);
//        java.lang.String str57 = functionType56.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType58 = functionType56.unboxesTo();
//        boolean boolean60 = functionType56.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType61 = null;
//        closureCodingConvention41.applySubclassRelationship(functionType48, functionType56, subclassType61);
//        com.google.javascript.rhino.ErrorReporter errorReporter63 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry65 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter63, true);
//        com.google.javascript.rhino.jstype.JSType jSType66 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray68 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType69 = jSTypeRegistry65.createFunctionType(jSType66, false, jSTypeArray68);
//        boolean boolean70 = functionType48.hasEqualCallType(functionType69);
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71, true);
//        com.google.javascript.rhino.jstype.JSType jSType74 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry73.createFunctionType(jSType74, false, jSTypeArray76);
//        java.lang.String str78 = functionType77.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType79 = functionType77.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType77.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType81 = jSTypeRegistry39.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType69, (com.google.javascript.rhino.jstype.JSType) functionType77);
//        int int82 = functionType69.getPropertiesCount();
//        com.google.javascript.rhino.jstype.FunctionType functionType83 = functionType69.getOwnerFunction();
//        try {
//            boolean boolean84 = functionType19.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType83);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {937010911}" + "'", str7.equals("function (): {937010911}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertNotNull(objectTypeIterable9);
//        org.junit.Assert.assertNull(property11);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(functionType27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (): {1462434519}" + "'", str28.equals("function (): {1462434519}"));
//        org.junit.Assert.assertNull(jSType29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(iterable36);
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertNotNull(functionType48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray55);
//        org.junit.Assert.assertNotNull(functionType56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "function (): {587606852}" + "'", str57.equals("function (): {587606852}"));
//        org.junit.Assert.assertNull(jSType58);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray68);
//        org.junit.Assert.assertNotNull(functionType69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray76);
//        org.junit.Assert.assertNotNull(functionType77);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "function (): {1180369891}" + "'", str78.equals("function (): {1180369891}"));
//        org.junit.Assert.assertNull(jSType79);
//        org.junit.Assert.assertNotNull(objectTypeIterable80);
//        org.junit.Assert.assertNotNull(parameterizedType81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNull(functionType83);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager2.getErrors();
        loggerErrorManager2.setTypedPercent((double) 52);
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager2.getErrors();
        org.junit.Assert.assertNotNull(jSErrorArray3);
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        jSTypeRegistry2.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder6 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder8 = functionBuilder6.withName("function (): {1172842042}");
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder10 = functionBuilder8.withName("");
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
//        com.google.javascript.rhino.jstype.JSType jSType14 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry13.createFunctionType(jSType14, false, jSTypeArray16);
//        java.lang.String str18 = functionType17.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType19 = functionType17.unboxesTo();
//        boolean boolean21 = functionType17.isPropertyInExterns(": hi!");
//        int int22 = functionType17.getMaxArguments();
//        boolean boolean23 = functionType17.isInstanceType();
//        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder24 = functionBuilder8.withTypeOfThis((com.google.javascript.rhino.jstype.ObjectType) functionType17);
//        com.google.javascript.rhino.jstype.FunctionType functionType25 = functionBuilder24.build();
//        java.lang.Iterable iterable26 = functionType25.getCtorExtendedInterfaces();
//        org.junit.Assert.assertNotNull(functionBuilder8);
//        org.junit.Assert.assertNotNull(functionBuilder10);
//        org.junit.Assert.assertNotNull(jSTypeArray16);
//        org.junit.Assert.assertNotNull(functionType17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "function (): {537451231}" + "'", str18.equals("function (): {537451231}"));
//        org.junit.Assert.assertNull(jSType19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(functionBuilder24);
//        org.junit.Assert.assertNotNull(functionType25);
//        org.junit.Assert.assertNotNull(iterable26);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.NodeUtil.getFunctionParameters(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("OR\n");
        boolean boolean4 = closureCodingConvention0.isConstant("function (): {250647373}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable4 = jSTypeRegistry2.getEachReferenceTypeWithProperty("function (): {221042019}");
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        java.lang.String str12 = functionType11.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType13 = functionType11.unboxesTo();
//        boolean boolean15 = functionType11.isPropertyInExterns(": hi!");
//        int int16 = functionType11.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, true);
//        com.google.javascript.rhino.jstype.JSType jSType20 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry19.createFunctionType(jSType20, false, jSTypeArray22);
//        java.lang.String str24 = functionType23.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType25 = functionType23.unboxesTo();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] { functionType11, functionType23 };
//        com.google.javascript.rhino.Node node27 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray26);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder29 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
//        boolean boolean30 = functionParamBuilder29.hasVarArgs();
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
//        jSTypeRegistry33.incrementGeneration();
//        jSTypeRegistry33.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention38 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = googleCodingConvention38.getDelegateRelationship(node42);
//        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention48 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship53 = googleCodingConvention48.getDelegateRelationship(node52);
//        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.hook(node42, node47, node52);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention55 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter56 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry58 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter56, true);
//        com.google.javascript.rhino.jstype.JSType jSType59 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray61 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType62 = jSTypeRegistry58.createFunctionType(jSType59, false, jSTypeArray61);
//        boolean boolean63 = functionType62.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter64 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter64, true);
//        com.google.javascript.rhino.jstype.JSType jSType67 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray69 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType70 = jSTypeRegistry66.createFunctionType(jSType67, false, jSTypeArray69);
//        java.lang.String str71 = functionType70.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType72 = functionType70.unboxesTo();
//        boolean boolean74 = functionType70.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType75 = null;
//        closureCodingConvention55.applySubclassRelationship(functionType62, functionType70, subclassType75);
//        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, true);
//        com.google.javascript.rhino.jstype.JSType jSType80 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray82 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType83 = jSTypeRegistry79.createFunctionType(jSType80, false, jSTypeArray82);
//        boolean boolean84 = functionType62.hasEqualCallType(functionType83);
//        com.google.javascript.rhino.jstype.EnumType enumType85 = jSTypeRegistry33.createEnumType("function (): {677104072}", node42, (com.google.javascript.rhino.jstype.JSType) functionType62);
//        com.google.javascript.rhino.Node node86 = functionParamBuilder29.newParameterFromNode(node42);
//        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder87 = node42.getJsDocBuilderForNode();
//        try {
//            node42.setSideEffectFlags(52);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got OR");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(objectTypeIterable4);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "function (): {147300479}" + "'", str12.equals("function (): {147300479}"));
//        org.junit.Assert.assertNull(jSType13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray22);
//        org.junit.Assert.assertNotNull(functionType23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "function (): {1105421997}" + "'", str24.equals("function (): {1105421997}"));
//        org.junit.Assert.assertNull(jSType25);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(delegateRelationship43);
//        org.junit.Assert.assertNull(delegateRelationship53);
//        org.junit.Assert.assertNotNull(node54);
//        org.junit.Assert.assertNotNull(jSTypeArray61);
//        org.junit.Assert.assertNotNull(functionType62);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray69);
//        org.junit.Assert.assertNotNull(functionType70);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "function (): {1159078731}" + "'", str71.equals("function (): {1159078731}"));
//        org.junit.Assert.assertNull(jSType72);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray82);
//        org.junit.Assert.assertNotNull(functionType83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//        org.junit.Assert.assertNotNull(enumType85);
//        org.junit.Assert.assertNotNull(node86);
//        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder87);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
//        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
//        boolean boolean20 = node12.isBreak();
//        node12.addSuppression("goog.exportSymbol");
//        boolean boolean23 = closureCodingConvention0.isOptionalParameter(node12);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        jSTypeRegistry26.incrementGeneration();
//        jSTypeRegistry26.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = googleCodingConvention31.getDelegateRelationship(node35);
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention41 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = googleCodingConvention41.getDelegateRelationship(node45);
//        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.hook(node35, node40, node45);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        boolean boolean56 = functionType55.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry59.createFunctionType(jSType60, false, jSTypeArray62);
//        java.lang.String str64 = functionType63.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType63.unboxesTo();
//        boolean boolean67 = functionType63.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType68 = null;
//        closureCodingConvention48.applySubclassRelationship(functionType55, functionType63, subclassType68);
//        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry72.createFunctionType(jSType73, false, jSTypeArray75);
//        boolean boolean77 = functionType55.hasEqualCallType(functionType76);
//        com.google.javascript.rhino.jstype.EnumType enumType78 = jSTypeRegistry26.createEnumType("function (): {677104072}", node35, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79, true);
//        com.google.javascript.rhino.jstype.JSType jSType82 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry81.createFunctionType(jSType82, false, jSTypeArray84);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType86 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType55, functionType85, subclassType86);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean89 = jSDocInfo88.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection90 = jSDocInfo88.getMarkers();
//        functionType55.setJSDocInfo(jSDocInfo88);
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList92 = jSDocInfo88.getExtendedInterfaces();
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList93 = jSDocInfo88.getExtendedInterfaces();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNull(delegateRelationship18);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(delegateRelationship36);
//        org.junit.Assert.assertNull(delegateRelationship46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "function (): {265846237}" + "'", str64.equals("function (): {265846237}"));
//        org.junit.Assert.assertNull(jSType65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray75);
//        org.junit.Assert.assertNotNull(functionType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(enumType78);
//        org.junit.Assert.assertNotNull(jSTypeArray84);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(markerCollection90);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList92);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList93);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
//        com.google.javascript.rhino.jstype.JSType jSType10 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry9.createFunctionType(jSType10, false, jSTypeArray12);
//        com.google.javascript.rhino.jstype.JSType jSType14 = jSTypeRegistry2.createOptionalType((com.google.javascript.rhino.jstype.JSType) functionType13);
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
//        jSTypeRegistry18.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention20 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21, true);
//        com.google.javascript.rhino.jstype.JSType jSType24 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry23.createFunctionType(jSType24, false, jSTypeArray26);
//        boolean boolean28 = functionType27.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29, true);
//        com.google.javascript.rhino.jstype.JSType jSType32 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry31.createFunctionType(jSType32, false, jSTypeArray34);
//        java.lang.String str36 = functionType35.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType37 = functionType35.unboxesTo();
//        boolean boolean39 = functionType35.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType40 = null;
//        closureCodingConvention20.applySubclassRelationship(functionType27, functionType35, subclassType40);
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, true);
//        com.google.javascript.rhino.jstype.JSType jSType45 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry44.createFunctionType(jSType45, false, jSTypeArray47);
//        boolean boolean49 = functionType27.hasEqualCallType(functionType48);
//        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50, true);
//        com.google.javascript.rhino.jstype.JSType jSType53 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray55 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry52.createFunctionType(jSType53, false, jSTypeArray55);
//        java.lang.String str57 = functionType56.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType58 = functionType56.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable59 = functionType56.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType60 = jSTypeRegistry18.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType48, (com.google.javascript.rhino.jstype.JSType) functionType56);
//        boolean boolean62 = parameterizedType60.hasProperty("function (): {749713027}");
//        boolean boolean63 = jSTypeRegistry2.declareType("function (): {1933549689}", (com.google.javascript.rhino.jstype.JSType) parameterizedType60);
//        boolean boolean64 = parameterizedType60.hasReferenceName();
//        com.google.javascript.rhino.jstype.JSType jSType65 = parameterizedType60.autobox();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(functionType13);
//        org.junit.Assert.assertNotNull(jSType14);
//        org.junit.Assert.assertNotNull(jSTypeArray26);
//        org.junit.Assert.assertNotNull(functionType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray34);
//        org.junit.Assert.assertNotNull(functionType35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "function (): {791576633}" + "'", str36.equals("function (): {791576633}"));
//        org.junit.Assert.assertNull(jSType37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertNotNull(functionType48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray55);
//        org.junit.Assert.assertNotNull(functionType56);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "function (): {615466520}" + "'", str57.equals("function (): {615466520}"));
//        org.junit.Assert.assertNull(jSType58);
//        org.junit.Assert.assertNotNull(objectTypeIterable59);
//        org.junit.Assert.assertNotNull(parameterizedType60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(jSType65);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        com.google.javascript.rhino.JSDocInfo jSDocInfo2 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean3 = jSDocInfo2.isNoSideEffects();
//        com.google.common.collect.ImmutableList<java.lang.String> strList4 = jSDocInfo2.getTemplateTypeNames();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean6 = jSDocInfo5.isNoSideEffects();
//        com.google.common.collect.ImmutableList<java.lang.String> strList7 = jSDocInfo5.getTemplateTypeNames();
//        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("function (): {1692957331}", "function (): {2010340701}", (java.util.List<java.lang.String>) strList4, (java.util.List<java.lang.String>) strList7);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, true);
//        com.google.javascript.rhino.jstype.JSType jSType13 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry12.createFunctionType(jSType13, false, jSTypeArray15);
//        boolean boolean17 = functionType16.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18, true);
//        com.google.javascript.rhino.jstype.JSType jSType21 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry20.createFunctionType(jSType21, false, jSTypeArray23);
//        java.lang.String str25 = functionType24.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType26 = functionType24.unboxesTo();
//        boolean boolean28 = functionType24.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType29 = null;
//        closureCodingConvention9.applySubclassRelationship(functionType16, functionType24, subclassType29);
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31, true);
//        com.google.javascript.rhino.jstype.JSType jSType34 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry33.createFunctionType(jSType34, false, jSTypeArray36);
//        boolean boolean38 = functionType16.hasEqualCallType(functionType37);
//        com.google.javascript.rhino.jstype.ObjectType.Property property40 = functionType37.getOwnSlot("function (): {1733413245}");
//        boolean boolean42 = functionType37.hasOwnProperty("function (): {1518342339}");
//        boolean boolean43 = simpleDependencyInfo8.equals((java.lang.Object) functionType37);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(strList4);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(strList7);
//        org.junit.Assert.assertNotNull(jSTypeArray15);
//        org.junit.Assert.assertNotNull(functionType16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray23);
//        org.junit.Assert.assertNotNull(functionType24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "function (): {2028142630}" + "'", str25.equals("function (): {2028142630}"));
//        org.junit.Assert.assertNull(jSType26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray36);
//        org.junit.Assert.assertNotNull(functionType37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(property40);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        jSModule1.setDepth(47);
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet4 = jSModule1.getThisAndAllDependencies();
        org.junit.Assert.assertNotNull(jSModuleSet4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.disabled("function (): {149787914}", ": hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray13 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray13);
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray22 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray22);
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType8, strArray22);
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("function (): {1609272738}", 16, 98, diagnosticType5, strArray22);
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.warning("", "hi!");
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray29 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType5, diagnosticType28 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup30 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray29);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(diagnosticTypeArray29);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList2 = jSModule1.getInputs();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        org.junit.Assert.assertNotNull(compilerInputList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getOriginalCommentString();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility3 = jSDocInfo0.getVisibility();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(visibility3);
        org.junit.Assert.assertNull(jSTypeExpression4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType7 = functionType6.getInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getModifies();
        boolean boolean5 = jSDocInfo0.isConstructor();
        boolean boolean6 = jSDocInfo0.isDeprecated();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, true);
//        com.google.javascript.rhino.jstype.JSType jSType10 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry9.createFunctionType(jSType10, false, jSTypeArray12);
//        java.lang.String str14 = functionType13.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType15 = functionType13.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable16 = functionType13.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ObjectType.Property property18 = functionType13.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention19 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20, true);
//        com.google.javascript.rhino.jstype.JSType jSType23 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry22.createFunctionType(jSType23, false, jSTypeArray25);
//        boolean boolean27 = functionType26.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28, true);
//        com.google.javascript.rhino.jstype.JSType jSType31 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry30.createFunctionType(jSType31, false, jSTypeArray33);
//        java.lang.String str35 = functionType34.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType36 = functionType34.unboxesTo();
//        boolean boolean38 = functionType34.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType39 = null;
//        closureCodingConvention19.applySubclassRelationship(functionType26, functionType34, subclassType39);
//        boolean boolean41 = functionType13.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType26);
//        boolean boolean42 = functionType26.hasReferenceName();
//        jSTypeRegistry2.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType26);
//        boolean boolean44 = functionType26.isString();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertNotNull(jSTypeArray12);
//        org.junit.Assert.assertNotNull(functionType13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "function (): {1293528093}" + "'", str14.equals("function (): {1293528093}"));
//        org.junit.Assert.assertNull(jSType15);
//        org.junit.Assert.assertNotNull(objectTypeIterable16);
//        org.junit.Assert.assertNull(property18);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(functionType34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "function (): {1466483233}" + "'", str35.equals("function (): {1466483233}"));
//        org.junit.Assert.assertNull(jSType36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            java.lang.String[] strArray2 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = node0.cloneTree();
        boolean boolean2 = node0.isParamList();
        boolean boolean3 = node0.isTypeOf();
        com.google.javascript.rhino.Node node5 = node0.getAncestor((int) (byte) 10);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(node5);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
//        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
//        boolean boolean20 = node12.isBreak();
//        node12.addSuppression("goog.exportSymbol");
//        boolean boolean23 = closureCodingConvention0.isOptionalParameter(node12);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        jSTypeRegistry26.incrementGeneration();
//        jSTypeRegistry26.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = googleCodingConvention31.getDelegateRelationship(node35);
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention41 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = googleCodingConvention41.getDelegateRelationship(node45);
//        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.hook(node35, node40, node45);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        boolean boolean56 = functionType55.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry59.createFunctionType(jSType60, false, jSTypeArray62);
//        java.lang.String str64 = functionType63.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType63.unboxesTo();
//        boolean boolean67 = functionType63.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType68 = null;
//        closureCodingConvention48.applySubclassRelationship(functionType55, functionType63, subclassType68);
//        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry72.createFunctionType(jSType73, false, jSTypeArray75);
//        boolean boolean77 = functionType55.hasEqualCallType(functionType76);
//        com.google.javascript.rhino.jstype.EnumType enumType78 = jSTypeRegistry26.createEnumType("function (): {677104072}", node35, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79, true);
//        com.google.javascript.rhino.jstype.JSType jSType82 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry81.createFunctionType(jSType82, false, jSTypeArray84);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType86 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType55, functionType85, subclassType86);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean89 = jSDocInfo88.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection90 = jSDocInfo88.getMarkers();
//        functionType55.setJSDocInfo(jSDocInfo88);
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList92 = jSDocInfo88.getExtendedInterfaces();
//        java.util.Set<java.lang.String> strSet93 = jSDocInfo88.getParameterNames();
//        java.lang.String str94 = jSDocInfo88.toString();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNull(delegateRelationship18);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(delegateRelationship36);
//        org.junit.Assert.assertNull(delegateRelationship46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "function (): {898632415}" + "'", str64.equals("function (): {898632415}"));
//        org.junit.Assert.assertNull(jSType65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray75);
//        org.junit.Assert.assertNotNull(functionType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(enumType78);
//        org.junit.Assert.assertNotNull(jSTypeArray84);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(markerCollection90);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList92);
//        org.junit.Assert.assertNotNull(strSet93);
//        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "JSDocInfo" + "'", str94.equals("JSDocInfo"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention4 = compiler1.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
        com.google.javascript.jscomp.SourceFile.Builder builder41 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile44 = builder41.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        node39.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile44);
        com.google.javascript.jscomp.JsAst jsAst46 = new com.google.javascript.jscomp.JsAst(sourceFile44);
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) jsAst46, "function (): {735754071}", true);
        com.google.javascript.rhino.InputId inputId50 = compilerInput49.getInputId();
        boolean boolean51 = compilerInput49.isExtern();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(delegateRelationship28);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(builder41);
        org.junit.Assert.assertNotNull(sourceFile44);
        org.junit.Assert.assertNotNull(inputId50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        boolean boolean12 = functionType11.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        java.lang.String str20 = functionType19.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType21 = functionType19.unboxesTo();
//        boolean boolean23 = functionType19.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
//        closureCodingConvention4.applySubclassRelationship(functionType11, functionType19, subclassType24);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
//        com.google.javascript.rhino.jstype.JSType jSType29 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry28.createFunctionType(jSType29, false, jSTypeArray31);
//        boolean boolean33 = functionType11.hasEqualCallType(functionType32);
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry36.createFunctionType(jSType37, false, jSTypeArray39);
//        java.lang.String str41 = functionType40.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType42 = functionType40.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = functionType40.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType44 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType32, (com.google.javascript.rhino.jstype.JSType) functionType40);
//        boolean boolean45 = parameterizedType44.isInterface();
//        boolean boolean46 = parameterizedType44.matchesStringContext();
//        boolean boolean47 = parameterizedType44.isUnknownType();
//        com.google.javascript.rhino.jstype.JSType jSType49 = parameterizedType44.getRestrictedTypeGivenToBooleanOutcome(false);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (): {2068523194}" + "'", str20.equals("function (): {2068523194}"));
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray31);
//        org.junit.Assert.assertNotNull(functionType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertNotNull(functionType40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "function (): {1125231038}" + "'", str41.equals("function (): {1125231038}"));
//        org.junit.Assert.assertNull(jSType42);
//        org.junit.Assert.assertNotNull(objectTypeIterable43);
//        org.junit.Assert.assertNotNull(parameterizedType44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(jSType49);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.disabled("function (): {149787914}", ": hi!");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray18 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray27 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType22, strArray27);
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make(diagnosticType13, strArray27);
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("function (): {1609272738}", 16, 98, diagnosticType10, strArray27);
        compiler1.report(jSError30);
        com.google.javascript.jscomp.Scope scope32 = compiler1.getTopScope();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNull(scope32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_PROVIDES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup2;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray5 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2, diagnosticGroup4 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = new com.google.javascript.jscomp.DiagnosticGroup("function (): {1062485636}", diagnosticGroupArray5);
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup6;
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertNotNull(diagnosticGroupArray5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback5);
        compiler1.reportCodeChange();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node7 = node4.getLastSibling();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable8 = node7.getAncestors();
        boolean boolean9 = node7.isAnd();
        com.google.javascript.rhino.Node node10 = node7.getLastChild();
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(ancestorIterable8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(node10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.paramList();
        boolean boolean2 = node1.isOptionalArg();
        boolean boolean3 = node1.isEmpty();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = googleCodingConvention4.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = googleCodingConvention14.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node8, node13, node18);
        com.google.javascript.rhino.Node node21 = node1.srcref(node18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.DiagnosticType.warning("", "hi!");
        com.google.javascript.jscomp.CheckLevel checkLevel25 = diagnosticType24.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType28 = com.google.javascript.jscomp.DiagnosticType.error("()", "hi!");
        java.lang.String[] strArray33 = new java.lang.String[] { "function (): {197093445}", "function (): {221042019}", "function (): {197093445}", "function (): {221042019}" };
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make(diagnosticType28, strArray33);
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make(diagnosticType24, strArray33);
        java.lang.String[] strArray40 = new java.lang.String[] { "function (): {1872939683}", "function (): {469031990}", "function (): {371501237}", "function (): {1913165}" };
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("function (): {729410073}", node1, diagnosticType24, strArray40);
        com.google.javascript.jscomp.DiagnosticType diagnosticType42 = jSError41.getType();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType28);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(strArray40);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(diagnosticType42);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile(": hi!");
        sourceFile3.setOriginalPath("hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        java.lang.String str8 = sourceFile3.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        jSModule1.remove(compilerInput9);
        jSModule1.removeAll();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + ": hi!" + "'", str8.equals(": hi!"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getOriginalCommentString();
        boolean boolean3 = jSDocInfo0.isNoShadow();
        java.lang.String str4 = jSDocInfo0.getBlockDescription();
        java.lang.String str6 = jSDocInfo0.getDescriptionForParameter("function (): {1915141811}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str6);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
//        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
//        boolean boolean20 = node12.isBreak();
//        node12.addSuppression("goog.exportSymbol");
//        boolean boolean23 = closureCodingConvention0.isOptionalParameter(node12);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        jSTypeRegistry26.incrementGeneration();
//        jSTypeRegistry26.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = googleCodingConvention31.getDelegateRelationship(node35);
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention41 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = googleCodingConvention41.getDelegateRelationship(node45);
//        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.hook(node35, node40, node45);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        boolean boolean56 = functionType55.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry59.createFunctionType(jSType60, false, jSTypeArray62);
//        java.lang.String str64 = functionType63.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType63.unboxesTo();
//        boolean boolean67 = functionType63.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType68 = null;
//        closureCodingConvention48.applySubclassRelationship(functionType55, functionType63, subclassType68);
//        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry72.createFunctionType(jSType73, false, jSTypeArray75);
//        boolean boolean77 = functionType55.hasEqualCallType(functionType76);
//        com.google.javascript.rhino.jstype.EnumType enumType78 = jSTypeRegistry26.createEnumType("function (): {677104072}", node35, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79, true);
//        com.google.javascript.rhino.jstype.JSType jSType82 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry81.createFunctionType(jSType82, false, jSTypeArray84);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType86 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType55, functionType85, subclassType86);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean89 = jSDocInfo88.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection90 = jSDocInfo88.getMarkers();
//        functionType55.setJSDocInfo(jSDocInfo88);
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList92 = jSDocInfo88.getExtendedInterfaces();
//        java.util.Set<java.lang.String> strSet93 = jSDocInfo88.getParameterNames();
//        com.google.javascript.rhino.JSTypeExpression jSTypeExpression94 = jSDocInfo88.getType();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNull(delegateRelationship18);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(delegateRelationship36);
//        org.junit.Assert.assertNull(delegateRelationship46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "function (): {1767121940}" + "'", str64.equals("function (): {1767121940}"));
//        org.junit.Assert.assertNull(jSType65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray75);
//        org.junit.Assert.assertNotNull(functionType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(enumType78);
//        org.junit.Assert.assertNotNull(jSTypeArray84);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(markerCollection90);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList92);
//        org.junit.Assert.assertNotNull(strSet93);
//        org.junit.Assert.assertNull(jSTypeExpression94);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("function (): {626404761}");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList2 = jSModule1.getInputs();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList6 = jSModule5.getInputs();
        com.google.javascript.jscomp.SourceFile.Builder builder7 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile10 = builder7.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile10);
        compilerInput11.clearAst();
        jSModule5.add(compilerInput11);
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList16 = jSModule15.getInputs();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet17 = jSModule15.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        jSModule19.setDepth(47);
        com.google.javascript.jscomp.JSModule jSModule23 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList24 = jSModule23.getInputs();
        com.google.javascript.jscomp.JSModule jSModule26 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList27 = jSModule26.getInputs();
        com.google.javascript.jscomp.SourceFile.Builder builder28 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile31 = builder28.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(sourceFile31);
        compilerInput32.clearAst();
        jSModule26.add(compilerInput32);
        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("function (): {1231979587}");
        jSModule36.setDepth(47);
        com.google.javascript.jscomp.JSModule[] jSModuleArray39 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule5, jSModule15, jSModule19, jSModule23, jSModule26, jSModule36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList40 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList40, jSModuleArray39);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph42 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList40);
        org.junit.Assert.assertNotNull(compilerInputList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertNotNull(compilerInputList6);
        org.junit.Assert.assertNotNull(builder7);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertNotNull(compilerInputList16);
        org.junit.Assert.assertNotNull(jSModuleSet17);
        org.junit.Assert.assertNotNull(compilerInputList24);
        org.junit.Assert.assertNotNull(compilerInputList27);
        org.junit.Assert.assertNotNull(builder28);
        org.junit.Assert.assertNotNull(sourceFile31);
        org.junit.Assert.assertNotNull(jSModuleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        jSTypeRegistry2.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
//        com.google.javascript.rhino.jstype.JSType jSType8 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry7.createFunctionType(jSType8, false, jSTypeArray10);
//        boolean boolean12 = functionType11.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13, true);
//        com.google.javascript.rhino.jstype.JSType jSType16 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry15.createFunctionType(jSType16, false, jSTypeArray18);
//        java.lang.String str20 = functionType19.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType21 = functionType19.unboxesTo();
//        boolean boolean23 = functionType19.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType24 = null;
//        closureCodingConvention4.applySubclassRelationship(functionType11, functionType19, subclassType24);
//        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26, true);
//        com.google.javascript.rhino.jstype.JSType jSType29 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry28.createFunctionType(jSType29, false, jSTypeArray31);
//        boolean boolean33 = functionType11.hasEqualCallType(functionType32);
//        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34, true);
//        com.google.javascript.rhino.jstype.JSType jSType37 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry36.createFunctionType(jSType37, false, jSTypeArray39);
//        java.lang.String str41 = functionType40.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType42 = functionType40.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable43 = functionType40.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType44 = jSTypeRegistry2.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType32, (com.google.javascript.rhino.jstype.JSType) functionType40);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean47 = jSDocInfo46.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection48 = jSDocInfo46.getMarkers();
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList49 = jSDocInfo46.getImplementedInterfaces();
//        java.util.Set<java.lang.String> strSet50 = jSDocInfo46.getModifies();
//        boolean boolean51 = jSDocInfo46.isConstructor();
//        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection52 = jSDocInfo46.getTypeNodes();
//        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection53 = jSDocInfo46.getTypeNodes();
//        functionType32.setPropertyJSDocInfo("function (): {581328886}", jSDocInfo46);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (): {1100850812}" + "'", str20.equals("function (): {1100850812}"));
//        org.junit.Assert.assertNull(jSType21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray31);
//        org.junit.Assert.assertNotNull(functionType32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray39);
//        org.junit.Assert.assertNotNull(functionType40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "function (): {132058422}" + "'", str41.equals("function (): {132058422}"));
//        org.junit.Assert.assertNull(jSType42);
//        org.junit.Assert.assertNotNull(objectTypeIterable43);
//        org.junit.Assert.assertNotNull(parameterizedType44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(markerCollection48);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList49);
//        org.junit.Assert.assertNotNull(strSet50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(nodeCollection52);
//        org.junit.Assert.assertNotNull(nodeCollection53);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback5);
        com.google.javascript.rhino.Node node7 = nodeTraversal6.getCurrentNode();
        boolean boolean8 = nodeTraversal6.hasScope();
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getImplementedInterfaces();
        java.lang.String str4 = jSDocInfo0.getMeaning();
        boolean boolean5 = jSDocInfo0.hasEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean2 = jSDocInfoBuilder1.recordInterface();
        java.util.Set<java.lang.String> strSet3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordModifies(strSet3);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder6 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean7 = jSDocInfoBuilder6.recordInterface();
        boolean boolean9 = jSDocInfoBuilder6.hasParameter("function (): {377837821}");
        boolean boolean10 = jSDocInfoBuilder6.recordHiddenness();
        boolean boolean11 = jSDocInfoBuilder6.isJavaDispatch();
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder13 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        boolean boolean14 = jSDocInfoBuilder13.recordInterface();
        boolean boolean16 = jSDocInfoBuilder13.recordLends("function (): {1720726686}");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention17 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship22 = googleCodingConvention17.getDelegateRelationship(node21);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention27 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship32 = googleCodingConvention27.getDelegateRelationship(node31);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.IR.hook(node21, node26, node31);
        boolean boolean34 = node26.isBreak();
        node26.addSuppression("goog.exportSymbol");
        boolean boolean37 = node26.isIf();
        boolean boolean38 = node26.isOnlyModifiesThisCall();
        boolean boolean39 = node26.isInstanceOf();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression41 = new com.google.javascript.rhino.JSTypeExpression(node26, "function (): {1373043384}");
        com.google.javascript.rhino.Node node42 = jSTypeExpression41.getRoot();
        boolean boolean43 = jSDocInfoBuilder13.recordBaseType(jSTypeExpression41);
        boolean boolean44 = jSDocInfoBuilder6.recordExtendedInterface(jSTypeExpression41);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention45 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship50 = googleCodingConvention45.getDelegateRelationship(node49);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention55 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship60 = googleCodingConvention55.getDelegateRelationship(node59);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.IR.hook(node49, node54, node59);
        boolean boolean62 = node54.isBreak();
        node54.addSuppression("goog.exportSymbol");
        boolean boolean65 = node54.isIf();
        boolean boolean66 = node54.isOnlyModifiesThisCall();
        boolean boolean67 = node54.isInstanceOf();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression69 = new com.google.javascript.rhino.JSTypeExpression(node54, "function (): {1373043384}");
        boolean boolean70 = jSDocInfoBuilder6.recordDefineType(jSTypeExpression69);
        boolean boolean71 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression69);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(delegateRelationship22);
        org.junit.Assert.assertNull(delegateRelationship32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(delegateRelationship50);
        org.junit.Assert.assertNull(delegateRelationship60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Scope scope2 = compiler1.getTopScope();
        java.lang.String str3 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        try {
            compiler1.init(jSSourceFileArray4, jSModuleArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        char[] charArray1 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        char[] charArray2 = anonymousFunctionNamingPolicy0.getReservedCharacters();
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertNotNull(charArray2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        boolean boolean2 = jSDocInfo0.hasModifies();
        boolean boolean3 = jSDocInfo0.containsDeclaration();
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention5 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean7 = closureCodingConvention5.isSuperClassReference("()");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention8 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = googleCodingConvention8.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention18 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship23 = googleCodingConvention18.getDelegateRelationship(node22);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.hook(node12, node17, node22);
        boolean boolean25 = node17.isBreak();
        node17.addSuppression("goog.exportSymbol");
        boolean boolean28 = closureCodingConvention5.isOptionalParameter(node17);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node30 = node29.cloneTree();
        boolean boolean31 = node29.isParamList();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.pos(node35);
        java.lang.String str37 = closureCodingConvention5.extractClassNameIfRequire(node29, node36);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention38 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship43 = googleCodingConvention38.getDelegateRelationship(node42);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention44 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship49 = googleCodingConvention44.getDelegateRelationship(node48);
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention54 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship59 = googleCodingConvention54.getDelegateRelationship(node58);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.hook(node48, node53, node58);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention61 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = googleCodingConvention61.getDelegateRelationship(node65);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention71 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship76 = googleCodingConvention71.getDelegateRelationship(node75);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.IR.hook(node65, node70, node75);
        java.lang.String str78 = googleCodingConvention38.extractClassNameIfRequire(node58, node77);
        boolean boolean79 = node77.isWhile();
        com.google.javascript.rhino.Node node80 = node77.removeChildren();
        node77.putBooleanProp((int) (short) 1, false);
        boolean boolean84 = node77.isBlock();
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(4, node29, node77);
        jSDocInfo0.setAssociatedNode(node85);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression87 = jSDocInfo0.getBaseType();
        jSDocInfo0.addSuppression("function (): {2022971717}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(delegateRelationship13);
        org.junit.Assert.assertNull(delegateRelationship23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(delegateRelationship43);
        org.junit.Assert.assertNull(delegateRelationship49);
        org.junit.Assert.assertNull(delegateRelationship59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertNull(delegateRelationship76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNull(jSTypeExpression87);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.JSDocInfo jSDocInfo2 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean3 = jSDocInfo2.isNoSideEffects();
        com.google.common.collect.ImmutableList<java.lang.String> strList4 = jSDocInfo2.getTemplateTypeNames();
        com.google.javascript.rhino.JSDocInfo jSDocInfo5 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean6 = jSDocInfo5.isNoSideEffects();
        com.google.common.collect.ImmutableList<java.lang.String> strList7 = jSDocInfo5.getTemplateTypeNames();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo8 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("function (): {1692957331}", "function (): {2010340701}", (java.util.List<java.lang.String>) strList4, (java.util.List<java.lang.String>) strList7);
        java.lang.String str9 = simpleDependencyInfo8.getName();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strList4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strList7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "function (): {2010340701}" + "'", str9.equals("function (): {2010340701}"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention1 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean3 = closureCodingConvention1.isSuperClassReference("()");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention4 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship9 = googleCodingConvention4.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention14 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship19 = googleCodingConvention14.getDelegateRelationship(node18);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.hook(node8, node13, node18);
        boolean boolean21 = node13.isBreak();
        node13.addSuppression("goog.exportSymbol");
        boolean boolean24 = closureCodingConvention1.isOptionalParameter(node13);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node26 = node25.cloneTree();
        boolean boolean27 = node25.isParamList();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.pos(node31);
        java.lang.String str33 = closureCodingConvention1.extractClassNameIfRequire(node25, node32);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention34 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship39 = googleCodingConvention34.getDelegateRelationship(node38);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention40 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship45 = googleCodingConvention40.getDelegateRelationship(node44);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention50 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship55 = googleCodingConvention50.getDelegateRelationship(node54);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.hook(node44, node49, node54);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention57 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship62 = googleCodingConvention57.getDelegateRelationship(node61);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention67 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship72 = googleCodingConvention67.getDelegateRelationship(node71);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.IR.hook(node61, node66, node71);
        java.lang.String str74 = googleCodingConvention34.extractClassNameIfRequire(node54, node73);
        boolean boolean75 = node73.isWhile();
        com.google.javascript.rhino.Node node76 = node73.removeChildren();
        node73.putBooleanProp((int) (short) 1, false);
        boolean boolean80 = node73.isBlock();
        com.google.javascript.rhino.Node node81 = new com.google.javascript.rhino.Node(4, node25, node73);
        boolean boolean82 = node73.isContinue();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(delegateRelationship9);
        org.junit.Assert.assertNull(delegateRelationship19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNull(delegateRelationship39);
        org.junit.Assert.assertNull(delegateRelationship45);
        org.junit.Assert.assertNull(delegateRelationship55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(delegateRelationship62);
        org.junit.Assert.assertNull(delegateRelationship72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getModifies();
        boolean boolean5 = jSDocInfo0.isConstructor();
        com.google.javascript.rhino.Node node6 = jSDocInfo0.getAssociatedNode();
        java.util.Collection<java.lang.String> strCollection7 = jSDocInfo0.getReferences();
        boolean boolean8 = jSDocInfo0.hasModifies();
        boolean boolean9 = jSDocInfo0.hasFileOverview();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(strCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
        boolean boolean41 = node39.isWhile();
        com.google.javascript.rhino.Node node42 = node39.removeChildren();
        node39.putBooleanProp((int) (short) 1, false);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention46 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship51 = googleCodingConvention46.getDelegateRelationship(node50);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder52 = node50.getJsDocBuilderForNode();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention53 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship58 = googleCodingConvention53.getDelegateRelationship(node57);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention59 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship64 = googleCodingConvention59.getDelegateRelationship(node63);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention69 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship74 = googleCodingConvention69.getDelegateRelationship(node73);
        com.google.javascript.rhino.Node node75 = com.google.javascript.rhino.IR.hook(node63, node68, node73);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention76 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship81 = googleCodingConvention76.getDelegateRelationship(node80);
        com.google.javascript.rhino.Node node85 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention86 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node90 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship91 = googleCodingConvention86.getDelegateRelationship(node90);
        com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.IR.hook(node80, node85, node90);
        java.lang.String str93 = googleCodingConvention53.extractClassNameIfRequire(node73, node92);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.IR.eq(node50, node92);
        com.google.javascript.rhino.Node node95 = node39.useSourceInfoIfMissingFrom(node92);
        boolean boolean96 = node39.isAdd();
        com.google.javascript.rhino.Node node97 = com.google.javascript.rhino.IR.throwNode(node39);
        org.junit.Assert.assertNull(delegateRelationship5);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNull(delegateRelationship21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(delegateRelationship28);
        org.junit.Assert.assertNull(delegateRelationship38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNull(delegateRelationship51);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder52);
        org.junit.Assert.assertNull(delegateRelationship58);
        org.junit.Assert.assertNull(delegateRelationship64);
        org.junit.Assert.assertNull(delegateRelationship74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(delegateRelationship81);
        org.junit.Assert.assertNull(delegateRelationship91);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertNotNull(node97);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.JsAst jsAst1 = new com.google.javascript.jscomp.JsAst(sourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("function (): {1221498044}");
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
//        com.google.javascript.rhino.jstype.JSType jSType3 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
//        java.lang.String str7 = functionType6.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType8 = functionType6.unboxesTo();
//        boolean boolean10 = functionType6.isPropertyInExterns(": hi!");
//        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, true);
//        jSTypeRegistry13.incrementGeneration();
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention15 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16, true);
//        com.google.javascript.rhino.jstype.JSType jSType19 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry18.createFunctionType(jSType19, false, jSTypeArray21);
//        boolean boolean23 = functionType22.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        com.google.javascript.rhino.jstype.JSType jSType27 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry26.createFunctionType(jSType27, false, jSTypeArray29);
//        java.lang.String str31 = functionType30.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType32 = functionType30.unboxesTo();
//        boolean boolean34 = functionType30.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType35 = null;
//        closureCodingConvention15.applySubclassRelationship(functionType22, functionType30, subclassType35);
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37, true);
//        com.google.javascript.rhino.jstype.JSType jSType40 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry39.createFunctionType(jSType40, false, jSTypeArray42);
//        boolean boolean44 = functionType22.hasEqualCallType(functionType43);
//        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45, true);
//        com.google.javascript.rhino.jstype.JSType jSType48 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry47.createFunctionType(jSType48, false, jSTypeArray50);
//        java.lang.String str52 = functionType51.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType53 = functionType51.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable54 = functionType51.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType55 = jSTypeRegistry13.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType43, (com.google.javascript.rhino.jstype.JSType) functionType51);
//        boolean boolean56 = parameterizedType55.isInterface();
//        boolean boolean57 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) parameterizedType55);
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable58 = parameterizedType55.getCtorExtendedInterfaces();
//        boolean boolean59 = parameterizedType55.hasAnyTemplateInternal();
//        org.junit.Assert.assertNotNull(jSTypeArray5);
//        org.junit.Assert.assertNotNull(functionType6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "function (): {1256706090}" + "'", str7.equals("function (): {1256706090}"));
//        org.junit.Assert.assertNull(jSType8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(functionType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray29);
//        org.junit.Assert.assertNotNull(functionType30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "function (): {409549965}" + "'", str31.equals("function (): {409549965}"));
//        org.junit.Assert.assertNull(jSType32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray42);
//        org.junit.Assert.assertNotNull(functionType43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray50);
//        org.junit.Assert.assertNotNull(functionType51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "function (): {1004661324}" + "'", str52.equals("function (): {1004661324}"));
//        org.junit.Assert.assertNull(jSType53);
//        org.junit.Assert.assertNotNull(objectTypeIterable54);
//        org.junit.Assert.assertNotNull(parameterizedType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertNotNull(objectTypeIterable58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        boolean boolean2 = closureCodingConvention0.isSuperClassReference("()");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention3 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship8 = googleCodingConvention3.getDelegateRelationship(node7);
//        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention13 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship18 = googleCodingConvention13.getDelegateRelationship(node17);
//        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.hook(node7, node12, node17);
//        boolean boolean20 = node12.isBreak();
//        node12.addSuppression("goog.exportSymbol");
//        boolean boolean23 = closureCodingConvention0.isOptionalParameter(node12);
//        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24, true);
//        jSTypeRegistry26.incrementGeneration();
//        jSTypeRegistry26.identifyNonNullableName("goog.exportSymbol");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention31 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship36 = googleCodingConvention31.getDelegateRelationship(node35);
//        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention41 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship46 = googleCodingConvention41.getDelegateRelationship(node45);
//        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.hook(node35, node40, node45);
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention48 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49, true);
//        com.google.javascript.rhino.jstype.JSType jSType52 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry51.createFunctionType(jSType52, false, jSTypeArray54);
//        boolean boolean56 = functionType55.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter57 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter57, true);
//        com.google.javascript.rhino.jstype.JSType jSType60 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray62 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType63 = jSTypeRegistry59.createFunctionType(jSType60, false, jSTypeArray62);
//        java.lang.String str64 = functionType63.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType65 = functionType63.unboxesTo();
//        boolean boolean67 = functionType63.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType68 = null;
//        closureCodingConvention48.applySubclassRelationship(functionType55, functionType63, subclassType68);
//        com.google.javascript.rhino.ErrorReporter errorReporter70 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter70, true);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry72.createFunctionType(jSType73, false, jSTypeArray75);
//        boolean boolean77 = functionType55.hasEqualCallType(functionType76);
//        com.google.javascript.rhino.jstype.EnumType enumType78 = jSTypeRegistry26.createEnumType("function (): {677104072}", node35, (com.google.javascript.rhino.jstype.JSType) functionType55);
//        com.google.javascript.rhino.ErrorReporter errorReporter79 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter79, true);
//        com.google.javascript.rhino.jstype.JSType jSType82 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray84 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType85 = jSTypeRegistry81.createFunctionType(jSType82, false, jSTypeArray84);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType86 = null;
//        closureCodingConvention0.applySubclassRelationship(functionType55, functionType85, subclassType86);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo88 = new com.google.javascript.rhino.JSDocInfo();
//        boolean boolean89 = jSDocInfo88.isIdGenerator();
//        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection90 = jSDocInfo88.getMarkers();
//        functionType55.setJSDocInfo(jSDocInfo88);
//        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList92 = jSDocInfo88.getExtendedInterfaces();
//        boolean boolean93 = jSDocInfo88.isNoSideEffects();
//        java.util.Set<java.lang.String> strSet94 = jSDocInfo88.getSuppressions();
//        java.lang.String str95 = jSDocInfo88.getDescription();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNull(delegateRelationship8);
//        org.junit.Assert.assertNull(delegateRelationship18);
//        org.junit.Assert.assertNotNull(node19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(delegateRelationship36);
//        org.junit.Assert.assertNull(delegateRelationship46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(jSTypeArray54);
//        org.junit.Assert.assertNotNull(functionType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray62);
//        org.junit.Assert.assertNotNull(functionType63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "function (): {518879711}" + "'", str64.equals("function (): {518879711}"));
//        org.junit.Assert.assertNull(jSType65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray75);
//        org.junit.Assert.assertNotNull(functionType76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(enumType78);
//        org.junit.Assert.assertNotNull(jSTypeArray84);
//        org.junit.Assert.assertNotNull(functionType85);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(markerCollection90);
//        org.junit.Assert.assertNotNull(jSTypeExpressionList92);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertNotNull(strSet94);
//        org.junit.Assert.assertNull(str95);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isIdGenerator();
        java.util.Collection<com.google.javascript.rhino.JSDocInfo.Marker> markerCollection2 = jSDocInfo0.getMarkers();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList3 = jSDocInfo0.getImplementedInterfaces();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getModifies();
        boolean boolean5 = jSDocInfo0.isConstructor();
        com.google.javascript.rhino.Node node6 = jSDocInfo0.getAssociatedNode();
        java.util.Collection<java.lang.String> strCollection7 = jSDocInfo0.getReferences();
        boolean boolean8 = jSDocInfo0.hasModifies();
        java.util.Collection<java.lang.String> strCollection9 = jSDocInfo0.getReferences();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(markerCollection2);
        org.junit.Assert.assertNotNull(jSTypeExpressionList3);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(strCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(strCollection9);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry2.createFunctionType(jSType3, false, jSTypeArray5);
        boolean boolean7 = functionType6.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, true);
        jSTypeRegistry10.incrementGeneration();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry10.getNativeType(jSTypeNative12);
        boolean boolean14 = functionType6.canTestForEqualityWith(jSType13);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = com.google.javascript.jscomp.SourceFile.builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromCode("goog.exportSymbol", "goog.exportSymbol");
        int int5 = sourceFile3.getColumnOfOffset(16);
        int int7 = sourceFile3.getColumnOfOffset(0);
        int int9 = sourceFile3.getLineOfOffset((int) ' ');
        org.junit.Assert.assertNotNull(builder0);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship5 = googleCodingConvention0.getDelegateRelationship(node4);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention6 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = googleCodingConvention6.getDelegateRelationship(node10);
//        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention16 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship21 = googleCodingConvention16.getDelegateRelationship(node20);
//        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.hook(node10, node15, node20);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention23 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = googleCodingConvention23.getDelegateRelationship(node27);
//        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention33 = new com.google.javascript.jscomp.GoogleCodingConvention();
//        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(100, 1, (int) (short) -1);
//        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship38 = googleCodingConvention33.getDelegateRelationship(node37);
//        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.IR.hook(node27, node32, node37);
//        java.lang.String str40 = googleCodingConvention0.extractClassNameIfRequire(node20, node39);
//        java.lang.String str41 = googleCodingConvention0.getExportSymbolFunction();
//        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42, true);
//        com.google.javascript.rhino.jstype.JSType jSType45 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry44.createFunctionType(jSType45, false, jSTypeArray47);
//        java.lang.String str49 = functionType48.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType50 = functionType48.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable51 = functionType48.getExtendedInterfaces();
//        com.google.javascript.rhino.ErrorReporter errorReporter52 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter52, true);
//        com.google.javascript.rhino.jstype.JSType jSType55 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray57 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry54.createFunctionType(jSType55, false, jSTypeArray57);
//        java.lang.String str59 = functionType58.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType60 = functionType58.unboxesTo();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable61 = functionType58.getExtendedInterfaces();
//        com.google.javascript.rhino.jstype.ObjectType.Property property63 = functionType58.getOwnSlot("function (): {1754866122}");
//        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention64 = new com.google.javascript.jscomp.ClosureCodingConvention();
//        com.google.javascript.rhino.ErrorReporter errorReporter65 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter65, true);
//        com.google.javascript.rhino.jstype.JSType jSType68 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray70 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType71 = jSTypeRegistry67.createFunctionType(jSType68, false, jSTypeArray70);
//        boolean boolean72 = functionType71.matchesInt32Context();
//        com.google.javascript.rhino.ErrorReporter errorReporter73 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter73, true);
//        com.google.javascript.rhino.jstype.JSType jSType76 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray78 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType79 = jSTypeRegistry75.createFunctionType(jSType76, false, jSTypeArray78);
//        java.lang.String str80 = functionType79.toDebugHashCodeString();
//        com.google.javascript.rhino.jstype.JSType jSType81 = functionType79.unboxesTo();
//        boolean boolean83 = functionType79.isPropertyInExterns(": hi!");
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType84 = null;
//        closureCodingConvention64.applySubclassRelationship(functionType71, functionType79, subclassType84);
//        boolean boolean86 = functionType58.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType71);
//        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType87 = null;
//        googleCodingConvention0.applySubclassRelationship(functionType48, functionType71, subclassType87);
//        int int89 = functionType48.getMaxArguments();
//        com.google.javascript.rhino.jstype.FunctionType functionType90 = functionType48.toMaybeFunctionType();
//        org.junit.Assert.assertNull(delegateRelationship5);
//        org.junit.Assert.assertNull(delegateRelationship11);
//        org.junit.Assert.assertNull(delegateRelationship21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNull(delegateRelationship28);
//        org.junit.Assert.assertNull(delegateRelationship38);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "goog.exportSymbol" + "'", str41.equals("goog.exportSymbol"));
//        org.junit.Assert.assertNotNull(jSTypeArray47);
//        org.junit.Assert.assertNotNull(functionType48);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "function (): {387302791}" + "'", str49.equals("function (): {387302791}"));
//        org.junit.Assert.assertNull(jSType50);
//        org.junit.Assert.assertNotNull(objectTypeIterable51);
//        org.junit.Assert.assertNotNull(jSTypeArray57);
//        org.junit.Assert.assertNotNull(functionType58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "function (): {1273486245}" + "'", str59.equals("function (): {1273486245}"));
//        org.junit.Assert.assertNull(jSType60);
//        org.junit.Assert.assertNotNull(objectTypeIterable61);
//        org.junit.Assert.assertNull(property63);
//        org.junit.Assert.assertNotNull(jSTypeArray70);
//        org.junit.Assert.assertNotNull(functionType71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray78);
//        org.junit.Assert.assertNotNull(functionType79);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "function (): {1893858646}" + "'", str80.equals("function (): {1893858646}"));
//        org.junit.Assert.assertNull(jSType81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
//        org.junit.Assert.assertNotNull(functionType90);
//    }
//}

