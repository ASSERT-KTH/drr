import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        int int12 = loggerErrorManager10.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.rhino.Node node15 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        java.io.PrintStream printStream16 = null;
        com.google.javascript.jscomp.Compiler compiler17 = new com.google.javascript.jscomp.Compiler(printStream16);
        try {
            com.google.javascript.rhino.Node node18 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkMissingReturn;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean10 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.generatePseudoNames;
        java.lang.String str5 = compilerOptions0.reportPath;
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.checkTypedPropertyCalls;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean7 = defaultCodingConvention5.isConstant("hi!");
        boolean boolean9 = defaultCodingConvention5.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] { node14, node18, node23 };
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray24);
        int int27 = node25.getIntProp(10);
        com.google.javascript.rhino.Node node28 = node25.getNext();
        java.lang.String str29 = defaultCodingConvention5.identifyTypeDefAssign(node28);
        boolean boolean32 = defaultCodingConvention5.isExported("ERROR 0", true);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention5);
        compilerOptions0.lineBreak = true;
        java.util.Set<java.lang.String> strSet36 = compilerOptions0.stripNamePrefixes;
        boolean boolean37 = compilerOptions0.coalesceVariableNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.strictMessageReplacement = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = node3.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor5 = ancestorIterable4.iterator();
        org.junit.Assert.assertNotNull(ancestorIterable4);
        org.junit.Assert.assertNotNull(nodeItor5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", 110, (-2));
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("Unknown class name");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName((-2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "<unknown=-2>" + "'", str1.equals("<unknown=-2>"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode2 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String str3 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) languageMode2);
        com.google.javascript.jscomp.parsing.Config config5 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode2, true);
        com.google.javascript.jscomp.parsing.Config config7 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true, languageMode2, true);
        org.junit.Assert.assertTrue("'" + languageMode2 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode2.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ECMASCRIPT5" + "'", str3.equals("ECMASCRIPT5"));
        org.junit.Assert.assertNotNull(config5);
        org.junit.Assert.assertNotNull(config7);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray19 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel11, diagnosticType12, strArray19);
        java.lang.String[] strArray21 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType12, strArray21);
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError22, (java.lang.Object) 41);
        int int25 = jSError22.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = jSError22.level;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType31 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray38 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError39 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel30, diagnosticType31, strArray38);
        loggerErrorManager1.println(checkLevel26, jSError39);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType31);
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertNotNull(jSError39);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        boolean boolean30 = node27.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 1, 0, 23);
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray51 = new com.google.javascript.rhino.Node[] { node41, node45, node50 };
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray51);
        com.google.javascript.rhino.Node node53 = node52.cloneNode();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node52, node58, node62 };
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node(33, nodeArray63, (int) (byte) 0, 10);
        boolean boolean67 = node66.hasChildren();
        boolean boolean68 = node35.isEquivalentToTyped(node66);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(nodeArray51);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean9 = compilerOptions0.markAsCompiled;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        compilerOptions0.setDefineToDoubleLiteral("", (double) (-1L));
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean8 = compilerOptions0.exportTestFunctions;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig9 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray30 = new com.google.javascript.rhino.Node[] { node20, node24, node29 };
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray30);
        int int32 = node31.getSideEffectFlags();
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node37, node41, node46 };
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray47);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection49 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node48);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray64 = new com.google.javascript.rhino.Node[] { node54, node58, node63 };
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray64);
        java.lang.String str69 = node65.toString(false, false, true);
        node31.addChildAfter(node48, node65);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray85 = new com.google.javascript.rhino.Node[] { node75, node79, node84 };
        com.google.javascript.rhino.Node node86 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray85);
        int int88 = node86.getIntProp(10);
        int int89 = node86.getSourcePosition();
        boolean boolean90 = node86.hasMoreThanOneChild();
        boolean boolean91 = node86.isQualifiedName();
        node48.addChildToBack(node86);
        java.lang.String str93 = closureCodingConvention0.getSingletonGetterClassName(node48);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry94 = null;
        com.google.javascript.jscomp.Scope scope95 = null;
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList96 = null;
        closureCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry94, scope95, objectTypeList96);
        com.google.javascript.rhino.Node node98 = null;
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship99 = closureCodingConvention0.getClassesDefinedByCall(node98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(nodeArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeArray47);
        org.junit.Assert.assertNotNull(nodeCollection49);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray64);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "ERROR" + "'", str69.equals("ERROR"));
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(nodeArray85);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(str93);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.debugFunctionSideEffectsPath = "@IMPLEMENTATION.VERSION@";
        boolean boolean10 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.setManageClosureDependencies(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        byte[] byteArray10 = null;
        compilerOptions0.inputVariableMapSerialized = byteArray10;
        compilerOptions0.syntheticBlockEndMarker = "Named type with empty name component";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        compilerOptions0.inlineLocalVariables = true;
        compilerOptions0.deadAssignmentElimination = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        node15.setVarArgs(true);
        boolean boolean18 = node15.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
//        java.lang.String str3 = diagnosticGroupWarningsGuard2.toString();
//        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray18 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel10, diagnosticType11, strArray18);
//        java.lang.String[] strArray20 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType11, strArray20);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = jSError21.getType();
//        int int23 = jSError21.lineNumber;
//        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticGroupWarningsGuard2.level(jSError21);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray40 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel32, diagnosticType33, strArray40);
//        java.lang.String[] strArray42 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType33, strArray42);
//        java.lang.RuntimeException runtimeException45 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError43, (java.lang.Object) 41);
//        int int46 = jSError43.lineNumber;
//        boolean boolean47 = diagnosticGroup25.matches(jSError43);
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup25;
//        try {
//            boolean boolean49 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str3.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticType11);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertNotNull(jSError19);
//        org.junit.Assert.assertNotNull(strArray20);
//        org.junit.Assert.assertNotNull(jSError21);
//        org.junit.Assert.assertNotNull(diagnosticType22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
//        org.junit.Assert.assertNull(checkLevel24);
//        org.junit.Assert.assertNotNull(diagnosticGroup25);
//        org.junit.Assert.assertNotNull(diagnosticType33);
//        org.junit.Assert.assertNotNull(strArray40);
//        org.junit.Assert.assertNotNull(jSError41);
//        org.junit.Assert.assertNotNull(strArray42);
//        org.junit.Assert.assertNotNull(jSError43);
//        org.junit.Assert.assertNotNull(runtimeException45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 32 + "'", int46 == 32);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int59 = node58.getChildCount();
        java.lang.Object obj61 = node58.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection62 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node58);
        com.google.javascript.rhino.Node node63 = node32.clonePropsFrom(node58);
        boolean boolean64 = node58.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node65 = node58.getLastSibling();
        java.util.Set<java.lang.String> strSet66 = node65.getDirectives();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNotNull(nodeCollection62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNull(strSet66);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        java.lang.String str58 = node15.toString(false, false, true);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "ERROR" + "'", str58.equals("ERROR"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy5 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions0.variableRenaming = variableRenamingPolicy5;
        compilerOptions0.prettyPrint = false;
        boolean boolean9 = compilerOptions0.tightenTypes;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy5 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy5.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.generatePseudoNames;
        java.lang.String str5 = compilerOptions0.reportPath;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions6.checkProvides;
        boolean boolean8 = compilerOptions6.lineBreak;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel15, diagnosticType16, strArray23);
        java.lang.String[] strArray25 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType16, strArray25);
        java.lang.Object obj27 = null;
        com.google.javascript.jscomp.SourceMap.Format format28 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        java.lang.RuntimeException runtimeException29 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSError26, obj27, (java.lang.Object) format28);
        compilerOptions6.sourceMapFormat = format28;
        compilerOptions0.sourceMapFormat = format28;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNotNull(format28);
        org.junit.Assert.assertNotNull(runtimeException29);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        java.lang.Object obj2 = context0.getDebuggerContextData();
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean18 = compilerOptions13.crossModuleCodeMotion;
        boolean boolean19 = compilerOptions13.inlineGetters;
        boolean boolean20 = compilerOptions13.devirtualizePrototypeMethods;
        boolean boolean21 = jSError12.equals((java.lang.Object) compilerOptions13);
        compilerOptions13.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        try {
            com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (byte) -1, nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        java.lang.Object obj5 = context1.getThreadLocal((java.lang.Object) diagnosticGroup4);
//        int int6 = context1.getOptimizationLevel();
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertNull(obj5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
        boolean boolean8 = compilerOptions5.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
        compilerOptions0.stripTypes = strSet9;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int59 = node58.getChildCount();
        java.lang.Object obj61 = node58.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection62 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node58);
        com.google.javascript.rhino.Node node63 = node32.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray78 = new com.google.javascript.rhino.Node[] { node68, node72, node77 };
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray78);
        int int80 = node79.getSideEffectFlags();
        boolean boolean81 = node79.wasEmptyNode();
        boolean boolean82 = node79.hasSideEffects();
        com.google.javascript.rhino.Node node86 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int87 = node86.getChildCount();
        node86.setCharno(0);
        boolean boolean90 = node86.isQuotedString();
        com.google.javascript.rhino.Node node91 = node79.clonePropsFrom(node86);
        int int92 = node79.getType();
        boolean boolean93 = node63.isEquivalentToTyped(node79);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNotNull(nodeCollection62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(nodeArray78);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(node91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean3 = node2.wasEmptyNode();
        java.lang.String[] strArray14 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        node2.setDirectives((java.util.Set<java.lang.String>) strSet15);
        int int18 = node2.getLineno();
        boolean boolean20 = node2.getBooleanProp(16);
        com.google.javascript.rhino.Node node21 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions22.checkProvides;
        compilerOptions22.aliasExternals = false;
        compilerOptions22.removeUnusedPrototypeProperties = false;
        byte[] byteArray30 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions22.inputPropertyMapSerialized = byteArray30;
        java.lang.String str32 = compilerOptions22.sourceMapOutputPath;
        compilerOptions22.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet34 = null;
        compilerOptions22.stripTypes = strSet34;
        boolean boolean36 = compilerOptions22.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel38 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions37.reportUnknownTypes = checkLevel38;
        compilerOptions37.extractPrototypeMemberDeclarations = false;
        boolean boolean42 = compilerOptions37.crossModuleCodeMotion;
        boolean boolean43 = compilerOptions37.inlineGetters;
        boolean boolean44 = compilerOptions37.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = compilerOptions37.checkShadowVars;
        compilerOptions22.checkRequires = checkLevel45;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention47 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj48 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention49 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean51 = defaultCodingConvention49.isExported("language version");
        java.lang.RuntimeException runtimeException52 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj48, (java.lang.Object) defaultCodingConvention49);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention53 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node59 = com.google.javascript.jscomp.NodeUtil.newExpr(node58);
        boolean boolean60 = defaultCodingConvention53.isOptionalParameter(node58);
        java.util.List<java.lang.String> strList61 = defaultCodingConvention49.identifyTypeDeclarationCall(node58);
        boolean boolean62 = closureCodingConvention47.isVarArgsParameter(node58);
        compilerOptions22.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention47);
        com.google.javascript.jscomp.CompilerOptions compilerOptions64 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel65 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions64.reportUnknownTypes = checkLevel65;
        compilerOptions64.extractPrototypeMemberDeclarations = false;
        boolean boolean69 = compilerOptions64.crossModuleCodeMotion;
        compilerOptions64.specializeInitialModule = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel72 = compilerOptions64.sourceMapDetailLevel;
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray88 = new com.google.javascript.rhino.Node[] { node78, node82, node87 };
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray88);
        int int90 = node89.getSideEffectFlags();
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node((-2), node89);
        boolean boolean92 = detailLevel72.apply(node89);
        java.lang.String str93 = closureCodingConvention47.identifyTypeDefAssign(node89);
        try {
            com.google.javascript.rhino.Node node96 = new com.google.javascript.rhino.Node(40, node2, node21, node89, 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(runtimeException52);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(strList61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(detailLevel72);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(nodeArray88);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNull(str93);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean18 = compilerOptions13.crossModuleCodeMotion;
        boolean boolean19 = compilerOptions13.inlineGetters;
        boolean boolean20 = compilerOptions13.devirtualizePrototypeMethods;
        boolean boolean21 = jSError12.equals((java.lang.Object) compilerOptions13);
        compilerOptions13.removeUnusedVars = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.setWarningLevel(diagnosticGroup24, checkLevel25);
        byte[] byteArray27 = compilerOptions13.inputPropertyMapSerialized;
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray27);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.reportUnknownTypes = checkLevel7;
        compilerOptions6.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions6.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.rewriteFunctionExpressions = false;
        compilerOptions0.unaliasableGlobals = "";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions8.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.reportMissingOverride;
        compilerOptions11.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions11.checkGlobalNamesLevel;
        compilerOptions8.aggressiveVarCheck = checkLevel18;
        compilerOptions0.reportMissingOverride = checkLevel18;
        boolean boolean21 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions0.checkProvides;
        boolean boolean23 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("goog.exportProperty");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions0.variableRenaming;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int5 = node4.getChildCount();
        node4.setCharno(0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection24 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node23);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node28.putBooleanProp(0, false);
        java.lang.String str32 = node23.checkTreeEquals(node28);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray47 = new com.google.javascript.rhino.Node[] { node37, node41, node46 };
        com.google.javascript.rhino.Node node48 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray47);
        int int49 = node48.getSideEffectFlags();
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray64 = new com.google.javascript.rhino.Node[] { node54, node58, node63 };
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray64);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection66 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node65);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray81 = new com.google.javascript.rhino.Node[] { node71, node75, node80 };
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray81);
        java.lang.String str86 = node82.toString(false, false, true);
        node48.addChildAfter(node65, node82);
        com.google.javascript.rhino.Node node91 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int92 = node91.getChildCount();
        java.lang.Object obj94 = node91.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection95 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node91);
        com.google.javascript.rhino.Node node96 = node65.clonePropsFrom(node91);
        com.google.javascript.rhino.jstype.JSType jSType97 = null;
        node96.setJSType(jSType97);
        try {
            com.google.javascript.rhino.Node node99 = new com.google.javascript.rhino.Node(30, node4, node23, node96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(nodeCollection24);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n" + "'", str32.equals("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n"));
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(nodeArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray64);
        org.junit.Assert.assertNotNull(nodeCollection66);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(nodeArray81);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "ERROR" + "'", str86.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNull(obj94);
        org.junit.Assert.assertNotNull(nodeCollection95);
        org.junit.Assert.assertNotNull(node96);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean2 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.instrumentForCoverageOnly = false;
        boolean boolean11 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.setDefineToDoubleLiteral("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", (double) 14);
        com.google.javascript.jscomp.CodingConvention codingConvention8 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(codingConvention8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean3 = node2.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention4 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean6 = defaultCodingConvention4.isConstant("hi!");
        boolean boolean8 = defaultCodingConvention4.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.jstype.FunctionType functionType9 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType10 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType11 = null;
        defaultCodingConvention4.applySubclassRelationship(functionType9, functionType10, subclassType11);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention13 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj14 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention15 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean17 = defaultCodingConvention15.isExported("language version");
        java.lang.RuntimeException runtimeException18 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj14, (java.lang.Object) defaultCodingConvention15);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention19 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node25 = com.google.javascript.jscomp.NodeUtil.newExpr(node24);
        boolean boolean26 = defaultCodingConvention19.isOptionalParameter(node24);
        java.util.List<java.lang.String> strList27 = defaultCodingConvention15.identifyTypeDeclarationCall(node24);
        boolean boolean28 = closureCodingConvention13.isVarArgsParameter(node24);
        boolean boolean29 = defaultCodingConvention4.isOptionalParameter(node24);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) 'a', "@IMPLEMENTATION.VERSION@", 0, 0);
        com.google.javascript.rhino.Node node35 = null;
        try {
            com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(27, node2, node24, node34, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(runtimeException18);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(strList27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node34);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        context0.removeActivationName("DiagnosticGroup<internetExplorerChecks>(ERROR)");
//        org.junit.Assert.assertNotNull(context0);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<deprecated>(null)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        boolean boolean7 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray15 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel7, diagnosticType8, strArray15);
        java.lang.String[] strArray17 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType8, strArray17);
        java.lang.RuntimeException runtimeException20 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError18, (java.lang.Object) 41);
        int int21 = jSError18.lineNumber;
        boolean boolean22 = diagnosticGroup0.matches(jSError18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = jSError18.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel24 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType23.level = checkLevel24;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(runtimeException20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        try {
            nodeTraversal7.traverseRoots(nodeArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.removeUnusedVars = true;
        com.google.javascript.jscomp.ErrorFormat errorFormat7 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        compilerOptions0.errorFormat = errorFormat7;
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertNotNull(errorFormat7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        java.lang.String str6 = compilerInput3.getLine(6);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceAst4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.closurePass;
        compilerOptions0.removeEmptyFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setTweakToNumberLiteral("Unknown class name", 6);
        compilerOptions0.setGenerateExports(false);
        com.google.javascript.jscomp.SourceMap.Format format8 = compilerOptions0.sourceMapFormat;
        java.lang.String str9 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.setTweakToNumberLiteral("com.google.javascript.rhino.EcmaError: hi!:  (#10)", 4095);
        org.junit.Assert.assertNotNull(format8);
        org.junit.Assert.assertNull(str9);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
//        boolean boolean4 = compilerOptions0.inlineGetters;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean8 = compilerOptions5.recordFunctionInformation;
//        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
//        compilerOptions0.stripTypes = strSet9;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup11;
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray24 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel16, diagnosticType17, strArray24);
//        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType17.defaultLevel;
//        compilerOptions0.setWarningLevel(diagnosticGroup11, checkLevel26);
//        byte[] byteArray28 = compilerOptions0.inputVariableMapSerialized;
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(strSet9);
//        org.junit.Assert.assertNotNull(diagnosticGroup11);
//        org.junit.Assert.assertNotNull(diagnosticType17);
//        org.junit.Assert.assertNotNull(strArray24);
//        org.junit.Assert.assertNotNull(jSError25);
//        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNull(byteArray28);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.aliasStringsBlacklist = "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n";
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.lineBreak = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = diagnosticType4.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = diagnosticType4.defaultLevel;
        java.text.MessageFormat messageFormat15 = diagnosticType4.format;
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(messageFormat15);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.details();
        java.lang.String str10 = ecmaError6.details();
        int int11 = ecmaError6.columnNumber();
        java.lang.String str12 = ecmaError6.toString();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!: " + "'", str9.equals("hi!: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!: " + "'", str10.equals("hi!: "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str12.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions0.reportUnknownTypes = checkLevel4;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.collapseProperties = false;
        boolean boolean10 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions11.checkProvides;
        compilerOptions11.crossModuleCodeMotion = true;
        java.lang.String str15 = compilerOptions11.syntheticBlockEndMarker;
        compilerOptions11.removeUnusedVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel18 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions11.sourceMapDetailLevel = detailLevel18;
        boolean boolean20 = compilerOptions11.checkSuspiciousCode;
        compilerOptions11.coalesceVariableNames = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions24.setCollapsePropertiesOnExternTypes(true);
        compilerOptions24.setTweakToNumberLiteral("Unknown class name", 6);
        compilerOptions24.setGenerateExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel33 = compilerOptions32.checkProvides;
        compilerOptions32.crossModuleCodeMotion = true;
        java.lang.String[] strArray37 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList38 = new java.util.ArrayList<java.lang.String>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList38, strArray37);
        compilerOptions32.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
        compilerOptions24.setManageClosureDependencies((java.util.List<java.lang.String>) strList38);
        compilerOptions11.setReplaceStringsConfiguration("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", (java.util.List<java.lang.String>) strList38);
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions43.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions43.optimizeReturns = true;
        boolean boolean48 = compilerOptions43.optimizeArgumentsArray;
        compilerOptions43.appNameStr = "ERROR";
        java.lang.RuntimeException runtimeException51 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) boolean10, (java.lang.Object) compilerOptions11, (java.lang.Object) compilerOptions43);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(detailLevel18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(runtimeException51);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test061");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        boolean boolean6 = context1.isGeneratingSource();
//        java.lang.Object obj8 = context1.getThreadLocal((java.lang.Object) (short) -1);
//        java.lang.Object obj9 = context1.getDebuggerContextData();
//        java.util.Locale locale10 = context1.getLocale();
//        try {
//            context1.setCompileFunctionsWithDynamicScope(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNull(obj8);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertNotNull(locale10);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            com.google.javascript.rhino.Context.reportWarning("com.google.javascript.rhino.EcmaError: hi!:  (#10)");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        com.google.javascript.rhino.Node node30 = node3.getLastChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node32 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean35 = defaultCodingConvention33.isConstant("hi!");
        com.google.javascript.rhino.Node node39 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention33, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship44 = defaultCodingConvention33.getDelegateRelationship(node43);
        try {
            node3.replaceChild(node32, node43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNull(delegateRelationship44);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        com.google.javascript.jscomp.Result result8 = compiler4.getResult();
        com.google.javascript.jscomp.Result result9 = compiler4.getResult();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertNotNull(result9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("null", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)", "goog.abstractMethod");
        java.io.Reader reader4 = sourceFile3.getCodeReader();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(reader4);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        int int3 = context1.getInstructionObserverThreshold();
//        int int4 = context1.getInstructionObserverThreshold();
//        context1.setLanguageVersion(0);
//        boolean boolean7 = context1.isGeneratingDebugChanged();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.recordFunctionInformation = false;
        boolean boolean7 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = true;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        com.google.javascript.rhino.jstype.JSType jSType61 = node16.getJSType();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNull(jSType61);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean2 = node1.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean5 = defaultCodingConvention3.isConstant("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention3, "language version", 160, (int) '4');
        boolean boolean10 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node11 = node1.copyInformationFromForTree(node9);
        com.google.javascript.rhino.Node node12 = node11.getNext();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, (int) (byte) 10, 0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo17 = node16.getJSDocInfo();
        try {
            com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(jSDocInfo17);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        boolean boolean5 = compilerOptions0.decomposeExpressions;
        compilerOptions0.optimizeArgumentsArray = false;
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean9 = node8.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention10 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean12 = defaultCodingConvention10.isConstant("hi!");
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention10, "language version", 160, (int) '4');
        boolean boolean17 = node16.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node18 = node8.copyInformationFromForTree(node16);
        int int19 = node18.getType();
        java.util.List<java.lang.String> strList20 = defaultCodingConvention0.identifyTypeDeclarationCall(node18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 40 + "'", int19 == 40);
        org.junit.Assert.assertNull(strList20);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType15.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel26;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler28 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.rhino.SourcePosition<com.google.javascript.jscomp.CompilerOptions.AliasTransformation> aliasTransformationSourcePosition30 = null;
        try {
            com.google.javascript.jscomp.CompilerOptions.AliasTransformation aliasTransformation31 = aliasTransformationHandler28.logAliasTransformation("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", aliasTransformationSourcePosition30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(aliasTransformationHandler28);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.ideMode = true;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.setTweakToDoubleLiteral("DiagnosticGroup<deprecated>(null)", (double) 3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        java.lang.String str20 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType25 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType21, objectType22, objectType23, functionType24, functionType25);
        boolean boolean28 = closureCodingConvention0.isSuperClassReference("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node20.putBooleanProp(0, false);
        java.lang.String str24 = node15.checkTreeEquals(node20);
        try {
            node20.setString("DiagnosticGroup<deprecated>(null)");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 10 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n" + "'", str24.equals("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.inlineVariables = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy9 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy9.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.collapseProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel6, diagnosticType7, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType7, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = jSError17.getType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = jSError17.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = jSError17.level;
        int int21 = jSError17.lineNumber;
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 32 + "'", int21 == 32);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean4 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray19 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel11, diagnosticType12, strArray19);
        java.lang.String[] strArray21 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType12, strArray21);
        java.lang.RuntimeException runtimeException24 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError22, (java.lang.Object) 41);
        int int25 = jSError22.lineNumber;
        com.google.javascript.jscomp.CheckLevel checkLevel26 = jSError22.level;
        compiler4.report(jSError22);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(runtimeException24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        compilerOptions0.smartNameRemoval = true;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions0.reportMissingOverride;
        boolean boolean12 = compilerOptions0.deadAssignmentElimination;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setCollapsePropertiesOnExternTypes(true);
        boolean boolean16 = compilerOptions13.inlineLocalFunctions;
        boolean boolean17 = compilerOptions13.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.setCollapsePropertiesOnExternTypes(true);
        boolean boolean21 = compilerOptions18.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet22 = compilerOptions18.aliasableStrings;
        compilerOptions13.stripTypes = strSet22;
        compilerOptions0.stripNameSuffixes = strSet22;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(strSet22);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        boolean boolean7 = defaultCodingConvention0.isOptionalParameter(node5);
        int int8 = node5.getSourcePosition();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable9 = node5.children();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        com.google.javascript.rhino.Node node12 = node5.copyInformationFrom(node11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node5.setJSType(jSType13);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable15 = node5.getAncestors();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(nodeIterable9);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(ancestorIterable15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(messageBundle9);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        java.lang.Object obj3 = null;
//        context1.seal(obj3);
//        java.lang.String str5 = context1.getImplementationVersion();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = node27.removeFirstChild();
        node27.removeProp(0);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("<unknown=-2>", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions5.reportUnknownTypes = checkLevel6;
        compilerOptions5.extractPrototypeMemberDeclarations = false;
        boolean boolean10 = compilerOptions5.crossModuleCodeMotion;
        boolean boolean11 = compilerOptions5.inlineGetters;
        boolean boolean12 = compilerOptions5.devirtualizePrototypeMethods;
        compilerOptions5.setShadowVariables(true);
        java.lang.String str15 = compilerOptions5.syntheticBlockStartMarker;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(logger16);
        double double18 = loggerErrorManager17.getTypedPercent();
        int int19 = loggerErrorManager17.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel26 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray34 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError35 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel26, diagnosticType27, strArray34);
        java.lang.String[] strArray36 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType27, strArray36);
        com.google.javascript.jscomp.CheckLevel checkLevel38 = diagnosticType27.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel45 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType46 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray53 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError54 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel45, diagnosticType46, strArray53);
        java.lang.String[] strArray55 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError56 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType46, strArray55);
        loggerErrorManager17.report(checkLevel38, jSError56);
        compilerOptions5.reportMissingOverride = checkLevel38;
        boolean boolean59 = compilerOptions5.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CompilerOptions compilerOptions60 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions60.setCollapsePropertiesOnExternTypes(true);
        boolean boolean63 = compilerOptions60.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel64 = compilerOptions60.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel65 = compilerOptions60.checkUndefinedProperties;
        compilerOptions5.checkGlobalThisLevel = checkLevel65;
        com.google.javascript.jscomp.CheckLevel checkLevel70 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray78 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError79 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel70, diagnosticType71, strArray78);
        loggerErrorManager1.println(checkLevel65, jSError79);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(jSError35);
        org.junit.Assert.assertNotNull(strArray36);
        org.junit.Assert.assertNotNull(jSError37);
        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType46);
        org.junit.Assert.assertNotNull(strArray53);
        org.junit.Assert.assertNotNull(jSError54);
        org.junit.Assert.assertNotNull(strArray55);
        org.junit.Assert.assertNotNull(jSError56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel65 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel65.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(jSError79);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        boolean boolean30 = node27.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node((int) (byte) 1, 0, 23);
        com.google.javascript.rhino.Node node35 = node27.copyInformationFromForTree(node34);
        com.google.javascript.rhino.Node node36 = node35.getParent();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkRequires = checkLevel4;
        java.util.List<java.lang.String> strList7 = null;
        try {
            compilerOptions0.setReplaceStringsConfiguration("", strList7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        int int12 = loggerErrorManager10.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.rhino.Node node15 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        com.google.javascript.jscomp.JSModule jSModule16 = null;
        try {
            java.lang.String[] strArray17 = compiler13.toSourceArray(jSModule16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = true;
        java.lang.Object obj8 = compilerOptions0.clone();
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler11, callback12);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        com.google.javascript.jscomp.JSModule jSModule16 = null;
        try {
            java.lang.String[] strArray17 = compiler11.toSourceArray(jSModule16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(messageFormatter15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isConstant("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention2, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship13 = defaultCodingConvention2.getDelegateRelationship(node12);
        com.google.javascript.rhino.Node node14 = null;
        try {
            node1.replaceChildAfter(node12, node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(delegateRelationship13);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        boolean boolean19 = node15.getBooleanProp(38);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.appNameStr = "ERROR";
        boolean boolean8 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.brokenClosureRequiresLevel;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup5;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup5;
        boolean boolean10 = diagnosticGroupWarningsGuard4.disables(diagnosticGroup5);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup11;
        boolean boolean13 = diagnosticGroupWarningsGuard4.disables(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
        boolean boolean8 = compilerOptions5.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
        compilerOptions0.stripTypes = strSet9;
        compilerOptions0.collapseProperties = false;
        boolean boolean13 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        java.io.PrintStream printStream3 = null;
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler(printStream3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback5);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] { node11, node15, node20 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray21);
        com.google.javascript.rhino.Node node23 = node22.cloneNode();
        node22.setOptionalArg(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType32 = com.google.javascript.jscomp.DiagnosticType.warning("hi!: ", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.jscomp.CheckLevel checkLevel36 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray44 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel36, diagnosticType37, strArray44);
        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)", 27, (int) ' ', diagnosticType32, strArray44);
        com.google.javascript.jscomp.JSError jSError47 = nodeTraversal6.makeError(node22, diagnosticType26, strArray44);
        com.google.javascript.jscomp.CheckLevel checkLevel54 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray62 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError63 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel54, diagnosticType55, strArray62);
        java.lang.String[] strArray64 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError65 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType55, strArray64);
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = jSError65.getType();
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray67 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType2, diagnosticType26, diagnosticType66 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup68 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray67);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup69 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray67);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(diagnosticType32);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(jSError46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(strArray62);
        org.junit.Assert.assertNotNull(jSError63);
        org.junit.Assert.assertNotNull(strArray64);
        org.junit.Assert.assertNotNull(jSError65);
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertNotNull(diagnosticTypeArray67);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.SourceMap.Format format9 = compilerOptions0.sourceMapFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(format9);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(110, "hi!");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        compilerOptions0.disambiguateProperties = false;
        boolean boolean9 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test107");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("ECMASCRIPT5");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ECMASCRIPT5");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        com.google.javascript.rhino.Node node30 = node3.getLastChild();
        try {
            node3.setDouble((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 10 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.jscomp.SourceMap sourceMap5 = compiler4.getSourceMap();
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler4.tracker;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray7 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule8 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray9 = new com.google.javascript.jscomp.JSModule[] { jSModule8 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.checkProvides;
        compilerOptions10.crossModuleCodeMotion = true;
        java.lang.String str14 = compilerOptions10.syntheticBlockEndMarker;
        compilerOptions10.setTweakToBooleanLiteral("", true);
        boolean boolean18 = compilerOptions10.foldConstants;
        byte[] byteArray19 = compilerOptions10.inputVariableMapSerialized;
        try {
            com.google.javascript.jscomp.Result result20 = compiler4.compile(jSSourceFileArray7, jSModuleArray9, compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(sourceMap5);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(jSSourceFileArray7);
        org.junit.Assert.assertNotNull(jSModuleArray9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(byteArray19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        boolean boolean7 = compilerOptions0.instrumentForCoverageOnly;
        java.lang.String str8 = compilerOptions0.syntheticBlockEndMarker;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test111");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
//        java.util.Set<java.lang.String> strSet3 = null;
//        compilerOptions1.stripNamePrefixes = strSet3;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions1.checkMissingGetCssNameLevel;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel5);
//        java.lang.String str7 = diagnosticGroupWarningsGuard6.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DiagnosticGroup<fileoverviewTags>(OFF)" + "'", str7.equals("DiagnosticGroup<fileoverviewTags>(OFF)"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder19.append("ECMASCRIPT5");
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.sourceName();
        java.lang.String str10 = ecmaError6.details();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!: " + "'", str10.equals("hi!: "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel6, diagnosticType7, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType7, strArray16);
        java.lang.Object obj18 = null;
        com.google.javascript.jscomp.SourceMap.Format format19 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        java.lang.RuntimeException runtimeException20 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSError17, obj18, (java.lang.Object) format19);
        int int21 = jSError17.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(format19);
        org.junit.Assert.assertNotNull(runtimeException20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        boolean boolean4 = diagnosticGroup2.matches(diagnosticType3);
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup2;
        com.google.javascript.rhino.Context context6 = null;
        com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter(context6);
        int int8 = context7.getLanguageVersion();
        long long9 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        java.lang.Object obj11 = context7.getThreadLocal((java.lang.Object) diagnosticGroup10);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup13 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup13;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup13;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup13;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray17 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup2, diagnosticGroup10, diagnosticGroup12, diagnosticGroup13 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = new com.google.javascript.jscomp.DiagnosticGroup("", diagnosticGroupArray17);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = new com.google.javascript.jscomp.DiagnosticGroup("TYPEOF", diagnosticGroupArray17);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(context7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(diagnosticGroup13);
        org.junit.Assert.assertNotNull(diagnosticGroupArray17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        int int18 = node16.getIntProp(10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(6, node16);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        int int10 = loggerErrorManager8.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker12 = compiler11.tracker;
        com.google.javascript.rhino.Node node13 = compilerInput6.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        int int19 = compiler18.getWarningCount();
        compiler18.reportCodeChange();
        compiler18.reportCodeChange();
        com.google.javascript.rhino.Node node22 = compilerInput6.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler18);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(performanceTracker12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", (int) (byte) 100, 140);
        java.lang.String str5 = defaultCodingConvention0.getGlobalObject();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "window" + "'", str5.equals("window"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("(Named type with empty name component)", "Not declared as a type name", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        int int17 = node16.getSideEffectFlags();
        boolean boolean18 = node16.wasEmptyNode();
        boolean boolean19 = node16.hasSideEffects();
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int24 = node23.getChildCount();
        node23.setCharno(0);
        boolean boolean27 = node23.isQuotedString();
        com.google.javascript.rhino.Node node28 = node16.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node29 = node28.removeFirstChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(18, node29, node33, 9, (int) ' ');
        java.lang.String str37 = node29.getQualifiedName();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.OFF;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        byte[] byteArray5 = compilerOptions0.inputPropertyMapSerialized;
        compilerOptions0.moveFunctionDeclarations = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.checkProvides;
        compilerOptions8.printInputDelimiter = false;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions8.checkRequires;
        compilerOptions0.checkUnreachableCode = checkLevel12;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isConstant("hi!");
        boolean boolean11 = defaultCodingConvention7.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.jstype.FunctionType functionType12 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType13 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType14 = null;
        defaultCodingConvention7.applySubclassRelationship(functionType12, functionType13, subclassType14);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7);
        java.lang.String str17 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions0.reportUnknownTypes = checkLevel4;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.optimizeCalls = true;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkShadowVars;
        compilerOptions0.setNameAnonymousFunctionsOnly(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("Not declared as a constructor", "null");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.collapseProperties = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy8 = compilerOptions0.variableRenaming;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy8.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        int int6 = node5.getSourcePosition();
        node5.setIsSyntheticBlock(true);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        boolean boolean14 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions15.reportUnknownTypes = checkLevel16;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        boolean boolean20 = compilerOptions15.crossModuleCodeMotion;
        boolean boolean21 = compilerOptions15.inlineGetters;
        boolean boolean22 = compilerOptions15.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions15.checkShadowVars;
        compilerOptions0.checkRequires = checkLevel23;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj26 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention27 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean29 = defaultCodingConvention27.isExported("language version");
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj26, (java.lang.Object) defaultCodingConvention27);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newExpr(node36);
        boolean boolean38 = defaultCodingConvention31.isOptionalParameter(node36);
        java.util.List<java.lang.String> strList39 = defaultCodingConvention27.identifyTypeDeclarationCall(node36);
        boolean boolean40 = closureCodingConvention25.isVarArgsParameter(node36);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention25);
        boolean boolean43 = closureCodingConvention25.isPrivate("@IMPLEMENTATION.VERSION@");
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection44 = closureCodingConvention25.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(strList39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection44);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean18 = compilerOptions13.crossModuleCodeMotion;
        boolean boolean19 = compilerOptions13.inlineGetters;
        boolean boolean20 = compilerOptions13.devirtualizePrototypeMethods;
        boolean boolean21 = jSError12.equals((java.lang.Object) compilerOptions13);
        compilerOptions13.removeUnusedVars = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.setWarningLevel(diagnosticGroup24, checkLevel25);
        boolean boolean27 = compilerOptions13.crossModuleCodeMotion;
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        int int7 = ecmaError6.getColumnNumber();
        java.lang.String str8 = ecmaError6.getLineSource();
        int int9 = ecmaError6.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            java.lang.String[] strArray7 = compiler4.toSourceArray(jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        boolean boolean7 = node3.isQuotedString();
        int int8 = node3.getType();
        node3.setIsSyntheticBlock(true);
        com.google.javascript.rhino.Node node11 = node3.removeFirstChild();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node15.putBooleanProp(0, false);
        com.google.javascript.rhino.Node node19 = node3.copyInformationFromForTree(node15);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable20 = node19.getAncestors();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(ancestorIterable20);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.checkTypedPropertyCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray19 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel11, diagnosticType12, strArray19);
        java.lang.String[] strArray21 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType12, strArray21);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = jSError22.getType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = jSError22.getType();
        com.google.javascript.jscomp.CheckLevel checkLevel25 = jSError22.level;
        compilerOptions0.checkUnreachableCode = checkLevel25;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.details();
        java.lang.String str10 = ecmaError6.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!: " + "'", str9.equals("hi!: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        compilerOptions0.aliasableGlobals = "ERROR";
        boolean boolean11 = compilerOptions0.generateExports;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkRequires;
        boolean boolean8 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        boolean boolean6 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        compilerOptions0.generateExports = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        com.google.javascript.jscomp.CodingConvention codingConvention6 = compilerOptions0.getCodingConvention();
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.setDefineToDoubleLiteral("DiagnosticGroup<internetExplorerChecks>(ERROR)", (-1.0d));
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        node27.removeProp(1);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) 'a', "@IMPLEMENTATION.VERSION@", 0, 0);
        node34.setQuotedString();
        com.google.javascript.rhino.Node node37 = node34.getAncestor(0);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int42 = node41.getChildCount();
        node41.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention45 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean47 = defaultCodingConvention45.isExported("language version");
        boolean boolean49 = defaultCodingConvention45.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray64 = new com.google.javascript.rhino.Node[] { node54, node58, node63 };
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray64);
        java.lang.String str66 = defaultCodingConvention45.getSingletonGetterClassName(node65);
        node41.addChildrenToBack(node65);
        com.google.javascript.rhino.Node node68 = node41.getLastChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder69 = node41.getJsDocBuilderForNode();
        java.lang.String str70 = node41.toStringTree();
        node27.addChildAfter(node34, node41);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(nodeArray64);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "EOF 10\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n" + "'", str70.equals("EOF 10\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel6, diagnosticType7, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType7, strArray16);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = jSError17.getType();
        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = jSError17.getType();
        int int20 = jSError17.lineNumber;
        boolean boolean22 = jSError17.equals((java.lang.Object) 13);
        java.lang.String str23 = jSError17.toString();
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(diagnosticType19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)" + "'", str23.equals("JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesGlobalState();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setThrows();
        sideEffectFlags1.setMutatesArguments();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean22 = defaultCodingConvention20.isConstant("hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention20, "language version", 160, (int) '4');
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node28 = node18.copyInformationFromForTree(node26);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node26);
        java.lang.String str30 = closureCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "goog.exportSymbol" + "'", str30.equals("goog.exportSymbol"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = false;
        compilerOptions0.setTweakToNumberLiteral("goog.exportSymbol", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkRequires = checkLevel4;
        boolean boolean6 = compilerOptions0.foldConstants;
        boolean boolean7 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        jSSourceFile29.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        jSSourceFile29.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
        com.google.javascript.rhino.Node node36 = compiler4.parse(jSSourceFile29);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker37 = compiler4.tracker;
        com.google.javascript.rhino.Node node38 = compiler4.getRoot();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertNull(performanceTracker37);
        org.junit.Assert.assertNull(node38);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.enableRuntimeTypeCheck("@IMPLEMENTATION.VERSION@");
        compilerOptions0.setTweakToNumberLiteral("Not declared as a constructor", 160);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        java.lang.String str20 = closureCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.jstype.ObjectType objectType21 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType24 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType25 = null;
        closureCodingConvention0.applyDelegateRelationship(objectType21, objectType22, objectType23, functionType24, functionType25);
        boolean boolean28 = closureCodingConvention0.isPrivate("language version");
        java.lang.String str29 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "goog.abstractMethod" + "'", str29.equals("goog.abstractMethod"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node24, node28, node33 };
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray34);
        int int37 = node35.getIntProp(10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        int int54 = node53.getSideEffectFlags();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node59, node63, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray69);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection71 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node70);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray86 = new com.google.javascript.rhino.Node[] { node76, node80, node85 };
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray86);
        java.lang.String str91 = node87.toString(false, false, true);
        node53.addChildAfter(node70, node87);
        java.lang.String str93 = closureCodingConvention0.extractClassNameIfRequire(node35, node70);
        boolean boolean95 = closureCodingConvention0.isSuperClassReference("ECMASCRIPT5");
        java.lang.String str96 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(nodeCollection71);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(nodeArray86);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "ERROR" + "'", str91.equals("ERROR"));
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "goog.abstractMethod" + "'", str96.equals("goog.abstractMethod"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        boolean boolean7 = defaultCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        int int24 = node23.getSideEffectFlags();
        boolean boolean25 = node23.wasEmptyNode();
        boolean boolean26 = node23.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder27 = node23.new FileLevelJsDocBuilder();
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship28 = defaultCodingConvention0.getDelegateRelationship(node23);
        java.lang.String str29 = defaultCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(delegateRelationship28);
        org.junit.Assert.assertNull(str29);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        compilerOptions0.setChainCalls(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        int int12 = loggerErrorManager10.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.rhino.Node node15 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        jsAst8.clearAst();
        com.google.javascript.jscomp.ErrorFormat errorFormat17 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        java.util.logging.Logger logger18 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager19 = new com.google.javascript.jscomp.LoggerErrorManager(logger18);
        double double20 = loggerErrorManager19.getTypedPercent();
        int int21 = loggerErrorManager19.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler22 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager19);
        java.nio.charset.Charset charset24 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset24);
        java.nio.charset.Charset charset27 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset27);
        com.google.javascript.jscomp.CompilerInput compilerInput29 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile25, jSSourceFile28 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList31 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList31, jSSourceFileArray30);
        com.google.javascript.jscomp.JSModule[] jSModuleArray33 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList34 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList34, jSModuleArray33);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph36 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList34);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions37.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean40 = compilerOptions37.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel41 = compilerOptions37.reportMissingOverride;
        boolean boolean42 = compilerOptions37.markNoSideEffectCalls;
        compiler22.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList31, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList34, compilerOptions37);
        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel45 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions44.reportUnknownTypes = checkLevel45;
        compilerOptions44.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions44.markAsCompiled = false;
        compilerOptions44.setRemoveAbstractMethods(true);
        boolean boolean53 = compilerOptions44.markAsCompiled;
        compilerOptions44.setNameAnonymousFunctionsOnly(false);
        compiler22.initOptions(compilerOptions44);
        com.google.javascript.jscomp.MessageFormatter messageFormatter58 = errorFormat17.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler22, true);
        com.google.javascript.rhino.Node node59 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler22);
        jsAst8.clearAst();
        com.google.javascript.jscomp.SourceFile sourceFile61 = null;
        try {
            jsAst8.setSourceFile(sourceFile61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(errorFormat17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile25);
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jSModuleArray33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + checkLevel41 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel41.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + checkLevel45 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel45.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(messageFormatter58);
        org.junit.Assert.assertNull(node59);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        jSSourceFile10.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        jSSourceFile10.setOriginalPath("null");
        java.lang.String str16 = jSSourceFile10.getName();
        java.lang.String str17 = jSSourceFile10.getOriginalPath();
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset19);
        java.nio.charset.Charset charset22 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset22);
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23);
        java.lang.String str25 = jSSourceFile23.getOriginalPath();
        java.lang.String str26 = jSSourceFile23.toString();
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset28);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile10, jSSourceFile20, jSSourceFile23, jSSourceFile29 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray31 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions32.collapseVariableDeclarations = false;
        com.google.javascript.jscomp.MessageBundle messageBundle37 = null;
        compilerOptions32.messageBundle = messageBundle37;
        compilerOptions32.setCollapsePropertiesOnExternTypes(true);
        compiler4.init(jSSourceFileArray30, jSModuleArray31, compilerOptions32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "null" + "'", str17.equals("null"));
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNotNull(jSModuleArray31);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        boolean boolean14 = compilerOptions0.flowSensitiveInlineVariables;
        compilerOptions0.generatePseudoNames = false;
        boolean boolean17 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int11 = node10.getChildCount();
        com.google.javascript.rhino.Node node12 = node10.getLastChild();
        java.lang.String str13 = defaultCodingConvention0.identifyTypeDefAssign(node12);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.rhino.Node node19 = compiler18.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback20);
        int int22 = nodeTraversal21.getLineNumber();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        int int40 = node38.getIntProp(10);
        int int41 = node38.getSourcePosition();
        boolean boolean42 = node38.hasMoreThanOneChild();
        boolean boolean43 = node38.isQualifiedName();
        com.google.javascript.rhino.Node node44 = null;
        com.google.javascript.rhino.Node node45 = node38.getChildBefore(node44);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast46 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal21, node45);
        boolean boolean47 = nodeTraversal21.hasScope();
        java.lang.String str48 = nodeTraversal21.getSourceName();
        java.lang.String str49 = nodeTraversal21.getSourceName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(objectLiteralCast46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention0.getDelegateRelationship(node10);
        java.lang.String str15 = node10.toString(false, false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "EOF" + "'", str15.equals("EOF"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        double double5 = loggerErrorManager4.getTypedPercent();
        int int6 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node15, node19, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray25);
        com.google.javascript.rhino.Node node27 = node26.cloneNode();
        boolean boolean28 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        int int45 = node44.getSideEffectFlags();
        boolean boolean46 = node44.wasEmptyNode();
        java.lang.String str47 = node44.toString();
        boolean boolean48 = node44.isOptionalArg();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node53, node57, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray63);
        java.lang.String str68 = node64.toString(false, false, true);
        node26.addChildAfter(node44, node64);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal10, node44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = null;
        com.google.javascript.jscomp.Scope scope72 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray73 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList74, objectTypeArray73);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry71, scope72, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList74);
        java.lang.String str77 = defaultCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR 0" + "'", str47.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR" + "'", str68.equals("ERROR"));
        org.junit.Assert.assertNull(objectLiteralCast70);
        org.junit.Assert.assertNotNull(objectTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(str77);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("DiagnosticGroup<fileoverviewTags>(null)", generator1);
        com.google.javascript.jscomp.JsAst jsAst3 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int59 = node58.getChildCount();
        java.lang.Object obj61 = node58.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection62 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node58);
        com.google.javascript.rhino.Node node63 = node32.clonePropsFrom(node58);
        boolean boolean64 = node63.isVarArgs();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int69 = node68.getChildCount();
        java.lang.Object obj71 = node68.getProp(0);
        com.google.javascript.rhino.Node node72 = node63.copyInformationFrom(node68);
        com.google.javascript.rhino.Node node73 = node63.getFirstChild();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNotNull(nodeCollection62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNull(obj71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(0.0d, 0, (int) '#');
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) diagnosticType3);
        com.google.javascript.jscomp.CheckLevel checkLevel5 = diagnosticType3.defaultLevel;
        java.lang.String[] strArray12 = new java.lang.String[] { "DiagnosticGroup<fileoverviewTags>(OFF)", "goog.exportProperty", "DiagnosticGroup<strictModuleDepCheck>(null)", "DiagnosticGroup<strictModuleDepCheck>(null)", "goog.exportProperty", "DiagnosticGroup<fileoverviewTags>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(OFF)" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", 120, 120, diagnosticType3, strArray12);
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str4.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test166");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        int int3 = context1.getInstructionObserverThreshold();
//        boolean boolean4 = context1.isGeneratingDebugChanged();
//        context1.setInstructionObserverThreshold(16);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        boolean boolean2 = closureCodingConvention0.isSuperClassReference("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)");
        java.lang.String str3 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "goog.exportProperty" + "'", str3.equals("goog.exportProperty"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int11 = node10.getChildCount();
        com.google.javascript.rhino.Node node12 = node10.getLastChild();
        java.lang.String str13 = defaultCodingConvention0.identifyTypeDefAssign(node12);
        java.lang.String str14 = defaultCodingConvention0.getDelegateSuperclassName();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node19);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node25, node29, node34 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray35);
        com.google.javascript.rhino.Node node37 = node36.cloneNode();
        node20.addChildrenToBack(node36);
        node20.putIntProp(15, 41);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship42 = defaultCodingConvention0.getDelegateRelationship(node20);
        boolean boolean44 = defaultCodingConvention0.isPrivate("");
        java.lang.String str45 = defaultCodingConvention0.getExportSymbolFunction();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection46 = defaultCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(delegateRelationship42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection46);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "EOF 10\n");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        int int5 = compiler4.getWarningCount();
        compiler4.reportCodeChange();
        compiler4.disableThreads();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean8 = compilerOptions0.exportTestFunctions;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        compilerOptions0.convertToDottedProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions11.syntheticBlockStartMarker = "ERROR 0";
        byte[] byteArray16 = compilerOptions11.inputPropertyMapSerialized;
        java.lang.RuntimeException runtimeException17 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) false, (java.lang.Object) byteArray16);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray16);
        org.junit.Assert.assertNotNull(runtimeException17);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Named type with empty name component", "ERROR 0");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("window", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.aliasableGlobals = "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n";
        java.lang.String str10 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean11 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.aliasExternals = false;
        boolean boolean14 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        int int12 = loggerErrorManager10.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.rhino.Node node15 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        jsAst8.clearAst();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        jSSourceFile19.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        jSSourceFile19.setOriginalPath("null");
        jsAst8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile19);
        jsAst8.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
        try {
            java.lang.String str6 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceAst4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        int int2 = ecmaError1.lineNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 18, 38);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 38.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = context1.getErrorReporter();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
//        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) diagnosticGroup3);
//        context1.setCompileFunctionsWithDynamicScope(false);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter2);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertNull(obj4);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test182");
//        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean3 = compilerOptions0.recordFunctionInformation;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
//        compilerOptions0.reportMissingOverride = checkLevel5;
//        compilerOptions0.inlineConstantVars = true;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions9.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean12 = compilerOptions9.inlineLocalFunctions;
//        boolean boolean13 = compilerOptions9.inlineGetters;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions14.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean17 = compilerOptions14.recordFunctionInformation;
//        java.util.Set<java.lang.String> strSet18 = compilerOptions14.aliasableStrings;
//        compilerOptions9.stripTypes = strSet18;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup20;
//        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray33 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel25, diagnosticType26, strArray33);
//        com.google.javascript.jscomp.CheckLevel checkLevel35 = diagnosticType26.defaultLevel;
//        compilerOptions9.setWarningLevel(diagnosticGroup20, checkLevel35);
//        compilerOptions0.checkUndefinedProperties = checkLevel35;
//        boolean boolean38 = compilerOptions0.checkCaja;
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(strSet18);
//        org.junit.Assert.assertNotNull(diagnosticGroup20);
//        org.junit.Assert.assertNotNull(diagnosticType26);
//        org.junit.Assert.assertNotNull(strArray33);
//        org.junit.Assert.assertNotNull(jSError34);
//        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        boolean boolean9 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.coalesceVariableNames = false;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap12 = compilerOptions0.getTweakReplacements();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strMap12);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.removeDeadCode;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        java.lang.String str5 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.setAcceptConstKeyword(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        com.google.javascript.rhino.Node node30 = node27.cloneNode();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(node30);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        int int3 = context1.getInstructionObserverThreshold();
//        boolean boolean4 = context1.isSealed();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean7 = compilerOptions6.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions6.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard9 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel8);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel11);
//        java.lang.String str13 = diagnosticGroupWarningsGuard12.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean16 = compilerOptions15.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions15.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard18 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel17);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard21 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup19, checkLevel20);
//        java.lang.String str22 = diagnosticGroupWarningsGuard21.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup23 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions24 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean25 = compilerOptions24.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions24.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard27 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup23, checkLevel26);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray28 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard9, diagnosticGroupWarningsGuard12, diagnosticGroupWarningsGuard18, diagnosticGroupWarningsGuard21, diagnosticGroupWarningsGuard27 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard29 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray28);
//        java.lang.String str30 = composeWarningsGuard29.toString();
//        java.lang.String str31 = composeWarningsGuard29.toString();
//        java.lang.String str32 = composeWarningsGuard29.toString();
//        java.lang.String str33 = composeWarningsGuard29.toString();
//        context1.removeThreadLocal((java.lang.Object) str33);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNull(diagnosticGroup10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "null(null)" + "'", str13.equals("null(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNull(diagnosticGroup19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "null(null)" + "'", str22.equals("null(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(warningsGuardArray28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)" + "'", str30.equals("DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)" + "'", str31.equals("DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)"));
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)" + "'", str32.equals("DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)" + "'", str33.equals("DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF), null(null), DiagnosticGroup<fileoverviewTags>(OFF)"));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        boolean boolean7 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.syntheticBlockEndMarker = "language version";
        boolean boolean10 = compilerOptions0.checkTypedPropertyCalls;
        compilerOptions0.checkCaja = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(20);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.instrumentForCoverageOnly = false;
        compilerOptions0.setDefineToStringLiteral("hi!", "Named type with empty name component");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel5, diagnosticType6, strArray13);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = diagnosticType6.defaultLevel;
        boolean boolean16 = diagnosticGroup0.matches(diagnosticType6);
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.rhino.Node node7 = node3.cloneTree();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.setTweakToBooleanLiteral("", true);
        compilerOptions0.unaliasableGlobals = "ERROR";
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy10 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy10;
        compilerOptions0.rewriteFunctionExpressions = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy10 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy10.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        boolean boolean3 = compilerOptions0.inlineGetters;
        boolean boolean4 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        boolean boolean17 = node15.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node22, node26, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray32);
        int int34 = node33.getSideEffectFlags();
        boolean boolean35 = node33.wasEmptyNode();
        java.lang.String str36 = node33.toString();
        boolean boolean37 = node33.isOptionalArg();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        java.lang.String str57 = node53.toString(false, false, true);
        node15.addChildAfter(node33, node53);
        java.lang.Class<?> wildcardClass59 = node15.getClass();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ERROR 0" + "'", str36.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "ERROR" + "'", str57.equals("ERROR"));
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<internetExplorerChecks>", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        boolean boolean6 = compilerOptions0.rewriteFunctionExpressions;
        compilerOptions0.ignoreCajaProperties = false;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        java.lang.String str6 = compilerOptions0.inputDelimiter;
        java.lang.String str7 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = compilerOptions0.sourceMapDetailLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "// Input %num%" + "'", str6.equals("// Input %num%"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(detailLevel8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.debugFunctionSideEffectsPath = "@IMPLEMENTATION.VERSION@";
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getErrorMessage();
        java.lang.String str8 = ecmaError6.getErrorMessage();
        java.lang.String str9 = ecmaError6.getSourceName();
        int int10 = ecmaError6.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("language version");
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0, (java.lang.Object) defaultCodingConvention1);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        boolean boolean12 = defaultCodingConvention5.isOptionalParameter(node10);
        java.util.List<java.lang.String> strList13 = defaultCodingConvention1.identifyTypeDeclarationCall(node10);
        com.google.javascript.rhino.Node node14 = node10.removeChildren();
        try {
            node14.setVarArgs(false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(runtimeException4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strList13);
        org.junit.Assert.assertNull(node14);
    }
}

