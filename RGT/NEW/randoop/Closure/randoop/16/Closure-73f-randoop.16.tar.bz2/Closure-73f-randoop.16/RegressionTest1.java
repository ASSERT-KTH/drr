import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getLanguageVersion();
        context1.seal((java.lang.Object) 100);
        try {
            context1.setLanguageVersion(25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("language version");
        boolean boolean4 = defaultCodingConvention0.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        java.lang.String str21 = defaultCodingConvention0.getSingletonGetterClassName(node20);
        node20.removeProp((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = node20.cloneTree();
        int int25 = node20.getCharno();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean18 = compilerOptions13.crossModuleCodeMotion;
        boolean boolean19 = compilerOptions13.inlineGetters;
        boolean boolean20 = compilerOptions13.devirtualizePrototypeMethods;
        boolean boolean21 = jSError12.equals((java.lang.Object) compilerOptions13);
        boolean boolean22 = compilerOptions13.shouldColorizeErrorOutput();
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.aliasStringsBlacklist = "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n";
        boolean boolean8 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.ambiguateProperties = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setTweakToNumberLiteral("Unknown class name", 6);
        compilerOptions0.setGenerateExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions8.checkProvides;
        compilerOptions8.crossModuleCodeMotion = true;
        java.lang.String[] strArray13 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList14 = new java.util.ArrayList<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList14, strArray13);
        compilerOptions8.setManageClosureDependencies((java.util.List<java.lang.String>) strList14);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList14);
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap18 = compilerOptions0.getDefineReplacements();
        compilerOptions0.inferTypesInGlobalScope = false;
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strMap18);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean5 = defaultCodingConvention3.isSuperClassReference("EOF 10\n");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship14 = defaultCodingConvention3.getDelegateRelationship(node11);
        try {
            com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(0, node2, node11, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(delegateRelationship14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        compilerOptions0.setLooseTypes(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        int int8 = nodeTraversal7.getLineNumber();
        com.google.javascript.jscomp.Scope scope9 = nodeTraversal7.getScope();
        java.lang.String str10 = nodeTraversal7.getSourceName();
        try {
            com.google.javascript.rhino.Node node11 = nodeTraversal7.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(scope9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(48);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        java.lang.String str5 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.locale = "DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        java.lang.String str61 = node22.getQualifiedName();
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((int) ' ');
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention64 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean66 = defaultCodingConvention64.isConstant("hi!");
        com.google.javascript.rhino.Node node70 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention64, "language version", 160, (int) '4');
        boolean boolean71 = node70.isOnlyModifiesThisCall();
        int int72 = node70.getChildCount();
        try {
            node22.replaceChild(node63, node70);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing6 = compilerOptions0.getTweakProcessing();
        boolean boolean7 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing6.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        int int10 = loggerErrorManager8.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker12 = compiler11.tracker;
        com.google.javascript.rhino.Node node13 = compilerInput6.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        java.util.List<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.setCollapsePropertiesOnExternTypes(true);
        boolean boolean23 = compilerOptions20.recordFunctionInformation;
        java.lang.String str24 = compilerOptions20.sourceMapOutputPath;
        try {
            compiler11.initModules(jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(performanceTracker12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] { node10, node14, node19 };
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray20);
        com.google.javascript.rhino.Node node22 = node21.cloneNode();
        node5.addChildrenToBack(node21);
        com.google.javascript.rhino.Node node25 = node5.getAncestor(15);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNull(node25);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(true);
        boolean boolean10 = compilerOptions0.collapseVariableDeclarations;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = compilerOptions0.sourceMapDetailLevel;
        boolean boolean9 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)" + "'", str1.equals("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.inlineVariables = false;
        boolean boolean9 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("<No stack trace available>", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        compilerOptions0.setOutputCharset("language version");
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions26.reportUnknownTypes = checkLevel27;
        compilerOptions26.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions26.markAsCompiled = false;
        compilerOptions26.setRemoveAbstractMethods(true);
        boolean boolean35 = compilerOptions26.markAsCompiled;
        compilerOptions26.setNameAnonymousFunctionsOnly(false);
        compiler4.initOptions(compilerOptions26);
        java.util.logging.Logger logger39 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager40 = new com.google.javascript.jscomp.LoggerErrorManager(logger39);
        double double41 = loggerErrorManager40.getTypedPercent();
        com.google.javascript.jscomp.CompilerOptions compilerOptions42 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean43 = compilerOptions42.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions42.checkShadowVars;
        com.google.javascript.jscomp.CheckLevel checkLevel51 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray59 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError60 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel51, diagnosticType52, strArray59);
        java.lang.String[] strArray61 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError62 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType52, strArray61);
        loggerErrorManager40.println(checkLevel44, jSError62);
        compiler4.report(jSError62);
        java.nio.charset.Charset charset66 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile67 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset66);
        java.lang.String str68 = jSSourceFile67.getName();
        com.google.javascript.jscomp.JSModule[] jSModuleArray69 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions70 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions70.setCollapsePropertiesOnExternTypes(true);
        boolean boolean73 = compilerOptions70.recordFunctionInformation;
        compilerOptions70.reserveRawExports = true;
        compilerOptions70.setOutputCharset("null");
        compilerOptions70.setCollapsePropertiesOnExternTypes(true);
        compilerOptions70.setProcessObjectPropertyString(true);
        try {
            com.google.javascript.jscomp.Result result82 = compiler4.compile(jSSourceFile67, jSModuleArray69, compilerOptions70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertNotNull(strArray59);
        org.junit.Assert.assertNotNull(jSError60);
        org.junit.Assert.assertNotNull(strArray61);
        org.junit.Assert.assertNotNull(jSError62);
        org.junit.Assert.assertNotNull(jSSourceFile67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
        org.junit.Assert.assertNotNull(jSModuleArray69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.setOutputCharset("null");
        boolean boolean8 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.syntheticBlockStartMarker = "Not declared as a constructor";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node34 = null;
        try {
            java.lang.String str35 = closureCodingConvention0.extractClassNameIfRequire(node32, node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        boolean boolean26 = compilerOptions19.recordFunctionInformation;
        boolean boolean27 = compilerOptions19.lineBreak;
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        int int3 = context1.getInstructionObserverThreshold();
//        context1.addActivationName("@IMPLEMENTATION.VERSION@");
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("language version");
        boolean boolean4 = defaultCodingConvention0.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        java.lang.String str21 = defaultCodingConvention0.getSingletonGetterClassName(node20);
        com.google.javascript.rhino.Node node22 = node20.getParent();
        try {
            com.google.javascript.rhino.Node node23 = node22.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(node22);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        java.lang.String[] strArray20 = new java.lang.String[] { "language version", "ERROR 0", "hi!", "" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        node15.setDirectives((java.util.Set<java.lang.String>) strSet21);
        boolean boolean24 = node15.isLocalResultCall();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        boolean boolean27 = compiler4.acceptConstKeyword();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "hi!");
        java.nio.charset.Charset charset32 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile33 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset32);
        jSSourceFile33.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput36 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile33);
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput36);
        java.util.logging.Logger logger38 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager39 = new com.google.javascript.jscomp.LoggerErrorManager(logger38);
        double double40 = loggerErrorManager39.getTypedPercent();
        int int41 = loggerErrorManager39.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler42 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager39);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker43 = compiler42.tracker;
        com.google.javascript.rhino.Node node44 = compilerInput37.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler42);
        java.nio.charset.Charset charset46 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset46);
        com.google.javascript.jscomp.CompilerInput compilerInput48 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47);
        java.lang.String str49 = jSSourceFile47.getOriginalPath();
        java.lang.String str50 = jSSourceFile47.toString();
        java.nio.charset.Charset charset52 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset52);
        jSSourceFile53.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromCode("com.google.javascript.rhino.EcmaError: hi!:  (#10)", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        java.nio.charset.Charset charset59 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile60 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset59);
        jSSourceFile60.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput63 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile60);
        jSSourceFile60.setOriginalPath("null");
        java.lang.String str66 = jSSourceFile60.getName();
        java.nio.charset.Charset charset68 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile69 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset68);
        jSSourceFile69.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput72 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile69);
        jSSourceFile69.setOriginalPath("null");
        java.lang.String str75 = jSSourceFile69.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray76 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile47, jSSourceFile53, jSSourceFile57, jSSourceFile60, jSSourceFile69 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray77 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions78 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions78.setCollapsePropertiesOnExternTypes(true);
        boolean boolean81 = compilerOptions78.recordFunctionInformation;
        compilerOptions78.collapseVariableDeclarations = true;
        byte[] byteArray84 = null;
        compilerOptions78.inputVariableMapSerialized = byteArray84;
        compiler42.init(jSSourceFileArray76, jSSourceFileArray77, compilerOptions78);
        com.google.javascript.jscomp.CompilerOptions compilerOptions87 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean88 = compilerOptions87.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel89 = compilerOptions87.checkShadowVars;
        boolean boolean90 = compilerOptions87.removeUnusedLocalVars;
        boolean boolean91 = compilerOptions87.generatePseudoNames;
        try {
            com.google.javascript.jscomp.Result result92 = compiler4.compile(jSSourceFile30, jSSourceFileArray77, compilerOptions87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFile33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNull(performanceTracker43);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertNotNull(jSSourceFile60);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile69);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray76);
        org.junit.Assert.assertNotNull(jSSourceFileArray77);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + checkLevel89 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel89.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = context1.getErrorReporter();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        java.lang.Object obj4 = context1.getThreadLocal((java.lang.Object) diagnosticGroup3);
        boolean boolean6 = context1.isActivationNeeded("JSC_NODE_TRAVERSAL_ERROR: {0}");
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(errorReporter2);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.reportUnknownTypes = checkLevel7;
        compilerOptions6.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions6.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean16 = compilerOptions0.convertToDottedProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        boolean boolean5 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("language version");
        boolean boolean5 = defaultCodingConvention1.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] { node10, node14, node19 };
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray20);
        java.lang.String str22 = defaultCodingConvention1.getSingletonGetterClassName(node21);
        node21.removeProp((int) (byte) 0);
        com.google.javascript.rhino.Node node25 = node21.getLastChild();
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node31, node35, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray41);
        com.google.javascript.rhino.Node node43 = node42.cloneNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node52 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray53 = new com.google.javascript.rhino.Node[] { node42, node48, node52 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node(33, nodeArray53, (int) (byte) 0, 10);
        boolean boolean57 = node56.hasChildren();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean60 = node59.wasEmptyNode();
        java.lang.String[] strArray71 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet72 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet72, strArray71);
        node59.setDirectives((java.util.Set<java.lang.String>) strSet72);
        com.google.javascript.rhino.Node node75 = node56.copyInformationFrom(node59);
        com.google.javascript.rhino.Node node76 = node56.getNext();
        try {
            com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node(14, node21, node76, 33, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNull(node76);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "or" + "'", str1.equals("or"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(130);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("Not declared as a constructor", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)");
        sourceFile2.setOriginalPath("");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean9 = compilerOptions0.markAsCompiled;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing12 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean13 = tweakProcessing12.shouldStrip();
        compilerOptions0.setTweakProcessing(tweakProcessing12);
        compilerOptions0.lineLengthThreshold(16);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing12 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing12.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        java.lang.Object obj29 = node15.getProp(48);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNull(obj29);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        com.google.javascript.rhino.Node node17 = node16.cloneNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node16, node22, node26 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(33, nodeArray27, (int) (byte) 0, 10);
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean34 = node33.wasEmptyNode();
        java.lang.String[] strArray45 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet46 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet46, strArray45);
        node33.setDirectives((java.util.Set<java.lang.String>) strSet46);
        com.google.javascript.rhino.Node node49 = node30.copyInformationFrom(node33);
        boolean boolean50 = node33.hasChildren();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str4 = jSSourceFile2.getOriginalPath();
        java.lang.String str5 = jSSourceFile2.toString();
        jSSourceFile2.setOriginalPath("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        java.lang.String str8 = jSSourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.setCollapsePropertiesOnExternTypes(true);
        boolean boolean10 = compilerOptions7.recordFunctionInformation;
        compilerOptions7.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy13 = compilerOptions7.variableRenaming;
        compilerOptions0.variableRenaming = variableRenamingPolicy13;
        java.lang.String str15 = compilerOptions0.unaliasableGlobals;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy13 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy13.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        boolean boolean1 = tweakProcessing0.shouldStrip();
        boolean boolean2 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("language version");
        boolean boolean4 = defaultCodingConvention0.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        java.lang.String str21 = defaultCodingConvention0.getSingletonGetterClassName(node20);
        node20.removeProp((int) (byte) 0);
        com.google.javascript.rhino.Node node24 = node20.cloneTree();
        boolean boolean25 = node24.isVarArgs();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("or", ": com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        compilerOptions0.locale = "EOF 10\n";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        int int10 = loggerErrorManager8.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker12 = compiler11.tracker;
        com.google.javascript.rhino.Node node13 = compilerInput6.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        java.lang.String str18 = jSSourceFile16.getOriginalPath();
        java.lang.String str19 = jSSourceFile16.toString();
        java.nio.charset.Charset charset21 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile22 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset21);
        jSSourceFile22.clearCachedSource();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromCode("com.google.javascript.rhino.EcmaError: hi!:  (#10)", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        jSSourceFile29.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        jSSourceFile29.setOriginalPath("null");
        java.lang.String str35 = jSSourceFile29.getName();
        java.nio.charset.Charset charset37 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile38 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset37);
        jSSourceFile38.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile38);
        jSSourceFile38.setOriginalPath("null");
        java.lang.String str44 = jSSourceFile38.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray45 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile16, jSSourceFile22, jSSourceFile26, jSSourceFile29, jSSourceFile38 };
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray46 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.setCollapsePropertiesOnExternTypes(true);
        boolean boolean50 = compilerOptions47.recordFunctionInformation;
        compilerOptions47.collapseVariableDeclarations = true;
        byte[] byteArray53 = null;
        compilerOptions47.inputVariableMapSerialized = byteArray53;
        compiler11.init(jSSourceFileArray45, jSSourceFileArray46, compilerOptions47);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray56 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray57 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.logging.Logger logger58 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager59 = new com.google.javascript.jscomp.LoggerErrorManager(logger58);
        double double60 = loggerErrorManager59.getTypedPercent();
        int int61 = loggerErrorManager59.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler62 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager59);
        java.nio.charset.Charset charset64 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile65 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset64);
        java.nio.charset.Charset charset67 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile68 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset67);
        com.google.javascript.jscomp.CompilerInput compilerInput69 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile68);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray70 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile65, jSSourceFile68 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList71 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean72 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList71, jSSourceFileArray70);
        com.google.javascript.jscomp.JSModule[] jSModuleArray73 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList74 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList74, jSModuleArray73);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph76 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList74);
        com.google.javascript.jscomp.CompilerOptions compilerOptions77 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions77.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean80 = compilerOptions77.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel81 = compilerOptions77.reportMissingOverride;
        boolean boolean82 = compilerOptions77.markNoSideEffectCalls;
        compiler62.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList71, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList74, compilerOptions77);
        boolean boolean84 = compilerOptions77.recordFunctionInformation;
        try {
            compiler11.init(jSSourceFileArray56, jSModuleArray57, compilerOptions77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(performanceTracker12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile22);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile38);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray45);
        org.junit.Assert.assertNotNull(jSSourceFileArray46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(jSModuleArray57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile65);
        org.junit.Assert.assertNotNull(jSSourceFile68);
        org.junit.Assert.assertNotNull(jSSourceFileArray70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(jSModuleArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + checkLevel81 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel81.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray4 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int59 = node58.getChildCount();
        java.lang.Object obj61 = node58.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection62 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node58);
        com.google.javascript.rhino.Node node63 = node32.clonePropsFrom(node58);
        boolean boolean64 = node63.isVarArgs();
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int69 = node68.getChildCount();
        java.lang.Object obj71 = node68.getProp(0);
        com.google.javascript.rhino.Node node72 = node63.copyInformationFrom(node68);
        try {
            node63.setSideEffectFlags(42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got ERROR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNull(obj61);
        org.junit.Assert.assertNotNull(nodeCollection62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNull(obj71);
        org.junit.Assert.assertNotNull(node72);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        loggerErrorManager1.generateReport();
        com.google.javascript.jscomp.JSError[] jSErrorArray6 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        int int5 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.sourceName();
        int int10 = ecmaError6.lineNumber();
        java.lang.Class<?> wildcardClass11 = ecmaError6.getClass();
        com.google.javascript.rhino.EcmaError ecmaError18 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str19 = ecmaError18.getSourceName();
        java.lang.String str20 = ecmaError18.toString();
        int int21 = ecmaError18.lineNumber();
        com.google.javascript.rhino.EvaluatorException evaluatorException25 = new com.google.javascript.rhino.EvaluatorException("", "hi!", (-1));
        ecmaError18.addSuppressed((java.lang.Throwable) evaluatorException25);
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError18);
        int int28 = ecmaError6.columnNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(ecmaError18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str20.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        com.google.javascript.rhino.Node node17 = node16.cloneNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node16, node22, node26 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(33, nodeArray27, (int) (byte) 0, 10);
        boolean boolean31 = node30.hasChildren();
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean34 = node33.wasEmptyNode();
        java.lang.String[] strArray45 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet46 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet46, strArray45);
        node33.setDirectives((java.util.Set<java.lang.String>) strSet46);
        com.google.javascript.rhino.Node node49 = node30.copyInformationFrom(node33);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node55 = com.google.javascript.jscomp.NodeUtil.newExpr(node54);
        int int56 = node55.getSourcePosition();
        boolean boolean57 = node49.hasChild(node55);
        java.util.Set<java.lang.String> strSet58 = node49.getDirectives();
        node49.setCharno((int) (byte) -1);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(strSet58);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.setSummaryDetailLevel(42);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        java.lang.String str18 = node15.toString();
        boolean boolean19 = node15.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node15.getFirstChild();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray35 = new com.google.javascript.rhino.Node[] { node25, node29, node34 };
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray35);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection37 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node36);
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node41.putBooleanProp(0, false);
        java.lang.String str45 = node36.checkTreeEquals(node41);
        boolean boolean46 = node41.hasSideEffects();
        com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray61 = new com.google.javascript.rhino.Node[] { node51, node55, node60 };
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray61);
        com.google.javascript.rhino.Node node63 = node62.cloneNode();
        boolean boolean64 = node63.isLocalResultCall();
        try {
            node15.replaceChildAfter(node41, node63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR 0" + "'", str18.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(nodeArray35);
        org.junit.Assert.assertNotNull(nodeCollection37);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n" + "'", str45.equals("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(nodeArray61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        try {
            com.google.javascript.rhino.Node node20 = node16.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] { node11, node15, node20 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray21);
        int int23 = node22.getSideEffectFlags();
        boolean boolean24 = node22.wasEmptyNode();
        java.lang.String str25 = node22.toString();
        boolean boolean26 = node3.isEquivalentTo(node22);
        boolean boolean27 = node22.hasChildren();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ERROR 0" + "'", str25.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions0.reportUnknownTypes = checkLevel4;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.optimizeCalls = true;
        compilerOptions0.setTweakToBooleanLiteral("@IMPLEMENTATION.VERSION@", true);
        boolean boolean13 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        boolean boolean7 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.syntheticBlockEndMarker = "language version";
        boolean boolean10 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkProvides;
        compilerOptions4.aliasExternals = false;
        compilerOptions4.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions4.reportUnknownTypes;
        compilerOptions0.checkGlobalThisLevel = checkLevel10;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.tightenTypes = false;
        compilerOptions0.setDefineToStringLiteral("DiagnosticGroup<strictModuleDepCheck>(null)", "ERROR");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        boolean boolean11 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        double double5 = loggerErrorManager4.getTypedPercent();
        int int6 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node15, node19, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray25);
        com.google.javascript.rhino.Node node27 = node26.cloneNode();
        boolean boolean28 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        int int45 = node44.getSideEffectFlags();
        boolean boolean46 = node44.wasEmptyNode();
        java.lang.String str47 = node44.toString();
        boolean boolean48 = node44.isOptionalArg();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node53, node57, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray63);
        java.lang.String str68 = node64.toString(false, false, true);
        node26.addChildAfter(node44, node64);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal10, node44);
        int int71 = nodeTraversal10.getLineNumber();
        com.google.javascript.rhino.Node node72 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel76 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType77 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray84 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError85 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel76, diagnosticType77, strArray84);
        java.lang.String[] strArray90 = new java.lang.String[] { "@IMPLEMENTATION.VERSION@", "hi!", "DiagnosticGroup<strictModuleDepCheck>(null)", "com.google.javascript.rhino.EcmaError: hi!:  (#10)" };
        nodeTraversal10.report(node72, diagnosticType77, strArray90);
        java.text.MessageFormat messageFormat92 = diagnosticType77.format;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR 0" + "'", str47.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR" + "'", str68.equals("ERROR"));
        org.junit.Assert.assertNull(objectLiteralCast70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(diagnosticType77);
        org.junit.Assert.assertNotNull(strArray84);
        org.junit.Assert.assertNotNull(jSError85);
        org.junit.Assert.assertNotNull(strArray90);
        org.junit.Assert.assertNotNull(messageFormat92);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(30, "", 4095, 0);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((-1), 34, (int) (short) 100);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        int int18 = node16.getIntProp(10);
        int int19 = node16.getSourcePosition();
        boolean boolean20 = node16.hasMoreThanOneChild();
        boolean boolean21 = node16.isQualifiedName();
        com.google.javascript.rhino.Node node22 = null;
        com.google.javascript.rhino.Node node23 = node16.getChildBefore(node22);
        try {
            com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (byte) 100, node23, 10, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        double double5 = loggerErrorManager4.getTypedPercent();
        int int6 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node15, node19, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray25);
        com.google.javascript.rhino.Node node27 = node26.cloneNode();
        boolean boolean28 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        int int45 = node44.getSideEffectFlags();
        boolean boolean46 = node44.wasEmptyNode();
        java.lang.String str47 = node44.toString();
        boolean boolean48 = node44.isOptionalArg();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node53, node57, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray63);
        java.lang.String str68 = node64.toString(false, false, true);
        node26.addChildAfter(node44, node64);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal10, node44);
        java.lang.String str71 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR 0" + "'", str47.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR" + "'", str68.equals("ERROR"));
        org.junit.Assert.assertNull(objectLiteralCast70);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("hi!: ", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        java.lang.String str18 = node15.toString();
        boolean boolean19 = node15.isOptionalArg();
        com.google.javascript.rhino.Node node20 = node15.getFirstChild();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean23 = node22.wasEmptyNode();
        java.lang.String[] strArray34 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet35 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet35, strArray34);
        node22.setDirectives((java.util.Set<java.lang.String>) strSet35);
        com.google.javascript.rhino.Node node38 = null;
        try {
            node15.addChildAfter(node22, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ERROR 0" + "'", str18.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions1.reportUnknownTypes = checkLevel2;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions4.reportUnknownTypes = checkLevel5;
        compilerOptions1.reportUnknownTypes = checkLevel5;
        java.util.Set<java.lang.String> strSet8 = compilerOptions1.stripNameSuffixes;
        compilerOptions0.setIdGenerators(strSet8);
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel10 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.setColorizeErrorOutput(false);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.checkGlobalThisLevel = checkLevel13;
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNotNull(detailLevel10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        compilerOptions0.setLooseTypes(false);
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType15.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel26;
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.removeUnusedLocalVars = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.sourceMapOutputPath = "null";
        compilerOptions0.moveFunctionDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        java.lang.String str6 = jSSourceFile2.getLine(160);
        try {
            java.io.Reader reader7 = jSSourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.removeDeadCode;
        compilerOptions0.setPropertyAffinity(false);
        boolean boolean7 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        int int8 = nodeTraversal7.getLineNumber();
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, (int) (byte) 10, 0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo13 = node12.getJSDocInfo();
        com.google.javascript.rhino.JSDocInfo jSDocInfo14 = node12.getJSDocInfo();
        boolean boolean15 = node12.hasOneChild();
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType24 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel23, diagnosticType24, strArray31);
        java.lang.String[] strArray33 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError34 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType24, strArray33);
        try {
            nodeTraversal7.report(node12, diagnosticType16, strArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(jSDocInfo13);
        org.junit.Assert.assertNull(jSDocInfo14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticType24);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(strArray33);
        org.junit.Assert.assertNotNull(jSError34);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        boolean boolean61 = node22.isQualifiedName();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        try {
            double double16 = node15.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR 0 is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] { node8, node12, node17 };
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray18);
        int int20 = node19.getSideEffectFlags();
        boolean boolean21 = node19.wasEmptyNode();
        boolean boolean22 = node19.hasSideEffects();
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int27 = node26.getChildCount();
        node26.setCharno(0);
        boolean boolean30 = node26.isQuotedString();
        com.google.javascript.rhino.Node node31 = node19.clonePropsFrom(node26);
        com.google.javascript.rhino.Node node32 = node31.removeFirstChild();
        try {
            nodeTraversal3.traverse(node31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.ideMode = true;
        boolean boolean5 = compilerOptions0.smartNameRemoval;
        compilerOptions0.inlineConstantVars = false;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        com.google.javascript.jscomp.JSModule jSModule6 = null;
        try {
            boolean boolean7 = jSModuleGraph4.dependsOn(jSModule5, jSModule6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)", 29, 17);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node20.putBooleanProp(0, false);
        java.lang.String str24 = node15.checkTreeEquals(node20);
        boolean boolean25 = node20.hasSideEffects();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean28 = defaultCodingConvention26.isConstant("hi!");
        com.google.javascript.rhino.Node node32 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention26, "language version", 160, (int) '4');
        boolean boolean33 = node32.isOnlyModifiesThisCall();
        node20.addChildToBack(node32);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n" + "'", str24.equals("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel9, diagnosticType10, strArray17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions19.reportUnknownTypes = checkLevel20;
        compilerOptions19.extractPrototypeMemberDeclarations = false;
        boolean boolean24 = compilerOptions19.crossModuleCodeMotion;
        boolean boolean25 = compilerOptions19.inlineGetters;
        boolean boolean26 = compilerOptions19.devirtualizePrototypeMethods;
        boolean boolean27 = jSError18.equals((java.lang.Object) compilerOptions19);
        compiler4.report(jSError18);
        com.google.javascript.jscomp.JSError[] jSErrorArray29 = compiler4.getErrors();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState30 = null;
        try {
            compiler4.setState(intermediateState30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSErrorArray29);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setMutatesGlobalState();
        sideEffectFlags1.setMutatesThis();
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType15.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel26;
        compilerOptions0.checkSuspiciousCode = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        com.google.javascript.rhino.Node node5 = node3.getLastChild();
        com.google.javascript.rhino.Node node7 = node3.getAncestor(36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        try {
            node16.setDouble((double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("goog.exportSymbol");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        int int14 = loggerErrorManager12.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel21, diagnosticType22, strArray29);
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType22, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel40, diagnosticType41, strArray48);
        java.lang.String[] strArray50 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType41, strArray50);
        loggerErrorManager12.report(checkLevel33, jSError51);
        compilerOptions0.reportMissingOverride = checkLevel33;
        byte[] byteArray54 = new byte[] {};
        compilerOptions0.inputVariableMapSerialized = byteArray54;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(byteArray54);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        try {
            com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(8, nodeArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: duplicate child");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("com.google.javascript.rhino.EcmaError: hi!:  (#10)", "Unknown class name", "goog.exportSymbol", (int) (short) 100, "Unknown class name", 33);
        try {
            ecmaError6.initLineSource("Named type with empty name component");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError6);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("DiagnosticGroup<strictModuleDepCheck>(null)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: DiagnosticGroup<strictModuleDepCheck>(null)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        compilerOptions0.printInputDelimiter = true;
        com.google.javascript.jscomp.SourceMap.Format format12 = compilerOptions0.sourceMapFormat;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean14 = compilerOptions13.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions13.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean19 = compilerOptions16.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions16.reportMissingOverride;
        compilerOptions16.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions16.checkGlobalNamesLevel;
        compilerOptions13.aggressiveVarCheck = checkLevel23;
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions13.checkProvides;
        compilerOptions0.checkFunctions = checkLevel25;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        boolean boolean9 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.checkTypedPropertyCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        boolean boolean5 = compilerOptions0.convertToDottedProperties;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel10, diagnosticType11, strArray18);
        java.lang.String[] strArray20 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType11, strArray20);
        com.google.javascript.jscomp.CheckLevel checkLevel22 = diagnosticType11.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray37 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel29, diagnosticType30, strArray37);
        java.lang.String[] strArray39 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType30, strArray39);
        loggerErrorManager1.report(checkLevel22, jSError40);
        loggerErrorManager1.setTypedPercent((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean4 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.sourceName();
        int int10 = ecmaError6.lineNumber();
        java.lang.Class<?> wildcardClass11 = ecmaError6.getClass();
        com.google.javascript.rhino.EcmaError ecmaError18 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str19 = ecmaError18.getSourceName();
        java.lang.String str20 = ecmaError18.toString();
        int int21 = ecmaError18.lineNumber();
        com.google.javascript.rhino.EvaluatorException evaluatorException25 = new com.google.javascript.rhino.EvaluatorException("", "hi!", (-1));
        ecmaError18.addSuppressed((java.lang.Throwable) evaluatorException25);
        ecmaError6.addSuppressed((java.lang.Throwable) ecmaError18);
        java.lang.String str28 = ecmaError6.getErrorMessage();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(ecmaError18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str20.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format5;
        java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) compilerOptions0);
        compilerOptions0.instrumentationTemplate = "com.google.javascript.rhino.EcmaError: hi!:  (#10)";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection18 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(nodeCollection18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput5.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5, false);
        com.google.javascript.jscomp.JSModule jSModule9 = compilerInput5.getModule();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
        org.junit.Assert.assertNull(jSModule9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node19 = node15.getNext();
        node15.setVarArgs(true);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(node19);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        java.util.logging.Logger logger0 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
//        double double2 = loggerErrorManager1.getTypedPercent();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean4 = compilerOptions3.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions3.checkShadowVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel12 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray20 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel12, diagnosticType13, strArray20);
//        java.lang.String[] strArray22 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType13, strArray22);
//        loggerErrorManager1.println(checkLevel5, jSError23);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel26 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions25.reportUnknownTypes = checkLevel26;
//        compilerOptions25.extractPrototypeMemberDeclarations = false;
//        compilerOptions25.aliasStringsBlacklist = "ERROR";
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = compilerOptions25.aggressiveVarCheck;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions33.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean36 = compilerOptions33.collapseVariableDeclarations;
//        compilerOptions33.ambiguateProperties = false;
//        compilerOptions33.instrumentForCoverage = false;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean42 = compilerOptions41.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel43 = compilerOptions41.checkShadowVars;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions44 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions44.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean47 = compilerOptions44.collapseVariableDeclarations;
//        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions44.reportMissingOverride;
//        compilerOptions44.recordFunctionInformation = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel51 = compilerOptions44.checkGlobalNamesLevel;
//        compilerOptions41.aggressiveVarCheck = checkLevel51;
//        compilerOptions33.reportMissingOverride = checkLevel51;
//        compilerOptions25.reportMissingOverride = checkLevel51;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup55 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel62 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType63 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray70 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError71 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel62, diagnosticType63, strArray70);
//        java.lang.String[] strArray72 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError73 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType63, strArray72);
//        java.lang.RuntimeException runtimeException75 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError73, (java.lang.Object) 41);
//        int int76 = jSError73.lineNumber;
//        boolean boolean77 = diagnosticGroup55.matches(jSError73);
//        com.google.javascript.jscomp.CheckLevel checkLevel78 = jSError73.level;
//        loggerErrorManager1.report(checkLevel51, jSError73);
//        int int80 = loggerErrorManager1.getWarningCount();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType13);
//        org.junit.Assert.assertNotNull(strArray20);
//        org.junit.Assert.assertNotNull(jSError21);
//        org.junit.Assert.assertNotNull(strArray22);
//        org.junit.Assert.assertNotNull(jSError23);
//        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel43 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel43.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + checkLevel51 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel51.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup55);
//        org.junit.Assert.assertNotNull(diagnosticType63);
//        org.junit.Assert.assertNotNull(strArray70);
//        org.junit.Assert.assertNotNull(jSError71);
//        org.junit.Assert.assertNotNull(strArray72);
//        org.junit.Assert.assertNotNull(jSError73);
//        org.junit.Assert.assertNotNull(runtimeException75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 32 + "'", int76 == 32);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel78 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel78.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        compilerOptions0.renamePrefix = "Unknown class name";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        com.google.javascript.jscomp.Result result8 = compiler4.getResult();
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        jSSourceFile11.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        jSSourceFile11.setOriginalPath("null");
        java.lang.String str17 = jSSourceFile11.getName();
        java.lang.String str18 = jSSourceFile11.getOriginalPath();
        com.google.javascript.rhino.Node node19 = compiler4.parse(jSSourceFile11);
        boolean boolean20 = compiler4.hasErrors();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(result8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "null" + "'", str18.equals("null"));
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        java.util.Set<java.lang.String> strSet8 = compilerOptions0.stripNamePrefixes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        java.lang.String str5 = compilerOptions0.nameReferenceGraphPath;
        compilerOptions0.ignoreCajaProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(logger6);
        double double8 = loggerErrorManager7.getTypedPercent();
        int int9 = loggerErrorManager7.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        java.nio.charset.Charset charset12 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset12);
        java.nio.charset.Charset charset15 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile16 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset15);
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile16);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray18 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile13, jSSourceFile16 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, jSSourceFileArray18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray21 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList22 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList22, jSModuleArray21);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph24 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList22);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean28 = compilerOptions25.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = compilerOptions25.reportMissingOverride;
        boolean boolean30 = compilerOptions25.markNoSideEffectCalls;
        compiler10.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList19, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList22, compilerOptions25);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel33 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions32.reportUnknownTypes = checkLevel33;
        compilerOptions32.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions32.markAsCompiled = false;
        compilerOptions32.setRemoveAbstractMethods(true);
        boolean boolean41 = compilerOptions32.markAsCompiled;
        compilerOptions32.setNameAnonymousFunctionsOnly(false);
        compiler10.initOptions(compilerOptions32);
        boolean boolean45 = compiler10.acceptEcmaScript5();
        compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
        com.google.javascript.jscomp.JSError[] jSErrorArray47 = compiler10.getMessages();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNotNull(jSSourceFile16);
        org.junit.Assert.assertNotNull(jSSourceFileArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(jSModuleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(jSErrorArray47);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        boolean boolean7 = defaultCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        int int24 = node23.getSideEffectFlags();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray39 = new com.google.javascript.rhino.Node[] { node29, node33, node38 };
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray39);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection41 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node40);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] { node46, node50, node55 };
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray56);
        java.lang.String str61 = node57.toString(false, false, true);
        node23.addChildAfter(node40, node57);
        boolean boolean63 = defaultCodingConvention0.isPropertyTestFunction(node23);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray78 = new com.google.javascript.rhino.Node[] { node68, node72, node77 };
        com.google.javascript.rhino.Node node79 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray78);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection80 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node79);
        com.google.javascript.rhino.Node node81 = node79.getNext();
        try {
            com.google.javascript.rhino.Node node82 = node23.removeChildAfter(node81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(nodeArray39);
        org.junit.Assert.assertNotNull(nodeCollection41);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "ERROR" + "'", str61.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(nodeArray78);
        org.junit.Assert.assertNotNull(nodeCollection80);
        org.junit.Assert.assertNull(node81);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.inlineGetters = true;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkGlobalNamesLevel;
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        boolean boolean6 = compilerOptions0.optimizeParameters;
        boolean boolean7 = compilerOptions0.ideMode;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 10.0f, 130, 48);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        compiler4.parse();
        boolean boolean28 = compiler4.acceptEcmaScript5();
        com.google.javascript.jscomp.CompilerInput compilerInput30 = compiler4.newExternInput("null");
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput31 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(compilerInput30);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.setOutputCharset("null");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setProcessObjectPropertyString(true);
        byte[] byteArray12 = compilerOptions0.inputPropertyMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(byteArray12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int11 = node10.getChildCount();
        com.google.javascript.rhino.Node node12 = node10.getLastChild();
        java.lang.String str13 = defaultCodingConvention0.identifyTypeDefAssign(node12);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.rhino.Node node19 = compiler18.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback20);
        int int22 = nodeTraversal21.getLineNumber();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        int int40 = node38.getIntProp(10);
        int int41 = node38.getSourcePosition();
        boolean boolean42 = node38.hasMoreThanOneChild();
        boolean boolean43 = node38.isQualifiedName();
        com.google.javascript.rhino.Node node44 = null;
        com.google.javascript.rhino.Node node45 = node38.getChildBefore(node44);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast46 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal21, node45);
        boolean boolean47 = nodeTraversal21.hasScope();
        boolean boolean48 = nodeTraversal21.hasScope();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(objectLiteralCast46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
        boolean boolean8 = compilerOptions5.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
        compilerOptions0.stripTypes = strSet9;
        compilerOptions0.collapseProperties = false;
        boolean boolean13 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.removeUnusedLocalVars = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean9 = compilerOptions0.markAsCompiled;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean11 = compilerOptions0.removeUnusedPrototypeProperties;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.setTweakToBooleanLiteral("", true);
        compilerOptions0.optimizeParameters = true;
        compilerOptions0.decomposeExpressions = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("com.google.javascript.rhino.EcmaError: hi!:  (#10)", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        java.lang.String str4 = jSSourceFile2.getLine(18);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = diagnosticType1.level;
        int int3 = diagnosticType0.compareTo(diagnosticType1);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.debugFunctionSideEffectsPath = "@IMPLEMENTATION.VERSION@";
        com.google.javascript.jscomp.MessageBundle messageBundle8 = compilerOptions0.messageBundle;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(messageBundle8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel6, diagnosticType7, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType7, strArray16);
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError17, (java.lang.Object) 41);
        int int20 = jSError17.lineNumber;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions21.reportUnknownTypes = checkLevel22;
        java.util.Set<java.lang.String> strSet24 = compilerOptions21.stripNamePrefixes;
        boolean boolean25 = jSError17.equals((java.lang.Object) compilerOptions21);
        compilerOptions21.removeEmptyFunctions = false;
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertNotNull(runtimeException19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 32 + "'", int20 == 32);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray1 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup("", diagnosticGroupArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        int int22 = node20.getIntProp(10);
        com.google.javascript.rhino.Node node23 = node20.getNext();
        java.lang.String str24 = defaultCodingConvention0.identifyTypeDefAssign(node23);
        boolean boolean27 = defaultCodingConvention0.isExported("ERROR 0", true);
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node32, node36, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray42);
        com.google.javascript.rhino.Node node44 = node43.cloneNode();
        boolean boolean45 = node44.isLocalResultCall();
        boolean boolean46 = defaultCodingConvention0.isPropertyTestFunction(node44);
        java.lang.String str47 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        java.lang.String str6 = jSSourceFile2.getLine(160);
        try {
            java.lang.String str7 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.reportUnknownTypes = checkLevel11;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        boolean boolean15 = compilerOptions10.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler16 = compilerOptions10.getAliasTransformationHandler();
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions10.checkRequires;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel17;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler16);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        node15.setType((int) (byte) 0);
        try {
            node15.setString("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: EOF 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.isQuotedString();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isExported("language version");
        boolean boolean4 = defaultCodingConvention0.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        java.lang.String str21 = defaultCodingConvention0.getSingletonGetterClassName(node20);
        com.google.javascript.rhino.Node node22 = node20.getParent();
        int int23 = node20.getCharno();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.reportUnknownTypes = checkLevel7;
        compilerOptions6.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions6.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.checkSuspiciousCode = false;
        boolean boolean16 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.foldConstants = true;
        compilerOptions0.inlineVariables = true;
        boolean boolean9 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.setRemoveClosureAsserts(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
//        java.lang.String str6 = diagnosticGroupWarningsGuard5.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup7 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard9 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup7, checkLevel8);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean12 = compilerOptions11.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions11.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel13);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel16 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard17 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup15, checkLevel16);
//        java.lang.String str18 = diagnosticGroupWarningsGuard17.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup19 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean21 = compilerOptions20.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions20.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup19, checkLevel22);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel25 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard26 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup24, checkLevel25);
//        java.lang.String str27 = diagnosticGroupWarningsGuard26.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean30 = compilerOptions29.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel31 = compilerOptions29.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard32 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel31);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray33 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard14, diagnosticGroupWarningsGuard17, diagnosticGroupWarningsGuard23, diagnosticGroupWarningsGuard26, diagnosticGroupWarningsGuard32 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard34 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray33);
//        java.lang.String str35 = composeWarningsGuard34.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup36 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean38 = compilerOptions37.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel39 = compilerOptions37.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard40 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup36, checkLevel39);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup41 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel42 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard43 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup41, checkLevel42);
//        java.lang.String str44 = diagnosticGroupWarningsGuard43.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup45 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions46 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean47 = compilerOptions46.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel48 = compilerOptions46.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard49 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup45, checkLevel48);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup50 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel51 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard52 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup50, checkLevel51);
//        java.lang.String str53 = diagnosticGroupWarningsGuard52.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup54 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean56 = compilerOptions55.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions55.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard58 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup54, checkLevel57);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray59 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard40, diagnosticGroupWarningsGuard43, diagnosticGroupWarningsGuard49, diagnosticGroupWarningsGuard52, diagnosticGroupWarningsGuard58 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard60 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray59);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup61 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel62 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard63 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup61, checkLevel62);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray64 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, diagnosticGroupWarningsGuard5, diagnosticGroupWarningsGuard9, composeWarningsGuard34, composeWarningsGuard60, diagnosticGroupWarningsGuard63 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard65 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray64);
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard66 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray64);
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticGroup3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str6.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup7);
//        org.junit.Assert.assertNotNull(diagnosticGroup10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup15);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str18.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str27.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(warningsGuardArray33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF)" + "'", str35.equals("DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel39 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel39.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str44.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel48 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel48.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup50);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str53.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(warningsGuardArray59);
//        org.junit.Assert.assertNotNull(diagnosticGroup61);
//        org.junit.Assert.assertNotNull(warningsGuardArray64);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.SourceMap.Format format7 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(format7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        int int18 = node15.getSourcePosition();
        com.google.javascript.rhino.Node node20 = node15.getAncestor((int) ' ');
        try {
            node20.setSideEffectFlags(5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.removeUnusedVars = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel7 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel7;
        boolean boolean9 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.optimizeCalls = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(detailLevel7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList6);
        java.util.Set<java.lang.String> strSet9 = null;
        compilerOptions0.aliasableStrings = strSet9;
        compilerOptions0.reportPath = "";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMissingReturn;
        boolean boolean6 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceFile sourceFile10 = compilerInput9.getSourceFile();
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput9);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(sourceFile10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("language version", "ERROR");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        boolean boolean28 = node27.isVarArgs();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray21 = new com.google.javascript.rhino.Node[] { node11, node15, node20 };
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray21);
        int int23 = node22.getSideEffectFlags();
        boolean boolean24 = node22.wasEmptyNode();
        java.lang.String str25 = node22.toString();
        boolean boolean26 = node22.isOptionalArg();
        com.google.javascript.rhino.Node node27 = node22.getFirstChild();
        boolean boolean28 = defaultCodingConvention0.isPropertyTestFunction(node27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(nodeArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ERROR 0" + "'", str25.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
//        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup4;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup4;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup4;
//        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup4;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup9;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup9;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        boolean boolean14 = diagnosticGroup12.matches(diagnosticType13);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
//        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup15;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup17 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup17;
//        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray19 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup0, diagnosticGroup4, diagnosticGroup9, diagnosticGroup12, diagnosticGroup15, diagnosticGroup17 };
//        try {
//            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup20 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertNull(diagnosticGroup9);
//        org.junit.Assert.assertNotNull(diagnosticGroup12);
//        org.junit.Assert.assertNotNull(diagnosticType13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup15);
//        org.junit.Assert.assertNotNull(diagnosticGroup17);
//        org.junit.Assert.assertNotNull(diagnosticGroupArray19);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.reportUnknownTypes = checkLevel7;
        compilerOptions6.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions6.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.setRemoveClosureAsserts(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean57 = node56.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention58 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean60 = defaultCodingConvention58.isConstant("hi!");
        com.google.javascript.rhino.Node node64 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention58, "language version", 160, (int) '4');
        boolean boolean65 = node64.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node66 = node56.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node67 = node64.getLastSibling();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray82 = new com.google.javascript.rhino.Node[] { node72, node76, node81 };
        com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray82);
        com.google.javascript.rhino.Node node84 = node83.cloneNode();
        try {
            node49.addChildBefore(node64, node83);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: node is not a child");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(nodeArray82);
        org.junit.Assert.assertNotNull(node84);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        boolean boolean61 = node16.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        boolean boolean17 = node15.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node22, node26, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray32);
        int int34 = node33.getSideEffectFlags();
        boolean boolean35 = node33.wasEmptyNode();
        java.lang.String str36 = node33.toString();
        boolean boolean37 = node33.isOptionalArg();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        java.lang.String str57 = node53.toString(false, false, true);
        node15.addChildAfter(node33, node53);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray73 = new com.google.javascript.rhino.Node[] { node63, node67, node72 };
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray73);
        int int75 = node74.getSideEffectFlags();
        boolean boolean76 = node74.wasEmptyNode();
        java.lang.String str77 = node74.toString();
        boolean boolean78 = node74.isOptionalArg();
        com.google.javascript.rhino.Node node79 = node74.getFirstChild();
        com.google.javascript.rhino.Node node80 = node53.clonePropsFrom(node79);
        try {
            com.google.javascript.rhino.Node node81 = com.google.javascript.jscomp.NodeUtil.newExpr(node80);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing sibling");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ERROR 0" + "'", str36.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "ERROR" + "'", str57.equals("ERROR"));
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(nodeArray73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "ERROR 0" + "'", str77.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node80);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(42);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType15.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel26;
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.closurePass = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder19.append("DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF)");
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = node27.removeFirstChild();
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node34, node38, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray44);
        com.google.javascript.rhino.Node node46 = node45.cloneNode();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] { node45, node51, node55 };
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(33, nodeArray56, (int) (byte) 0, 10);
        boolean boolean60 = node59.hasChildren();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean63 = node62.wasEmptyNode();
        java.lang.String[] strArray74 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet75 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean76 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet75, strArray74);
        node62.setDirectives((java.util.Set<java.lang.String>) strSet75);
        com.google.javascript.rhino.Node node78 = node59.copyInformationFrom(node62);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node84 = com.google.javascript.jscomp.NodeUtil.newExpr(node83);
        int int85 = node84.getSourcePosition();
        boolean boolean86 = node78.hasChild(node84);
        boolean boolean88 = node84.getBooleanProp(0);
        node28.addChildrenToBack(node84);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(strArray74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 1 + "'", int85 == 1);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder6 = null;
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        com.google.javascript.rhino.Node node24 = node23.cloneNode();
        boolean boolean25 = node23.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node30, node34, node39 };
        com.google.javascript.rhino.Node node41 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray40);
        int int42 = node41.getSideEffectFlags();
        boolean boolean43 = node41.wasEmptyNode();
        java.lang.String str44 = node41.toString();
        boolean boolean45 = node41.isOptionalArg();
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node50, node54, node59 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray60);
        java.lang.String str65 = node61.toString(false, false, true);
        node23.addChildAfter(node41, node61);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray81 = new com.google.javascript.rhino.Node[] { node71, node75, node80 };
        com.google.javascript.rhino.Node node82 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray81);
        int int83 = node82.getSideEffectFlags();
        boolean boolean84 = node82.wasEmptyNode();
        java.lang.String str85 = node82.toString();
        boolean boolean86 = node82.isOptionalArg();
        com.google.javascript.rhino.Node node87 = node82.getFirstChild();
        com.google.javascript.rhino.Node node88 = node61.clonePropsFrom(node87);
        try {
            compiler4.toSource(codeBuilder6, 4, node87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ERROR 0" + "'", str44.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "ERROR" + "'", str65.equals("ERROR"));
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(nodeArray81);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "ERROR 0" + "'", str85.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.level;
        boolean boolean4 = diagnosticGroup0.matches(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        java.lang.String str5 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.checkTypes = false;
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions6.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard9 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel8);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) diagnosticGroupWarningsGuard9);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] { node6, node10, node15 };
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray16);
        int int18 = node17.getSideEffectFlags();
        boolean boolean19 = node17.wasEmptyNode();
        boolean boolean20 = node17.hasSideEffects();
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int25 = node24.getChildCount();
        node24.setCharno(0);
        boolean boolean28 = node24.isQuotedString();
        com.google.javascript.rhino.Node node29 = node17.clonePropsFrom(node24);
        int int30 = node17.getType();
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray46 = new com.google.javascript.rhino.Node[] { node36, node40, node45 };
        com.google.javascript.rhino.Node node47 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray46);
        com.google.javascript.rhino.Node node48 = node47.cloneNode();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray58 = new com.google.javascript.rhino.Node[] { node47, node53, node57 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(33, nodeArray58, (int) (byte) 0, 10);
        boolean boolean62 = node61.hasChildren();
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean65 = node64.wasEmptyNode();
        java.lang.String[] strArray76 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet77 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet77, strArray76);
        node64.setDirectives((java.util.Set<java.lang.String>) strSet77);
        com.google.javascript.rhino.Node node80 = node61.copyInformationFrom(node64);
        java.lang.String str81 = closureCodingConvention0.extractClassNameIfProvide(node17, node61);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.abstractMethod" + "'", str1.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(nodeArray46);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(nodeArray58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(strArray76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNull(str81);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.rewriteFunctionExpressions = true;
        compilerOptions0.closurePass = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("goog.abstractMethod", 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int5 = node4.getChildCount();
        node4.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean10 = defaultCodingConvention8.isExported("language version");
        boolean boolean12 = defaultCodingConvention8.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node17, node21, node26 };
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray27);
        java.lang.String str29 = defaultCodingConvention8.getSingletonGetterClassName(node28);
        node4.addChildrenToBack(node28);
        com.google.javascript.rhino.Node node31 = node4.getLastChild();
        java.util.List<java.lang.String> strList32 = closureCodingConvention0.identifyTypeDeclarationCall(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(strList32);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = diagnosticType15.defaultLevel;
        compilerOptions0.checkUndefinedProperties = checkLevel26;
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType15);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertNotNull(jSError23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        boolean boolean6 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.setGenerateExports(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format5;
        compilerOptions0.inlineGetters = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        int int4 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean23 = compilerOptions20.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.reportMissingOverride;
        boolean boolean25 = compilerOptions20.markNoSideEffectCalls;
        compiler5.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions27.reportUnknownTypes = checkLevel28;
        compilerOptions27.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions27.markAsCompiled = false;
        compilerOptions27.setRemoveAbstractMethods(true);
        boolean boolean36 = compilerOptions27.markAsCompiled;
        compilerOptions27.setNameAnonymousFunctionsOnly(false);
        compiler5.initOptions(compilerOptions27);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        jSSourceFile42.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.rhino.Node node46 = compiler5.parse(jSSourceFile42);
        com.google.javascript.jscomp.MessageFormatter messageFormatter48 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, false);
        compiler5.reportCodeChange();
        com.google.javascript.jscomp.JSError[] jSErrorArray50 = compiler5.getMessages();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(messageFormatter48);
        org.junit.Assert.assertNotNull(jSErrorArray50);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        boolean boolean7 = node6.isOnlyModifiesThisCall();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection8 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(nodeCollection8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node9, node13, node18 };
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray19);
        int int22 = node20.getIntProp(10);
        com.google.javascript.rhino.Node node23 = node20.getNext();
        java.lang.String str24 = defaultCodingConvention0.identifyTypeDefAssign(node23);
        boolean boolean27 = defaultCodingConvention0.isExported("ERROR 0", true);
        boolean boolean29 = defaultCodingConvention0.isValidEnumKey("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNull(node23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.setChainCalls(true);
        compilerOptions0.gatherCssNames = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel27 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions26.reportUnknownTypes = checkLevel27;
        compilerOptions26.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions26.markAsCompiled = false;
        compilerOptions26.setRemoveAbstractMethods(true);
        boolean boolean35 = compilerOptions26.markAsCompiled;
        compilerOptions26.setNameAnonymousFunctionsOnly(false);
        compiler4.initOptions(compilerOptions26);
        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions39.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean42 = compilerOptions39.collapseVariableDeclarations;
        compilerOptions39.ambiguateProperties = false;
        compilerOptions39.instrumentForCoverage = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean48 = compilerOptions47.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions47.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions50.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean53 = compilerOptions50.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions50.reportMissingOverride;
        compilerOptions50.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions50.checkGlobalNamesLevel;
        compilerOptions47.aggressiveVarCheck = checkLevel57;
        compilerOptions39.reportMissingOverride = checkLevel57;
        boolean boolean60 = compilerOptions39.aliasKeywords;
        com.google.javascript.jscomp.CheckLevel checkLevel61 = compilerOptions39.checkProvides;
        compiler4.initOptions(compilerOptions39);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + checkLevel61 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel61.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        node3.setVarArgs(false);
        com.google.javascript.rhino.Node node9 = node3.getLastChild();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(0);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        java.util.logging.Logger logger0 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
//        double double2 = loggerErrorManager1.getTypedPercent();
//        int int3 = loggerErrorManager1.getErrorCount();
//        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
//        java.nio.charset.Charset charset6 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
//        java.nio.charset.Charset charset9 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
//        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
//        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
//        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
//        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
//        java.lang.String str26 = compiler4.getAstDotGraph();
//        java.nio.charset.Charset charset28 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
//        jSSourceFile29.setOriginalPath("language version");
//        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
//        jSSourceFile29.setOriginalPath("null");
//        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
//        com.google.javascript.rhino.Node node36 = compiler4.parse(jSSourceFile29);
//        java.lang.String str39 = compiler4.getSourceLine("", 4095);
//        com.google.javascript.jscomp.CheckLevel checkLevel46 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray54 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel46, diagnosticType47, strArray54);
//        java.lang.String[] strArray56 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType47, strArray56);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = jSError57.getType();
//        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = jSError57.getType();
//        com.google.javascript.jscomp.CheckLevel checkLevel60 = jSError57.level;
//        compiler4.report(jSError57);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile7);
//        org.junit.Assert.assertNotNull(jSSourceFile10);
//        org.junit.Assert.assertNotNull(jSSourceFileArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(jSSourceFile29);
//        org.junit.Assert.assertNull(node36);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertNotNull(diagnosticType47);
//        org.junit.Assert.assertNotNull(strArray54);
//        org.junit.Assert.assertNotNull(jSError55);
//        org.junit.Assert.assertNotNull(strArray56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertNotNull(diagnosticType58);
//        org.junit.Assert.assertNotNull(diagnosticType59);
//        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        node3.setVarArgs(false);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj10 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean13 = defaultCodingConvention11.isExported("language version");
        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj10, (java.lang.Object) defaultCodingConvention11);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention15 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        boolean boolean22 = defaultCodingConvention15.isOptionalParameter(node20);
        java.util.List<java.lang.String> strList23 = defaultCodingConvention11.identifyTypeDeclarationCall(node20);
        boolean boolean24 = closureCodingConvention9.isVarArgsParameter(node20);
        java.lang.String str25 = closureCodingConvention9.getAbstractMethodName();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean28 = node27.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention29 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean31 = defaultCodingConvention29.isConstant("hi!");
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention29, "language version", 160, (int) '4');
        boolean boolean36 = node35.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node37 = node27.copyInformationFromForTree(node35);
        boolean boolean38 = closureCodingConvention9.isVarArgsParameter(node35);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention39 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean41 = defaultCodingConvention39.isConstant("hi!");
        com.google.javascript.rhino.Node node45 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention39, "language version", 160, (int) '4');
        boolean boolean46 = node45.isOnlyModifiesThisCall();
        try {
            node3.replaceChildAfter(node35, node45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(runtimeException14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "goog.abstractMethod" + "'", str25.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.checkSymbols;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.inlineVariables = false;
        compilerOptions0.jsOutputFile = "@IMPLEMENTATION.VERSION@";
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.setDefineToNumberLiteral("language version", (int) (short) 1);
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions8.reportUnknownTypes = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions8.stripNameSuffixes;
        compilerOptions8.collapseProperties = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions8.reportUnknownTypes = checkLevel18;
        compilerOptions0.checkFunctions = checkLevel18;
        compilerOptions0.removeUnusedVars = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        int int8 = nodeTraversal7.getLineNumber();
        com.google.javascript.jscomp.Scope scope9 = nodeTraversal7.getScope();
        java.lang.String str10 = nodeTraversal7.getSourceName();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput11 = nodeTraversal7.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(scope9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.rewriteFunctionExpressions = true;
        boolean boolean4 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.foldConstants = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy7, propertyRenamingPolicy8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy8 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy8.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        int int4 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean23 = compilerOptions20.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.reportMissingOverride;
        boolean boolean25 = compilerOptions20.markNoSideEffectCalls;
        compiler5.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions27.reportUnknownTypes = checkLevel28;
        compilerOptions27.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions27.markAsCompiled = false;
        compilerOptions27.setRemoveAbstractMethods(true);
        boolean boolean36 = compilerOptions27.markAsCompiled;
        compilerOptions27.setNameAnonymousFunctionsOnly(false);
        compiler5.initOptions(compilerOptions27);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        jSSourceFile42.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        com.google.javascript.rhino.Node node46 = compiler5.parse(jSSourceFile42);
        com.google.javascript.jscomp.MessageFormatter messageFormatter48 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, false);
        compiler5.reportCodeChange();
        com.google.javascript.jscomp.JSError[] jSErrorArray50 = compiler5.getErrors();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(messageFormatter48);
        org.junit.Assert.assertNotNull(jSErrorArray50);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions8.reportUnknownTypes = checkLevel12;
        compilerOptions0.checkProvides = checkLevel12;
        boolean boolean16 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroups.TWEAKS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        jSSourceFile29.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        jSSourceFile29.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
        com.google.javascript.rhino.Node node36 = compiler4.parse(jSSourceFile29);
        try {
            compiler4.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNull(node36);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        compilerOptions0.aliasableGlobals = "ERROR";
        boolean boolean11 = compilerOptions0.generateExports;
        boolean boolean12 = compilerOptions0.inferTypesInGlobalScope;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkProvides;
        compilerOptions4.aliasExternals = false;
        compilerOptions4.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions4.reportUnknownTypes;
        compilerOptions0.checkGlobalThisLevel = checkLevel10;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.reportPath = "// Input %num%";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(Named type with empty name component)" + "'", str1.equals("(Named type with empty name component)"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getWarningCount();
        double double4 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        compilerOptions0.setSummaryDetailLevel(0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        org.junit.Assert.assertNotNull(config1);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        boolean boolean6 = context1.isGeneratingSource();
//        java.lang.Object obj8 = context1.getThreadLocal((java.lang.Object) (short) -1);
//        java.lang.Object obj9 = context1.getDebuggerContextData();
//        java.util.logging.Logger logger10 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(logger10);
//        double double12 = loggerErrorManager11.getTypedPercent();
//        int int13 = loggerErrorManager11.getErrorCount();
//        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
//        com.google.javascript.rhino.Node node15 = compiler14.getRoot();
//        com.google.javascript.jscomp.CheckLevel checkLevel19 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray27 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel19, diagnosticType20, strArray27);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions29 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions29.reportUnknownTypes = checkLevel30;
//        compilerOptions29.extractPrototypeMemberDeclarations = false;
//        boolean boolean34 = compilerOptions29.crossModuleCodeMotion;
//        boolean boolean35 = compilerOptions29.inlineGetters;
//        boolean boolean36 = compilerOptions29.devirtualizePrototypeMethods;
//        boolean boolean37 = jSError28.equals((java.lang.Object) compilerOptions29);
//        compiler14.report(jSError28);
//        com.google.javascript.jscomp.JSError[] jSErrorArray39 = compiler14.getErrors();
//        com.google.javascript.jscomp.SourceMap sourceMap40 = compiler14.getSourceMap();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup41 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel48 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray56 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError57 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel48, diagnosticType49, strArray56);
//        java.lang.String[] strArray58 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError59 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType49, strArray58);
//        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError59, (java.lang.Object) 41);
//        int int62 = jSError59.lineNumber;
//        boolean boolean63 = diagnosticGroup41.matches(jSError59);
//        try {
//            context1.putThreadLocal((java.lang.Object) compiler14, (java.lang.Object) jSError59);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNull(obj8);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNull(node15);
//        org.junit.Assert.assertNotNull(diagnosticType20);
//        org.junit.Assert.assertNotNull(strArray27);
//        org.junit.Assert.assertNotNull(jSError28);
//        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(jSErrorArray39);
//        org.junit.Assert.assertNull(sourceMap40);
//        org.junit.Assert.assertNotNull(diagnosticGroup41);
//        org.junit.Assert.assertNotNull(diagnosticType49);
//        org.junit.Assert.assertNotNull(strArray56);
//        org.junit.Assert.assertNotNull(jSError57);
//        org.junit.Assert.assertNotNull(strArray58);
//        org.junit.Assert.assertNotNull(jSError59);
//        org.junit.Assert.assertNotNull(runtimeException61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 32 + "'", int62 == 32);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.setDefineToNumberLiteral("language version", (int) (short) 1);
        compilerOptions0.aliasKeywords = false;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode8 = compilerOptions0.tracer;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + tracerMode8 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode8.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean19 = node18.wasEmptyNode();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention20 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean22 = defaultCodingConvention20.isConstant("hi!");
        com.google.javascript.rhino.Node node26 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention20, "language version", 160, (int) '4');
        boolean boolean27 = node26.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node28 = node18.copyInformationFromForTree(node26);
        boolean boolean29 = closureCodingConvention0.isVarArgsParameter(node26);
        com.google.javascript.rhino.Node node34 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node34, node38, node43 };
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray44);
        node45.setType((int) 'a');
        com.google.javascript.rhino.Node node48 = null;
        try {
            java.lang.String str49 = closureCodingConvention0.extractClassNameIfRequire(node45, node48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(nodeArray44);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        int int4 = loggerErrorManager2.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        java.nio.charset.Charset charset7 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions20.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean23 = compilerOptions20.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.reportMissingOverride;
        boolean boolean25 = compilerOptions20.markNoSideEffectCalls;
        compiler5.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions27.reportUnknownTypes = checkLevel28;
        compilerOptions27.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions27.markAsCompiled = false;
        compilerOptions27.setRemoveAbstractMethods(true);
        boolean boolean36 = compilerOptions27.markAsCompiled;
        compilerOptions27.setNameAnonymousFunctionsOnly(false);
        compiler5.initOptions(compilerOptions27);
        com.google.javascript.jscomp.MessageFormatter messageFormatter41 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, true);
        try {
            compiler5.normalize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSModuleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(messageFormatter41);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.lang.String str1 = context0.getImplementationVersion();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str1.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node6 = node5.removeChildren();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "", 100, 2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        loggerErrorManager1.setTypedPercent((double) 41);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions1.checkProvides;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard3 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel2);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        java.util.Set<java.lang.String> strSet2 = null;
        compilerOptions0.stripNamePrefixes = strSet2;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkMissingGetCssNameLevel;
        compilerOptions0.checkControlStructures = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.labelRenaming;
        compilerOptions0.setOutputCharset("");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        java.util.Set<java.lang.String> strSet3 = compilerOptions0.stripNamePrefixes;
        boolean boolean4 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        int int18 = node15.getSourcePosition();
        boolean boolean19 = node15.hasMoreThanOneChild();
        boolean boolean20 = node15.isQualifiedName();
        com.google.javascript.rhino.Node node21 = node15.cloneNode();
        try {
            java.lang.String str22 = node15.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.gatherCssNames = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        boolean boolean8 = compilerOptions0.checkSymbols;
        java.lang.String str9 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.checkDuplicateMessages = true;
        compilerOptions0.setCollapsePropertiesOnExternTypes(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        compilerOptions0.inlineLocalVariables = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.setDefineToNumberLiteral("language version", (int) (short) 1);
        boolean boolean6 = compilerOptions0.inlineLocalVariables;
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        int int10 = loggerErrorManager8.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel17 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray25 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel17, diagnosticType18, strArray25);
        java.lang.String[] strArray27 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType18, strArray27);
        com.google.javascript.jscomp.CheckLevel checkLevel29 = diagnosticType18.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel36 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray44 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel36, diagnosticType37, strArray44);
        java.lang.String[] strArray46 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError47 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType37, strArray46);
        loggerErrorManager8.report(checkLevel29, jSError47);
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel29;
        boolean boolean50 = compilerOptions0.allowLegacyJsMessages;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + checkLevel29 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel29.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertNotNull(jSError47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("ECMASCRIPT5", 41, 0);
        com.google.javascript.rhino.Node node4 = node3.getParent();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setTweakToNumberLiteral("Unknown class name", 6);
        compilerOptions0.setGenerateExports(false);
        com.google.javascript.jscomp.SourceMap.Format format8 = compilerOptions0.sourceMapFormat;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n";
        org.junit.Assert.assertNotNull(format8);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        boolean boolean5 = compilerOptions0.specializeInitialModule;
        compilerOptions0.reserveRawExports = false;
        compilerOptions0.optimizeParameters = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions1.reportUnknownTypes = checkLevel2;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions4.reportUnknownTypes = checkLevel5;
        compilerOptions1.reportUnknownTypes = checkLevel5;
        java.util.Set<java.lang.String> strSet8 = compilerOptions1.stripNameSuffixes;
        compilerOptions0.setIdGenerators(strSet8);
        compilerOptions0.foldConstants = true;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap12 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertNull(cssRenamingMap12);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("hi!: ");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: hi!: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions13.extractPrototypeMemberDeclarations = false;
        boolean boolean18 = compilerOptions13.crossModuleCodeMotion;
        boolean boolean19 = compilerOptions13.inlineGetters;
        boolean boolean20 = compilerOptions13.devirtualizePrototypeMethods;
        boolean boolean21 = jSError12.equals((java.lang.Object) compilerOptions13);
        int int22 = jSError12.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) false, (java.lang.Object) 32);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        compilerOptions0.recordFunctionInformation = false;
        java.lang.String str7 = compilerOptions0.syntheticBlockStartMarker;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        com.google.javascript.rhino.Node node18 = node15.getNext();
        node15.detachChildren();
        boolean boolean20 = node15.isQualifiedName();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.removeTryCatchFinally = false;
        boolean boolean9 = compilerOptions0.recordFunctionInformation;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("DiagnosticGroup<strictModuleDepCheck>(null)");
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection2 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        try {
            int int4 = node1.getExistingIntProp(45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeCollection2);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
//        java.lang.String str8 = diagnosticGroupWarningsGuard7.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean11 = compilerOptions10.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions10.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel12);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
//        java.lang.String str17 = diagnosticGroupWarningsGuard16.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean20 = compilerOptions19.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions19.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup18, checkLevel21);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray23 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard22 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard24 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray23);
//        com.google.javascript.jscomp.CheckLevel checkLevel28 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray36 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError37 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel28, diagnosticType29, strArray36);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup38 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType39 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
//        boolean boolean40 = diagnosticGroup38.matches(diagnosticType39);
//        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray41 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType29, diagnosticType39 };
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup42 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray41);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup43 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray41);
//        try {
//            boolean boolean44 = composeWarningsGuard24.disables(diagnosticGroup43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str8.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str17.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(warningsGuardArray23);
//        org.junit.Assert.assertNotNull(diagnosticType29);
//        org.junit.Assert.assertNotNull(strArray36);
//        org.junit.Assert.assertNotNull(jSError37);
//        org.junit.Assert.assertNotNull(diagnosticGroup38);
//        org.junit.Assert.assertNotNull(diagnosticType39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(diagnosticTypeArray41);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention8 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean10 = defaultCodingConvention8.isExported("language version");
        boolean boolean12 = defaultCodingConvention8.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node18, node22, node27 };
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray28);
        com.google.javascript.rhino.Node node30 = node29.cloneNode();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray40 = new com.google.javascript.rhino.Node[] { node29, node35, node39 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(33, nodeArray40, (int) (byte) 0, 10);
        boolean boolean44 = node43.hasChildren();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean47 = node46.wasEmptyNode();
        java.lang.String[] strArray58 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet59 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean60 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet59, strArray58);
        node46.setDirectives((java.util.Set<java.lang.String>) strSet59);
        com.google.javascript.rhino.Node node62 = node43.copyInformationFrom(node46);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node68 = com.google.javascript.jscomp.NodeUtil.newExpr(node67);
        int int69 = node68.getSourcePosition();
        boolean boolean70 = node62.hasChild(node68);
        boolean boolean71 = defaultCodingConvention8.isPropertyTestFunction(node68);
        com.google.javascript.jscomp.DiagnosticType diagnosticType74 = com.google.javascript.jscomp.DiagnosticType.disabled("", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.jscomp.DiagnosticType diagnosticType80 = com.google.javascript.jscomp.DiagnosticType.warning("hi!: ", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.jscomp.CheckLevel checkLevel84 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType85 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray92 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError93 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel84, diagnosticType85, strArray92);
        com.google.javascript.jscomp.JSError jSError94 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)", 27, (int) ' ', diagnosticType80, strArray92);
        nodeTraversal7.report(node68, diagnosticType74, strArray92);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(nodeArray40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(strArray58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(diagnosticType74);
        org.junit.Assert.assertNotNull(diagnosticType80);
        org.junit.Assert.assertNotNull(diagnosticType85);
        org.junit.Assert.assertNotNull(strArray92);
        org.junit.Assert.assertNotNull(jSError93);
        org.junit.Assert.assertNotNull(jSError94);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("DiagnosticGroup<fileoverviewTags>(null)", "Not declared as a constructor", "// Input %num%", "// Input %num%");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<fileoverviewTags>(null)");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean8 = compilerOptions0.exportTestFunctions;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.reportUnknownTypes = checkLevel11;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy15 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions10.variableRenaming = variableRenamingPolicy15;
        compilerOptions0.variableRenaming = variableRenamingPolicy15;
        compilerOptions0.nameReferenceGraphPath = "goog.exportSymbol";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy15.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "TYPEOF", (int) '#', ": com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", 46);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.collapseAnonymousFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(43, "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", (int) (byte) 0, (int) '4');
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing6 = compilerOptions0.getTweakProcessing();
        boolean boolean7 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing6 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing6.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.removeActivationName("goog.exportSymbol");
//        context1.setInstructionObserverThreshold(25);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isSuperClassReference("EOF 10\n");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        boolean boolean10 = defaultCodingConvention3.isOptionalParameter(node8);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention0.getDelegateRelationship(node8);
        boolean boolean13 = defaultCodingConvention0.isConstant("ECMASCRIPT5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        boolean boolean6 = context1.isGeneratingSource();
//        int int7 = context1.getInstructionObserverThreshold();
//        int int8 = context1.getOptimizationLevel();
//        boolean boolean10 = context1.isActivationNeeded("goog.abstractMethod");
//        int int11 = context1.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.inlineAnonymousFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkShadowVars;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.reportMissingOverride;
        boolean boolean5 = compilerOptions0.specializeInitialModule;
        compilerOptions0.reserveRawExports = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions8.reportUnknownTypes = checkLevel12;
        java.util.Set<java.lang.String> strSet15 = compilerOptions8.stripNameSuffixes;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel17 = compilerOptions16.checkProvides;
        compilerOptions16.crossModuleCodeMotion = true;
        java.lang.String[] strArray21 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
        compilerOptions16.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        compilerOptions8.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList22);
        boolean boolean27 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.inlineLocalFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        byte[] byteArray5 = compilerOptions0.inputPropertyMapSerialized;
        boolean boolean6 = compilerOptions0.isExternExportsEnabled();
        boolean boolean7 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("ECMASCRIPT5", 41, 0);
        java.lang.Appendable appendable4 = null;
        try {
            node3.appendStringTree(appendable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)", '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        compilerOptions0.aliasableGlobals = "ERROR";
        boolean boolean11 = compilerOptions0.generateExports;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel12 = com.google.javascript.jscomp.SourceMap.DetailLevel.ALL;
        compilerOptions0.sourceMapDetailLevel = detailLevel12;
        compilerOptions0.reportPath = "or";
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(detailLevel12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.nameReferenceReportPath = "ERROR 0\n";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.closurePass;
        boolean boolean6 = compilerOptions0.checkTypes;
        boolean boolean7 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean8 = compilerOptions0.exportTestFunctions;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.reportUnknownTypes = checkLevel11;
        compilerOptions10.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy15 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions10.variableRenaming = variableRenamingPolicy15;
        compilerOptions0.variableRenaming = variableRenamingPolicy15;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap18 = compilerOptions0.customPasses;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy15 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy15.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap18);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean2 = node1.wasEmptyNode();
        boolean boolean3 = node1.isVarArgs();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        java.lang.String str6 = diagnosticType5.toString();
        boolean boolean7 = diagnosticGroup0.matches(diagnosticType5);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str6.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj10 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean13 = defaultCodingConvention11.isExported("language version");
        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj10, (java.lang.Object) defaultCodingConvention11);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention15 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        boolean boolean22 = defaultCodingConvention15.isOptionalParameter(node20);
        java.util.List<java.lang.String> strList23 = defaultCodingConvention11.identifyTypeDeclarationCall(node20);
        boolean boolean24 = closureCodingConvention9.isVarArgsParameter(node20);
        boolean boolean25 = defaultCodingConvention0.isOptionalParameter(node20);
        int int26 = node20.getSourcePosition();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(runtimeException14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        boolean boolean11 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        java.lang.String str9 = ecmaError6.details();
        java.lang.String str10 = ecmaError6.details();
        int int11 = ecmaError6.columnNumber();
        int int12 = ecmaError6.getLineNumber();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!: " + "'", str9.equals("hi!: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!: " + "'", str10.equals("hi!: "));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.foldConstants = true;
        compilerOptions0.inlineVariables = true;
        compilerOptions0.setDefineToNumberLiteral("ERROR 0", 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkUndefinedProperties;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) ' ');
        java.lang.String str2 = node1.toString();
        com.google.javascript.rhino.Node node3 = node1.getNext();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TYPEOF" + "'", str2.equals("TYPEOF"));
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        boolean boolean55 = node15.wasEmptyNode();
        boolean boolean56 = node15.wasEmptyNode();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        com.google.javascript.rhino.Node node17 = node16.cloneNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node16, node22, node26 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(33, nodeArray27, (int) (byte) 0, 10);
        boolean boolean31 = node30.hasChildren();
        node30.putBooleanProp((int) (short) -1, false);
        boolean boolean35 = node30.isVarArgs();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        java.lang.Object obj6 = node3.getProp(0);
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        compilerOptions0.setOutputCharset("null");
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setProcessObjectPropertyString(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions12.checkProvides;
        compilerOptions12.crossModuleCodeMotion = true;
        java.lang.String str16 = compilerOptions12.syntheticBlockEndMarker;
        compilerOptions12.removeUnusedVars = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.setCollapsePropertiesOnExternTypes(true);
        boolean boolean22 = compilerOptions19.recordFunctionInformation;
        compilerOptions19.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy25 = compilerOptions19.variableRenaming;
        compilerOptions12.variableRenaming = variableRenamingPolicy25;
        java.lang.RuntimeException runtimeException27 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) compilerOptions0, (java.lang.Object) variableRenamingPolicy25);
        boolean boolean28 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy25 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy25.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(runtimeException27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.setMutatesArguments();
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = true;
        boolean boolean8 = compilerOptions0.printInputDelimiter;
        java.lang.String str9 = compilerOptions0.unaliasableGlobals;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions11.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions11.markAsCompiled = false;
        compilerOptions11.setRemoveAbstractMethods(true);
        boolean boolean20 = compilerOptions11.markAsCompiled;
        compilerOptions11.setDefineToNumberLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", 44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.setCollapsePropertiesOnExternTypes(true);
        compilerOptions25.setTweakToNumberLiteral("Unknown class name", 6);
        compilerOptions25.setGenerateExports(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions33.checkProvides;
        compilerOptions33.crossModuleCodeMotion = true;
        java.lang.String[] strArray38 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList39 = new java.util.ArrayList<java.lang.String>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList39, strArray38);
        compilerOptions33.setManageClosureDependencies((java.util.List<java.lang.String>) strList39);
        compilerOptions25.setManageClosureDependencies((java.util.List<java.lang.String>) strList39);
        compilerOptions11.setReplaceStringsConfiguration("", (java.util.List<java.lang.String>) strList39);
        compilerOptions0.setReplaceStringsConfiguration("ERROR", (java.util.List<java.lang.String>) strList39);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean4 = compilerOptions0.checkTypedPropertyCalls;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean7 = defaultCodingConvention5.isConstant("hi!");
        boolean boolean9 = defaultCodingConvention5.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] { node14, node18, node23 };
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray24);
        int int27 = node25.getIntProp(10);
        com.google.javascript.rhino.Node node28 = node25.getNext();
        java.lang.String str29 = defaultCodingConvention5.identifyTypeDefAssign(node28);
        boolean boolean32 = defaultCodingConvention5.isExported("ERROR 0", true);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention5);
        compilerOptions0.lineBreak = true;
        java.util.Set<java.lang.String> strSet36 = compilerOptions0.stripNamePrefixes;
        compilerOptions0.printInputDelimiter = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(node28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(strSet36);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 29);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        boolean boolean27 = compiler4.acceptConstKeyword();
        try {
            compiler4.check();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule4 = null;
        com.google.javascript.jscomp.JSModule jSModule5 = null;
        try {
            boolean boolean6 = jSModuleGraph3.dependsOn(jSModule4, jSModule5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setCollapsePropertiesOnExternTypes(true);
        boolean boolean11 = compilerOptions8.inlineLocalFunctions;
        boolean boolean12 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setCollapsePropertiesOnExternTypes(true);
        boolean boolean16 = compilerOptions13.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet17 = compilerOptions13.aliasableStrings;
        compilerOptions8.stripTypes = strSet17;
        compilerOptions0.stripNameSuffixes = strSet17;
        boolean boolean20 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.setSummaryDetailLevel(44);
        compilerOptions0.syntheticBlockEndMarker = "DiagnosticGroup<internetExplorerChecks>";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, (int) (byte) 10, 0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node3.getJSDocInfo();
        boolean boolean6 = node3.getBooleanProp(0);
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel11);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) diagnosticGroupWarningsGuard12);
        compilerOptions0.skipAllCompilerPasses();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder19 = node15.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder19.append("");
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode1 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode1, false);
        org.junit.Assert.assertTrue("'" + languageMode1 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode1.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.appNameStr = "ERROR";
        java.lang.String str8 = compilerOptions0.checkMissingGetCssNameBlacklist;
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = diagnosticType0.level;
        java.lang.String str2 = diagnosticType0.toString();
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}" + "'", str2.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}"));
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(logger1);
//        double double3 = loggerErrorManager2.getTypedPercent();
//        int int4 = loggerErrorManager2.getErrorCount();
//        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
//        java.nio.charset.Charset charset7 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset7);
//        java.nio.charset.Charset charset10 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
//        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile8, jSSourceFile11 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray16 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList17 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList17, jSModuleArray16);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph19 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions20.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean23 = compilerOptions20.collapseVariableDeclarations;
//        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions20.reportMissingOverride;
//        boolean boolean25 = compilerOptions20.markNoSideEffectCalls;
//        compiler5.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList17, compilerOptions20);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel28 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions27.reportUnknownTypes = checkLevel28;
//        compilerOptions27.syntheticBlockStartMarker = "ERROR 0";
//        compilerOptions27.markAsCompiled = false;
//        compilerOptions27.setRemoveAbstractMethods(true);
//        boolean boolean36 = compilerOptions27.markAsCompiled;
//        compilerOptions27.setNameAnonymousFunctionsOnly(false);
//        compiler5.initOptions(compilerOptions27);
//        java.nio.charset.Charset charset41 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
//        jSSourceFile42.setOriginalPath("language version");
//        com.google.javascript.jscomp.CompilerInput compilerInput45 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
//        com.google.javascript.rhino.Node node46 = compiler5.parse(jSSourceFile42);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter48 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler5, false);
//        compiler5.reportCodeChange();
//        com.google.javascript.jscomp.Result result50 = compiler5.getResult();
//        java.util.logging.Logger logger51 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager52 = new com.google.javascript.jscomp.LoggerErrorManager(logger51);
//        double double53 = loggerErrorManager52.getTypedPercent();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions54 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean55 = compilerOptions54.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel56 = compilerOptions54.checkShadowVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel63 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType64 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray71 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError72 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel63, diagnosticType64, strArray71);
//        java.lang.String[] strArray73 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError74 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType64, strArray73);
//        loggerErrorManager52.println(checkLevel56, jSError74);
//        compiler5.report(jSError74);
//        com.google.javascript.jscomp.CheckLevel checkLevel77 = jSError74.level;
//        org.junit.Assert.assertNotNull(errorFormat0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile8);
//        org.junit.Assert.assertNotNull(jSSourceFile11);
//        org.junit.Assert.assertNotNull(jSSourceFileArray13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(jSSourceFile42);
//        org.junit.Assert.assertNull(node46);
//        org.junit.Assert.assertNotNull(messageFormatter48);
//        org.junit.Assert.assertNotNull(result50);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel56 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel56.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType64);
//        org.junit.Assert.assertNotNull(strArray71);
//        org.junit.Assert.assertNotNull(jSError72);
//        org.junit.Assert.assertNotNull(strArray73);
//        org.junit.Assert.assertNotNull(jSError74);
//        org.junit.Assert.assertTrue("'" + checkLevel77 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel77.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel10, diagnosticType11, strArray18);
        java.lang.String[] strArray20 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError21 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType11, strArray20);
        com.google.javascript.jscomp.CheckLevel checkLevel22 = diagnosticType11.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray37 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError38 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel29, diagnosticType30, strArray37);
        java.lang.String[] strArray39 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError40 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType30, strArray39);
        loggerErrorManager1.report(checkLevel22, jSError40);
        int int42 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray43 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(jSError21);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray37);
        org.junit.Assert.assertNotNull(jSError38);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertNotNull(jSError40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(jSErrorArray43);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.collapseVariableDeclarations = true;
        compilerOptions0.inlineLocalVariables = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = true;
        java.lang.Object obj8 = compilerOptions0.clone();
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler11, callback12);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        try {
            java.lang.String str16 = compiler11.toSource();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(messageFormatter15);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType6 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str7 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) diagnosticType6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType6.defaultLevel;
        compilerOptions0.checkRequires = checkLevel8;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(diagnosticType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str7.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.rhino.JSDocInfo jSDocInfo2 = null;
        node1.setJSDocInfo(jSDocInfo2);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection4 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node1);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(nodeCollection4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags18 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags18.clearSideEffectFlags();
        try {
            node15.setSideEffectFlags(sideEffectFlags18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got ERROR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(nodeCollection16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        boolean boolean9 = compilerOptions0.markAsCompiled;
        java.lang.String str10 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean11 = compilerOptions0.inlineConstantVars;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkGlobalThisLevel;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.clearAllFlags();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setThrows();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        try {
//            context1.setCompileFunctionsWithDynamicScope(false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.SourceMap.Format format5 = com.google.javascript.jscomp.SourceMap.Format.EXPERIMENTIAL;
        compilerOptions0.sourceMapFormat = format5;
        compilerOptions0.collapseAnonymousFunctions = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(format5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        boolean boolean8 = compilerOptions0.checkSymbols;
        compilerOptions0.flowSensitiveInlineVariables = false;
        compilerOptions0.prettyPrint = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
        boolean boolean8 = compilerOptions5.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
        compilerOptions0.stripTypes = strSet9;
        compilerOptions0.prettyPrint = true;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.setTweakToDoubleLiteral("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", (double) 25);
        compilerOptions0.closurePass = false;
        boolean boolean9 = compilerOptions0.decomposeExpressions;
        boolean boolean10 = compilerOptions0.removeUnusedPrototypeProperties;
        boolean boolean11 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        boolean boolean7 = defaultCodingConvention0.isOptionalParameter(node5);
        boolean boolean9 = defaultCodingConvention0.isConstant(": com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        boolean boolean10 = compilerOptions0.removeEmptyFunctions;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy3 = compilerOptions0.propertyRenaming;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy3.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        boolean boolean4 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setCollapsePropertiesOnExternTypes(true);
        boolean boolean8 = compilerOptions5.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet9 = compilerOptions5.aliasableStrings;
        compilerOptions0.stripTypes = strSet9;
        boolean boolean11 = compilerOptions0.aliasAllStrings;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.setTweakToBooleanLiteral("", true);
        boolean boolean8 = compilerOptions0.markAsCompiled;
        boolean boolean9 = compilerOptions0.removeEmptyFunctions;
        compilerOptions0.setShadowVariables(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        double double5 = loggerErrorManager4.getTypedPercent();
        int int6 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node15, node19, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray25);
        com.google.javascript.rhino.Node node27 = node26.cloneNode();
        boolean boolean28 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        int int45 = node44.getSideEffectFlags();
        boolean boolean46 = node44.wasEmptyNode();
        java.lang.String str47 = node44.toString();
        boolean boolean48 = node44.isOptionalArg();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node53, node57, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray63);
        java.lang.String str68 = node64.toString(false, false, true);
        node26.addChildAfter(node44, node64);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal10, node44);
        com.google.javascript.jscomp.Scope scope71 = nodeTraversal10.getScope();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR 0" + "'", str47.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR" + "'", str68.equals("ERROR"));
        org.junit.Assert.assertNull(objectLiteralCast70);
        org.junit.Assert.assertNull(scope71);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        java.lang.Object obj6 = node3.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection7 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node3);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray22 = new com.google.javascript.rhino.Node[] { node12, node16, node21 };
        com.google.javascript.rhino.Node node23 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray22);
        int int25 = node23.getIntProp(10);
        int int26 = node23.getSourcePosition();
        boolean boolean27 = node23.hasMoreThanOneChild();
        boolean boolean28 = node23.isQualifiedName();
        com.google.javascript.rhino.Node node29 = null;
        com.google.javascript.rhino.Node node30 = node23.getChildBefore(node29);
        try {
            node3.addChildrenToBack(node29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(nodeCollection7);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(nodeArray22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node30);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean6 = compilerOptions3.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions3.reportMissingOverride;
        compilerOptions3.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions3.checkGlobalNamesLevel;
        compilerOptions0.aggressiveVarCheck = checkLevel10;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean14 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        int int17 = node16.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node22, node26, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray32);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection34 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node33);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node39, node43, node48 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray49);
        java.lang.String str54 = node50.toString(false, false, true);
        node16.addChildAfter(node33, node50);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray70 = new com.google.javascript.rhino.Node[] { node60, node64, node69 };
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray70);
        int int73 = node71.getIntProp(10);
        int int74 = node71.getSourcePosition();
        boolean boolean75 = node71.hasMoreThanOneChild();
        boolean boolean76 = node71.isQualifiedName();
        node33.addChildToBack(node71);
        boolean boolean78 = node71.isOnlyModifiesThisCall();
        node71.removeProp(0);
        try {
            com.google.javascript.rhino.Node node83 = new com.google.javascript.rhino.Node((int) (byte) 10, node71, 110, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(nodeCollection34);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ERROR" + "'", str54.equals("ERROR"));
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(nodeArray70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        boolean boolean17 = node15.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node22, node26, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray32);
        int int34 = node33.getSideEffectFlags();
        boolean boolean35 = node33.wasEmptyNode();
        java.lang.String str36 = node33.toString();
        boolean boolean37 = node33.isOptionalArg();
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        java.lang.String str57 = node53.toString(false, false, true);
        node15.addChildAfter(node33, node53);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray73 = new com.google.javascript.rhino.Node[] { node63, node67, node72 };
        com.google.javascript.rhino.Node node74 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray73);
        int int75 = node74.getSideEffectFlags();
        boolean boolean76 = node74.wasEmptyNode();
        java.lang.String str77 = node74.toString();
        boolean boolean78 = node74.isOptionalArg();
        com.google.javascript.rhino.Node node79 = node74.getFirstChild();
        com.google.javascript.rhino.Node node80 = node53.clonePropsFrom(node79);
        com.google.javascript.rhino.JSDocInfo jSDocInfo81 = null;
        node53.setJSDocInfo(jSDocInfo81);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ERROR 0" + "'", str36.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "ERROR" + "'", str57.equals("ERROR"));
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(nodeArray73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "ERROR 0" + "'", str77.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node80);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(48);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] { node6, node10, node15 };
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray16);
        com.google.javascript.rhino.Node node18 = node17.cloneNode();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray28 = new com.google.javascript.rhino.Node[] { node17, node23, node27 };
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(33, nodeArray28, (int) (byte) 0, 10);
        boolean boolean32 = node31.hasChildren();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean35 = node34.wasEmptyNode();
        java.lang.String[] strArray46 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet47 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean48 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet47, strArray46);
        node34.setDirectives((java.util.Set<java.lang.String>) strSet47);
        com.google.javascript.rhino.Node node50 = node31.copyInformationFrom(node34);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node56 = com.google.javascript.jscomp.NodeUtil.newExpr(node55);
        int int57 = node56.getSourcePosition();
        boolean boolean58 = node50.hasChild(node56);
        boolean boolean60 = node56.getBooleanProp(0);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (byte) 100, node56);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(strArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions1.reportUnknownTypes = checkLevel2;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions4.reportUnknownTypes = checkLevel5;
        compilerOptions1.reportUnknownTypes = checkLevel5;
        java.util.Set<java.lang.String> strSet8 = compilerOptions1.stripNameSuffixes;
        compilerOptions0.setIdGenerators(strSet8);
        compilerOptions0.foldConstants = true;
        compilerOptions0.inlineFunctions = false;
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions0.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode7 = compilerOptions0.tracer;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode7 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode7.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}", "(Named type with empty name component)");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions6.reportUnknownTypes = checkLevel7;
        compilerOptions6.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy11 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        compilerOptions6.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.variableRenaming = variableRenamingPolicy11;
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.sourceMapOutputPath = "ERROR";
        boolean boolean18 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy11.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions3.reportUnknownTypes = checkLevel4;
//        compilerOptions3.setDefineToNumberLiteral("language version", (int) (short) 1);
//        boolean boolean9 = compilerOptions3.inlineLocalVariables;
//        java.util.logging.Logger logger10 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(logger10);
//        double double12 = loggerErrorManager11.getTypedPercent();
//        int int13 = loggerErrorManager11.getWarningCount();
//        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray28 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel20, diagnosticType21, strArray28);
//        java.lang.String[] strArray30 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType21, strArray30);
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType21.defaultLevel;
//        com.google.javascript.jscomp.CheckLevel checkLevel39 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray47 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel39, diagnosticType40, strArray47);
//        java.lang.String[] strArray49 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType40, strArray49);
//        loggerErrorManager11.report(checkLevel32, jSError50);
//        compilerOptions3.checkMissingGetCssNameLevel = checkLevel32;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel32);
//        java.lang.String str54 = diagnosticGroupWarningsGuard53.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup55 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup55;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup55;
//        java.lang.String str58 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) diagnosticGroup55);
//        boolean boolean59 = diagnosticGroupWarningsGuard53.disables(diagnosticGroup55);
//        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup55;
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(diagnosticType21);
//        org.junit.Assert.assertNotNull(strArray28);
//        org.junit.Assert.assertNotNull(jSError29);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType40);
//        org.junit.Assert.assertNotNull(strArray47);
//        org.junit.Assert.assertNotNull(jSError48);
//        org.junit.Assert.assertNotNull(strArray49);
//        org.junit.Assert.assertNotNull(jSError50);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DiagnosticGroup<internetExplorerChecks>(ERROR)" + "'", str54.equals("DiagnosticGroup<internetExplorerChecks>(ERROR)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "DiagnosticGroup<internetExplorerChecks>" + "'", str58.equals("DiagnosticGroup<internetExplorerChecks>"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("(goog.exportSymbol)");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: (goog.exportSymbol)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkShadowVars;
        boolean boolean4 = compilerOptions1.removeUnusedLocalVars;
        boolean boolean5 = compilerOptions1.removeDeadCode;
        compilerOptions1.rewriteFunctionExpressions = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions1.checkMissingGetCssNameLevel;
        java.lang.Object obj9 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions10.checkProvides;
        compilerOptions10.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions10.checkRequires = checkLevel14;
        boolean boolean16 = compilerOptions10.foldConstants;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy17 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        compilerOptions10.propertyRenaming = propertyRenamingPolicy17;
        try {
            java.lang.String str19 = com.google.javascript.rhino.ScriptRuntime.getMessage3("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)", (java.lang.Object) checkLevel8, obj9, (java.lang.Object) compilerOptions10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF)");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy17 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy17.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        compilerOptions0.setTweakToNumberLiteral("Unknown class name", 6);
        boolean boolean6 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.collapseProperties = true;
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.removeDeadCode;
        compilerOptions0.rewriteFunctionExpressions = true;
        java.lang.String str7 = compilerOptions0.nameReferenceReportPath;
        boolean boolean8 = compilerOptions0.optimizeCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        com.google.javascript.rhino.Node node17 = node16.cloneNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node[] nodeArray27 = new com.google.javascript.rhino.Node[] { node16, node22, node26 };
        com.google.javascript.rhino.Node node30 = new com.google.javascript.rhino.Node(33, nodeArray27, (int) (byte) 0, 10);
        boolean boolean31 = node30.hasChildren();
        node30.putBooleanProp((int) (short) -1, false);
        try {
            java.lang.String str35 = node30.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: GETPROP 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(nodeArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        int int14 = loggerErrorManager12.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel21, diagnosticType22, strArray29);
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType22, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel40, diagnosticType41, strArray48);
        java.lang.String[] strArray50 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType41, strArray50);
        loggerErrorManager12.report(checkLevel33, jSError51);
        compilerOptions0.reportMissingOverride = checkLevel33;
        boolean boolean54 = compilerOptions0.foldConstants;
        compilerOptions0.setTweakToStringLiteral("JSC_NODE_TRAVERSAL_ERROR: {0}", "ERROR 0\n");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        int int2 = context1.getLanguageVersion();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions3.extractPrototypeMemberDeclarations = false;
        compilerOptions3.aliasStringsBlacklist = "ERROR";
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions3.aggressiveVarCheck;
        boolean boolean11 = compilerOptions3.checkSymbols;
        compilerOptions3.flowSensitiveInlineVariables = false;
        try {
            context1.unseal((java.lang.Object) compilerOptions3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkRequires = checkLevel4;
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        boolean boolean13 = compilerOptions0.exportTestFunctions;
        compilerOptions0.checkSymbols = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel17 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions16.reportUnknownTypes = checkLevel17;
        java.util.Set<java.lang.String> strSet19 = compilerOptions16.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet19);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel17 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel17.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet19);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        com.google.javascript.rhino.jstype.JSType jSType30 = node27.getJSType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(jSType30);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        java.lang.String str20 = closureCodingConvention0.getDelegateSuperclassName();
        java.lang.String str21 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "goog.abstractMethod" + "'", str21.equals("goog.abstractMethod"));
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        boolean boolean6 = context1.isGeneratingSource();
//        boolean boolean7 = context1.isGeneratingSource();
//        boolean boolean8 = context1.isSealed();
//        try {
//            context1.setGeneratingSource(false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions4.reportUnknownTypes = checkLevel5;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel8 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions7.reportUnknownTypes = checkLevel8;
//        compilerOptions4.reportUnknownTypes = checkLevel8;
//        java.util.Set<java.lang.String> strSet11 = compilerOptions4.stripNameSuffixes;
//        context1.putThreadLocal((java.lang.Object) 42, (java.lang.Object) strSet11);
//        context1.setCompileFunctionsWithDynamicScope(true);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(strSet11);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("");
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        boolean boolean10 = defaultCodingConvention0.isConstantKey("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of code motion iterations: {0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.JSModule jSModule6 = compilerInput5.getModule();
        try {
            java.util.Collection<java.lang.String> strCollection7 = compilerInput5.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(jSModule6);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel6, diagnosticType7, strArray14);
        java.lang.String[] strArray16 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType7, strArray16);
        java.lang.String str18 = diagnosticType7.toString();
        java.lang.RuntimeException runtimeException19 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) diagnosticType7);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str18.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(runtimeException19);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.debugFunctionSideEffectsPath = "@IMPLEMENTATION.VERSION@";
        boolean boolean10 = compilerOptions0.inlineLocalVariables;
        java.lang.String str11 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        java.lang.Object obj3 = null;
//        context1.seal(obj3);
//        java.lang.String str5 = context1.getImplementationVersion();
//        boolean boolean6 = context1.isGeneratingDebugChanged();
//        try {
//            context1.removeActivationName("@IMPLEMENTATION.VERSION@");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<typeInvalidation>(OFF)", checkLevel1, "(goog.exportSymbol)");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule2 = null;
        com.google.javascript.jscomp.JSModule jSModule3 = null;
        try {
            boolean boolean4 = jSModuleGraph1.dependsOn(jSModule2, jSModule3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isSuperClassReference("EOF 10\n");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention3 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node9 = com.google.javascript.jscomp.NodeUtil.newExpr(node8);
        boolean boolean10 = defaultCodingConvention3.isOptionalParameter(node8);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship11 = defaultCodingConvention0.getDelegateRelationship(node8);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        int int28 = node27.getSideEffectFlags();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection45 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node44);
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray60 = new com.google.javascript.rhino.Node[] { node50, node54, node59 };
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray60);
        java.lang.String str65 = node61.toString(false, false, true);
        node27.addChildAfter(node44, node61);
        com.google.javascript.rhino.Node node67 = node8.copyInformationFrom(node61);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(delegateRelationship11);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertNotNull(nodeCollection45);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray60);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "ERROR" + "'", str65.equals("ERROR"));
        org.junit.Assert.assertNotNull(node67);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("JSC_NODE_TRAVERSAL_ERROR: {0}", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        double double7 = loggerErrorManager6.getTypedPercent();
        int int8 = loggerErrorManager6.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel15, diagnosticType16, strArray23);
        java.lang.String[] strArray25 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError26 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType16, strArray25);
        com.google.javascript.jscomp.CheckLevel checkLevel27 = diagnosticType16.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel34 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray42 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel34, diagnosticType35, strArray42);
        java.lang.String[] strArray44 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError45 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType35, strArray44);
        loggerErrorManager6.report(checkLevel27, jSError45);
        compilerOptions0.checkGlobalNamesLevel = checkLevel27;
        boolean boolean48 = compilerOptions0.checkTypes;
        compilerOptions0.optimizeReturns = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertNotNull(jSError26);
        org.junit.Assert.assertTrue("'" + checkLevel27 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel27.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(strArray42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(strArray44);
        org.junit.Assert.assertNotNull(jSError45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        context1.seal((java.lang.Object) 100);
//        java.lang.String str5 = context1.getImplementationVersion();
//        java.lang.Object obj7 = context1.getThreadLocal((java.lang.Object) 10.0d);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertNull(obj7);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection33 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node32);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray48 = new com.google.javascript.rhino.Node[] { node38, node42, node47 };
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray48);
        java.lang.String str53 = node49.toString(false, false, true);
        node15.addChildAfter(node32, node49);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node59, node63, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray69);
        int int72 = node70.getIntProp(10);
        int int73 = node70.getSourcePosition();
        boolean boolean74 = node70.hasMoreThanOneChild();
        boolean boolean75 = node70.isQualifiedName();
        node32.addChildToBack(node70);
        boolean boolean77 = node70.isOnlyModifiesThisCall();
        node70.removeProp(0);
        com.google.javascript.rhino.Node node80 = node70.cloneNode();
        boolean boolean81 = node70.isVarArgs();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertNotNull(nodeCollection33);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(nodeArray48);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "ERROR" + "'", str53.equals("ERROR"));
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        compiler4.parse();
        boolean boolean28 = compiler4.acceptEcmaScript5();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = compiler4.getTypeRegistry();
        boolean boolean30 = compiler4.acceptConstKeyword();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(jSTypeRegistry29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<internetExplorerChecks>(ERROR)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<internetExplorerChecks>(ERROR)" + "'", str1.equals("DiagnosticGroup<internetExplorerChecks>(ERROR)"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        boolean boolean5 = compilerOptions0.foldConstants;
        boolean boolean6 = compilerOptions0.aliasAllStrings;
        boolean boolean7 = compilerOptions0.checkSymbols;
        com.google.javascript.jscomp.ErrorFormat errorFormat8 = compilerOptions0.errorFormat;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(errorFormat8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType4 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel3, diagnosticType4, strArray11);
        java.lang.String str13 = jSError12.description;
        int int14 = jSError12.getCharno();
        org.junit.Assert.assertNotNull(diagnosticType4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        int int2 = sideEffectFlags0.valueOf();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray20 = new com.google.javascript.rhino.Node[] { node10, node14, node19 };
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray20);
        com.google.javascript.rhino.Node node22 = node21.cloneNode();
        node5.addChildrenToBack(node21);
        node5.putIntProp(15, 41);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray41 = new com.google.javascript.rhino.Node[] { node31, node35, node40 };
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray41);
        com.google.javascript.rhino.Node node43 = node42.cloneNode();
        boolean boolean44 = node43.isLocalResultCall();
        java.lang.String str45 = node43.getQualifiedName();
        node5.addChildrenToFront(node43);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(nodeArray20);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(nodeArray41);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str45);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean11 = compilerOptions0.inlineAnonymousFunctionExpressions;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray16 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel8, diagnosticType9, strArray16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions18.reportUnknownTypes = checkLevel19;
        compilerOptions18.extractPrototypeMemberDeclarations = false;
        boolean boolean23 = compilerOptions18.crossModuleCodeMotion;
        boolean boolean24 = compilerOptions18.inlineGetters;
        boolean boolean25 = compilerOptions18.devirtualizePrototypeMethods;
        boolean boolean26 = jSError17.equals((java.lang.Object) compilerOptions18);
        compilerOptions18.removeUnusedVars = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup29 = null;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions18.setWarningLevel(diagnosticGroup29, checkLevel30);
        compilerOptions0.aggressiveVarCheck = checkLevel30;
        compilerOptions0.aliasableGlobals = "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType9);
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(jSError17);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        boolean boolean2 = compilerOptions0.rewriteFunctionExpressions;
        java.lang.String str3 = compilerOptions0.aliasableGlobals;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        java.lang.String str14 = compilerOptions0.syntheticBlockEndMarker;
        boolean boolean15 = compilerOptions0.checkSymbols;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.rhino.Node node7 = node3.getFirstChild();
        try {
            node7.setCharno((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.checkRequires;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions0.reportMissingOverride = checkLevel5;
        boolean boolean7 = compilerOptions0.instrumentForCoverageOnly;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setRemoveClosureAsserts(true);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.checkRequires = checkLevel4;
        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        compilerOptions0.inputVariableMapSerialized = byteArray11;
        compilerOptions0.optimizeCalls = true;
        boolean boolean15 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.Object obj0 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention1 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean3 = defaultCodingConvention1.isExported("language version");
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj0, (java.lang.Object) defaultCodingConvention1);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention5 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        boolean boolean12 = defaultCodingConvention5.isOptionalParameter(node10);
        java.util.List<java.lang.String> strList13 = defaultCodingConvention1.identifyTypeDeclarationCall(node10);
        com.google.javascript.rhino.Node node14 = node10.removeChildren();
        node10.putIntProp((int) ' ', 20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(runtimeException4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(strList13);
        org.junit.Assert.assertNull(node14);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray12 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, jSSourceFileArray12);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean22 = compilerOptions19.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions19.reportMissingOverride;
        boolean boolean24 = compilerOptions19.markNoSideEffectCalls;
        compiler4.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList13, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16, compilerOptions19);
        java.lang.String str26 = compiler4.getAstDotGraph();
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        jSSourceFile29.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        jSSourceFile29.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst35 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile29);
        com.google.javascript.rhino.Node node36 = compiler4.parse(jSSourceFile29);
        java.lang.String str39 = compiler4.getSourceLine("", 4095);
        com.google.javascript.jscomp.CodingConvention codingConvention40 = compiler4.getCodingConvention();
        java.lang.String[] strArray41 = compiler4.toSourceArray();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertNotNull(jSSourceFileArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertNull(node36);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertNotNull(codingConvention40);
        org.junit.Assert.assertNotNull(strArray41);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.setOriginalPath("null");
        com.google.javascript.jscomp.JsAst jsAst8 = new com.google.javascript.jscomp.JsAst((com.google.javascript.jscomp.SourceFile) jSSourceFile2);
        java.util.logging.Logger logger9 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager10 = new com.google.javascript.jscomp.LoggerErrorManager(logger9);
        double double11 = loggerErrorManager10.getTypedPercent();
        int int12 = loggerErrorManager10.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler13 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager10);
        com.google.javascript.rhino.Node node14 = compiler13.getRoot();
        com.google.javascript.rhino.Node node15 = jsAst8.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler13);
        jsAst8.clearAst();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        jSSourceFile19.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19);
        jSSourceFile19.setOriginalPath("null");
        jsAst8.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile19);
        com.google.javascript.jscomp.SourceFile sourceFile26 = jsAst8.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(sourceFile26);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            com.google.javascript.rhino.Context.reportWarning("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "or", 43, "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", 100);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.generatePseudoNames;
        java.lang.String str5 = compilerOptions0.reportPath;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkFunctions;
        byte[] byteArray7 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(byteArray7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        java.lang.String str8 = compilerOptions0.nameReferenceGraphPath;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        boolean boolean4 = defaultCodingConvention0.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType6 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType7 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType5, functionType6, subclassType7);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj10 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention11 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean13 = defaultCodingConvention11.isExported("language version");
        java.lang.RuntimeException runtimeException14 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj10, (java.lang.Object) defaultCodingConvention11);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention15 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node21 = com.google.javascript.jscomp.NodeUtil.newExpr(node20);
        boolean boolean22 = defaultCodingConvention15.isOptionalParameter(node20);
        java.util.List<java.lang.String> strList23 = defaultCodingConvention11.identifyTypeDeclarationCall(node20);
        boolean boolean24 = closureCodingConvention9.isVarArgsParameter(node20);
        boolean boolean25 = defaultCodingConvention0.isOptionalParameter(node20);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection26 = defaultCodingConvention0.getAssertionFunctions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(runtimeException14);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(strList23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection26);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset2);
        jSSourceFile3.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile3);
        jSSourceFile3.setOriginalPath("null");
        java.lang.String str9 = jSSourceFile3.getName();
        try {
            java.lang.String str10 = com.google.javascript.rhino.ScriptRuntime.getMessage1("language version", (java.lang.Object) str9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property language version");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
//        java.util.logging.Logger logger1 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
//        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard6 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup4, checkLevel5);
//        java.lang.String str7 = diagnosticGroupWarningsGuard6.toString();
//        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType15 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray22 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError23 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel14, diagnosticType15, strArray22);
//        java.lang.String[] strArray24 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType15, strArray24);
//        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = jSError25.getType();
//        int int27 = jSError25.lineNumber;
//        com.google.javascript.jscomp.CheckLevel checkLevel28 = diagnosticGroupWarningsGuard6.level(jSError25);
//        compiler3.report(jSError25);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel31 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions30.reportUnknownTypes = checkLevel31;
//        compilerOptions30.extractPrototypeMemberDeclarations = false;
//        boolean boolean35 = compilerOptions30.crossModuleCodeMotion;
//        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler36 = compilerOptions30.getAliasTransformationHandler();
//        com.google.javascript.jscomp.CheckLevel checkLevel37 = compilerOptions30.checkRequires;
//        com.google.javascript.jscomp.ErrorFormat errorFormat38 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
//        java.util.logging.Logger logger39 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager40 = new com.google.javascript.jscomp.LoggerErrorManager(logger39);
//        double double41 = loggerErrorManager40.getTypedPercent();
//        int int42 = loggerErrorManager40.getErrorCount();
//        com.google.javascript.jscomp.Compiler compiler43 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager40);
//        java.nio.charset.Charset charset45 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile46 = com.google.javascript.jscomp.JSSourceFile.fromFile("hi!", charset45);
//        java.nio.charset.Charset charset48 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile49 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset48);
//        com.google.javascript.jscomp.CompilerInput compilerInput50 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile49);
//        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray51 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile46, jSSourceFile49 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList52 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
//        boolean boolean53 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList52, jSSourceFileArray51);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray54 = new com.google.javascript.jscomp.JSModule[] {};
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList55 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList55, jSModuleArray54);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph57 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList55);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions58.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean61 = compilerOptions58.collapseVariableDeclarations;
//        com.google.javascript.jscomp.CheckLevel checkLevel62 = compilerOptions58.reportMissingOverride;
//        boolean boolean63 = compilerOptions58.markNoSideEffectCalls;
//        compiler43.initModules((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList52, (java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList55, compilerOptions58);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions65 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel66 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions65.reportUnknownTypes = checkLevel66;
//        compilerOptions65.syntheticBlockStartMarker = "ERROR 0";
//        compilerOptions65.markAsCompiled = false;
//        compilerOptions65.setRemoveAbstractMethods(true);
//        boolean boolean74 = compilerOptions65.markAsCompiled;
//        compilerOptions65.setNameAnonymousFunctionsOnly(false);
//        compiler43.initOptions(compilerOptions65);
//        com.google.javascript.jscomp.MessageFormatter messageFormatter79 = errorFormat38.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler43, true);
//        java.lang.String str80 = jSError25.format(checkLevel37, messageFormatter79);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str7.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticType15);
//        org.junit.Assert.assertNotNull(strArray22);
//        org.junit.Assert.assertNotNull(jSError23);
//        org.junit.Assert.assertNotNull(strArray24);
//        org.junit.Assert.assertNotNull(jSError25);
//        org.junit.Assert.assertNotNull(diagnosticType26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 32 + "'", int27 == 32);
//        org.junit.Assert.assertNull(checkLevel28);
//        org.junit.Assert.assertTrue("'" + checkLevel31 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel31.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(aliasTransformationHandler36);
//        org.junit.Assert.assertTrue("'" + checkLevel37 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel37.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(errorFormat38);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(jSSourceFile46);
//        org.junit.Assert.assertNotNull(jSSourceFile49);
//        org.junit.Assert.assertNotNull(jSSourceFileArray51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel66 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel66.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(messageFormatter79);
//        org.junit.Assert.assertNull(str80);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        boolean boolean14 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions15.reportUnknownTypes = checkLevel16;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        boolean boolean20 = compilerOptions15.crossModuleCodeMotion;
        boolean boolean21 = compilerOptions15.inlineGetters;
        boolean boolean22 = compilerOptions15.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions15.checkShadowVars;
        compilerOptions0.checkRequires = checkLevel23;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj26 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention27 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean29 = defaultCodingConvention27.isExported("language version");
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj26, (java.lang.Object) defaultCodingConvention27);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newExpr(node36);
        boolean boolean38 = defaultCodingConvention31.isOptionalParameter(node36);
        java.util.List<java.lang.String> strList39 = defaultCodingConvention27.identifyTypeDeclarationCall(node36);
        boolean boolean40 = closureCodingConvention25.isVarArgsParameter(node36);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention25);
        boolean boolean44 = closureCodingConvention25.isExported("or", false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(strList39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String str4 = compilerOptions0.syntheticBlockEndMarker;
        compilerOptions0.setTweakToBooleanLiteral("", true);
        compilerOptions0.unaliasableGlobals = "ERROR";
        boolean boolean10 = compilerOptions0.ideMode;
        boolean boolean11 = compilerOptions0.inlineLocalFunctions;
        boolean boolean12 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup0;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions3.reportUnknownTypes = checkLevel4;
//        compilerOptions3.setDefineToNumberLiteral("language version", (int) (short) 1);
//        boolean boolean9 = compilerOptions3.inlineLocalVariables;
//        java.util.logging.Logger logger10 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(logger10);
//        double double12 = loggerErrorManager11.getTypedPercent();
//        int int13 = loggerErrorManager11.getWarningCount();
//        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray28 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel20, diagnosticType21, strArray28);
//        java.lang.String[] strArray30 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType21, strArray30);
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType21.defaultLevel;
//        com.google.javascript.jscomp.CheckLevel checkLevel39 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray47 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel39, diagnosticType40, strArray47);
//        java.lang.String[] strArray49 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType40, strArray49);
//        loggerErrorManager11.report(checkLevel32, jSError50);
//        compilerOptions3.checkMissingGetCssNameLevel = checkLevel32;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard53 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel32);
//        java.lang.String str54 = diagnosticGroupWarningsGuard53.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup55 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
//        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup55;
//        com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS = diagnosticGroup55;
//        java.lang.String str58 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) diagnosticGroup55);
//        boolean boolean59 = diagnosticGroupWarningsGuard53.disables(diagnosticGroup55);
//        java.lang.String str60 = diagnosticGroup55.toString();
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(diagnosticType21);
//        org.junit.Assert.assertNotNull(strArray28);
//        org.junit.Assert.assertNotNull(jSError29);
//        org.junit.Assert.assertNotNull(strArray30);
//        org.junit.Assert.assertNotNull(jSError31);
//        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertNotNull(diagnosticType40);
//        org.junit.Assert.assertNotNull(strArray47);
//        org.junit.Assert.assertNotNull(jSError48);
//        org.junit.Assert.assertNotNull(strArray49);
//        org.junit.Assert.assertNotNull(jSError50);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "DiagnosticGroup<internetExplorerChecks>(ERROR)" + "'", str54.equals("DiagnosticGroup<internetExplorerChecks>(ERROR)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "DiagnosticGroup<internetExplorerChecks>" + "'", str58.equals("DiagnosticGroup<internetExplorerChecks>"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "DiagnosticGroup<internetExplorerChecks>" + "'", str60.equals("DiagnosticGroup<internetExplorerChecks>"));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        int int5 = compiler4.getWarningCount();
        try {
            compiler4.processDefines();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkShadowVars;
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean11 = compilerOptions0.ideMode;
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        compilerInput5.clearAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        java.lang.String str17 = closureCodingConvention0.getExportPropertyFunction();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "goog.exportProperty" + "'", str17.equals("goog.exportProperty"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions8.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.reportMissingOverride;
        compilerOptions11.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions11.checkGlobalNamesLevel;
        compilerOptions8.aggressiveVarCheck = checkLevel18;
        compilerOptions0.reportMissingOverride = checkLevel18;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions0.reportUnknownTypes;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        java.lang.Object obj9 = compilerOptions0.clone();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        java.nio.charset.Charset charset1 = null;
//        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
//        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
//        com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(160);
//        java.util.logging.Logger logger6 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(logger6);
//        double double8 = loggerErrorManager7.getTypedPercent();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean10 = compilerOptions9.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel11 = compilerOptions9.checkShadowVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel18 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType19 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray26 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel18, diagnosticType19, strArray26);
//        java.lang.String[] strArray28 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType19, strArray28);
//        loggerErrorManager7.println(checkLevel11, jSError29);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions31 = new com.google.javascript.jscomp.CompilerOptions();
//        com.google.javascript.jscomp.CheckLevel checkLevel32 = com.google.javascript.jscomp.CheckLevel.ERROR;
//        compilerOptions31.reportUnknownTypes = checkLevel32;
//        compilerOptions31.extractPrototypeMemberDeclarations = false;
//        compilerOptions31.aliasStringsBlacklist = "ERROR";
//        com.google.javascript.jscomp.CheckLevel checkLevel38 = compilerOptions31.aggressiveVarCheck;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions39 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions39.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean42 = compilerOptions39.collapseVariableDeclarations;
//        compilerOptions39.ambiguateProperties = false;
//        compilerOptions39.instrumentForCoverage = false;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean48 = compilerOptions47.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel49 = compilerOptions47.checkShadowVars;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions50 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions50.removeUnusedPrototypePropertiesInExterns = false;
//        boolean boolean53 = compilerOptions50.collapseVariableDeclarations;
//        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions50.reportMissingOverride;
//        compilerOptions50.recordFunctionInformation = false;
//        com.google.javascript.jscomp.CheckLevel checkLevel57 = compilerOptions50.checkGlobalNamesLevel;
//        compilerOptions47.aggressiveVarCheck = checkLevel57;
//        compilerOptions39.reportMissingOverride = checkLevel57;
//        compilerOptions31.reportMissingOverride = checkLevel57;
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup61 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel68 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType69 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray76 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError77 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel68, diagnosticType69, strArray76);
//        java.lang.String[] strArray78 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError79 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType69, strArray78);
//        java.lang.RuntimeException runtimeException81 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError79, (java.lang.Object) 41);
//        int int82 = jSError79.lineNumber;
//        boolean boolean83 = diagnosticGroup61.matches(jSError79);
//        com.google.javascript.jscomp.CheckLevel checkLevel84 = jSError79.level;
//        loggerErrorManager7.report(checkLevel57, jSError79);
//        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
//        com.google.javascript.jscomp.CompilerInput compilerInput87 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3);
//        org.junit.Assert.assertNotNull(jSSourceFile2);
//        org.junit.Assert.assertNull(region5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType19);
//        org.junit.Assert.assertNotNull(strArray26);
//        org.junit.Assert.assertNotNull(jSError27);
//        org.junit.Assert.assertNotNull(strArray28);
//        org.junit.Assert.assertNotNull(jSError29);
//        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
//        org.junit.Assert.assertTrue("'" + checkLevel38 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel38.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertTrue("'" + checkLevel57 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel57.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup61);
//        org.junit.Assert.assertNotNull(diagnosticType69);
//        org.junit.Assert.assertNotNull(strArray76);
//        org.junit.Assert.assertNotNull(jSError77);
//        org.junit.Assert.assertNotNull(strArray78);
//        org.junit.Assert.assertNotNull(jSError79);
//        org.junit.Assert.assertNotNull(runtimeException81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 32 + "'", int82 == 32);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel84 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel84.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportUnknownTypes;
        compilerOptions0.checkEs5Strict = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        int int14 = loggerErrorManager12.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel21, diagnosticType22, strArray29);
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType22, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel40, diagnosticType41, strArray48);
        java.lang.String[] strArray50 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType41, strArray50);
        loggerErrorManager12.report(checkLevel33, jSError51);
        compilerOptions0.reportMissingOverride = checkLevel33;
        boolean boolean54 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention55 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean57 = defaultCodingConvention55.isConstant("hi!");
        boolean boolean59 = defaultCodingConvention55.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray74 = new com.google.javascript.rhino.Node[] { node64, node68, node73 };
        com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray74);
        int int77 = node75.getIntProp(10);
        com.google.javascript.rhino.Node node78 = node75.getNext();
        java.lang.String str79 = defaultCodingConvention55.identifyTypeDefAssign(node78);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention55);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(nodeArray74);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNull(node78);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(17, nodeArray1, 45, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags(29);
        sideEffectFlags1.setReturnsTainted();
        sideEffectFlags1.setMutatesGlobalState();
        boolean boolean4 = sideEffectFlags1.areAllFlagsSet();
        sideEffectFlags1.setMutatesArguments();
        sideEffectFlags1.clearAllFlags();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        com.google.javascript.jscomp.CompilerOptions compilerOptions4 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions4.checkProvides;
        compilerOptions4.aliasExternals = false;
        compilerOptions4.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions4.reportUnknownTypes;
        compilerOptions0.checkGlobalThisLevel = checkLevel10;
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.brokenClosureRequiresLevel;
        compilerOptions0.tightenTypes = false;
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesThis();
        sideEffectFlags0.clearSideEffectFlags();
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.lang.String str4 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.foldConstants = true;
        compilerOptions0.setDefineToStringLiteral("ECMASCRIPT5", "com.google.javascript.rhino.EcmaError: hi!:  (#10)");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions0.reportUnknownTypes = checkLevel4;
        compilerOptions0.checkCaja = true;
        java.lang.String str9 = compilerOptions0.debugFunctionSideEffectsPath;
        java.lang.String str10 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setRemoveAbstractMethods(false);
        boolean boolean13 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node16);
        com.google.javascript.rhino.Node node18 = node16.getNext();
        java.lang.String str19 = closureCodingConvention0.identifyTypeDefAssign(node16);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] { node24, node28, node33 };
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray34);
        int int37 = node35.getIntProp(10);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        int int54 = node53.getSideEffectFlags();
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node59, node63, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray69);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection71 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node70);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node80 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray86 = new com.google.javascript.rhino.Node[] { node76, node80, node85 };
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray86);
        java.lang.String str91 = node87.toString(false, false, true);
        node53.addChildAfter(node70, node87);
        java.lang.String str93 = closureCodingConvention0.extractClassNameIfRequire(node35, node70);
        com.google.javascript.rhino.Node node97 = new com.google.javascript.rhino.Node(18, (int) (short) 1, 40);
        int int98 = node97.getSourcePosition();
        try {
            boolean boolean99 = closureCodingConvention0.isPropertyTestFunction(node97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertNotNull(nodeCollection17);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNotNull(nodeCollection71);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertNotNull(nodeArray86);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "ERROR" + "'", str91.equals("ERROR"));
        org.junit.Assert.assertNull(str93);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 4136 + "'", int98 == 4136);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        boolean boolean4 = node3.hasOneChild();
        boolean boolean5 = node3.wasEmptyNode();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList6);
        java.util.Set<java.lang.String> strSet9 = null;
        compilerOptions0.aliasableStrings = strSet9;
        compilerOptions0.exportTestFunctions = true;
        compilerOptions0.coalesceVariableNames = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.collapseVariableDeclarations = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy6 = compilerOptions0.variableRenaming;
        boolean boolean7 = compilerOptions0.inlineAnonymousFunctionExpressions;
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy6 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy6.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.lang.Object obj2 = context1.getDebuggerContextData();
//        java.lang.Object obj3 = null;
//        context1.seal(obj3);
//        java.lang.String str5 = context1.getImplementationVersion();
//        int int6 = context1.getLanguageVersion();
//        int int7 = context1.getInstructionObserverThreshold();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str5.equals("@IMPLEMENTATION.VERSION@"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback2);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray18 = new com.google.javascript.rhino.Node[] { node8, node12, node17 };
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray18);
        com.google.javascript.rhino.Node node20 = node19.cloneNode();
        node19.setOptionalArg(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.MOTION_ITERATIONS_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("hi!: ", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.jscomp.CheckLevel checkLevel33 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray41 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel33, diagnosticType34, strArray41);
        com.google.javascript.jscomp.JSError jSError43 = com.google.javascript.jscomp.JSError.make("DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null), DiagnosticGroup<fileoverviewTags>(null)", 27, (int) ' ', diagnosticType29, strArray41);
        com.google.javascript.jscomp.JSError jSError44 = nodeTraversal3.makeError(node19, diagnosticType23, strArray41);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeArray18);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(jSError43);
        org.junit.Assert.assertNotNull(jSError44);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        compilerOptions0.removeUnusedVars = true;
        compilerOptions0.inlineGetters = true;
        compilerOptions0.prettyPrint = false;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean13 = node12.wasEmptyNode();
        java.lang.String[] strArray24 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet25 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet25, strArray24);
        node12.setDirectives((java.util.Set<java.lang.String>) strSet25);
        compilerOptions0.stripTypes = strSet25;
        boolean boolean29 = compilerOptions0.removeUnusedVars;
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        compilerOptions0.generateExports = true;
        boolean boolean7 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = false;
        boolean boolean8 = compilerOptions0.gatherCssNames;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap9 = compilerOptions0.customPasses;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.appNameStr = "ERROR";
        compilerOptions0.setAcceptConstKeyword(true);
        com.google.javascript.jscomp.CodingConvention codingConvention10 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(codingConvention10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.util.logging.Logger logger7 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager8 = new com.google.javascript.jscomp.LoggerErrorManager(logger7);
        double double9 = loggerErrorManager8.getTypedPercent();
        int int10 = loggerErrorManager8.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager8);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker12 = compiler11.tracker;
        com.google.javascript.rhino.Node node13 = compilerInput6.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler11);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = loggerErrorManager15.getWarnings();
        compilerInput6.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.SourceFile sourceFile20 = compilerInput6.getSourceFile();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(performanceTracker12);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNotNull(sourceFile20);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        com.google.javascript.rhino.Node node16 = node15.cloneNode();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node21);
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        com.google.javascript.rhino.Node node39 = node38.cloneNode();
        node22.addChildrenToBack(node38);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node49 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray55 = new com.google.javascript.rhino.Node[] { node45, node49, node54 };
        com.google.javascript.rhino.Node node56 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray55);
        int int58 = node56.getIntProp(10);
        com.google.javascript.rhino.Node node59 = node56.getNext();
        node16.addChildAfter(node22, node56);
        boolean boolean61 = node16.isQuotedString();
        com.google.javascript.rhino.Node node62 = null;
        try {
            node16.removeChild(node62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(nodeArray55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNull(node59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions1.reportUnknownTypes = checkLevel2;
        compilerOptions1.extractPrototypeMemberDeclarations = false;
        compilerOptions1.aliasStringsBlacklist = "ERROR";
        compilerOptions1.disambiguateProperties = false;
        compilerOptions1.checkTypedPropertyCalls = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean13 = compilerOptions12.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions12.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions15.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean18 = compilerOptions15.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions15.reportMissingOverride;
        compilerOptions15.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions15.checkGlobalNamesLevel;
        compilerOptions12.aggressiveVarCheck = checkLevel22;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = compilerOptions12.checkProvides;
        compilerOptions1.checkGlobalNamesLevel = checkLevel24;
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int30 = node29.getChildCount();
        node29.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention33 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean35 = defaultCodingConvention33.isExported("language version");
        boolean boolean37 = defaultCodingConvention33.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray52 = new com.google.javascript.rhino.Node[] { node42, node46, node51 };
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray52);
        java.lang.String str54 = defaultCodingConvention33.getSingletonGetterClassName(node53);
        node29.addChildrenToBack(node53);
        com.google.javascript.rhino.Node node56 = node29.getLastChild();
        java.lang.Class<?> wildcardClass57 = node56.getClass();
        com.google.javascript.jscomp.CompilerOptions compilerOptions58 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel59 = compilerOptions58.checkProvides;
        compilerOptions58.crossModuleCodeMotion = true;
        java.lang.String[] strArray63 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList64 = new java.util.ArrayList<java.lang.String>();
        boolean boolean65 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList64, strArray63);
        compilerOptions58.setManageClosureDependencies((java.util.List<java.lang.String>) strList64);
        com.google.javascript.jscomp.SourceMap.Format format67 = compilerOptions58.sourceMapFormat;
        com.google.javascript.jscomp.CheckLevel checkLevel68 = compilerOptions58.checkGlobalThisLevel;
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node77 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray83 = new com.google.javascript.rhino.Node[] { node73, node77, node82 };
        com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray83);
        int int86 = node84.getIntProp(10);
        int int87 = node84.getSourcePosition();
        boolean boolean88 = node84.hasMoreThanOneChild();
        boolean boolean89 = node84.isQualifiedName();
        com.google.javascript.rhino.Node node90 = node84.cloneNode();
        try {
            java.lang.String str91 = com.google.javascript.rhino.ScriptRuntime.getMessage4("goog.exportSymbol", (java.lang.Object) checkLevel24, (java.lang.Object) wildcardClass57, (java.lang.Object) compilerOptions58, (java.lang.Object) node84);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportSymbol");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(nodeArray52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + checkLevel59 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel59.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(format67);
        org.junit.Assert.assertTrue("'" + checkLevel68 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel68.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(nodeArray83);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(node90);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkUndefinedProperties;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing3 = compilerOptions0.getTweakProcessing();
        boolean boolean4 = tweakProcessing3.isOn();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + tweakProcessing3 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing3.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int4 = node3.getChildCount();
        node3.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isExported("language version");
        boolean boolean11 = defaultCodingConvention7.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        java.lang.String str28 = defaultCodingConvention7.getSingletonGetterClassName(node27);
        node3.addChildrenToBack(node27);
        node3.detachChildren();
        boolean boolean31 = node3.hasOneChild();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.lang.String str4 = jSSourceFile2.getOriginalPath();
        java.lang.String str5 = jSSourceFile2.toString();
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", true);
        java.lang.String str10 = compilerInput6.getName();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        closureCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        boolean boolean8 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(logger6);
        double double8 = loggerErrorManager7.getTypedPercent();
        int int9 = loggerErrorManager7.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler10 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        int int11 = compiler10.getWarningCount();
        compiler10.reportCodeChange();
        try {
            compilerInput5.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray0 = null;
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticGroupArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setCollapsePropertiesOnExternTypes(true);
        boolean boolean11 = compilerOptions8.inlineLocalFunctions;
        boolean boolean12 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setCollapsePropertiesOnExternTypes(true);
        boolean boolean16 = compilerOptions13.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet17 = compilerOptions13.aliasableStrings;
        compilerOptions8.stripTypes = strSet17;
        compilerOptions0.stripNameSuffixes = strSet17;
        boolean boolean20 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.setSummaryDetailLevel(44);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions23.optimizeReturns = true;
        compilerOptions23.removeUnusedVars = true;
        compilerOptions23.inlineGetters = true;
        compilerOptions23.prettyPrint = false;
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString("ERROR");
        boolean boolean36 = node35.wasEmptyNode();
        java.lang.String[] strArray47 = new java.lang.String[] { "ERROR 0", "EOF 10\n", "DiagnosticGroup<deprecated>(null)", "<No stack trace available>", "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "<No stack trace available>" };
        java.util.LinkedHashSet<java.lang.String> strSet48 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet48, strArray47);
        node35.setDirectives((java.util.Set<java.lang.String>) strSet48);
        compilerOptions23.stripTypes = strSet48;
        compilerOptions0.stripTypePrefixes = strSet48;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        int int2 = context1.getLanguageVersion();
//        long long3 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
//        java.lang.Object obj5 = context1.getThreadLocal((java.lang.Object) diagnosticGroup4);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
//        compilerOptions6.setCollapsePropertiesOnExternTypes(true);
//        boolean boolean9 = compilerOptions6.recordFunctionInformation;
//        compilerOptions6.reserveRawExports = true;
//        compilerOptions6.setOutputCharset("null");
//        compilerOptions6.setCollapsePropertiesOnExternTypes(true);
//        compilerOptions6.setProcessObjectPropertyString(true);
//        boolean boolean18 = compilerOptions6.lineBreak;
//        context1.removeThreadLocal((java.lang.Object) compilerOptions6);
//        compilerOptions6.ideMode = true;
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(diagnosticGroup4);
//        org.junit.Assert.assertNull(obj5);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region7 = compilerInput5.getRegion(43);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        boolean boolean10 = compilerInput9.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("error reporter", "hi!");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        java.lang.String[] strArray5 = new java.lang.String[] { "hi!: " };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setManageClosureDependencies((java.util.List<java.lang.String>) strList6);
        java.util.Set<java.lang.String> strSet9 = null;
        compilerOptions0.aliasableStrings = strSet9;
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        boolean boolean10 = compilerOptions0.moveFunctionDeclarations;
        compilerOptions0.setDefineToDoubleLiteral("goog.exportProperty", (double) 38);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        compilerOptions0.instrumentForCoverage = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions8.checkShadowVars;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions11.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean14 = compilerOptions11.collapseVariableDeclarations;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions11.reportMissingOverride;
        compilerOptions11.recordFunctionInformation = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions11.checkGlobalNamesLevel;
        compilerOptions8.aggressiveVarCheck = checkLevel18;
        compilerOptions0.reportMissingOverride = checkLevel18;
        boolean boolean21 = compilerOptions0.aliasKeywords;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = compilerOptions0.checkProvides;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap23 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap23;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            boolean boolean5 = compiler4.isTypeCheckingEnabled();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int11 = node10.getChildCount();
        com.google.javascript.rhino.Node node12 = node10.getLastChild();
        java.lang.String str13 = defaultCodingConvention0.identifyTypeDefAssign(node12);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.rhino.Node node19 = compiler18.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback20);
        int int22 = nodeTraversal21.getLineNumber();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        int int40 = node38.getIntProp(10);
        int int41 = node38.getSourcePosition();
        boolean boolean42 = node38.hasMoreThanOneChild();
        boolean boolean43 = node38.isQualifiedName();
        com.google.javascript.rhino.Node node44 = null;
        com.google.javascript.rhino.Node node45 = node38.getChildBefore(node44);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast46 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal21, node45);
        boolean boolean48 = defaultCodingConvention0.isSuperClassReference("");
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node54 = com.google.javascript.jscomp.NodeUtil.newExpr(node53);
        int int55 = node54.getSourcePosition();
        try {
            boolean boolean56 = defaultCodingConvention0.isVarArgsParameter(node54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(objectLiteralCast46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.closurePass;
        compilerOptions0.setRewriteNewDateGoogNow(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) 'a');
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        int int33 = node32.getSideEffectFlags();
        boolean boolean34 = node32.wasEmptyNode();
        boolean boolean35 = node32.hasSideEffects();
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int40 = node39.getChildCount();
        node39.setCharno(0);
        boolean boolean43 = node39.isQuotedString();
        com.google.javascript.rhino.Node node44 = node32.clonePropsFrom(node39);
        node44.removeProp(1);
        java.lang.String str47 = closureCodingConvention0.getSingletonGetterClassName(node44);
        boolean boolean50 = closureCodingConvention0.isExported("", true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        compilerOptions0.checkCaja = true;
        compilerOptions0.decomposeExpressions = false;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.checkTypedPropertyCalls = false;
        compilerOptions0.removeUnusedVars = false;
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions10.reportUnknownTypes = checkLevel11;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel14 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions13.reportUnknownTypes = checkLevel14;
        compilerOptions10.reportUnknownTypes = checkLevel14;
        java.util.Set<java.lang.String> strSet17 = compilerOptions10.stripNameSuffixes;
        compilerOptions10.collapseProperties = false;
        boolean boolean20 = compilerOptions10.ideMode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel22 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions21.reportUnknownTypes = checkLevel22;
        compilerOptions21.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions21.markAsCompiled = false;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = compilerOptions21.checkMissingReturn;
        compilerOptions10.checkMissingGetCssNameLevel = checkLevel28;
        compilerOptions0.reportUnknownTypes = checkLevel28;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel22 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel22.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray15 = new com.google.javascript.rhino.Node[] { node5, node9, node14 };
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray15);
        int int17 = node16.getSideEffectFlags();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray32 = new com.google.javascript.rhino.Node[] { node22, node26, node31 };
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray32);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection34 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node33);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray49 = new com.google.javascript.rhino.Node[] { node39, node43, node48 };
        com.google.javascript.rhino.Node node50 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray49);
        java.lang.String str54 = node50.toString(false, false, true);
        node16.addChildAfter(node33, node50);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int60 = node59.getChildCount();
        java.lang.Object obj62 = node59.getProp(0);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection63 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node59);
        com.google.javascript.rhino.Node node64 = node33.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString(44, "ERROR");
        com.google.javascript.rhino.Node node68 = null;
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) (byte) 1, 0, 23);
        try {
            com.google.javascript.rhino.Node node75 = new com.google.javascript.rhino.Node(0, node64, node67, node68, node72, 21, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(nodeArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(nodeArray32);
        org.junit.Assert.assertNotNull(nodeCollection34);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(nodeArray49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ERROR" + "'", str54.equals("ERROR"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertNotNull(nodeCollection63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node67);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean2 = compilerOptions1.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions1.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard4 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel3);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
//        java.lang.String str8 = diagnosticGroupWarningsGuard7.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup9 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean11 = compilerOptions10.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions10.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard13 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup9, checkLevel12);
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup14 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
//        com.google.javascript.jscomp.CheckLevel checkLevel15 = null;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard16 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup14, checkLevel15);
//        java.lang.String str17 = diagnosticGroupWarningsGuard16.toString();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup18 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
//        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean20 = compilerOptions19.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions19.checkUndefinedProperties;
//        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard22 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup18, checkLevel21);
//        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray23 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard4, diagnosticGroupWarningsGuard7, diagnosticGroupWarningsGuard13, diagnosticGroupWarningsGuard16, diagnosticGroupWarningsGuard22 };
//        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard24 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray23);
//        java.util.logging.Logger logger25 = null;
//        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager26 = new com.google.javascript.jscomp.LoggerErrorManager(logger25);
//        double double27 = loggerErrorManager26.getTypedPercent();
//        com.google.javascript.jscomp.CompilerOptions compilerOptions28 = new com.google.javascript.jscomp.CompilerOptions();
//        boolean boolean29 = compilerOptions28.markNoSideEffectCalls;
//        com.google.javascript.jscomp.CheckLevel checkLevel30 = compilerOptions28.checkShadowVars;
//        com.google.javascript.jscomp.CheckLevel checkLevel37 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray45 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError46 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel37, diagnosticType38, strArray45);
//        java.lang.String[] strArray47 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType38, strArray47);
//        loggerErrorManager26.println(checkLevel30, jSError48);
//        int int50 = jSError48.lineNumber;
//        com.google.javascript.jscomp.CheckLevel checkLevel51 = composeWarningsGuard24.level(jSError48);
//        org.junit.Assert.assertNotNull(diagnosticGroup0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str8.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticGroup14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str17.equals("DiagnosticGroup<fileoverviewTags>(null)"));
//        org.junit.Assert.assertNotNull(diagnosticGroup18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(warningsGuardArray23);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.OFF));
//        org.junit.Assert.assertNotNull(diagnosticType38);
//        org.junit.Assert.assertNotNull(strArray45);
//        org.junit.Assert.assertNotNull(jSError46);
//        org.junit.Assert.assertNotNull(strArray47);
//        org.junit.Assert.assertNotNull(jSError48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 32 + "'", int50 == 32);
//        org.junit.Assert.assertNull(checkLevel51);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error(": com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)", "ERROR 0");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel9 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.reportUnknownTypes = checkLevel9;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions8.reportUnknownTypes = checkLevel12;
        compilerOptions0.checkProvides = checkLevel12;
        compilerOptions0.extractPrototypeMemberDeclarations = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        jSSourceFile2.setOriginalPath("language version");
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Region region7 = compilerInput5.getRegion(43);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput5);
        java.util.logging.Logger logger10 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager11 = new com.google.javascript.jscomp.LoggerErrorManager(logger10);
        double double12 = loggerErrorManager11.getTypedPercent();
        int int13 = loggerErrorManager11.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel20 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray28 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError29 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel20, diagnosticType21, strArray28);
        java.lang.String[] strArray30 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType21, strArray30);
        com.google.javascript.jscomp.CheckLevel checkLevel32 = diagnosticType21.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel39 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray47 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError48 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel39, diagnosticType40, strArray47);
        java.lang.String[] strArray49 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType40, strArray49);
        loggerErrorManager11.report(checkLevel32, jSError50);
        int int52 = loggerErrorManager11.getErrorCount();
        compilerInput5.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager11);
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNull(region7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertNotNull(jSError29);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + checkLevel32 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel32.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray47);
        org.junit.Assert.assertNotNull(jSError48);
        org.junit.Assert.assertNotNull(strArray49);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkShadowVars;
        boolean boolean3 = compilerOptions0.removeUnusedLocalVars;
        boolean boolean4 = compilerOptions0.generatePseudoNames;
        boolean boolean5 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
        java.lang.String str2 = evaluatorException1.getScriptStackTrace();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "<No stack trace available>" + "'", str2.equals("<No stack trace available>"));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = context0.getErrorReporter();
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions2.reportUnknownTypes = checkLevel3;
        boolean boolean5 = compilerOptions2.inlineGetters;
        compilerOptions2.rewriteFunctionExpressions = true;
        java.lang.Object obj8 = context0.getThreadLocal((java.lang.Object) true);
        org.junit.Assert.assertNull(errorReporter1);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(0, (int) (byte) 10, 0);
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = node3.getJSDocInfo();
        node3.setType((int) (short) 1);
        boolean boolean7 = node3.isQuotedString();
        org.junit.Assert.assertNull(jSDocInfo4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        int int18 = node15.getSourcePosition();
        boolean boolean19 = node15.hasMoreThanOneChild();
        boolean boolean20 = node15.isQualifiedName();
        com.google.javascript.rhino.Node node21 = null;
        com.google.javascript.rhino.Node node22 = node15.getChildBefore(node21);
        try {
            node15.setDouble((double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        boolean boolean5 = compilerOptions0.checkTypedPropertyCalls;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n", (java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("ECMASCRIPT5", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        java.lang.String str3 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.removeTryCatchFinally = false;
        java.lang.String str9 = compilerOptions0.aliasableGlobals;
        boolean boolean10 = compilerOptions0.checkEs5Strict;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        compilerOptions0.aliasStringsBlacklist = "ERROR";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.aggressiveVarCheck;
        boolean boolean8 = compilerOptions0.checkSymbols;
        compilerOptions0.flowSensitiveInlineVariables = false;
        java.util.Set<java.lang.String> strSet11 = compilerOptions0.stripTypes;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        boolean boolean14 = compilerOptions0.flowSensitiveInlineVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel16 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions15.reportUnknownTypes = checkLevel16;
        compilerOptions15.extractPrototypeMemberDeclarations = false;
        boolean boolean20 = compilerOptions15.crossModuleCodeMotion;
        boolean boolean21 = compilerOptions15.inlineGetters;
        boolean boolean22 = compilerOptions15.devirtualizePrototypeMethods;
        com.google.javascript.jscomp.CheckLevel checkLevel23 = compilerOptions15.checkShadowVars;
        compilerOptions0.checkRequires = checkLevel23;
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention25 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj26 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention27 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean29 = defaultCodingConvention27.isExported("language version");
        java.lang.RuntimeException runtimeException30 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj26, (java.lang.Object) defaultCodingConvention27);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention31 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node37 = com.google.javascript.jscomp.NodeUtil.newExpr(node36);
        boolean boolean38 = defaultCodingConvention31.isOptionalParameter(node36);
        java.util.List<java.lang.String> strList39 = defaultCodingConvention27.identifyTypeDeclarationCall(node36);
        boolean boolean40 = closureCodingConvention25.isVarArgsParameter(node36);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) closureCodingConvention25);
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection42 = closureCodingConvention25.getAssertionFunctions();
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int47 = node46.getChildCount();
        node46.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention50 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean52 = defaultCodingConvention50.isExported("language version");
        boolean boolean54 = defaultCodingConvention50.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray69 = new com.google.javascript.rhino.Node[] { node59, node63, node68 };
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray69);
        java.lang.String str71 = defaultCodingConvention50.getSingletonGetterClassName(node70);
        node46.addChildrenToBack(node70);
        node46.detachChildren();
        com.google.javascript.rhino.Node node74 = node46.getParent();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention75 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node81 = com.google.javascript.jscomp.NodeUtil.newExpr(node80);
        boolean boolean82 = defaultCodingConvention75.isOptionalParameter(node80);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node88 = com.google.javascript.jscomp.NodeUtil.newExpr(node87);
        java.lang.String str89 = defaultCodingConvention75.getSingletonGetterClassName(node88);
        java.lang.String str90 = closureCodingConvention25.extractClassNameIfRequire(node46, node88);
        node88.putIntProp(0, 27);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel23 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel23.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(runtimeException30);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(strList39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(nodeArray69);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertNull(node74);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNull(str89);
        org.junit.Assert.assertNull(str90);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        int int14 = loggerErrorManager12.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel21, diagnosticType22, strArray29);
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType22, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel40, diagnosticType41, strArray48);
        java.lang.String[] strArray50 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType41, strArray50);
        loggerErrorManager12.report(checkLevel33, jSError51);
        compilerOptions0.reportMissingOverride = checkLevel33;
        boolean boolean54 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        compilerOptions0.enableRuntimeTypeCheck("com.google.javascript.rhino.EcmaError: hi!:  (#10)");
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        try {
            com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = compiler4.getTypeRegistry();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getAbstractMethodName();
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray31 = new com.google.javascript.rhino.Node[] { node21, node25, node30 };
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray31);
        int int33 = node32.getSideEffectFlags();
        boolean boolean34 = node32.wasEmptyNode();
        boolean boolean35 = node32.hasSideEffects();
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int40 = node39.getChildCount();
        node39.setCharno(0);
        boolean boolean43 = node39.isQuotedString();
        com.google.javascript.rhino.Node node44 = node32.clonePropsFrom(node39);
        node44.removeProp(1);
        java.lang.String str47 = closureCodingConvention0.getSingletonGetterClassName(node44);
        com.google.javascript.rhino.Node node48 = null;
        try {
            boolean boolean49 = closureCodingConvention0.isPropertyTestFunction(node48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.abstractMethod" + "'", str16.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(nodeArray31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNull(str47);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("Named type with empty name component", "JSC_NODE_TRAVERSAL_ERROR: {0}");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        compilerOptions0.flowSensitiveInlineVariables = true;
        boolean boolean16 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        byte[] byteArray5 = compilerOptions0.inputPropertyMapSerialized;
        boolean boolean6 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.checkCaja = true;
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        boolean boolean6 = compilerOptions0.inlineGetters;
        boolean boolean7 = compilerOptions0.devirtualizePrototypeMethods;
        compilerOptions0.setShadowVariables(true);
        java.lang.String str10 = compilerOptions0.syntheticBlockStartMarker;
        java.util.logging.Logger logger11 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager12 = new com.google.javascript.jscomp.LoggerErrorManager(logger11);
        double double13 = loggerErrorManager12.getTypedPercent();
        int int14 = loggerErrorManager12.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel21 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError30 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel21, diagnosticType22, strArray29);
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType22, strArray31);
        com.google.javascript.jscomp.CheckLevel checkLevel33 = diagnosticType22.defaultLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel40 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType41 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray48 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError49 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel40, diagnosticType41, strArray48);
        java.lang.String[] strArray50 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType41, strArray50);
        loggerErrorManager12.report(checkLevel33, jSError51);
        compilerOptions0.reportMissingOverride = checkLevel33;
        com.google.javascript.jscomp.CheckLevel checkLevel54 = compilerOptions0.checkGlobalNamesLevel;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy55 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy55;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertNotNull(jSError30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertTrue("'" + checkLevel33 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel33.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType41);
        org.junit.Assert.assertNotNull(strArray48);
        org.junit.Assert.assertNotNull(jSError49);
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertTrue("'" + checkLevel54 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel54.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy55 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy55.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkMethods;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention0, "language version", 160, (int) '4');
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int11 = node10.getChildCount();
        com.google.javascript.rhino.Node node12 = node10.getLastChild();
        java.lang.String str13 = defaultCodingConvention0.identifyTypeDefAssign(node12);
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(logger14);
        double double16 = loggerErrorManager15.getTypedPercent();
        int int17 = loggerErrorManager15.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler18 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.rhino.Node node19 = compiler18.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler18, callback20);
        int int22 = nodeTraversal21.getLineNumber();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray37 = new com.google.javascript.rhino.Node[] { node27, node31, node36 };
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray37);
        int int40 = node38.getIntProp(10);
        int int41 = node38.getSourcePosition();
        boolean boolean42 = node38.hasMoreThanOneChild();
        boolean boolean43 = node38.isQualifiedName();
        com.google.javascript.rhino.Node node44 = null;
        com.google.javascript.rhino.Node node45 = node38.getChildBefore(node44);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast46 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal21, node45);
        boolean boolean47 = nodeTraversal21.hasScope();
        int int48 = nodeTraversal21.getLineNumber();
        boolean boolean49 = nodeTraversal21.hasScope();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(node19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(nodeArray37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNull(objectLiteralCast46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test463");
//        java.io.PrintStream printStream0 = null;
//        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
//        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
//        com.google.javascript.jscomp.DiagnosticType diagnosticType9 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
//        java.lang.String[] strArray16 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
//        com.google.javascript.jscomp.JSError jSError17 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel8, diagnosticType9, strArray16);
//        java.lang.String[] strArray18 = new java.lang.String[] {};
//        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType9, strArray18);
//        java.lang.RuntimeException runtimeException21 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) jSError19, (java.lang.Object) 41);
//        compiler1.report(jSError19);
//        org.junit.Assert.assertNotNull(diagnosticType9);
//        org.junit.Assert.assertNotNull(strArray16);
//        org.junit.Assert.assertNotNull(jSError17);
//        org.junit.Assert.assertNotNull(strArray18);
//        org.junit.Assert.assertNotNull(jSError19);
//        org.junit.Assert.assertNotNull(runtimeException21);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.setCollapsePropertiesOnExternTypes(true);
        boolean boolean11 = compilerOptions8.inlineLocalFunctions;
        boolean boolean12 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions13 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions13.setCollapsePropertiesOnExternTypes(true);
        boolean boolean16 = compilerOptions13.recordFunctionInformation;
        java.util.Set<java.lang.String> strSet17 = compilerOptions13.aliasableStrings;
        compilerOptions8.stripTypes = strSet17;
        compilerOptions0.stripNameSuffixes = strSet17;
        boolean boolean20 = compilerOptions0.ignoreCajaProperties;
        compilerOptions0.setSummaryDetailLevel(44);
        compilerOptions0.renamePrefix = "ERROR 0";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strSet17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!: ", "DiagnosticGroup<deprecated>(null)", "hi!: ", 27, "Unknown class name", 7);
        java.io.FilenameFilter filenameFilter7 = null;
        java.lang.String str8 = ecmaError6.getScriptStackTrace(filenameFilter7);
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<No stack trace available>" + "'", str8.equals("<No stack trace available>"));
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test466");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("DiagnosticGroup<internetExplorerChecks>");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: DiagnosticGroup<internetExplorerChecks>");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.optimizeReturns = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.appNameStr = "ERROR";
        compilerOptions0.collapseVariableDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("DiagnosticGroup<fileoverviewTags>(null)");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DiagnosticGroup<fileoverviewTags>(null)" + "'", str1.equals("DiagnosticGroup<fileoverviewTags>(null)"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.crossModuleCodeMotion = true;
        compilerOptions0.exportTestFunctions = true;
        boolean boolean6 = compilerOptions0.checkCaja;
        boolean boolean7 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.markNoSideEffectCalls = true;
        compilerOptions0.checkSuspiciousCode = true;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.NodeUtil.newExpr(node5);
        boolean boolean7 = defaultCodingConvention0.isOptionalParameter(node5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node13 = com.google.javascript.jscomp.NodeUtil.newExpr(node12);
        java.lang.String str14 = defaultCodingConvention0.getSingletonGetterClassName(node13);
        com.google.javascript.rhino.Node node15 = node13.cloneTree();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesGlobalState();
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler6 = compilerOptions0.getAliasTransformationHandler();
        compilerOptions0.sourceMapOutputPath = "null";
        boolean boolean9 = compilerOptions0.inlineGetters;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        int int18 = node15.getSourcePosition();
        boolean boolean19 = node15.hasMoreThanOneChild();
        boolean boolean20 = node15.isQualifiedName();
        com.google.javascript.rhino.Node node21 = node15.cloneNode();
        com.google.javascript.rhino.Node node22 = node21.removeFirstChild();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention23 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean25 = defaultCodingConvention23.isExported("language version");
        boolean boolean27 = defaultCodingConvention23.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray42 = new com.google.javascript.rhino.Node[] { node32, node36, node41 };
        com.google.javascript.rhino.Node node43 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray42);
        java.lang.String str44 = defaultCodingConvention23.getSingletonGetterClassName(node43);
        node43.removeProp((int) (byte) 0);
        com.google.javascript.rhino.Node node47 = node43.cloneTree();
        com.google.javascript.rhino.Node node48 = node21.copyInformationFromForTree(node47);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray42);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        java.util.Locale locale1 = context0.getLocale();
        org.junit.Assert.assertNotNull(locale1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int17 = node15.getIntProp(10);
        int int18 = node15.getSourcePosition();
        boolean boolean19 = node15.hasMoreThanOneChild();
        boolean boolean20 = node15.isQualifiedName();
        com.google.javascript.rhino.Node node21 = null;
        com.google.javascript.rhino.Node node22 = node15.getChildBefore(node21);
        node15.setVarArgs(true);
        boolean boolean26 = node15.getBooleanProp(0);
        com.google.javascript.rhino.Node node27 = node15.getParent();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(node27);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveAbstractMethods(true);
        compilerOptions0.setChainCalls(false);
        compilerOptions0.aliasableGlobals = "TYPEOF";
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        java.lang.String str3 = jSSourceFile2.getName();
        try {
            java.lang.String str4 = jSSourceFile2.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = false;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel8 = compilerOptions0.sourceMapDetailLevel;
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray24 = new com.google.javascript.rhino.Node[] { node14, node18, node23 };
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray24);
        int int26 = node25.getSideEffectFlags();
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((-2), node25);
        boolean boolean28 = detailLevel8.apply(node25);
        try {
            node25.setString("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: ERROR 0 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(detailLevel8);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(nodeArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions0.brokenClosureRequiresLevel;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.removeTryCatchFinally = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF), DiagnosticGroup<strictModuleDepCheck>(null), DiagnosticGroup<uselessCode>(OFF)", "Named type with empty name component", 110);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkUndefinedProperties;
        compilerOptions0.setTweakToStringLiteral("Node tree inequality:\nTree1:\nEXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nTree2:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree1: EXPR_RESULT 0\n    OR hi! 0\n    ERROR 0\n        EOF 10\n        EOF 10\n        OR hi! 0\n\n\nSubtree2: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n", "com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        double double4 = loggerErrorManager2.getTypedPercent();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel4 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions3.reportUnknownTypes = checkLevel4;
        compilerOptions0.reportUnknownTypes = checkLevel4;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.collapseProperties = false;
        boolean boolean10 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel12 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions11.reportUnknownTypes = checkLevel12;
        compilerOptions11.syntheticBlockStartMarker = "ERROR 0";
        compilerOptions11.markAsCompiled = false;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = compilerOptions11.checkMissingReturn;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel18;
        compilerOptions0.setProcessObjectPropertyString(false);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strSet7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        int int16 = node15.getSideEffectFlags();
        boolean boolean17 = node15.wasEmptyNode();
        boolean boolean18 = node15.hasSideEffects();
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        boolean boolean26 = node22.isQuotedString();
        com.google.javascript.rhino.Node node27 = node15.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = node27.removeFirstChild();
        com.google.javascript.rhino.Node node29 = null;
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node35 = com.google.javascript.jscomp.NodeUtil.newExpr(node34);
        int int36 = node35.getSourcePosition();
        try {
            node28.addChildBefore(node29, node35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.shouldColorizeErrorOutput();
        compilerOptions0.checkSuspiciousCode = false;
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        int int3 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager1);
        com.google.javascript.rhino.Node node5 = compiler4.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal7 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler4, callback6);
        int int8 = nodeTraversal7.getLineNumber();
        com.google.javascript.jscomp.Scope scope9 = nodeTraversal7.getScope();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = nodeTraversal7.getInput();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(scope9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        boolean boolean2 = compilerOptions0.lineBreak;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String[] strArray17 = new java.lang.String[] { "", "language version", "", "language version", "language version", "" };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("", 0, (int) (short) -1, checkLevel9, diagnosticType10, strArray17);
        java.lang.String[] strArray19 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError20 = com.google.javascript.jscomp.JSError.make("language version", (int) ' ', (int) (short) -1, diagnosticType10, strArray19);
        java.lang.Object obj21 = null;
        com.google.javascript.jscomp.SourceMap.Format format22 = com.google.javascript.jscomp.SourceMap.Format.LEGACY;
        java.lang.RuntimeException runtimeException23 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) jSError20, obj21, (java.lang.Object) format22);
        compilerOptions0.sourceMapFormat = format22;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean27 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(jSError20);
        org.junit.Assert.assertNotNull(format22);
        org.junit.Assert.assertNotNull(runtimeException23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("hi!", "", "", 10, "", (int) (short) 0);
        java.lang.String str7 = ecmaError6.getSourceName();
        java.lang.String str8 = ecmaError6.toString();
        int int9 = ecmaError6.lineNumber();
        com.google.javascript.rhino.EvaluatorException evaluatorException13 = new com.google.javascript.rhino.EvaluatorException("", "hi!", (-1));
        ecmaError6.addSuppressed((java.lang.Throwable) evaluatorException13);
        java.lang.Throwable[] throwableArray15 = ecmaError6.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "com.google.javascript.rhino.EcmaError: hi!:  (#10)" + "'", str8.equals("com.google.javascript.rhino.EcmaError: hi!:  (#10)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.Object obj1 = null;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean4 = defaultCodingConvention2.isExported("language version");
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.notFunctionError(obj1, (java.lang.Object) defaultCodingConvention2);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention6 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node node12 = com.google.javascript.jscomp.NodeUtil.newExpr(node11);
        boolean boolean13 = defaultCodingConvention6.isOptionalParameter(node11);
        java.util.List<java.lang.String> strList14 = defaultCodingConvention2.identifyTypeDeclarationCall(node11);
        boolean boolean15 = closureCodingConvention0.isVarArgsParameter(node11);
        java.lang.String str16 = closureCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        int int23 = node22.getChildCount();
        node22.setCharno(0);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention26 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean28 = defaultCodingConvention26.isExported("language version");
        boolean boolean30 = defaultCodingConvention26.isConstantKey("ERROR");
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node39 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray45 = new com.google.javascript.rhino.Node[] { node35, node39, node44 };
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray45);
        java.lang.String str47 = defaultCodingConvention26.getSingletonGetterClassName(node46);
        node22.addChildrenToBack(node46);
        boolean boolean49 = node46.isUnscopedQualifiedName();
        java.lang.String str50 = node46.toString();
        java.lang.String str51 = closureCodingConvention0.extractClassNameIfRequire(node18, node46);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(runtimeException5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(strList14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "goog.exportSymbol" + "'", str16.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(nodeArray45);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "ERROR 0" + "'", str50.equals("ERROR 0"));
        org.junit.Assert.assertNull(str51);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean3 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.ambiguateProperties = false;
        boolean boolean6 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.disambiguateProperties = false;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypeProperties;
        compilerOptions0.setProcessObjectPropertyString(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.extractPrototypeMemberDeclarations = false;
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        compilerOptions0.specializeInitialModule = true;
        java.lang.Object obj8 = compilerOptions0.clone();
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = compilerOptions0.errorFormat;
        java.io.PrintStream printStream10 = null;
        com.google.javascript.jscomp.Compiler compiler11 = new com.google.javascript.jscomp.Compiler(printStream10);
        com.google.javascript.jscomp.NodeTraversal.Callback callback12 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal13 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler11, callback12);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = errorFormat9.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler11, true);
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger16);
        java.util.logging.Logger logger18 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager19 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger18);
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(errorFormat9);
        org.junit.Assert.assertNotNull(messageFormatter15);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.markNoSideEffectCalls;
        com.google.javascript.jscomp.CompilerOptions compilerOptions2 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions2.removeUnusedPrototypePropertiesInExterns = false;
        boolean boolean5 = compilerOptions2.collapseVariableDeclarations;
        boolean boolean6 = compilerOptions2.checkTypedPropertyCalls;
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention7 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean9 = defaultCodingConvention7.isConstant("hi!");
        boolean boolean11 = defaultCodingConvention7.isExported("com.google.javascript.rhino.EcmaError: TypeError: Cannot call method \"41\" of JSC_NODE_TRAVERSAL_ERROR. {0} at language version line 32 : (unknown column)");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray26 = new com.google.javascript.rhino.Node[] { node16, node20, node25 };
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray26);
        int int29 = node27.getIntProp(10);
        com.google.javascript.rhino.Node node30 = node27.getNext();
        java.lang.String str31 = defaultCodingConvention7.identifyTypeDefAssign(node30);
        boolean boolean34 = defaultCodingConvention7.isExported("ERROR 0", true);
        compilerOptions2.setCodingConvention((com.google.javascript.jscomp.CodingConvention) defaultCodingConvention7);
        compilerOptions2.lineBreak = true;
        java.util.Set<java.lang.String> strSet38 = compilerOptions2.stripNamePrefixes;
        compilerOptions0.setIdGenerators(strSet38);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(nodeArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(strSet38);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isConstant("hi!");
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        double double5 = loggerErrorManager4.getTypedPercent();
        int int6 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager4);
        com.google.javascript.rhino.Node node8 = compiler7.getRoot();
        com.google.javascript.jscomp.NodeTraversal.Callback callback9 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal10 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler7, callback9);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray25 = new com.google.javascript.rhino.Node[] { node15, node19, node24 };
        com.google.javascript.rhino.Node node26 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray25);
        com.google.javascript.rhino.Node node27 = node26.cloneNode();
        boolean boolean28 = node26.hasMoreThanOneChild();
        com.google.javascript.rhino.Node node33 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray43 = new com.google.javascript.rhino.Node[] { node33, node37, node42 };
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray43);
        int int45 = node44.getSideEffectFlags();
        boolean boolean46 = node44.wasEmptyNode();
        java.lang.String str47 = node44.toString();
        boolean boolean48 = node44.isOptionalArg();
        com.google.javascript.rhino.Node node53 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray63 = new com.google.javascript.rhino.Node[] { node53, node57, node62 };
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray63);
        java.lang.String str68 = node64.toString(false, false, true);
        node26.addChildAfter(node44, node64);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast70 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal10, node44);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = null;
        com.google.javascript.jscomp.Scope scope72 = null;
        com.google.javascript.rhino.jstype.ObjectType[] objectTypeArray73 = new com.google.javascript.rhino.jstype.ObjectType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType> objectTypeList74 = new java.util.ArrayList<com.google.javascript.rhino.jstype.ObjectType>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList74, objectTypeArray73);
        defaultCodingConvention0.defineDelegateProxyPrototypeProperties(jSTypeRegistry71, scope72, (java.util.List<com.google.javascript.rhino.jstype.ObjectType>) objectTypeList74);
        com.google.javascript.rhino.jstype.FunctionType functionType77 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType78 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType79 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType77, functionType78, subclassType79);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(nodeArray25);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(nodeArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "ERROR 0" + "'", str47.equals("ERROR 0"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(nodeArray63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "ERROR" + "'", str68.equals("ERROR"));
        org.junit.Assert.assertNull(objectLiteralCast70);
        org.junit.Assert.assertNotNull(objectTypeArray73);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput5 = compiler3.getInput("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "hi!", (int) (short) 0, (int) (byte) 1);
        com.google.javascript.rhino.Node[] nodeArray14 = new com.google.javascript.rhino.Node[] { node4, node8, node13 };
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) -1, nodeArray14);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection16 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(0, 10, (int) (byte) 10);
        node20.putBooleanProp(0, false);
        java.lang.String str24 = node15.checkTreeEquals(node20);
        node20.detachChildren();
        node20.setOptionalArg(false);
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) ' ');
        java.lang.String str30 = node29.toString();
        node20.addChildToBack(node29);
        com.google.javascript.rhino.jstype.JSType jSType32 = node29.getJSType();
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(nodeArray14);
        org.junit.Assert.assertNotNull(nodeCollection16);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n" + "'", str24.equals("Node tree inequality:\nTree1:\nERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nTree2:\nEOF 10\n\n\nSubtree1: ERROR 0\n    EOF 10\n    EOF 10\n    OR hi! 0\n\n\nSubtree2: EOF 10\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TYPEOF" + "'", str30.equals("TYPEOF"));
        org.junit.Assert.assertNull(jSType32);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = compilerOptions0.checkProvides;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.removeUnusedPrototypeProperties = false;
        byte[] byteArray8 = new byte[] { (byte) 0, (byte) 1 };
        compilerOptions0.inputPropertyMapSerialized = byteArray8;
        java.lang.String str10 = compilerOptions0.sourceMapOutputPath;
        compilerOptions0.disableRuntimeTypeCheck();
        java.util.Set<java.lang.String> strSet12 = null;
        compilerOptions0.stripTypes = strSet12;
        java.lang.String str14 = compilerOptions0.syntheticBlockEndMarker;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode15 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        compilerOptions0.tracer = tracerMode15;
        boolean boolean17 = compilerOptions0.optimizeArgumentsArray;
        java.lang.String str18 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + tracerMode15 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode15.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.reportUnknownTypes = checkLevel1;
        compilerOptions0.syntheticBlockStartMarker = "ERROR 0";
        byte[] byteArray5 = compilerOptions0.inputPropertyMapSerialized;
        boolean boolean6 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode9 = compilerOptions0.tracer;
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNull(byteArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + tracerMode9 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode9.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        boolean boolean3 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.reserveRawExports = true;
        boolean boolean6 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }
}

