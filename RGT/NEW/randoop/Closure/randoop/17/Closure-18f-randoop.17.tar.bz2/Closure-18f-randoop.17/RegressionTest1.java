import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.findPropertyType("module$");
        boolean boolean92 = parameterizedType89.isUnknownType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 'a');
        boolean boolean2 = node1.isDelProp();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags3 = null;
        try {
            node1.setSideEffectFlags(sideEffectFlags3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean2 = jSDocInfoBuilder1.isInterfaceRecorded();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.withName("hi!");
        java.lang.String[] strArray14 = new java.lang.String[] { "module$", "./", "module$", "", "./", "" };
        java.util.ArrayList<java.lang.String> strList15 = new java.util.ArrayList<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList15, strArray14);
        java.lang.String[] strArray20 = new java.lang.String[] { "2019/06/10 13:15", "./", "DiagnosticGroup<const>" };
        java.util.ArrayList<java.lang.String> strList21 = new java.util.ArrayList<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList21, strArray20);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo23 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "hi!", (java.util.List<java.lang.String>) strList15, (java.util.List<java.lang.String>) strList21);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        int int30 = functionType28.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = null;
        functionType28.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo32);
        boolean boolean34 = functionType28.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry36.createConstructorTypeWithVarArgs(jSType37, jSTypeArray38);
        boolean boolean40 = functionType39.isFunctionType();
        int int41 = functionType39.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry43.createConstructorTypeWithVarArgs(jSType44, jSTypeArray45);
        boolean boolean47 = functionType46.isFunctionType();
        boolean boolean48 = functionType39.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType46);
        boolean boolean49 = functionType39.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair50 = functionType28.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType39);
        com.google.common.collect.ImmutableList<java.lang.String> strList51 = functionType39.getTemplateTypeNames();
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo52 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("Not declared as a type name", "", (java.util.List<java.lang.String>) strList21, (java.util.List<java.lang.String>) strList51);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder53 = functionBuilder1.withTemplateNames(strList51);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(typePair50);
        org.junit.Assert.assertNotNull(strList51);
        org.junit.Assert.assertNotNull(functionBuilder53);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean30 = functionType4.isNumberObjectType();
        boolean boolean31 = functionType4.isInstanceType();
        boolean boolean32 = functionType4.hasInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromGenerator("DiagnosticGroup<const>", generator2);
        com.google.javascript.jscomp.SourceFile.Generator generator5 = null;
        com.google.javascript.jscomp.SourceFile sourceFile6 = builder0.buildFromGenerator("function (new:{...}): ?", generator5);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        boolean boolean14 = node9.isTry();
        boolean boolean15 = node9.isCall();
        boolean boolean16 = node9.isGetterDef();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection17 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node9);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeCollection17);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.getPropertyType("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        boolean boolean93 = parameterizedType89.removeProperty("function (): {330869298}");
        boolean boolean95 = parameterizedType89.hasOwnProperty("2019/06/10 13:15");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNotNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.number((double) (byte) -1);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder2 = node1.new FileLevelJsDocBuilder();
        fileLevelJsDocBuilder2.append("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        node4.setString("./");
        boolean boolean16 = node4.isInstanceOf();
        com.google.javascript.rhino.Node node17 = node4.cloneNode();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable3 = jSTypeRegistry1.getTypesWithProperty("InputId: hi!");
        com.google.javascript.rhino.jstype.JSType jSType5 = jSTypeRegistry1.getType("module$");
        com.google.javascript.rhino.jstype.JSType jSType10 = jSTypeRegistry1.createNamedType("goog.exportSymbol", "goog.exportSymbol", 4095, 1);
        org.junit.Assert.assertNotNull(jSTypeIterable3);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNotNull(jSType10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler();
        compiler1.reportCodeChange();
        compiler1.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, false);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker6 = compiler1.tracker;
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler1.getState();
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(messageFormatter5);
        org.junit.Assert.assertNull(performanceTracker6);
        org.junit.Assert.assertNotNull(intermediateState7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setCheckSymbols(true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int14 = diagnosticType10.compareTo(diagnosticType13);
        java.lang.String[] strArray15 = null;
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType10, strArray15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean22 = node21.isWith();
        boolean boolean23 = jSError16.equals((java.lang.Object) boolean22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = new com.google.javascript.jscomp.JSError[] { jSError16 };
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int39 = diagnosticType35.compareTo(diagnosticType38);
        java.lang.String[] strArray40 = null;
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", node30, diagnosticType35, strArray40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean47 = node46.isWith();
        boolean boolean48 = jSError41.equals((java.lang.Object) boolean47);
        com.google.javascript.jscomp.JSError[] jSErrorArray49 = new com.google.javascript.jscomp.JSError[] { jSError41 };
        com.google.javascript.jscomp.VariableMap variableMap51 = null;
        com.google.javascript.jscomp.VariableMap variableMap52 = null;
        com.google.javascript.jscomp.VariableMap variableMap53 = null;
        com.google.javascript.jscomp.FunctionInformationMap functionInformationMap54 = null;
        com.google.javascript.jscomp.SourceMap sourceMap55 = null;
        com.google.javascript.jscomp.Result result57 = new com.google.javascript.jscomp.Result(jSErrorArray24, jSErrorArray49, "hi!", variableMap51, variableMap52, variableMap53, functionInformationMap54, sourceMap55, "InputId: hi!");
        com.google.javascript.jscomp.VariableMap variableMap58 = result57.stringMap;
        com.google.javascript.jscomp.VariableMap variableMap59 = result57.stringMap;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jSErrorArray49);
        org.junit.Assert.assertNull(variableMap58);
        org.junit.Assert.assertNull(variableMap59);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        jSDocInfoBuilder1.markText("Not declared as a constructor", (int) (byte) 0, (int) (byte) 100, (int) (short) 0, 52);
        boolean boolean8 = jSDocInfoBuilder1.recordOverride();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) 'a');
        double double2 = node1.getDouble();
        boolean boolean3 = node1.isOptionalArg();
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.NodeTraversal.Callback callback2 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node7.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int15 = node14.getSideEffectFlags();
        boolean boolean16 = node14.isFalse();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node21.setCharno(0);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node33.setCharno(0);
        boolean boolean36 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node33);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.comma(node28, node33);
        com.google.javascript.rhino.Node node38 = node21.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node43.setCharno(0);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node55.setCharno(0);
        boolean boolean58 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node55);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.comma(node50, node55);
        com.google.javascript.rhino.Node node60 = node43.clonePropsFrom(node59);
        boolean boolean61 = node59.isNull();
        com.google.javascript.rhino.Node[] nodeArray62 = new com.google.javascript.rhino.Node[] { node14, node38, node59 };
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.IR.call(node7, nodeArray62);
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback2, nodeArray62);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(nodeArray62);
        org.junit.Assert.assertNotNull(node63);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        java.lang.String str2 = compiler0.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig4 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions3);
        compiler0.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig4);
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler();
        compiler6.reportCodeChange();
        java.lang.String str8 = compiler6.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig10 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions9);
        compiler6.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig10);
        try {
            compiler0.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: this.passes has already been assigned");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.getPropertyType("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        boolean boolean93 = parameterizedType89.removeProperty("function (): {330869298}");
        com.google.javascript.rhino.jstype.UnionType unionType94 = parameterizedType89.toMaybeUnionType();
        boolean boolean95 = parameterizedType89.isAllType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNotNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNull(unionType94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable3 = jSTypeRegistry1.getTypesWithProperty("InputId: hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        boolean boolean9 = functionType8.isFunctionType();
        int int10 = functionType8.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        boolean boolean17 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        int int24 = functionType22.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo26 = null;
        functionType22.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo26);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair28 = functionType8.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean29 = functionType8.isNativeObjectType();
        com.google.javascript.rhino.jstype.JSType jSType31 = jSTypeRegistry1.getGreatestSubtypeWithProperty((com.google.javascript.rhino.jstype.JSType) functionType8, "DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        org.junit.Assert.assertNotNull(jSTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(typePair28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(jSType31);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.getPropertyType("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        boolean boolean93 = parameterizedType89.removeProperty("function (): {330869298}");
        boolean boolean94 = parameterizedType89.isOrdinaryFunction();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNotNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node7.setCharno(0);
        boolean boolean10 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node7);
        boolean boolean11 = node7.isGetProp();
        boolean boolean13 = node7.getBooleanProp((int) (short) 10);
        java.lang.String str14 = node7.getSourceFileName();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node19.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '#', node7, node19, node26, 0, (int) (short) 0);
        boolean boolean30 = node26.isFor();
        try {
            astValidator1.validateCodeRoot(node26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DUPLICATE_MESSAGE = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setCharno(0);
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node5);
        boolean boolean9 = node5.isGetProp();
        boolean boolean11 = node5.getBooleanProp((int) (short) 10);
        java.lang.String str12 = node5.getSourceFileName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '#', node5, node17, node24, 0, (int) (short) 0);
        int int28 = node5.getLength();
        com.google.javascript.rhino.Node node29 = node5.getLastChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(node29);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.jstype.TemplateType templateType72 = parameterizedType71.toMaybeTemplateType();
        int int73 = parameterizedType71.getPropertiesCount();
        com.google.javascript.rhino.jstype.FunctionType functionType74 = parameterizedType71.getOwnerFunction();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertNull(templateType72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNull(functionType74);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordDescription("./: module$");
        jSDocInfoBuilder1.markName("", (int) (short) 1, 44);
        boolean boolean8 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        boolean boolean9 = jSDocInfoBuilder1.recordPreserveTry();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.jstype.ObjectType objectType14 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType4);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable15 = functionType4.getAllImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objectType14);
        org.junit.Assert.assertNotNull(objectTypeIterable15);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = googleCodingConvention0.getDelegateRelationship(node18);
        boolean boolean32 = googleCodingConvention0.isExported("Not declared as a type name", true);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.AstValidator astValidator0 = new com.google.javascript.jscomp.AstValidator();
        com.google.javascript.rhino.Node node1 = null;
        try {
            astValidator0.validateExpression(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression4, "2019/06/10 13:15");
        boolean boolean8 = jSDocInfoBuilder1.addAuthor("DiagnosticGroup<const>");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder1.recordParameter("DiagnosticGroup<const>", jSTypeExpression10);
        boolean boolean13 = jSDocInfoBuilder1.recordDescription("function (new:?): ?");
        boolean boolean14 = jSDocInfoBuilder1.recordExport();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("./: module$", "DiagnosticGroup<const>");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setCharno(0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node16.setCharno(0);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.comma(node11, node16);
        com.google.javascript.rhino.Node node21 = node4.clonePropsFrom(node20);
        boolean boolean22 = node20.isNull();
        com.google.javascript.rhino.Node node23 = node20.removeFirstChild();
        boolean boolean24 = node23.hasOneChild();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node29.setCharno(0);
        boolean boolean32 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node29);
        boolean boolean33 = node29.isGetProp();
        boolean boolean35 = node29.getBooleanProp((int) (short) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.getelem(node23, node29);
        boolean boolean37 = node36.isTrue();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        boolean boolean29 = node28.isAdd();
        try {
            java.lang.String str30 = com.google.javascript.rhino.ScriptRuntime.getMessage1("2019/06/10 13:15", (java.lang.Object) boolean29);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 2019/06/10 13:15");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        functionType48.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = functionType34.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue55 = functionType26.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = functionType34.getJSDocInfo();
        boolean boolean57 = functionType34.isStringValueType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNotNull(ternaryValue55);
        org.junit.Assert.assertNull(jSDocInfo56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter3 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry2);
        java.util.Collection<java.lang.String> strCollection4 = googleCodingConvention0.getIndirectlyDeclaredProperties();
        boolean boolean6 = googleCodingConvention0.isExported("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(strCollection4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = null;
        functionType4.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo8);
        boolean boolean10 = functionType4.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        int int17 = functionType15.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        boolean boolean24 = functionType15.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean25 = functionType15.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair26 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.jstype.JSType jSType27 = functionType15.getParameterType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(typePair26);
        org.junit.Assert.assertNull(jSType27);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("InputId: hi!");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node13.setIsSyntheticBlock(false);
        boolean boolean16 = node13.hasOneChild();
        boolean boolean17 = node13.isEmpty();
        node6.addChildToFront(node13);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node28.setCharno(0);
        boolean boolean31 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node28);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.comma(node23, node28);
        boolean boolean33 = node28.isTry();
        boolean boolean34 = node28.isFunction();
        com.google.javascript.rhino.Node node35 = node13.useSourceInfoFrom(node28);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        int int44 = functionType42.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        com.google.javascript.rhino.jstype.JSType jSType47 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray48 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType49 = jSTypeRegistry46.createConstructorTypeWithVarArgs(jSType47, jSTypeArray48);
        boolean boolean50 = functionType49.isFunctionType();
        boolean boolean51 = functionType42.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType49);
        boolean boolean52 = functionType42.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        int int59 = functionType57.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        boolean boolean66 = functionType57.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType64);
        boolean boolean67 = functionType42.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType64);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray68 = new com.google.javascript.rhino.jstype.JSType[] { functionType64 };
        com.google.javascript.rhino.Node node69 = jSTypeRegistry37.createOptionalParameters(jSTypeArray68);
        try {
            node1.addChildAfter(node13, node69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray48);
        org.junit.Assert.assertNotNull(functionType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(jSTypeArray68);
        org.junit.Assert.assertNotNull(node69);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.jstype.JSType jSType2 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
//        boolean boolean5 = functionType4.isFunctionType();
//        int int6 = functionType4.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
//        com.google.javascript.rhino.jstype.JSType jSType9 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
//        boolean boolean12 = functionType11.isFunctionType();
//        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
//        boolean boolean14 = functionType4.isEmptyType();
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
//        com.google.javascript.rhino.jstype.JSType jSType17 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
//        boolean boolean20 = functionType19.isFunctionType();
//        int int21 = functionType19.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
//        com.google.javascript.rhino.jstype.JSType jSType24 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
//        boolean boolean27 = functionType26.isFunctionType();
//        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
//        boolean boolean29 = functionType19.isEmptyType();
//        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
//        com.google.javascript.rhino.jstype.JSType jSType32 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
//        boolean boolean35 = functionType34.isFunctionType();
//        int int36 = functionType34.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
//        com.google.javascript.rhino.jstype.JSType jSType39 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
//        boolean boolean42 = functionType41.isFunctionType();
//        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
//        boolean boolean44 = functionType19.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType41);
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair45 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType19);
//        java.lang.String str46 = functionType4.toDebugHashCodeString();
//        boolean boolean47 = functionType4.isInstanceType();
//        boolean boolean48 = functionType4.isObject();
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(functionType4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray10);
//        org.junit.Assert.assertNotNull(functionType11);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray18);
//        org.junit.Assert.assertNotNull(functionType19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray25);
//        org.junit.Assert.assertNotNull(functionType26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray33);
//        org.junit.Assert.assertNotNull(functionType34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray40);
//        org.junit.Assert.assertNotNull(functionType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(typePair45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "function (): {1720659524}" + "'", str46.equals("function (): {1720659524}"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        java.lang.Iterable iterable30 = functionType26.getCtorExtendedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(iterable30);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int14 = diagnosticType10.compareTo(diagnosticType13);
        java.lang.String[] strArray15 = null;
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType10, strArray15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean22 = node21.isWith();
        boolean boolean23 = jSError16.equals((java.lang.Object) boolean22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = new com.google.javascript.jscomp.JSError[] { jSError16 };
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int39 = diagnosticType35.compareTo(diagnosticType38);
        java.lang.String[] strArray40 = null;
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", node30, diagnosticType35, strArray40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean47 = node46.isWith();
        boolean boolean48 = jSError41.equals((java.lang.Object) boolean47);
        com.google.javascript.jscomp.JSError[] jSErrorArray49 = new com.google.javascript.jscomp.JSError[] { jSError41 };
        com.google.javascript.jscomp.VariableMap variableMap51 = null;
        com.google.javascript.jscomp.VariableMap variableMap52 = null;
        com.google.javascript.jscomp.VariableMap variableMap53 = null;
        com.google.javascript.jscomp.FunctionInformationMap functionInformationMap54 = null;
        com.google.javascript.jscomp.SourceMap sourceMap55 = null;
        com.google.javascript.jscomp.Result result57 = new com.google.javascript.jscomp.Result(jSErrorArray24, jSErrorArray49, "hi!", variableMap51, variableMap52, variableMap53, functionInformationMap54, sourceMap55, "InputId: hi!");
        boolean boolean58 = result57.success;
        com.google.javascript.jscomp.VariableMap variableMap59 = result57.propertyMap;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jSErrorArray49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(variableMap59);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordDescription("./: module$");
        boolean boolean4 = jSDocInfoBuilder1.recordNoCompile();
        jSDocInfoBuilder1.markText("2019/06/10 13:15", 38, 29, (-28), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String[] strArray8 = new java.lang.String[] { "module$", "./", "module$", "", "./", "" };
        java.util.ArrayList<java.lang.String> strList9 = new java.util.ArrayList<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList9, strArray8);
        java.lang.String[] strArray14 = new java.lang.String[] { "2019/06/10 13:15", "./", "DiagnosticGroup<const>" };
        java.util.ArrayList<java.lang.String> strList15 = new java.util.ArrayList<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList15, strArray14);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo17 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "hi!", (java.util.List<java.lang.String>) strList9, (java.util.List<java.lang.String>) strList15);
        java.util.Collection<java.lang.String> strCollection18 = simpleDependencyInfo17.getProvides();
        java.util.Collection<java.lang.String> strCollection19 = simpleDependencyInfo17.getRequires();
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strCollection18);
        org.junit.Assert.assertNotNull(strCollection19);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        boolean boolean6 = node4.isFalse();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.returnNode(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (byte) -1, 52, 44);
        boolean boolean12 = node4.hasChild(node11);
        node4.addSuppression("function (new:?): ?");
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean6 = jSTypeRegistry1.hasNamespace("");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        compiler0.disableThreads();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        jSTypeRegistry1.setLastGeneration(false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry1.getNativeFunctionType(jSTypeNative7);
        boolean boolean10 = functionType8.isPropertyInExterns("module$");
        boolean boolean11 = functionType8.isNominalType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setMarkAsCompiled(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        jSTypeRegistry1.setLastGeneration(false);
        boolean boolean8 = jSTypeRegistry1.isForwardDeclaredType("OR  32");
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        int int15 = functionType13.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType18, jSTypeArray19);
        boolean boolean21 = functionType20.isFunctionType();
        boolean boolean22 = functionType13.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType20);
        com.google.javascript.rhino.ErrorReporter errorReporter23 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter23);
        com.google.javascript.rhino.jstype.JSType jSType25 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray26 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry24.createConstructorTypeWithVarArgs(jSType25, jSTypeArray26);
        boolean boolean28 = functionType27.isFunctionType();
        int int29 = functionType27.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo31 = null;
        functionType27.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo31);
        boolean boolean33 = functionType27.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry35.createConstructorTypeWithVarArgs(jSType36, jSTypeArray37);
        boolean boolean39 = functionType38.isFunctionType();
        int int40 = functionType38.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.JSType jSType43 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry42.createConstructorTypeWithVarArgs(jSType43, jSTypeArray44);
        boolean boolean46 = functionType45.isFunctionType();
        boolean boolean47 = functionType38.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType45);
        boolean boolean48 = functionType38.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair49 = functionType27.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType38);
        boolean boolean50 = functionType13.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType38);
        com.google.javascript.rhino.jstype.ObjectType objectType51 = functionType13.getTypeOfThis();
        com.google.javascript.rhino.jstype.JSType jSType52 = jSTypeRegistry1.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType51);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(jSTypeArray26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(typePair49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertNotNull(jSType52);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node23.setCharno(0);
        boolean boolean26 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node23);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.IR.comma(node18, node23);
        boolean boolean28 = node23.isTry();
        boolean boolean29 = node23.isFromExterns();
        boolean boolean30 = node23.isCase();
        boolean boolean31 = node23.isNull();
        com.google.javascript.rhino.Node node32 = node9.srcrefTree(node23);
        com.google.javascript.rhino.Node node33 = node9.cloneTree();
        com.google.javascript.rhino.jstype.JSType jSType34 = node9.getJSType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(jSType34);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        com.google.javascript.jscomp.MessageFormatter messageFormatter4 = null;
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter4, logger5);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType11, strArray12);
        com.google.javascript.jscomp.DiagnosticType diagnosticType14 = jSError13.getType();
        loggerErrorManager6.report(checkLevel7, jSError13);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node21.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int30 = diagnosticType26.compareTo(diagnosticType29);
        java.lang.String[] strArray31 = null;
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("", node21, diagnosticType26, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = jSError32.getType();
        loggerErrorManager2.report(checkLevel7, jSError32);
        com.google.javascript.jscomp.CheckLevel checkLevel35 = jSError32.getDefaultLevel();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertNotNull(diagnosticType14);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType33);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        int int1 = stringPosition0.getEndLine();
        try {
            stringPosition0.setPositionInformation(16, 0, (int) (short) 10, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Recorded bad position information\nstart-line: 16\nend-line: 10");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.stringKey("");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("", 31, (int) (byte) 100);
        boolean boolean4 = node3.isBlock();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable5 = node3.siblings();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(nodeIterable5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.block();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        boolean boolean5 = jSDocInfoBuilder1.addAuthor("2019/06/10 13:15");
        boolean boolean6 = jSDocInfoBuilder1.recordImplicitCast();
        boolean boolean7 = jSDocInfoBuilder1.recordInterface();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.jstype.TemplateType templateType72 = parameterizedType71.toMaybeTemplateType();
        boolean boolean73 = parameterizedType71.isNullable();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertNull(templateType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int12 = node11.getSideEffectFlags();
        boolean boolean13 = node11.isFalse();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setCharno(0);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setCharno(0);
        boolean boolean33 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node30);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.comma(node25, node30);
        com.google.javascript.rhino.Node node35 = node18.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node40.setCharno(0);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node52.setCharno(0);
        boolean boolean55 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node52);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.comma(node47, node52);
        com.google.javascript.rhino.Node node57 = node40.clonePropsFrom(node56);
        boolean boolean58 = node56.isNull();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node11, node35, node56 };
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.call(node4, nodeArray59);
        boolean boolean61 = node60.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry15.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isFunctionType();
        int int20 = functionType18.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        functionType18.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo22);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair24 = functionType4.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType18);
        boolean boolean25 = functionType4.isStringValueType();
        boolean boolean26 = functionType4.hasAnyTemplate();
        boolean boolean27 = functionType4.hasDisplayName();
        boolean boolean28 = functionType4.isOrdinaryFunction();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable29 = functionType4.getOwnImplementedInterfaces();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(typePair24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable29);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {330869298}");
        com.google.javascript.jscomp.SourceFile.Builder builder2 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile4 = builder2.buildFromFile("2019/06/10 13:15");
        jSModule1.addFirst(sourceFile4);
        org.junit.Assert.assertNotNull(sourceFile4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordDescription("./: module$");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression4);
        boolean boolean6 = jSDocInfoBuilder1.recordNoTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setCharno(0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node16.setCharno(0);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.comma(node11, node16);
        com.google.javascript.rhino.Node node21 = node4.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.pos(node4);
        java.lang.String str23 = node4.toString();
        boolean boolean24 = node4.isScript();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "OR  32" + "'", str23.equals("OR  32"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter3 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry2);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        boolean boolean6 = closureCodingConvention4.isPrivate("function (): {330869298}");
        com.google.javascript.rhino.Node node7 = null;
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node12.setCharno(0);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node24.setCharno(0);
        boolean boolean27 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.comma(node19, node24);
        com.google.javascript.rhino.Node node29 = node12.clonePropsFrom(node28);
        java.lang.String str30 = closureCodingConvention4.extractClassNameIfRequire(node7, node12);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString("", 31, (int) (byte) 100);
        try {
            java.lang.String str35 = closureCodingConvention4.getSingletonGetterClassName(node34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(node34);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS = diagnosticGroup0;
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        boolean boolean15 = functionType4.hasInstanceType();
        boolean boolean16 = functionType4.isUnionType();
        com.google.javascript.rhino.jstype.ObjectType objectType18 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) functionType4, "DiagnosticGroup<checkRegExp>");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(objectType18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.jstype.ObjectType objectType14 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType4);
        com.google.javascript.rhino.jstype.ObjectType objectType16 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface((com.google.javascript.rhino.jstype.ObjectType) functionType4, "OR  32");
        com.google.javascript.rhino.jstype.FunctionType functionType17 = functionType4.toMaybeFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType18 = functionType4.unboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(objectType14);
        org.junit.Assert.assertNull(objectType16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertNull(jSType18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        boolean boolean16 = functionType6.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        boolean boolean22 = functionType21.isFunctionType();
        int int23 = functionType21.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        boolean boolean30 = functionType21.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType28);
        boolean boolean31 = functionType6.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { functionType28 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry1.createOptionalParameters(jSTypeArray32);
        com.google.javascript.rhino.Node node34 = node33.getLastSibling();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node39.setCharno(0);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node51.setCharno(0);
        boolean boolean54 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node51);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.comma(node46, node51);
        com.google.javascript.rhino.Node node56 = node39.clonePropsFrom(node55);
        try {
            com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.doNode(node34, node39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean3 = compilerOptions0.inlineGetters;
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.jstype.JSType jSType15 = functionType4.getRestrictedTypeGivenToBooleanOutcome(false);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(jSType15);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry7.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        boolean boolean11 = functionType10.isFunctionType();
        int int12 = functionType10.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry14.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        boolean boolean18 = functionType17.isFunctionType();
        boolean boolean19 = functionType10.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        boolean boolean25 = functionType24.isFunctionType();
        int int26 = functionType24.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = null;
        functionType24.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo28);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair30 = functionType10.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType24);
        boolean boolean31 = functionType10.isStringValueType();
        boolean boolean32 = functionType10.hasAnyTemplate();
        boolean boolean33 = functionType10.hasDisplayName();
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node38.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node45.setIsSyntheticBlock(false);
        boolean boolean48 = node45.hasOneChild();
        boolean boolean49 = node45.isEmpty();
        node38.addChildToFront(node45);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node60.setCharno(0);
        boolean boolean63 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node60);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.comma(node55, node60);
        boolean boolean65 = node60.isTry();
        boolean boolean66 = node60.isFunction();
        com.google.javascript.rhino.Node node67 = node45.useSourceInfoFrom(node60);
        boolean boolean68 = functionType4.defineInferredProperty("DiagnosticGroup<const>", (com.google.javascript.rhino.jstype.JSType) functionType10, node45);
        java.lang.String str69 = functionType4.getDisplayName();
        boolean boolean70 = functionType4.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(typePair30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(str69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.matchesInt32Context();
        boolean boolean6 = functionType4.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = googleCodingConvention0.isConstantKey("Not declared as a constructor");
        java.lang.String str4 = googleCodingConvention0.getGlobalObject();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.global" + "'", str4.equals("goog.global"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.name("function (): {330869298}");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node8.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType16 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int17 = diagnosticType13.compareTo(diagnosticType16);
        java.lang.String[] strArray18 = null;
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make("", node8, diagnosticType13, strArray18);
        com.google.javascript.jscomp.DiagnosticType diagnosticType20 = jSError19.getType();
        java.lang.String[] strArray21 = null;
        com.google.javascript.jscomp.JSError jSError22 = com.google.javascript.jscomp.JSError.make("2019/06/10 13:15", node2, diagnosticType20, strArray21);
        int int23 = jSError22.getNodeSourceOffset();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertNotNull(diagnosticType20);
        org.junit.Assert.assertNotNull(jSError22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("2019/06/10 13:15");
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder0.withOriginalPath("function (): {1244485907}");
        com.google.javascript.jscomp.SourceFile sourceFile9 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst10 = new com.google.javascript.jscomp.JsAst(sourceFile9);
        java.lang.String str11 = sourceFile9.getOriginalPath();
        java.io.Reader reader12 = sourceFile9.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile13 = builder4.buildFromReader("InputId: hi!", reader12);
        com.google.javascript.jscomp.SourceFile sourceFile16 = builder4.buildFromCode("goog.exportSymbol", "module$");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertNotNull(sourceFile9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(reader12);
        org.junit.Assert.assertNotNull(sourceFile13);
        org.junit.Assert.assertNotNull(sourceFile16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        boolean boolean16 = functionType6.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        boolean boolean22 = functionType21.isFunctionType();
        int int23 = functionType21.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        boolean boolean30 = functionType21.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType28);
        boolean boolean31 = functionType6.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { functionType28 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry1.createOptionalParameters(jSTypeArray32);
        boolean boolean34 = node33.isNot();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("./");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordImplementedInterface(jSTypeExpression2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = googleCodingConvention0.isPrivate("function (): {330869298}");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        boolean boolean7 = node4.hasOneChild();
        boolean boolean8 = node4.isEmpty();
        boolean boolean9 = node4.isScript();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.returnNode(node4);
        boolean boolean11 = node10.isNot();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.withName("hi!");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node8.setIsSyntheticBlock(false);
        boolean boolean11 = node8.hasOneChild();
        boolean boolean12 = node8.isEmpty();
        boolean boolean13 = node8.isOr();
        boolean boolean14 = node8.isSwitch();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node24.setCharno(0);
        boolean boolean27 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node24);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.comma(node19, node24);
        boolean boolean29 = node24.isTry();
        boolean boolean30 = node24.isCall();
        boolean boolean31 = node24.isBreak();
        boolean boolean32 = node24.isOr();
        java.lang.String str33 = node8.checkTreeEquals(node24);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder34 = functionBuilder3.withParamsNode(node24);
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(functionBuilder34);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.hasModifies();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        java.util.Set set72 = parameterizedType71.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertNotNull(set72);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        boolean boolean6 = node4.isFalse();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.returnNode(node4);
        boolean boolean8 = node4.isWith();
        com.google.javascript.rhino.Node node9 = node4.cloneNode();
        boolean boolean10 = node4.isFalse();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstant("function (): {1244485907}");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node12.setCharno(0);
        boolean boolean15 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node12);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.comma(node7, node12);
        boolean boolean17 = node16.isExprResult();
        com.google.javascript.rhino.jstype.JSType jSType18 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 10, "");
        com.google.javascript.rhino.Node node22 = node16.srcref(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node27.setIsSyntheticBlock(false);
        boolean boolean30 = node27.hasOneChild();
        boolean boolean31 = node27.isEmpty();
        boolean boolean32 = node27.isOr();
        com.google.javascript.rhino.Node node33 = node22.useSourceInfoIfMissingFromForTree(node27);
        java.util.List<java.lang.String> strList34 = googleCodingConvention0.identifyTypeDeclarationCall(node22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNull(strList34);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = null;
        functionType4.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo8);
        boolean boolean10 = functionType4.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        int int17 = functionType15.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        boolean boolean24 = functionType15.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean25 = functionType15.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair26 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        boolean boolean34 = functionType33.isFunctionType();
        int int35 = functionType33.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType38, jSTypeArray39);
        boolean boolean41 = functionType40.isFunctionType();
        boolean boolean42 = functionType33.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType40);
        boolean boolean43 = functionType33.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry52.createConstructorTypeWithVarArgs(jSType53, jSTypeArray54);
        boolean boolean56 = functionType55.isFunctionType();
        boolean boolean57 = functionType48.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType55);
        boolean boolean58 = functionType33.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType55);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] { functionType55 };
        com.google.javascript.rhino.Node node60 = jSTypeRegistry28.createOptionalParameters(jSTypeArray59);
        functionType15.setSource(node60);
        try {
            com.google.javascript.rhino.JSDocInfo jSDocInfo62 = com.google.javascript.jscomp.NodeUtil.getFunctionJSDocInfo(node60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(typePair26);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(node60);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        boolean boolean16 = functionType6.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        boolean boolean22 = functionType21.isFunctionType();
        int int23 = functionType21.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        boolean boolean30 = functionType21.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType28);
        boolean boolean31 = functionType6.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType28);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] { functionType28 };
        com.google.javascript.rhino.Node node33 = jSTypeRegistry1.createOptionalParameters(jSTypeArray32);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node39.setCharno(0);
        boolean boolean42 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node39);
        boolean boolean43 = node39.isGetProp();
        boolean boolean45 = node39.getBooleanProp((int) (short) 10);
        java.lang.String str46 = node39.getSourceFileName();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node51.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((int) '#', node39, node51, node58, 0, (int) (short) 0);
        boolean boolean62 = node58.isFor();
        node58.setLength((int) (byte) 100);
        node58.setSourceEncodedPositionForTree((int) 'a');
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node71.setCharno(0);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node83.setCharno(0);
        boolean boolean86 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node83);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.IR.comma(node78, node83);
        com.google.javascript.rhino.Node node88 = node71.clonePropsFrom(node87);
        com.google.javascript.rhino.Node node89 = node58.useSourceInfoIfMissingFrom(node88);
        node89.setCharno((int) (byte) 10);
        try {
            com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.IR.assign(node33, node89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt3 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt3);
        lightweightMessageFormatter4.setColorize(false);
        lightweightMessageFormatter4.setColorize(false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.ErrorFormat errorFormat1 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        com.google.javascript.jscomp.Compiler compiler2 = new com.google.javascript.jscomp.Compiler();
        compiler2.reportCodeChange();
        compiler2.reportCodeChange();
        com.google.javascript.jscomp.MessageFormatter messageFormatter6 = errorFormat1.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        com.google.javascript.jscomp.MessageFormatter messageFormatter8 = errorFormat0.toFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler2, false);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput10 = compiler2.newExternInput("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(errorFormat0);
        org.junit.Assert.assertNotNull(errorFormat1);
        org.junit.Assert.assertNotNull(messageFormatter6);
        org.junit.Assert.assertNotNull(messageFormatter8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        functionType48.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = functionType34.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue55 = functionType26.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        boolean boolean56 = functionType34.hasCachedValues();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNotNull(ternaryValue55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        boolean boolean14 = node13.isExprResult();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.not(node13);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node25.setCharno(0);
        boolean boolean28 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node25);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.comma(node20, node25);
        boolean boolean30 = node25.isTry();
        boolean boolean31 = node25.isFromExterns();
        try {
            com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.assign(node13, node25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setCharno(0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node16.setCharno(0);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.comma(node11, node16);
        com.google.javascript.rhino.Node node21 = node4.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node22 = com.google.javascript.jscomp.NodeUtil.newExpr(node4);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.CompilerOptions.Reach reach22 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setInlineVariables(reach22);
        compilerOptions0.setInstrumentationTemplate("./");
        compilerOptions0.crossModuleCodeMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + reach22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach22.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        functionType48.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = functionType34.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue55 = functionType26.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = functionType34.getJSDocInfo();
        boolean boolean57 = functionType34.matchesUint32Context();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNotNull(ternaryValue55);
        org.junit.Assert.assertNull(jSDocInfo56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        boolean boolean14 = node13.isExprResult();
        com.google.javascript.rhino.jstype.JSType jSType15 = node13.getJSType();
        boolean boolean16 = node13.isGetterDef();
        boolean boolean17 = node13.isBlock();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isNoType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setCharno(0);
        boolean boolean13 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node10);
        boolean boolean14 = node10.isGetProp();
        boolean boolean15 = node10.isOptionalArg();
        com.google.javascript.rhino.Node node16 = node10.cloneNode();
        boolean boolean17 = functionType4.equals((java.lang.Object) node16);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean30 = functionType26.isInstanceType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType31 = functionType26.toMaybeParameterizedType();
        functionType26.clearResolved();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(parameterizedType31);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry15.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isFunctionType();
        int int20 = functionType18.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        functionType18.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo22);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair24 = functionType4.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType18);
        boolean boolean25 = functionType4.isStringValueType();
        boolean boolean26 = functionType4.isInstanceType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        boolean boolean32 = functionType31.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter33 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry34 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter33);
        com.google.javascript.rhino.jstype.JSType jSType35 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray36 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType37 = jSTypeRegistry34.createConstructorTypeWithVarArgs(jSType35, jSTypeArray36);
        boolean boolean38 = functionType37.isFunctionType();
        int int39 = functionType37.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        boolean boolean46 = functionType37.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.jstype.JSType jSType47 = functionType31.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean48 = functionType31.isInstanceType();
        boolean boolean49 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType31);
        com.google.javascript.rhino.jstype.JSType jSType50 = functionType4.unboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(typePair24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(jSTypeArray36);
        org.junit.Assert.assertNotNull(functionType37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(jSType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(jSType50);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        boolean boolean29 = node25.isFor();
        node25.setLength((int) (byte) 100);
        node25.setSourceEncodedPositionForTree((int) 'a');
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node38.setCharno(0);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setCharno(0);
        boolean boolean53 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node50);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.comma(node45, node50);
        com.google.javascript.rhino.Node node55 = node38.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node56 = node25.useSourceInfoIfMissingFrom(node55);
        node56.setCharno((int) (byte) 10);
        boolean boolean59 = node56.isVoid();
        boolean boolean60 = googleCodingConvention0.isOptionalParameter(node56);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = null;
        functionType4.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo8);
        boolean boolean10 = functionType4.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        int int17 = functionType15.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        boolean boolean24 = functionType15.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean25 = functionType15.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair26 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        boolean boolean34 = functionType33.isFunctionType();
        int int35 = functionType33.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType38, jSTypeArray39);
        boolean boolean41 = functionType40.isFunctionType();
        boolean boolean42 = functionType33.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType40);
        boolean boolean43 = functionType33.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry52.createConstructorTypeWithVarArgs(jSType53, jSTypeArray54);
        boolean boolean56 = functionType55.isFunctionType();
        boolean boolean57 = functionType48.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType55);
        boolean boolean58 = functionType33.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType55);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] { functionType55 };
        com.google.javascript.rhino.Node node60 = jSTypeRegistry28.createOptionalParameters(jSTypeArray59);
        functionType15.setSource(node60);
        boolean boolean62 = node60.isNE();
        node60.setIsSyntheticBlock(false);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(typePair26);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression4, "2019/06/10 13:15");
        boolean boolean7 = jSDocInfoBuilder1.recordIdGenerator();
        boolean boolean9 = jSDocInfoBuilder1.recordReturnDescription("hi!");
        boolean boolean10 = jSDocInfoBuilder1.recordNoCompile();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordDescription("module$");
        boolean boolean4 = jSDocInfoBuilder1.shouldParseDocumentation();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        node4.setString("./");
        boolean boolean16 = node4.isAnd();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        com.google.javascript.rhino.jstype.TemplateType templateType72 = parameterizedType71.toMaybeTemplateType();
        int int73 = parameterizedType71.getPropertiesCount();
        int int74 = parameterizedType71.getPropertiesCount();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertNull(templateType72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.setSummaryDetailLevel((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int12 = node11.getSideEffectFlags();
        boolean boolean13 = node11.isFalse();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setCharno(0);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setCharno(0);
        boolean boolean33 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node30);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.comma(node25, node30);
        com.google.javascript.rhino.Node node35 = node18.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node40.setCharno(0);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node52.setCharno(0);
        boolean boolean55 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node52);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.comma(node47, node52);
        com.google.javascript.rhino.Node node57 = node40.clonePropsFrom(node56);
        boolean boolean58 = node56.isNull();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node11, node35, node56 };
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.call(node4, nodeArray59);
        boolean boolean61 = node60.isFunction();
        node60.setSourceEncodedPosition(10);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType26.toObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(objectType30);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean30 = functionType26.hasInstanceType();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet31 = functionType26.getPossibleToBooleanOutcomes();
        boolean boolean33 = functionType26.removeProperty("2019/06/10 13:15");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet31 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet31.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (byte) 100, "hi!", (int) (short) 0, (int) (byte) 100);
        node4.addSuppression("./: module$");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString("", 31, (int) (byte) 100);
        boolean boolean11 = node10.isBlock();
        com.google.javascript.rhino.Node node12 = node4.useSourceInfoIfMissingFromForTree(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry14.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        boolean boolean18 = functionType17.isFunctionType();
        int int19 = functionType17.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        boolean boolean25 = functionType24.isFunctionType();
        boolean boolean26 = functionType17.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType24);
        boolean boolean27 = functionType17.isEmptyType();
        boolean boolean28 = functionType17.hasInstanceType();
        com.google.javascript.rhino.jstype.ObjectType objectType30 = functionType17.getTopMostDefiningType("");
        node10.setJSType((com.google.javascript.rhino.jstype.JSType) objectType30);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(objectType30);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.ideMode;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy2 = compilerOptions0.variableRenaming;
        boolean boolean3 = compilerOptions0.inlineFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy2 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy2.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.withName("2019/06/10 13:15");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.setIsConstructor(true);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder7 = functionBuilder5.withName("OR  32");
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
        org.junit.Assert.assertNotNull(functionBuilder7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention18 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node24.setCharno(0);
        boolean boolean27 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node24);
        boolean boolean28 = node24.isGetProp();
        boolean boolean30 = node24.getBooleanProp((int) (short) 10);
        java.lang.String str31 = node24.getSourceFileName();
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node36.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node46 = new com.google.javascript.rhino.Node((int) '#', node24, node36, node43, 0, (int) (short) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship47 = googleCodingConvention18.getDelegateRelationship(node36);
        compilerOptions0.setCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNull(delegateRelationship47);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
//        com.google.javascript.rhino.jstype.JSType jSType2 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
//        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
//        node10.setIsSyntheticBlock(false);
//        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
//        java.lang.Object obj15 = null;
//        node10.putProp((int) '4', obj15);
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
//        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
//        com.google.javascript.rhino.jstype.JSType jSType20 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
//        boolean boolean23 = functionType22.isFunctionType();
//        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
//        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
//        com.google.javascript.rhino.jstype.JSType jSType27 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
//        boolean boolean30 = functionType29.isFunctionType();
//        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
//        com.google.javascript.rhino.jstype.JSType jSType33 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
//        boolean boolean36 = functionType35.isFunctionType();
//        int int37 = functionType35.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
//        com.google.javascript.rhino.jstype.JSType jSType40 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
//        boolean boolean43 = functionType42.isFunctionType();
//        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
//        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
//        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
//        com.google.javascript.rhino.jstype.JSType jSType48 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
//        boolean boolean51 = functionType50.isFunctionType();
//        int int52 = functionType50.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
//        com.google.javascript.rhino.jstype.JSType jSType55 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
//        boolean boolean58 = functionType57.isFunctionType();
//        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
//        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
//        com.google.javascript.rhino.jstype.JSType jSType62 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
//        boolean boolean65 = functionType64.isFunctionType();
//        int int66 = functionType64.getMaxArguments();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
//        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
//        boolean boolean70 = functionType64.isInterface();
//        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
//        com.google.javascript.rhino.jstype.JSType jSType73 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
//        boolean boolean76 = functionType75.isFunctionType();
//        int int77 = functionType75.getMaxArguments();
//        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
//        com.google.javascript.rhino.jstype.JSType jSType80 = null;
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
//        boolean boolean83 = functionType82.isFunctionType();
//        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
//        boolean boolean85 = functionType75.isEmptyType();
//        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
//        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
//        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
//        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
//        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.getPropertyType("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
//        java.lang.String str92 = parameterizedType89.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(jSTypeArray3);
//        org.junit.Assert.assertNotNull(functionType4);
//        org.junit.Assert.assertNotNull(node10);
//        org.junit.Assert.assertNull(jSType13);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertNotNull(jSTypeArray21);
//        org.junit.Assert.assertNotNull(functionType22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(enumType24);
//        org.junit.Assert.assertNotNull(jSTypeArray28);
//        org.junit.Assert.assertNotNull(functionType29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray34);
//        org.junit.Assert.assertNotNull(functionType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray41);
//        org.junit.Assert.assertNotNull(functionType42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(jSType45);
//        org.junit.Assert.assertNotNull(jSTypeArray49);
//        org.junit.Assert.assertNotNull(functionType50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray56);
//        org.junit.Assert.assertNotNull(functionType57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertNotNull(jSTypeArray63);
//        org.junit.Assert.assertNotNull(functionType64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(jSTypeArray74);
//        org.junit.Assert.assertNotNull(functionType75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
//        org.junit.Assert.assertNotNull(jSTypeArray81);
//        org.junit.Assert.assertNotNull(functionType82);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(typePair86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertNotNull(objectType88);
//        org.junit.Assert.assertNotNull(parameterizedType89);
//        org.junit.Assert.assertNotNull(jSType91);
//        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "{proxy:function (): {1849660335}}" + "'", str92.equals("{proxy:function (): {1849660335}}"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter3 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry2);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention4 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0);
        boolean boolean6 = closureCodingConvention4.isPrivate("function (): {330869298}");
        java.lang.String str7 = closureCodingConvention4.getAbstractMethodName();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node13.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType18 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType21 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int22 = diagnosticType18.compareTo(diagnosticType21);
        java.lang.String[] strArray23 = null;
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make("", node13, diagnosticType18, strArray23);
        boolean boolean25 = node13.isTypeOf();
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType33 = node30.getJSType();
        boolean boolean34 = node30.isFromExterns();
        java.lang.String str35 = closureCodingConvention4.extractClassNameIfProvide(node13, node30);
        java.lang.String str36 = node13.getString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "goog.abstractMethod" + "'", str7.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(diagnosticType18);
        org.junit.Assert.assertNotNull(diagnosticType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNull(jSType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        com.google.javascript.rhino.Node node1 = com.google.javascript.jscomp.parsing.JsDocInfoParser.parseTypeString("OR  32");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.isNoShadow();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList10 = jSDocInfo8.getThrownTypes();
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection11 = jSDocInfo8.getTypeNodes();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList10);
        org.junit.Assert.assertNotNull(nodeCollection11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(52, "hi!", (int) ' ', (int) (short) 10);
        boolean boolean5 = node4.isDo();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.isOverride();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int6 = diagnosticType2.compareTo(diagnosticType5);
        java.lang.String str7 = diagnosticType5.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType11 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray12 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType11, strArray12);
        int int14 = diagnosticType5.compareTo(diagnosticType11);
        java.lang.String str15 = diagnosticType5.toString();
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "./: module$" + "'", str7.equals("./: module$"));
        org.junit.Assert.assertNotNull(diagnosticType11);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28) + "'", int14 == (-28));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "./: module$" + "'", str15.equals("./: module$"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        com.google.javascript.jscomp.deps.JsFileParser jsFileParser4 = new com.google.javascript.jscomp.deps.JsFileParser((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.deps.DependencyInfo dependencyInfo8 = jsFileParser4.parseFile("Not declared as a type name", "goog.exportSymbol", "function (): {1244485907}");
        jsFileParser4.setShortcutMode(false);
        jsFileParser4.setShortcutMode(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(dependencyInfo8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean72 = parameterizedType71.isInterface();
        boolean boolean73 = parameterizedType71.matchesStringContext();
        com.google.javascript.rhino.jstype.ObjectType objectType74 = null;
        try {
            parameterizedType71.matchConstraint(objectType74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int14 = diagnosticType10.compareTo(diagnosticType13);
        java.lang.String[] strArray15 = null;
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType10, strArray15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean22 = node21.isWith();
        boolean boolean23 = jSError16.equals((java.lang.Object) boolean22);
        com.google.javascript.jscomp.JSError[] jSErrorArray24 = new com.google.javascript.jscomp.JSError[] { jSError16 };
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType35 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType38 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int39 = diagnosticType35.compareTo(diagnosticType38);
        java.lang.String[] strArray40 = null;
        com.google.javascript.jscomp.JSError jSError41 = com.google.javascript.jscomp.JSError.make("", node30, diagnosticType35, strArray40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean47 = node46.isWith();
        boolean boolean48 = jSError41.equals((java.lang.Object) boolean47);
        com.google.javascript.jscomp.JSError[] jSErrorArray49 = new com.google.javascript.jscomp.JSError[] { jSError41 };
        com.google.javascript.jscomp.VariableMap variableMap51 = null;
        com.google.javascript.jscomp.VariableMap variableMap52 = null;
        com.google.javascript.jscomp.VariableMap variableMap53 = null;
        com.google.javascript.jscomp.FunctionInformationMap functionInformationMap54 = null;
        com.google.javascript.jscomp.SourceMap sourceMap55 = null;
        com.google.javascript.jscomp.Result result57 = new com.google.javascript.jscomp.Result(jSErrorArray24, jSErrorArray49, "hi!", variableMap51, variableMap52, variableMap53, functionInformationMap54, sourceMap55, "InputId: hi!");
        com.google.javascript.jscomp.VariableMap variableMap58 = result57.stringMap;
        com.google.javascript.jscomp.JSError[] jSErrorArray59 = result57.errors;
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSErrorArray24);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(diagnosticType35);
        org.junit.Assert.assertNotNull(diagnosticType38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(jSError41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jSErrorArray49);
        org.junit.Assert.assertNull(variableMap58);
        org.junit.Assert.assertNotNull(jSErrorArray59);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder3 = functionBuilder1.withName("2019/06/10 13:15");
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder5 = functionBuilder1.setIsConstructor(true);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType6 = functionBuilder1.build();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(functionBuilder3);
        org.junit.Assert.assertNotNull(functionBuilder5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int14 = diagnosticType10.compareTo(diagnosticType13);
        java.lang.String[] strArray15 = null;
        com.google.javascript.jscomp.JSError jSError16 = com.google.javascript.jscomp.JSError.make("", node5, diagnosticType10, strArray15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean22 = node21.isWith();
        boolean boolean23 = jSError16.equals((java.lang.Object) boolean22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node33.setCharno(0);
        boolean boolean36 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node33);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.comma(node28, node33);
        java.lang.String str38 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node28);
        boolean boolean39 = jSError16.equals((java.lang.Object) str38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node49.setCharno(0);
        boolean boolean52 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node49);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.comma(node44, node49);
        boolean boolean54 = node49.isTry();
        boolean boolean55 = node49.isCall();
        boolean boolean56 = node49.isBreak();
        boolean boolean57 = node49.isOr();
        boolean boolean58 = jSError16.equals((java.lang.Object) node49);
        java.lang.Object obj59 = null;
        boolean boolean60 = jSError16.equals(obj59);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSError16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.JSDocInfo.TypePosition typePosition0 = new com.google.javascript.rhino.JSDocInfo.TypePosition();
        com.google.javascript.rhino.Node node1 = typePosition0.getItem();
        com.google.javascript.rhino.Node node2 = typePosition0.getItem();
        org.junit.Assert.assertNull(node1);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.findPropertyType("module$");
        boolean boolean92 = parameterizedType89.isNoObjectType();
        com.google.javascript.rhino.jstype.JSType jSType93 = parameterizedType89.getParameterType();
        com.google.javascript.rhino.jstype.EnumElementType enumElementType94 = parameterizedType89.toMaybeEnumElementType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(jSType93);
        org.junit.Assert.assertNull(enumElementType94);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.rhino.JSDocInfo.Marker marker0 = new com.google.javascript.rhino.JSDocInfo.Marker();
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean30 = functionType26.isResolved();
        boolean boolean31 = functionType26.hasCachedValues();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.script();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        double double3 = loggerErrorManager2.getTypedPercent();
        int int4 = loggerErrorManager2.getWarningCount();
        com.google.javascript.jscomp.deps.JsFileParser jsFileParser5 = new com.google.javascript.jscomp.deps.JsFileParser((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        boolean boolean6 = node4.isFalse();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.returnNode(node4);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber((double) (byte) -1, 52, 44);
        boolean boolean12 = node4.hasChild(node11);
        com.google.javascript.rhino.Node node13 = node11.getNext();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node13);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType19.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        boolean boolean44 = functionType19.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair45 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType19);
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable46 = functionType19.getCtorExtendedInterfaces();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = functionType19.getImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType48 = functionType19.unboxesTo();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(typePair45);
        org.junit.Assert.assertNotNull(objectTypeIterable46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertNull(jSType48);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.CompilerOptions.Reach reach22 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setInlineVariables(reach22);
        compilerOptions0.setInstrumentationTemplate("./");
        compilerOptions0.removeUnusedClassProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + reach22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach22.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node7.setCharno(0);
        boolean boolean10 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node7);
        boolean boolean11 = node7.isGetProp();
        boolean boolean13 = node7.getBooleanProp((int) (short) 10);
        java.lang.String str14 = node7.getSourceFileName();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node19.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) '#', node7, node19, node26, 0, (int) (short) 0);
        boolean boolean30 = node26.isCatch();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node35.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType38 = node35.getJSType();
        java.lang.Object obj40 = null;
        node35.putProp((int) '4', obj40);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.pos(node35);
        com.google.javascript.rhino.Node node43 = node26.useSourceInfoFrom(node35);
        boolean boolean44 = googleCodingConvention0.isPrototypeAlias(node26);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean50 = node49.isDec();
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship51 = googleCodingConvention0.getClassesDefinedByCall(node49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNull(jSType38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.getPropertyType("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        boolean boolean93 = parameterizedType89.removeProperty("function (): {330869298}");
        boolean boolean94 = parameterizedType89.isNullable();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNotNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        boolean boolean5 = compilerOptions0.exportTestFunctions;
        compilerOptions0.disableRuntimeTypeCheck();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType10, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = jSError12.getType();
        loggerErrorManager5.report(checkLevel6, jSError12);
        compilerOptions0.setReportUnknownTypes(checkLevel6);
        com.google.javascript.jscomp.SourceMap.Format format16 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(format16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        boolean boolean15 = functionType4.hasInstanceType();
        java.lang.String str16 = functionType4.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        int int24 = functionType22.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        boolean boolean31 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType29);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        int int38 = functionType36.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = null;
        functionType36.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo40);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair42 = functionType22.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean43 = functionType22.isStringValueType();
        boolean boolean44 = functionType22.hasAnyTemplate();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setCharno(0);
        boolean boolean53 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node50);
        boolean boolean54 = node50.isGetProp();
        boolean boolean56 = node50.getBooleanProp((int) (short) 10);
        java.lang.String str57 = node50.getSourceFileName();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node62.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) '#', node50, node62, node69, 0, (int) (short) 0);
        boolean boolean73 = functionType4.defineDeclaredProperty("", (com.google.javascript.rhino.jstype.JSType) functionType22, node50);
        boolean boolean74 = functionType4.isNativeObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(typePair42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setCoalesceVariableNames(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        int int2 = node0.getIntProp(0);
        com.google.javascript.rhino.Node node3 = node0.getLastChild();
        java.lang.Appendable appendable4 = null;
        try {
            node0.appendStringTree(appendable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(node3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry7.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        boolean boolean11 = functionType10.isFunctionType();
        int int12 = functionType10.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry14.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        boolean boolean18 = functionType17.isFunctionType();
        boolean boolean19 = functionType10.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        com.google.javascript.rhino.jstype.JSType jSType22 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray23 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType22, jSTypeArray23);
        boolean boolean25 = functionType24.isFunctionType();
        int int26 = functionType24.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo28 = null;
        functionType24.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo28);
        boolean boolean30 = functionType24.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        boolean boolean45 = functionType35.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair46 = functionType24.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType35);
        boolean boolean47 = functionType10.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType35);
        boolean boolean48 = functionType35.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.JSType jSType49 = functionType4.resolve(errorReporter5, (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType35);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSTypeArray23);
        org.junit.Assert.assertNotNull(functionType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(typePair46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(jSType49);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.CompilerOptions.Reach reach22 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setInlineVariables(reach22);
        boolean boolean24 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + reach22 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach22.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable3 = jSTypeRegistry1.getTypesWithProperty("InputId: hi!");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray7 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType8 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType6, jSTypeArray7);
        boolean boolean9 = functionType8.isFunctionType();
        int int10 = functionType8.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        boolean boolean17 = functionType8.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType15);
        boolean boolean18 = functionType8.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType21, jSTypeArray22);
        boolean boolean24 = functionType23.isFunctionType();
        int int25 = functionType23.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter26 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter26);
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry27.createConstructorTypeWithVarArgs(jSType28, jSTypeArray29);
        boolean boolean31 = functionType30.isFunctionType();
        boolean boolean32 = functionType23.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType30);
        boolean boolean33 = functionType23.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry35.createConstructorTypeWithVarArgs(jSType36, jSTypeArray37);
        boolean boolean39 = functionType38.isFunctionType();
        int int40 = functionType38.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.JSType jSType43 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry42.createConstructorTypeWithVarArgs(jSType43, jSTypeArray44);
        boolean boolean46 = functionType45.isFunctionType();
        boolean boolean47 = functionType38.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType45);
        boolean boolean48 = functionType23.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType45);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair49 = functionType8.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType23);
        boolean boolean51 = functionType8.hasOwnProperty("function (): {330869298}");
        jSTypeRegistry1.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType8);
        boolean boolean54 = functionType8.isPropertyTypeDeclared("{...}");
        org.junit.Assert.assertNotNull(jSTypeIterable3);
        org.junit.Assert.assertNotNull(jSTypeArray7);
        org.junit.Assert.assertNotNull(functionType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(typePair49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("./");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        double double1 = compiler0.getProgress();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt3 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter4 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt3);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker5 = null;
        compiler0.tracker = performanceTracker5;
        java.lang.String str7 = compiler0.getAstDotGraph();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setChainCalls(false);
        com.google.javascript.jscomp.CompilerOptions.Reach reach24 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions0.setRemoveUnusedVariables(reach24);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + reach24 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach24.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        boolean boolean5 = jSDocInfoBuilder1.addAuthor("2019/06/10 13:15");
        boolean boolean6 = jSDocInfoBuilder1.recordImplicitCast();
        boolean boolean7 = jSDocInfoBuilder1.isPopulated();
        boolean boolean9 = jSDocInfoBuilder1.recordFileOverview("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {330869298}");
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst6 = new com.google.javascript.jscomp.JsAst(sourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceFile5, false);
        compilerInput8.clearAst();
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput8.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst11 = compilerInput8.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8);
        jSModule1.remove(compilerInput8);
        jSModule1.removeAll();
        java.util.List<java.lang.String> strList15 = jSModule1.getRequires();
        int int16 = jSModule1.getDepth();
        int int17 = jSModule1.getDepth();
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNotNull(sourceAst11);
        org.junit.Assert.assertNotNull(strList15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.String[] strArray8 = new java.lang.String[] { "module$", "./", "module$", "", "./", "" };
        java.util.ArrayList<java.lang.String> strList9 = new java.util.ArrayList<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList9, strArray8);
        java.lang.String[] strArray14 = new java.lang.String[] { "2019/06/10 13:15", "./", "DiagnosticGroup<const>" };
        java.util.ArrayList<java.lang.String> strList15 = new java.util.ArrayList<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList15, strArray14);
        com.google.javascript.jscomp.deps.SimpleDependencyInfo simpleDependencyInfo17 = new com.google.javascript.jscomp.deps.SimpleDependencyInfo("", "hi!", (java.util.List<java.lang.String>) strList9, (java.util.List<java.lang.String>) strList15);
        java.util.Collection<java.lang.String> strCollection18 = simpleDependencyInfo17.getProvides();
        java.lang.String str19 = simpleDependencyInfo17.getName();
        java.lang.String str20 = simpleDependencyInfo17.getPathRelativeToClosureBase();
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(strCollection18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        double double1 = compiler0.getProgress();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3 };
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType10, jSTypeArray11);
        boolean boolean13 = functionType12.isFunctionType();
        int int14 = functionType12.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        boolean boolean21 = functionType12.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType19);
        java.util.Set<java.lang.String> strSet22 = functionType19.getOwnPropertyNames();
        compilerOptions6.setAliasableStrings(strSet22);
        compilerOptions6.setAliasableGlobals("Unversioned directory");
        byte[] byteArray26 = compilerOptions6.inputVariableMapSerialized;
        boolean boolean27 = compilerOptions6.extractPrototypeMemberDeclarations;
        boolean boolean28 = compilerOptions6.smartNameRemoval;
        com.google.javascript.jscomp.MessageFormatter messageFormatter29 = null;
        java.util.logging.Logger logger30 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager31 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter29, logger30);
        double double32 = loggerErrorManager31.getTypedPercent();
        com.google.javascript.jscomp.MessageFormatter messageFormatter33 = null;
        java.util.logging.Logger logger34 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager35 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter33, logger34);
        com.google.javascript.jscomp.CheckLevel checkLevel36 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType40 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray41 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType40, strArray41);
        com.google.javascript.jscomp.DiagnosticType diagnosticType43 = jSError42.getType();
        loggerErrorManager35.report(checkLevel36, jSError42);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType55 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType58 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int59 = diagnosticType55.compareTo(diagnosticType58);
        java.lang.String[] strArray60 = null;
        com.google.javascript.jscomp.JSError jSError61 = com.google.javascript.jscomp.JSError.make("", node50, diagnosticType55, strArray60);
        com.google.javascript.jscomp.DiagnosticType diagnosticType62 = jSError61.getType();
        loggerErrorManager31.report(checkLevel36, jSError61);
        compilerOptions6.setCheckGlobalThisLevel(checkLevel36);
        try {
            com.google.javascript.jscomp.Result result65 = compiler0.compile(jSSourceFileArray4, jSModuleArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(strSet22);
        org.junit.Assert.assertNull(byteArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + checkLevel36 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel36.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType40);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertNotNull(diagnosticType43);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(diagnosticType55);
        org.junit.Assert.assertNotNull(diagnosticType58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(jSError61);
        org.junit.Assert.assertNotNull(diagnosticType62);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.checkMissingGetCssNameBlacklist = "Unversioned directory";
        compilerOptions0.setDefineToBooleanLiteral("Not declared as a constructor", true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setCharno(0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node16.setCharno(0);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.comma(node11, node16);
        com.google.javascript.rhino.Node node21 = node4.clonePropsFrom(node20);
        boolean boolean22 = node20.isNull();
        com.google.javascript.rhino.Node node23 = node20.removeFirstChild();
        boolean boolean24 = node23.hasOneChild();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node29.setCharno(0);
        boolean boolean32 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node29);
        boolean boolean33 = node29.isGetProp();
        boolean boolean35 = node29.getBooleanProp((int) (short) 10);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.getelem(node23, node29);
        try {
            com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.defaultCase(node23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node36);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.findPropertyType("module$");
        boolean boolean92 = parameterizedType89.isNoObjectType();
        com.google.javascript.rhino.Node node94 = parameterizedType89.getPropertyNode("module$");
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNull(node94);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        int int1 = stringPosition0.getEndLine();
        int int2 = stringPosition0.getEndLine();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType7, jSTypeArray8);
        boolean boolean10 = functionType9.isFunctionType();
        int int11 = functionType9.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType14, jSTypeArray15);
        boolean boolean17 = functionType16.isFunctionType();
        boolean boolean18 = functionType9.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType16);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType9);
        jSTypeRegistry1.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) objectType19);
        jSTypeRegistry1.clearTemplateTypeNames();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder22 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry1);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objectType19);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setDisambiguateProperties(true);
        compilerOptions0.setExternExports(false);
        compilerOptions0.aliasStringsBlacklist = "DiagnosticGroup<checkRegExp>";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setCharno(0);
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node5);
        boolean boolean9 = node5.isGetProp();
        boolean boolean11 = node5.getBooleanProp((int) (short) 10);
        java.lang.String str12 = node5.getSourceFileName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '#', node5, node17, node24, 0, (int) (short) 0);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node33.setCharno(0);
        boolean boolean36 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node33);
        boolean boolean37 = node33.isGetProp();
        boolean boolean39 = node33.getBooleanProp((int) (short) 10);
        java.lang.String str40 = node33.getSourceFileName();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node45.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node55 = new com.google.javascript.rhino.Node((int) '#', node33, node45, node52, 0, (int) (short) 0);
        boolean boolean56 = node52.isDebugger();
        com.google.javascript.rhino.Node node57 = node17.useSourceInfoIfMissingFrom(node52);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(node57);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship29 = googleCodingConvention0.getDelegateRelationship(node18);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        jSTypeRegistry31.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType36);
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter38 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention0, jSTypeRegistry31);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node43.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setIsSyntheticBlock(false);
        boolean boolean53 = node50.hasOneChild();
        boolean boolean54 = node50.isEmpty();
        node43.addChildToFront(node50);
        int int56 = node50.getCharno();
        boolean boolean57 = googleCodingConvention0.isPrototypeAlias(node50);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNull(delegateRelationship29);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 32 + "'", int56 == 32);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setChainCalls(false);
        java.lang.String str24 = compilerOptions0.inputDelimiter;
        com.google.javascript.jscomp.DiagnosticType diagnosticType27 = com.google.javascript.jscomp.DiagnosticType.error("", "DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        com.google.javascript.jscomp.CheckLevel checkLevel28 = diagnosticType27.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType29 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType29.level = checkLevel30;
        diagnosticType27.level = checkLevel30;
        compilerOptions0.reportMissingOverride = checkLevel30;
        com.google.javascript.jscomp.CodingConvention codingConvention34 = compilerOptions0.getCodingConvention();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "// Input %num%" + "'", str24.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(diagnosticType27);
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType29);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNull(codingConvention34);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry4.createConstructorTypeWithVarArgs(jSType5, jSTypeArray6);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8);
        com.google.javascript.rhino.jstype.JSType jSType10 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray11 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry9.createConstructorTypeWithVarArgs(jSType10, jSTypeArray11);
        boolean boolean13 = functionType12.isFunctionType();
        int int14 = functionType12.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        boolean boolean21 = functionType12.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType19);
        com.google.javascript.rhino.jstype.ObjectType objectType22 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType12);
        jSTypeRegistry4.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) objectType22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        int int30 = functionType28.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        boolean boolean37 = functionType28.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType35);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        int int44 = functionType42.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo46 = null;
        functionType42.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo46);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair48 = functionType28.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType42);
        boolean boolean49 = functionType28.isStringValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter50 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter50);
        com.google.javascript.rhino.jstype.JSType jSType52 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray53 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType54 = jSTypeRegistry51.createConstructorTypeWithVarArgs(jSType52, jSTypeArray53);
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry4.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType28, jSTypeArray53);
        com.google.javascript.rhino.jstype.FunctionType functionType56 = jSTypeRegistry1.createFunctionTypeWithVarArgs(jSType2, jSTypeArray53);
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertNotNull(jSTypeArray11);
        org.junit.Assert.assertNotNull(functionType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(typePair48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(jSTypeArray53);
        org.junit.Assert.assertNotNull(functionType54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertNotNull(functionType56);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.hasType();
        java.util.List<com.google.javascript.rhino.JSTypeExpression> jSTypeExpressionList10 = jSDocInfo8.getImplementedInterfaces();
        java.lang.String str11 = jSDocInfo8.getBlockDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(jSTypeExpressionList10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry7.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        boolean boolean11 = functionType10.isFunctionType();
        int int12 = functionType10.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        com.google.javascript.rhino.jstype.JSType jSType15 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray16 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType17 = jSTypeRegistry14.createConstructorTypeWithVarArgs(jSType15, jSTypeArray16);
        boolean boolean18 = functionType17.isFunctionType();
        boolean boolean19 = functionType10.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType17);
        com.google.javascript.rhino.jstype.JSType jSType20 = functionType4.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType17);
        boolean boolean21 = functionType17.matchesInt32Context();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray16);
        org.junit.Assert.assertNotNull(functionType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setAcceptConstKeyword(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        boolean boolean15 = functionType4.hasInstanceType();
        java.lang.String str16 = functionType4.getReferenceName();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        int int24 = functionType22.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        boolean boolean31 = functionType22.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType29);
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        int int38 = functionType36.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo40 = null;
        functionType36.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo40);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair42 = functionType22.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean43 = functionType22.isStringValueType();
        boolean boolean44 = functionType22.hasAnyTemplate();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setCharno(0);
        boolean boolean53 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node50);
        boolean boolean54 = node50.isGetProp();
        boolean boolean56 = node50.getBooleanProp((int) (short) 10);
        java.lang.String str57 = node50.getSourceFileName();
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node62.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((int) '#', node50, node62, node69, 0, (int) (short) 0);
        boolean boolean73 = functionType4.defineDeclaredProperty("", (com.google.javascript.rhino.jstype.JSType) functionType22, node50);
        functionType4.clearResolved();
        boolean boolean75 = functionType4.hasReferenceName();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(typePair42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile.Generator generator2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder0.buildFromGenerator("DiagnosticGroup<const>", generator2);
        com.google.javascript.jscomp.SourceFile sourceFile6 = builder0.buildFromCode("Not declared as a type name", "./");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile9 = builder0.buildFromCode("", "function (new:?): ?");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean22 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        double double26 = loggerErrorManager25.getTypedPercent();
        com.google.javascript.jscomp.MessageFormatter messageFormatter27 = null;
        java.util.logging.Logger logger28 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager29 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter27, logger28);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType34, strArray35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = jSError36.getType();
        loggerErrorManager29.report(checkLevel30, jSError36);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node44.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int53 = diagnosticType49.compareTo(diagnosticType52);
        java.lang.String[] strArray54 = null;
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("", node44, diagnosticType49, strArray54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = jSError55.getType();
        loggerErrorManager25.report(checkLevel30, jSError55);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel30);
        compilerOptions0.setPrintInputDelimiter(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(diagnosticType56);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        com.google.javascript.rhino.Node node2 = compiler0.getRoot();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        compiler3.reportCodeChange();
        java.lang.String str5 = compiler3.getAstDotGraph();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig7 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions6);
        compiler3.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig7);
        compiler0.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig7);
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("function (): {330869298}");
        jSModule11.clearAsts();
        try {
            java.lang.String str13 = compiler0.toSource(jSModule11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        java.lang.String str14 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node4);
        com.google.javascript.rhino.InputId inputId15 = node4.getInputId();
        boolean boolean16 = node4.isInstanceOf();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(inputId15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.error("DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = null;
        functionType4.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo8);
        boolean boolean10 = functionType4.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        int int17 = functionType15.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        boolean boolean24 = functionType15.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean25 = functionType15.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair26 = functionType4.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType15);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        boolean boolean34 = functionType33.isFunctionType();
        int int35 = functionType33.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        com.google.javascript.rhino.jstype.JSType jSType38 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray39 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType40 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType38, jSTypeArray39);
        boolean boolean41 = functionType40.isFunctionType();
        boolean boolean42 = functionType33.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType40);
        boolean boolean43 = functionType33.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter51 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter51);
        com.google.javascript.rhino.jstype.JSType jSType53 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray54 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType55 = jSTypeRegistry52.createConstructorTypeWithVarArgs(jSType53, jSTypeArray54);
        boolean boolean56 = functionType55.isFunctionType();
        boolean boolean57 = functionType48.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType55);
        boolean boolean58 = functionType33.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType55);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] { functionType55 };
        com.google.javascript.rhino.Node node60 = jSTypeRegistry28.createOptionalParameters(jSTypeArray59);
        functionType15.setSource(node60);
        boolean boolean62 = functionType15.isArrayType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(typePair26);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray39);
        org.junit.Assert.assertNotNull(functionType40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray54);
        org.junit.Assert.assertNotNull(functionType55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        boolean boolean7 = node4.hasOneChild();
        boolean boolean8 = node4.isEmpty();
        java.lang.String str9 = node4.getSourceFileName();
        boolean boolean10 = node4.isAnd();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression4, "2019/06/10 13:15");
        boolean boolean8 = jSDocInfoBuilder1.addAuthor("DiagnosticGroup<const>");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder1.recordParameter("DiagnosticGroup<const>", jSTypeExpression10);
        boolean boolean13 = jSDocInfoBuilder1.recordDescription("function (new:?): ?");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder15 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression17 = null;
        boolean boolean18 = jSDocInfoBuilder15.recordParameter("module$Unversioned directory", jSTypeExpression17);
        boolean boolean19 = jSDocInfoBuilder15.isPopulated();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = jSDocInfoBuilder15.build(node21);
        java.util.Set<java.lang.String> strSet23 = jSDocInfo22.getModifies();
        boolean boolean24 = jSDocInfoBuilder1.recordModifies(strSet23);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(jSDocInfo22);
        org.junit.Assert.assertNotNull(strSet23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo39 = null;
        functionType35.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo39);
        boolean boolean41 = functionType35.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter42 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter42);
        com.google.javascript.rhino.jstype.JSType jSType44 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray45 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType46 = jSTypeRegistry43.createConstructorTypeWithVarArgs(jSType44, jSTypeArray45);
        boolean boolean47 = functionType46.isFunctionType();
        int int48 = functionType46.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter49 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter49);
        com.google.javascript.rhino.jstype.JSType jSType51 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType53 = jSTypeRegistry50.createConstructorTypeWithVarArgs(jSType51, jSTypeArray52);
        boolean boolean54 = functionType53.isFunctionType();
        boolean boolean55 = functionType46.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType53);
        boolean boolean56 = functionType46.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair57 = functionType35.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType46);
        com.google.javascript.rhino.jstype.JSType jSType58 = functionType4.resolve(errorReporter30, (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) functionType46);
        java.lang.String str59 = functionType4.toAnnotationString();
        boolean boolean60 = functionType4.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSTypeArray45);
        org.junit.Assert.assertNotNull(functionType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(functionType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(typePair57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "function (new:?): ?" + "'", str59.equals("function (new:?): ?"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType10, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = jSError12.getType();
        loggerErrorManager5.report(checkLevel6, jSError12);
        compilerOptions0.setReportUnknownTypes(checkLevel6);
        compilerOptions0.inputDelimiter = "module$Unversioned directory";
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode18 = compilerOptions0.getLanguageOut();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNull(languageMode18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.SourceFile.Builder builder1 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile3 = builder1.buildFromFile("2019/06/10 13:15");
        com.google.javascript.jscomp.SourceFile.Builder builder5 = builder1.withOriginalPath("function (): {1244485907}");
        com.google.javascript.jscomp.SourceFile sourceFile10 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst11 = new com.google.javascript.jscomp.JsAst(sourceFile10);
        java.lang.String str12 = sourceFile10.getOriginalPath();
        java.io.Reader reader13 = sourceFile10.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile14 = builder5.buildFromReader("InputId: hi!", reader13);
        com.google.javascript.jscomp.SourceFile sourceFile19 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst20 = new com.google.javascript.jscomp.JsAst(sourceFile19);
        java.lang.String str21 = sourceFile19.getOriginalPath();
        java.io.Reader reader22 = sourceFile19.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile23 = builder5.buildFromReader("goog.exportSymbol", reader22);
        com.google.javascript.jscomp.SourceFile sourceFile24 = com.google.javascript.jscomp.SourceFile.fromReader("2019/06/10 13:15", reader22);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(builder5);
        org.junit.Assert.assertNotNull(sourceFile10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(reader13);
        org.junit.Assert.assertNotNull(sourceFile14);
        org.junit.Assert.assertNotNull(sourceFile19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(reader22);
        org.junit.Assert.assertNotNull(sourceFile23);
        org.junit.Assert.assertNotNull(sourceFile24);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("./");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Not declared as a type name");
        com.google.javascript.rhino.Node node4 = assertInstanceofSpec1.getAssertedParam(node3);
        com.google.javascript.rhino.Node node5 = null;
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6);
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry7.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray14 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType15 = jSTypeRegistry12.createConstructorTypeWithVarArgs(jSType13, jSTypeArray14);
        boolean boolean16 = functionType15.isFunctionType();
        int int17 = functionType15.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        boolean boolean24 = functionType15.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.jstype.ObjectType objectType25 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType15);
        jSTypeRegistry7.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) objectType25);
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        boolean boolean32 = functionType31.isFunctionType();
        int int33 = functionType31.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry35.createConstructorTypeWithVarArgs(jSType36, jSTypeArray37);
        boolean boolean39 = functionType38.isFunctionType();
        boolean boolean40 = functionType31.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType38);
        com.google.javascript.rhino.ErrorReporter errorReporter41 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter41);
        com.google.javascript.rhino.jstype.JSType jSType43 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray44 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType45 = jSTypeRegistry42.createConstructorTypeWithVarArgs(jSType43, jSTypeArray44);
        boolean boolean46 = functionType45.isFunctionType();
        int int47 = functionType45.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = null;
        functionType45.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo49);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair51 = functionType31.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType45);
        boolean boolean52 = functionType31.isStringValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        com.google.javascript.rhino.jstype.FunctionType functionType58 = jSTypeRegistry7.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType31, jSTypeArray56);
        try {
            com.google.javascript.rhino.jstype.JSType jSType59 = assertInstanceofSpec1.getAssertedType(node5, jSTypeRegistry7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertNotNull(jSTypeArray14);
        org.junit.Assert.assertNotNull(functionType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(jSTypeArray44);
        org.junit.Assert.assertNotNull(functionType45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(typePair51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNotNull(functionType58);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        java.lang.String str20 = compilerOptions0.inputDelimiter;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "// Input %num%" + "'", str20.equals("// Input %num%"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean2 = jSDocInfoBuilder1.recordNoShadow();
        boolean boolean3 = jSDocInfoBuilder1.isInterfaceRecorded();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        boolean boolean3 = compilerOptions0.inlineGetters;
        compilerOptions0.setCheckTypes(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.NodeTraversal.Callback callback3 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal4 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler0, callback3);
        int int5 = nodeTraversal4.getLineNumber();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        boolean boolean7 = node4.hasOneChild();
        boolean boolean8 = node4.isEmpty();
        java.lang.String str9 = node4.getSourceFileName();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable10 = node4.getAncestors();
        boolean boolean11 = node4.isDelProp();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(ancestorIterable10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = diagnosticGroups0.forName("DiagnosticGroup<const>");
        org.junit.Assert.assertNull(diagnosticGroup2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        functionType48.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = functionType34.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue55 = functionType26.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = functionType34.getJSDocInfo();
        boolean boolean57 = functionType34.isOrdinaryFunction();
        boolean boolean58 = functionType34.isConstructor();
        boolean boolean59 = functionType34.isStringObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNotNull(ternaryValue55);
        org.junit.Assert.assertNull(jSDocInfo56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        com.google.javascript.jscomp.SourceFile sourceFile2 = builder0.buildFromFile("2019/06/10 13:15");
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder0.withOriginalPath("function (): {1244485907}");
        com.google.javascript.jscomp.SourceFile sourceFile7 = builder0.buildFromCode("./", "./. module$ at (unknown source) line 32 : 32");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int12 = node11.getSideEffectFlags();
        boolean boolean13 = node11.isFalse();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setCharno(0);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node30.setCharno(0);
        boolean boolean33 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node30);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.IR.comma(node25, node30);
        com.google.javascript.rhino.Node node35 = node18.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node40.setCharno(0);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node52.setCharno(0);
        boolean boolean55 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node52);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.comma(node47, node52);
        com.google.javascript.rhino.Node node57 = node40.clonePropsFrom(node56);
        boolean boolean58 = node56.isNull();
        com.google.javascript.rhino.Node[] nodeArray59 = new com.google.javascript.rhino.Node[] { node11, node35, node56 };
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.IR.call(node4, nodeArray59);
        boolean boolean61 = node4.isCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(nodeArray59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("./");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Not declared as a type name");
        com.google.javascript.rhino.Node node4 = assertInstanceofSpec1.getAssertedParam(node3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setCharno(0);
        boolean boolean13 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node10);
        boolean boolean14 = node10.isGetProp();
        boolean boolean16 = node10.getBooleanProp((int) (short) 10);
        java.lang.String str17 = node10.getSourceFileName();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node22.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node32 = new com.google.javascript.rhino.Node((int) '#', node10, node22, node29, 0, (int) (short) 0);
        boolean boolean33 = node29.isCatch();
        com.google.javascript.rhino.Node node34 = assertInstanceofSpec1.getAssertedParam(node29);
        node29.setSourceFileForTesting("2019/06/10 13:15");
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        jSDocInfoBuilder1.markText("function (): {1244485907}", (int) (byte) 100, (int) (byte) 10, 32, 31);
        boolean boolean8 = jSDocInfoBuilder1.isJavaDispatch();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler21 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler21);
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        com.google.javascript.jscomp.CheckLevel checkLevel26 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray31 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError32 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType30, strArray31);
        com.google.javascript.jscomp.DiagnosticType diagnosticType33 = jSError32.getType();
        loggerErrorManager25.report(checkLevel26, jSError32);
        compilerOptions0.setReportUnknownTypes(checkLevel26);
        compilerOptions0.setRemoveDeadCode(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(strArray31);
        org.junit.Assert.assertNotNull(jSError32);
        org.junit.Assert.assertNotNull(diagnosticType33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.ideMode;
        compilerOptions0.inlineVariables = true;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("{...}");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        compilerOptions0.setInlineVariables(true);
        compilerOptions0.setExportTestFunctions(false);
        org.junit.Assert.assertNull(messageBundle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        boolean boolean29 = node28.isAdd();
        com.google.javascript.jscomp.CompilerOptions compilerOptions30 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean31 = compilerOptions30.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        int int38 = functionType36.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter39 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter39);
        com.google.javascript.rhino.jstype.JSType jSType41 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType43 = jSTypeRegistry40.createConstructorTypeWithVarArgs(jSType41, jSTypeArray42);
        boolean boolean44 = functionType43.isFunctionType();
        boolean boolean45 = functionType36.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType43);
        java.util.Set<java.lang.String> strSet46 = functionType43.getOwnPropertyNames();
        compilerOptions30.setAliasableStrings(strSet46);
        compilerOptions30.setAliasableGlobals("Unversioned directory");
        byte[] byteArray50 = compilerOptions30.inputVariableMapSerialized;
        boolean boolean51 = compilerOptions30.extractPrototypeMemberDeclarations;
        compilerOptions30.setChainCalls(false);
        java.lang.String str54 = compilerOptions30.inputDelimiter;
        com.google.javascript.jscomp.DiagnosticType diagnosticType57 = com.google.javascript.jscomp.DiagnosticType.error("", "DependencyInfo(relativePath='', path='hi!', provides=[module$, ./, module$, , ./, ], requires=[2019/06/10 13:15, ./, DiagnosticGroup<const>])");
        com.google.javascript.jscomp.CheckLevel checkLevel58 = diagnosticType57.defaultLevel;
        com.google.javascript.jscomp.DiagnosticType diagnosticType59 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel60 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType59.level = checkLevel60;
        diagnosticType57.level = checkLevel60;
        compilerOptions30.reportMissingOverride = checkLevel60;
        com.google.javascript.jscomp.DiagnosticType diagnosticType66 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        java.lang.String[] strArray68 = new java.lang.String[] { "module$" };
        com.google.javascript.jscomp.JSError jSError69 = com.google.javascript.jscomp.JSError.make("module$Unversioned directory", node28, checkLevel60, diagnosticType66, strArray68);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(functionType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(strSet46);
        org.junit.Assert.assertNull(byteArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "// Input %num%" + "'", str54.equals("// Input %num%"));
        org.junit.Assert.assertNotNull(diagnosticType57);
        org.junit.Assert.assertTrue("'" + checkLevel58 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel58.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType59);
        org.junit.Assert.assertTrue("'" + checkLevel60 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel60.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType66);
        org.junit.Assert.assertNotNull(strArray68);
        org.junit.Assert.assertNotNull(jSError69);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType7 = node4.getJSType();
        java.lang.Object obj9 = null;
        node4.putProp((int) '4', obj9);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.pos(node4);
        java.lang.Appendable appendable12 = null;
        try {
            node4.appendStringTree(appendable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.setInlineFunctions(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy9);
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setConvertToDottedProperties(false);
        compilerOptions0.setSyntheticBlockEndMarker("Not declared as a constructor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        int int37 = functionType35.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isFunctionType();
        boolean boolean44 = functionType35.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.jstype.JSType jSType45 = functionType29.getLeastSupertype((com.google.javascript.rhino.jstype.JSType) functionType42);
        com.google.javascript.rhino.ErrorReporter errorReporter46 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter46);
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry47.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        boolean boolean51 = functionType50.isFunctionType();
        int int52 = functionType50.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        boolean boolean58 = functionType57.isFunctionType();
        boolean boolean59 = functionType50.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType57);
        com.google.javascript.rhino.ErrorReporter errorReporter60 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry61 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter60);
        com.google.javascript.rhino.jstype.JSType jSType62 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray63 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType64 = jSTypeRegistry61.createConstructorTypeWithVarArgs(jSType62, jSTypeArray63);
        boolean boolean65 = functionType64.isFunctionType();
        int int66 = functionType64.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo68 = null;
        functionType64.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo68);
        boolean boolean70 = functionType64.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter71 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry72 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter71);
        com.google.javascript.rhino.jstype.JSType jSType73 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray74 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType75 = jSTypeRegistry72.createConstructorTypeWithVarArgs(jSType73, jSTypeArray74);
        boolean boolean76 = functionType75.isFunctionType();
        int int77 = functionType75.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter78 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter78);
        com.google.javascript.rhino.jstype.JSType jSType80 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry79.createConstructorTypeWithVarArgs(jSType80, jSTypeArray81);
        boolean boolean83 = functionType82.isFunctionType();
        boolean boolean84 = functionType75.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType82);
        boolean boolean85 = functionType75.isEmptyType();
        com.google.javascript.rhino.jstype.JSType.TypePair typePair86 = functionType64.getTypesUnderInequality((com.google.javascript.rhino.jstype.JSType) functionType75);
        boolean boolean87 = functionType50.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType75);
        com.google.javascript.rhino.jstype.ObjectType objectType88 = functionType50.getTypeOfThis();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType89 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType50);
        com.google.javascript.rhino.jstype.JSType jSType91 = parameterizedType89.findPropertyType("module$");
        boolean boolean92 = parameterizedType89.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.ObjectType objectType93 = parameterizedType89.getImplicitPrototype();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeArray63);
        org.junit.Assert.assertNotNull(functionType64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(jSTypeArray74);
        org.junit.Assert.assertNotNull(functionType75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(typePair86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(parameterizedType89);
        org.junit.Assert.assertNull(jSType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(objectType93);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        compilerOptions0.setInlineVariables(true);
        compilerOptions0.optimizeReturns = false;
        org.junit.Assert.assertNull(messageBundle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        java.util.Set<java.lang.String> strSet9 = jSDocInfo8.getModifies();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = jSDocInfo8.getTypedefType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNull(jSTypeExpression10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        int int1 = stringPosition0.getPositionOnEndLine();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.setChainCalls(false);
        compilerOptions0.setComputeFunctionSideEffects(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 100);
        int int2 = node1.getLength();
        java.lang.Object obj4 = node1.getProp((int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setClosurePass(false);
        boolean boolean7 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str1 = googleCodingConvention0.getExportSymbolFunction();
        boolean boolean3 = googleCodingConvention0.isConstantKey("Not declared as a constructor");
        boolean boolean5 = googleCodingConvention0.isConstant("function (new:{...}): ?");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        boolean boolean13 = node10.hasOneChild();
        boolean boolean14 = node10.isEmpty();
        boolean boolean15 = node10.isScript();
        boolean boolean16 = googleCodingConvention0.isOptionalParameter(node10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "goog.exportSymbol" + "'", str1.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "./");
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str4 = sourceFile2.toString();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.isNoShadow();
        boolean boolean10 = jSDocInfo8.isDeprecated();
        boolean boolean11 = jSDocInfo8.hasReturnType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        int int2 = node0.getIntProp(0);
        com.google.javascript.rhino.Node node3 = node0.getLastChild();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile4 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node0);
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention5 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str6 = googleCodingConvention5.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter8 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention5, jSTypeRegistry7);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention9 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention5);
        boolean boolean11 = closureCodingConvention9.isPrivate("function (): {330869298}");
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.nullNode();
        com.google.javascript.jscomp.CodingConvention.Bind bind14 = closureCodingConvention9.describeFunctionBind(node12, false);
        int int15 = node0.getIndexOfChild(node12);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNull(staticSourceFile4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "goog.exportSymbol" + "'", str6.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(bind14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray8 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType9 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType7, jSTypeArray8);
        boolean boolean10 = functionType9.isFunctionType();
        int int11 = functionType9.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType14, jSTypeArray15);
        boolean boolean17 = functionType16.isFunctionType();
        boolean boolean18 = functionType9.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType16);
        com.google.javascript.rhino.jstype.ObjectType objectType19 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) functionType9);
        jSTypeRegistry1.resolveTypesInScope((com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) objectType19);
        com.google.javascript.rhino.ErrorReporter errorReporter21 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry22 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter21);
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry22.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        boolean boolean26 = functionType25.isFunctionType();
        int int27 = functionType25.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        com.google.javascript.rhino.jstype.JSType jSType30 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray31 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType32 = jSTypeRegistry29.createConstructorTypeWithVarArgs(jSType30, jSTypeArray31);
        boolean boolean33 = functionType32.isFunctionType();
        boolean boolean34 = functionType25.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType32);
        com.google.javascript.rhino.ErrorReporter errorReporter35 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter35);
        com.google.javascript.rhino.jstype.JSType jSType37 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry36.createConstructorTypeWithVarArgs(jSType37, jSTypeArray38);
        boolean boolean40 = functionType39.isFunctionType();
        int int41 = functionType39.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo43 = null;
        functionType39.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo43);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair45 = functionType25.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType39);
        boolean boolean46 = functionType25.isStringValueType();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry1.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) functionType25, jSTypeArray50);
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        com.google.javascript.rhino.jstype.JSType jSType55 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType57 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType55, jSTypeArray56);
        com.google.javascript.rhino.jstype.JSType jSType58 = jSTypeRegistry1.createUnionType(jSTypeArray56);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(jSTypeArray8);
        org.junit.Assert.assertNotNull(functionType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray31);
        org.junit.Assert.assertNotNull(functionType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(typePair45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertNotNull(functionType52);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(functionType57);
        org.junit.Assert.assertNotNull(jSType58);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        boolean boolean25 = node17.isWhile();
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention26 = new com.google.javascript.jscomp.GoogleCodingConvention();
        java.lang.String str27 = googleCodingConvention26.getExportSymbolFunction();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = null;
        com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter29 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter((com.google.javascript.jscomp.CodingConvention) googleCodingConvention26, jSTypeRegistry28);
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention30 = new com.google.javascript.jscomp.ClosureCodingConvention((com.google.javascript.jscomp.CodingConvention) googleCodingConvention26);
        boolean boolean32 = closureCodingConvention30.isPrivate("function (): {330869298}");
        java.lang.String str33 = closureCodingConvention30.getAbstractMethodName();
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node39.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType44 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType47 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int48 = diagnosticType44.compareTo(diagnosticType47);
        java.lang.String[] strArray49 = null;
        com.google.javascript.jscomp.JSError jSError50 = com.google.javascript.jscomp.JSError.make("", node39, diagnosticType44, strArray49);
        boolean boolean51 = node39.isTypeOf();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node56.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType59 = node56.getJSType();
        boolean boolean60 = node56.isFromExterns();
        java.lang.String str61 = closureCodingConvention30.extractClassNameIfProvide(node39, node56);
        try {
            com.google.javascript.rhino.Node node62 = node17.removeChildAfter(node56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "goog.exportSymbol" + "'", str27.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "goog.abstractMethod" + "'", str33.equals("goog.abstractMethod"));
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(diagnosticType44);
        org.junit.Assert.assertNotNull(diagnosticType47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(jSError50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNull(jSType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {330869298}");
        com.google.javascript.jscomp.SourceFile sourceFile5 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst6 = new com.google.javascript.jscomp.JsAst(sourceFile5);
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceFile5, false);
        compilerInput8.clearAst();
        com.google.javascript.jscomp.JSModule jSModule10 = compilerInput8.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst11 = compilerInput8.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8);
        jSModule1.remove(compilerInput8);
        jSModule1.removeAll();
        java.util.List<java.lang.String> strList15 = jSModule1.getRequires();
        int int16 = jSModule1.getDepth();
        com.google.javascript.jscomp.SourceFile sourceFile20 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst21 = new com.google.javascript.jscomp.JsAst(sourceFile20);
        com.google.javascript.jscomp.CompilerInput compilerInput23 = new com.google.javascript.jscomp.CompilerInput(sourceFile20, false);
        compilerInput23.clearAst();
        com.google.javascript.jscomp.JSModule jSModule25 = compilerInput23.getModule();
        jSModule1.add(compilerInput23);
        org.junit.Assert.assertNotNull(sourceFile5);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNotNull(sourceAst11);
        org.junit.Assert.assertNotNull(strList15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(sourceFile20);
        org.junit.Assert.assertNull(jSModule25);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean2 = jSDocInfoBuilder1.recordHiddenness();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordImplementedInterface(jSTypeExpression3);
        jSDocInfoBuilder1.markAnnotation("module$function (): {330869298}", 4095, 0);
        boolean boolean9 = jSDocInfoBuilder1.recordNoCompile();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        int int6 = node4.getSideEffectFlags();
        boolean boolean7 = node4.isOr();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setCharno(0);
        boolean boolean20 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node17);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.comma(node12, node17);
        boolean boolean22 = node21.isExprResult();
        com.google.javascript.rhino.jstype.JSType jSType23 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 10, "");
        com.google.javascript.rhino.Node node27 = node21.srcref(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node32.setIsSyntheticBlock(false);
        boolean boolean35 = node32.hasOneChild();
        boolean boolean36 = node32.isEmpty();
        boolean boolean37 = node32.isOr();
        com.google.javascript.rhino.Node node38 = node27.useSourceInfoIfMissingFromForTree(node32);
        com.google.javascript.rhino.Node node39 = node4.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder41 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression43 = null;
        boolean boolean44 = jSDocInfoBuilder41.recordParameter("module$Unversioned directory", jSTypeExpression43);
        boolean boolean45 = jSDocInfoBuilder41.isPopulated();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = jSDocInfoBuilder41.build(node47);
        java.lang.String str49 = jSDocInfo48.getFileOverview();
        node4.setJSDocInfo(jSDocInfo48);
        boolean boolean51 = jSDocInfo48.isIdGenerator();
        boolean boolean52 = jSDocInfo48.hasEnumParameterType();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(jSDocInfo48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean3 = jSDocInfoBuilder1.recordDescription("./: module$");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordBaseType(jSTypeExpression4);
        boolean boolean6 = jSDocInfoBuilder1.isPopulatedWithFileOverview();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder1.recordParameter("{...}", jSTypeExpression8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        java.lang.String str2 = codeBuilder0.toString();
        java.lang.String str3 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        compilerInput6.clearAst();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput6.getAst();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node15.setCharno(0);
        boolean boolean18 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node15);
        boolean boolean19 = node15.isGetProp();
        boolean boolean21 = node15.getBooleanProp((int) (short) 10);
        java.lang.String str22 = node15.getSourceFileName();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node27.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node37 = new com.google.javascript.rhino.Node((int) '#', node15, node27, node34, 0, (int) (short) 0);
        com.google.javascript.jscomp.SourceFile sourceFile40 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "./");
        node27.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile40);
        compilerInput6.setSourceFile(sourceFile40);
        java.lang.String str44 = sourceFile40.getLine(0);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(sourceAst9);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(sourceFile40);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "./" + "'", str44.equals("./"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14);
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry15.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isFunctionType();
        int int20 = functionType18.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo22 = null;
        functionType18.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo22);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair24 = functionType4.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType18);
        boolean boolean25 = functionType18.canBeCalled();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(typePair24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType10, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = jSError12.getType();
        loggerErrorManager5.report(checkLevel6, jSError12);
        compilerOptions0.setReportUnknownTypes(checkLevel6);
        boolean boolean16 = compilerOptions0.optimizeArgumentsArray;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setCharno(0);
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node5);
        boolean boolean9 = node5.isGetProp();
        boolean boolean11 = node5.getBooleanProp((int) (short) 10);
        java.lang.String str12 = node5.getSourceFileName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '#', node5, node17, node24, 0, (int) (short) 0);
        int int28 = node5.getLength();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder29 = node5.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node34.setCharno(0);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node46.setCharno(0);
        boolean boolean49 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node46);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.IR.comma(node41, node46);
        com.google.javascript.rhino.Node node51 = node34.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.IR.pos(node34);
        java.lang.String str53 = node34.toString();
        com.google.javascript.rhino.Node node54 = node34.getParent();
        boolean boolean55 = node34.isAssignAdd();
        com.google.javascript.rhino.Node node56 = node5.clonePropsFrom(node34);
        node56.setString("NUMBER -1.0");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "OR  32" + "'", str53.equals("OR  32"));
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.jstype.FunctionType functionType31 = functionType26.getBindReturnType(44);
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(functionType31);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.Region region5 = sourceFile3.getRegion(100);
        sourceFile3.setOriginalPath("./");
        java.lang.String str8 = sourceFile3.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(region5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "./" + "'", str8.equals("./"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        int int6 = node4.getSideEffectFlags();
        boolean boolean7 = node4.isOr();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setCharno(0);
        boolean boolean20 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node17);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.comma(node12, node17);
        boolean boolean22 = node21.isExprResult();
        com.google.javascript.rhino.jstype.JSType jSType23 = node21.getJSType();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) (short) 10, "");
        com.google.javascript.rhino.Node node27 = node21.srcref(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node32.setIsSyntheticBlock(false);
        boolean boolean35 = node32.hasOneChild();
        boolean boolean36 = node32.isEmpty();
        boolean boolean37 = node32.isOr();
        com.google.javascript.rhino.Node node38 = node27.useSourceInfoIfMissingFromForTree(node32);
        com.google.javascript.rhino.Node node39 = node4.useSourceInfoIfMissingFrom(node27);
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder41 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression43 = null;
        boolean boolean44 = jSDocInfoBuilder41.recordParameter("module$Unversioned directory", jSTypeExpression43);
        boolean boolean45 = jSDocInfoBuilder41.isPopulated();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo48 = jSDocInfoBuilder41.build(node47);
        java.lang.String str49 = jSDocInfo48.getFileOverview();
        node4.setJSDocInfo(jSDocInfo48);
        boolean boolean51 = jSDocInfo48.isNoSideEffects();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSType23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(jSDocInfo48);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.setInlineFunctions(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy9);
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setConvertToDottedProperties(false);
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node10.setIsSyntheticBlock(false);
        com.google.javascript.rhino.jstype.JSType jSType13 = node10.getJSType();
        java.lang.Object obj15 = null;
        node10.putProp((int) '4', obj15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.pos(node10);
        com.google.javascript.rhino.ErrorReporter errorReporter18 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter18);
        com.google.javascript.rhino.jstype.JSType jSType20 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray21 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry19.createConstructorTypeWithVarArgs(jSType20, jSTypeArray21);
        boolean boolean23 = functionType22.isFunctionType();
        com.google.javascript.rhino.jstype.EnumType enumType24 = jSTypeRegistry1.createEnumType("Unversioned directory", node17, (com.google.javascript.rhino.jstype.JSType) functionType22);
        com.google.javascript.rhino.ErrorReporter errorReporter25 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter25);
        com.google.javascript.rhino.jstype.JSType jSType27 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray28 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType29 = jSTypeRegistry26.createConstructorTypeWithVarArgs(jSType27, jSTypeArray28);
        boolean boolean30 = functionType29.isFunctionType();
        int int31 = functionType29.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        com.google.javascript.rhino.jstype.JSType jSType34 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray35 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType36 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType34, jSTypeArray35);
        boolean boolean37 = functionType36.isFunctionType();
        boolean boolean38 = functionType29.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType36);
        boolean boolean39 = functionType29.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter40 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter40);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry41.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        boolean boolean45 = functionType44.isFunctionType();
        int int46 = functionType44.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter47 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter47);
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry48.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isFunctionType();
        boolean boolean53 = functionType44.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType51);
        boolean boolean54 = functionType44.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter55 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter55);
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry56.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        boolean boolean60 = functionType59.isFunctionType();
        int int61 = functionType59.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        com.google.javascript.rhino.jstype.JSType jSType64 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray65 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType66 = jSTypeRegistry63.createConstructorTypeWithVarArgs(jSType64, jSTypeArray65);
        boolean boolean67 = functionType66.isFunctionType();
        boolean boolean68 = functionType59.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean69 = functionType44.canTestForShallowEqualityWith((com.google.javascript.rhino.jstype.JSType) functionType66);
        boolean boolean70 = functionType44.isNumberObjectType();
        com.google.javascript.rhino.jstype.ParameterizedType parameterizedType71 = jSTypeRegistry1.createParameterizedType((com.google.javascript.rhino.jstype.ObjectType) functionType29, (com.google.javascript.rhino.jstype.JSType) functionType44);
        boolean boolean72 = parameterizedType71.isInterface();
        java.lang.String str73 = parameterizedType71.getNormalizedReferenceName();
        boolean boolean74 = parameterizedType71.isInstanceType();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(jSTypeArray21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(enumType24);
        org.junit.Assert.assertNotNull(jSTypeArray28);
        org.junit.Assert.assertNotNull(functionType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray35);
        org.junit.Assert.assertNotNull(functionType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray65);
        org.junit.Assert.assertNotNull(functionType66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(parameterizedType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.collapseVariableDeclarations;
        compilerOptions21.setInlineConstantVars(false);
        com.google.javascript.jscomp.CheckLevel checkLevel25 = compilerOptions21.reportMissingOverride;
        compilerOptions0.checkGlobalNamesLevel = checkLevel25;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + checkLevel25 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel25.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("function (): {330869298}");
        jSModule1.setDepth(47);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setCharno(0);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node16.setCharno(0);
        boolean boolean19 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node16);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.comma(node11, node16);
        com.google.javascript.rhino.Node node21 = node4.clonePropsFrom(node20);
        boolean boolean22 = node20.isNull();
        com.google.javascript.rhino.Node node23 = node20.removeFirstChild();
        boolean boolean24 = node23.isNot();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean30 = functionType26.hasInstanceType();
        boolean boolean31 = functionType26.isObject();
        com.google.javascript.rhino.jstype.FunctionType functionType32 = functionType26.getOwnerFunction();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(functionType32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        compilerInput6.clearAst();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        com.google.javascript.jscomp.SourceFile sourceFile9 = compilerInput6.getSourceFile();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler10 = null;
        compilerInput6.setCompiler(abstractCompiler10);
        try {
            compilerInput6.removeRequire("Unversioned directory");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: hi!");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber((double) (byte) -1, 52, 44);
        try {
            astValidator1.validateStatement(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        boolean boolean5 = node4.isQualifiedName();
        boolean boolean7 = node4.getBooleanProp((int) (short) 1);
        boolean boolean8 = node4.isVoid();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler3.getSourceMap();
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal6 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback5);
        org.junit.Assert.assertNull(sourceMap4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        compilerOptions0.setInlineVariables(true);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkProvides;
        org.junit.Assert.assertNull(messageBundle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node4.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node11.setIsSyntheticBlock(false);
        boolean boolean14 = node11.hasOneChild();
        boolean boolean15 = node11.isEmpty();
        node4.addChildToFront(node11);
        boolean boolean17 = node11.isScript();
        int int18 = node11.getSourcePosition();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 131104 + "'", int18 == 131104);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.isNoShadow();
        boolean boolean10 = jSDocInfo8.isDeprecated();
        boolean boolean11 = jSDocInfo8.isOverride();
        boolean boolean12 = jSDocInfo8.isConsistentIdGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("Not declared as a constructor");
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        boolean boolean7 = compilerOptions0.optimizeReturns;
        boolean boolean8 = compilerOptions0.optimizeReturns;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setDefineToDoubleLiteral("Unversioned directory", (double) 30);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.setLabelRenaming(true);
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node6.setCharno(0);
        boolean boolean9 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node6);
        boolean boolean10 = node6.isGetProp();
        boolean boolean12 = node6.getBooleanProp((int) (short) 10);
        java.lang.String str13 = node6.getSourceFileName();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node18.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node28 = new com.google.javascript.rhino.Node((int) '#', node6, node18, node25, 0, (int) (short) 0);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node38.setCharno(0);
        boolean boolean41 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node38);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.IR.comma(node33, node38);
        boolean boolean43 = node38.isTry();
        boolean boolean44 = node38.isCall();
        boolean boolean45 = node38.isBreak();
        boolean boolean46 = node38.isOr();
        node38.setCharno((int) (byte) 1);
        try {
            com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node(29, node28, node38, 39, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: second new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        int int1 = stringPosition0.getPositionOnStartLine();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.DEBUGGER_STATEMENT_PRESENT = diagnosticGroup0;
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.CompilerOptions compilerOptions22 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean23 = compilerOptions22.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        com.google.javascript.rhino.jstype.JSType jSType26 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray27 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType28 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType26, jSTypeArray27);
        boolean boolean29 = functionType28.isFunctionType();
        int int30 = functionType28.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter31 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter31);
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry32.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        boolean boolean36 = functionType35.isFunctionType();
        boolean boolean37 = functionType28.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType35);
        java.util.Set<java.lang.String> strSet38 = functionType35.getOwnPropertyNames();
        compilerOptions22.setAliasableStrings(strSet38);
        compilerOptions0.stripTypes = strSet38;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(jSTypeArray27);
        org.junit.Assert.assertNotNull(functionType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(strSet38);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray3 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType4 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType2, jSTypeArray3);
        boolean boolean5 = functionType4.isFunctionType();
        int int6 = functionType4.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        boolean boolean12 = functionType11.isFunctionType();
        boolean boolean13 = functionType4.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType11);
        boolean boolean14 = functionType4.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        boolean boolean20 = functionType19.isFunctionType();
        int int21 = functionType19.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter22 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter22);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry23.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isFunctionType();
        boolean boolean28 = functionType19.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType26);
        boolean boolean29 = functionType4.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType26);
        com.google.javascript.rhino.ErrorReporter errorReporter30 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter30);
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry31.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        boolean boolean35 = functionType34.isFunctionType();
        int int36 = functionType34.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter37 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter37);
        com.google.javascript.rhino.jstype.JSType jSType39 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray40 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType41 = jSTypeRegistry38.createConstructorTypeWithVarArgs(jSType39, jSTypeArray40);
        boolean boolean42 = functionType41.isFunctionType();
        boolean boolean43 = functionType34.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType41);
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        com.google.javascript.rhino.jstype.JSType jSType46 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType48 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType46, jSTypeArray47);
        boolean boolean49 = functionType48.isFunctionType();
        int int50 = functionType48.getMaxArguments();
        com.google.javascript.rhino.JSDocInfo jSDocInfo52 = null;
        functionType48.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo52);
        com.google.javascript.rhino.jstype.JSType.TypePair typePair54 = functionType34.getTypesUnderShallowInequality((com.google.javascript.rhino.jstype.JSType) functionType48);
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue55 = functionType26.testForEquality((com.google.javascript.rhino.jstype.JSType) functionType34);
        java.util.Set<java.lang.String> strSet56 = functionType26.getOwnPropertyNames();
        int int57 = functionType26.getMinArguments();
        org.junit.Assert.assertNotNull(jSTypeArray3);
        org.junit.Assert.assertNotNull(functionType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray40);
        org.junit.Assert.assertNotNull(functionType41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(functionType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(typePair54);
        org.junit.Assert.assertNotNull(ternaryValue55);
        org.junit.Assert.assertNotNull(strSet56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        compilerOptions0.setInlineFunctions(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        compilerOptions0.setVariableRenaming(variableRenamingPolicy9);
        compilerOptions0.removeTryCatchFinally = false;
        compilerOptions0.setConvertToDottedProperties(false);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy15 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy15 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy15.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node9.setCharno(0);
        boolean boolean12 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node9);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.comma(node4, node9);
        boolean boolean14 = node13.isExprResult();
        com.google.javascript.rhino.jstype.JSType jSType15 = node13.getJSType();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) (short) 10, "");
        com.google.javascript.rhino.Node node19 = node13.srcref(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node24.setIsSyntheticBlock(false);
        boolean boolean27 = node24.hasOneChild();
        boolean boolean28 = node24.isEmpty();
        boolean boolean29 = node24.isOr();
        com.google.javascript.rhino.Node node30 = node19.useSourceInfoIfMissingFromForTree(node24);
        com.google.javascript.rhino.Node node31 = null;
        int int32 = node19.getIndexOfChild(node31);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node38.setCharno(0);
        boolean boolean41 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node38);
        boolean boolean42 = node38.isGetProp();
        boolean boolean44 = node38.getBooleanProp((int) (short) 10);
        java.lang.String str45 = node38.getSourceFileName();
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node50.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((int) '#', node38, node50, node57, 0, (int) (short) 0);
        int int61 = node38.getLength();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder62 = node38.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node67.setCharno(0);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node79 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node79.setCharno(0);
        boolean boolean82 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node79);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.IR.comma(node74, node79);
        com.google.javascript.rhino.Node node84 = node67.clonePropsFrom(node83);
        com.google.javascript.rhino.Node node85 = com.google.javascript.rhino.IR.pos(node67);
        java.lang.String str86 = node67.toString();
        com.google.javascript.rhino.Node node87 = node67.getParent();
        boolean boolean88 = node67.isAssignAdd();
        com.google.javascript.rhino.Node node89 = node38.clonePropsFrom(node67);
        com.google.javascript.rhino.Node node90 = node38.cloneTree();
        try {
            com.google.javascript.rhino.Node node91 = com.google.javascript.rhino.IR.assign(node31, node38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jSType15);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "OR  32" + "'", str86.equals("OR  32"));
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(node90);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(false);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean4 = jSDocInfoBuilder1.recordParameter("module$Unversioned directory", jSTypeExpression3);
        boolean boolean5 = jSDocInfoBuilder1.isPopulated();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.labelName("goog.exportSymbol");
        com.google.javascript.rhino.JSDocInfo jSDocInfo8 = jSDocInfoBuilder1.build(node7);
        boolean boolean9 = jSDocInfo8.isNoShadow();
        boolean boolean10 = jSDocInfo8.isDeprecated();
        boolean boolean11 = jSDocInfo8.isNoTypeCheck();
        jSDocInfo8.addSuppression("NUMBER -1.0");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(jSDocInfo8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager2.getWarnings();
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler((com.google.javascript.jscomp.ErrorManager) loggerErrorManager2);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        int int15 = functionType13.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter16 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter16);
        com.google.javascript.rhino.jstype.JSType jSType18 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray19 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType20 = jSTypeRegistry17.createConstructorTypeWithVarArgs(jSType18, jSTypeArray19);
        boolean boolean21 = functionType20.isFunctionType();
        boolean boolean22 = functionType13.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType20);
        java.util.Set<java.lang.String> strSet23 = functionType20.getOwnPropertyNames();
        compilerOptions7.setAliasableStrings(strSet23);
        compilerOptions7.setDisambiguateProperties(true);
        try {
            com.google.javascript.jscomp.Result result27 = compiler4.compile(jSSourceFileArray5, jSSourceFileArray6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSErrorArray3);
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray19);
        org.junit.Assert.assertNotNull(functionType20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(strSet23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        int int5 = node4.getSideEffectFlags();
        boolean boolean6 = node4.isFalse();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.returnNode(node4);
        boolean boolean8 = node4.isWith();
        com.google.javascript.rhino.Node node9 = node4.cloneNode();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        com.google.javascript.rhino.jstype.JSType jSType14 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray15 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType16 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType14, jSTypeArray15);
        boolean boolean17 = functionType16.isFunctionType();
        int int18 = functionType16.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType21, jSTypeArray22);
        boolean boolean24 = functionType23.isFunctionType();
        boolean boolean25 = functionType16.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType23);
        boolean boolean26 = functionType16.isEmptyType();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        com.google.javascript.rhino.jstype.JSType jSType29 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray30 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType31 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType29, jSTypeArray30);
        boolean boolean32 = functionType31.isFunctionType();
        int int33 = functionType31.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter34 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter34);
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry35.createConstructorTypeWithVarArgs(jSType36, jSTypeArray37);
        boolean boolean39 = functionType38.isFunctionType();
        boolean boolean40 = functionType31.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType38);
        boolean boolean41 = functionType16.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType38);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { functionType38 };
        com.google.javascript.rhino.Node node43 = jSTypeRegistry11.createOptionalParameters(jSTypeArray42);
        com.google.javascript.rhino.Node node44 = node43.getLastSibling();
        com.google.javascript.rhino.Node node45 = node9.useSourceInfoIfMissingFromForTree(node44);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(jSTypeArray15);
        org.junit.Assert.assertNotNull(functionType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray30);
        org.junit.Assert.assertNotNull(functionType31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.MessageFormatter messageFormatter3 = null;
        java.util.logging.Logger logger4 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager5 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter3, logger4);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray11 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError12 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType10, strArray11);
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = jSError12.getType();
        loggerErrorManager5.report(checkLevel6, jSError12);
        compilerOptions0.setReportUnknownTypes(checkLevel6);
        compilerOptions0.setMoveFunctionDeclarations(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(jSError12);
        org.junit.Assert.assertNotNull(diagnosticType13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        compilerOptions0.instrumentationTemplate = "./: module$";
        compilerOptions0.printInputDelimiter = false;
        org.junit.Assert.assertNull(messageBundle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        java.lang.String str8 = compilerInput6.getLine(1);
        java.lang.String str9 = compilerInput6.getName();
        com.google.javascript.jscomp.SourceFile sourceFile13 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst14 = new com.google.javascript.jscomp.JsAst(sourceFile13);
        com.google.javascript.rhino.InputId inputId15 = jsAst14.getInputId();
        com.google.javascript.jscomp.CompilerInput compilerInput17 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6, inputId15, false);
        com.google.javascript.jscomp.SourceAst sourceAst18 = compilerInput17.getSourceAst();
        try {
            com.google.javascript.jscomp.Region region20 = compilerInput17.getRegion(0);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(sourceFile13);
        org.junit.Assert.assertNotNull(inputId15);
        org.junit.Assert.assertNotNull(sourceAst18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2);
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry3.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isFunctionType();
        int int8 = functionType6.getMaxArguments();
        com.google.javascript.rhino.ErrorReporter errorReporter9 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter9);
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry10.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isFunctionType();
        boolean boolean15 = functionType6.isSubtype((com.google.javascript.rhino.jstype.JSType) functionType13);
        java.util.Set<java.lang.String> strSet16 = functionType13.getOwnPropertyNames();
        compilerOptions0.setAliasableStrings(strSet16);
        compilerOptions0.setAliasableGlobals("Unversioned directory");
        byte[] byteArray20 = compilerOptions0.inputVariableMapSerialized;
        boolean boolean21 = compilerOptions0.extractPrototypeMemberDeclarations;
        boolean boolean22 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.MessageFormatter messageFormatter23 = null;
        java.util.logging.Logger logger24 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager25 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter23, logger24);
        double double26 = loggerErrorManager25.getTypedPercent();
        com.google.javascript.jscomp.MessageFormatter messageFormatter27 = null;
        java.util.logging.Logger logger28 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager29 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter27, logger28);
        com.google.javascript.jscomp.CheckLevel checkLevel30 = com.google.javascript.jscomp.CheckLevel.WARNING;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray35 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError36 = com.google.javascript.jscomp.JSError.make("OR  32", 44, (int) (short) 10, diagnosticType34, strArray35);
        com.google.javascript.jscomp.DiagnosticType diagnosticType37 = jSError36.getType();
        loggerErrorManager29.report(checkLevel30, jSError36);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node44.setIsSyntheticBlock(false);
        com.google.javascript.jscomp.DiagnosticType diagnosticType49 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        com.google.javascript.jscomp.DiagnosticType diagnosticType52 = com.google.javascript.jscomp.DiagnosticType.warning("./", "module$");
        int int53 = diagnosticType49.compareTo(diagnosticType52);
        java.lang.String[] strArray54 = null;
        com.google.javascript.jscomp.JSError jSError55 = com.google.javascript.jscomp.JSError.make("", node44, diagnosticType49, strArray54);
        com.google.javascript.jscomp.DiagnosticType diagnosticType56 = jSError55.getType();
        loggerErrorManager25.report(checkLevel30, jSError55);
        compilerOptions0.setCheckGlobalThisLevel(checkLevel30);
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy59 = compilerOptions0.anonymousFunctionNaming;
        java.lang.String str60 = compilerOptions0.renamePrefix;
        com.google.javascript.jscomp.DiagnosticType diagnosticType61 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel62 = com.google.javascript.jscomp.CheckLevel.WARNING;
        diagnosticType61.level = checkLevel62;
        com.google.javascript.jscomp.CheckLevel checkLevel64 = diagnosticType61.level;
        compilerOptions0.setCheckProvides(checkLevel64);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(byteArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + checkLevel30 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel30.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertNotNull(strArray35);
        org.junit.Assert.assertNotNull(jSError36);
        org.junit.Assert.assertNotNull(diagnosticType37);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(diagnosticType49);
        org.junit.Assert.assertNotNull(diagnosticType52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(jSError55);
        org.junit.Assert.assertNotNull(diagnosticType56);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy59 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy59.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertNotNull(diagnosticType61);
        org.junit.Assert.assertTrue("'" + checkLevel62 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel62.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
        org.junit.Assert.assertTrue("'" + checkLevel64 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel64.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "", "");
        com.google.javascript.jscomp.JsAst jsAst4 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, false);
        compilerInput6.clearAst();
        com.google.javascript.jscomp.JSModule jSModule8 = compilerInput6.getModule();
        com.google.javascript.jscomp.SourceFile sourceFile9 = compilerInput6.getSourceFile();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler10 = null;
        compilerInput6.setCompiler(abstractCompiler10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput6);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(sourceFile9);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setOutputJsStringUsage(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.MessageBundle messageBundle5 = compilerOptions0.messageBundle;
        boolean boolean6 = compilerOptions0.reserveRawExports;
        compilerOptions0.instrumentationTemplate = "./: module$";
        com.google.javascript.jscomp.SourceMap.LocationMapping[] locationMappingArray9 = new com.google.javascript.jscomp.SourceMap.LocationMapping[] {};
        java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList10 = new java.util.ArrayList<com.google.javascript.jscomp.SourceMap.LocationMapping>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.SourceMap.LocationMapping>) locationMappingList10, locationMappingArray9);
        compilerOptions0.sourceMapLocationMappings = locationMappingList10;
        org.junit.Assert.assertNull(messageBundle5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(locationMappingArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression2 = null;
        boolean boolean3 = jSDocInfoBuilder1.recordThrowType(jSTypeExpression2);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = null;
        boolean boolean6 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression4, "2019/06/10 13:15");
        boolean boolean7 = jSDocInfoBuilder1.recordIdGenerator();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression8 = null;
        boolean boolean9 = jSDocInfoBuilder1.recordType(jSTypeExpression8);
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression10 = null;
        boolean boolean11 = jSDocInfoBuilder1.recordReturnType(jSTypeExpression10);
        boolean boolean13 = jSDocInfoBuilder1.recordVersion("./: module$");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        com.google.javascript.rhino.JSDocInfoBuilder jSDocInfoBuilder1 = new com.google.javascript.rhino.JSDocInfoBuilder(true);
        boolean boolean2 = jSDocInfoBuilder1.recordHiddenness();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression3 = null;
        boolean boolean5 = jSDocInfoBuilder1.recordThrowDescription(jSTypeExpression3, "./: module$");
        boolean boolean7 = jSDocInfoBuilder1.hasParameter("./: module$");
        jSDocInfoBuilder1.recordOriginalCommentString("Unversioned directory");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.collapseVariableDeclarations;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setInlineGetters(false);
        compilerOptions0.setGenerateExports(false);
        boolean boolean7 = compilerOptions0.checkSymbols;
        compilerOptions0.closurePass = true;
        boolean boolean10 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node5.setCharno(0);
        boolean boolean8 = com.google.javascript.jscomp.NodeUtil.isRelationalOperation(node5);
        boolean boolean9 = node5.isGetProp();
        boolean boolean11 = node5.getBooleanProp((int) (short) 10);
        java.lang.String str12 = node5.getSourceFileName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        node17.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) (short) 100, "", (int) ' ', (int) ' ');
        com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node((int) '#', node5, node17, node24, 0, (int) (short) 0);
        com.google.javascript.jscomp.SourceFile sourceFile30 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "./");
        node17.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile30);
        com.google.javascript.rhino.Node node33 = node17.getAncestor((int) (short) 100);
        try {
            int int34 = node17.getSourceOffset();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Expected line number between 1 and 1\nActual: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(sourceFile30);
        org.junit.Assert.assertNull(node33);
    }
}

