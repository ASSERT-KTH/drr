import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        com.google.javascript.rhino.jstype.ObjectType objectType0 = null;
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType2 = com.google.javascript.rhino.jstype.FunctionType.getTopDefiningInterface(objectType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        try {
            com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter semanticReverseAbstractInterpreter2 = new com.google.javascript.jscomp.type.SemanticReverseAbstractInterpreter(codingConvention0, jSTypeRegistry1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.neg(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = null;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray2 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = new com.google.javascript.jscomp.DiagnosticGroup("hi!", diagnosticGroupArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroupArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean11 = node10.isEmpty();
        com.google.javascript.rhino.Node node12 = node9.copyInformationFromForTree(node10);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.forIn(node3, node8, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.paramList(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean8 = node7.isRegExp();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.add(node0, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Node.INFERRED_FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean4 = node3.isEmpty();
        com.google.javascript.rhino.Node node5 = node2.copyInformationFromForTree(node3);
        try {
            com.google.javascript.rhino.Node node6 = node0.removeChildAfter(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        com.google.javascript.jscomp.DiagnosticType[] diagnosticTypeArray1 = new com.google.javascript.jscomp.DiagnosticType[] { diagnosticType0 };
        try {
            com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = new com.google.javascript.jscomp.DiagnosticGroup(diagnosticTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticTypeArray1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INTERNET_EXPLORER_CHECKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isInc();
        try {
            node8.setSideEffectFlags((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got CONTINUE");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.jscomp.SourceFile sourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceFile0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("InputId: ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(InputId: )" + "'", str1.equals("(InputId: )"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isRegExp();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean9 = node8.isEmpty();
        com.google.javascript.rhino.Node node10 = node7.copyInformationFromForTree(node8);
        boolean boolean11 = node10.isLocalResultCall();
        node5.addChildrenToFront(node10);
        boolean boolean13 = node10.isInc();
        try {
            com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.or(node0, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("", "(InputId: )");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: a source must have a name");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        long long0 = com.google.javascript.rhino.InputId.serialVersionUID;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1L + "'", long0 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isInc();
        boolean boolean12 = node8.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.pos(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.V1;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean11 = node10.isRegExp();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean14 = node13.isEmpty();
        com.google.javascript.rhino.Node node15 = node12.copyInformationFromForTree(node13);
        boolean boolean16 = node15.isLocalResultCall();
        node10.addChildrenToFront(node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.add(node5, node10);
        try {
            com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.caseNode(node1, node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.rhino.InputId inputId1 = new com.google.javascript.rhino.InputId("");
        java.lang.String str2 = inputId1.toString();
        boolean boolean4 = inputId1.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "InputId: " + "'", str2.equals("InputId: "));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray3 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray3);
        boolean boolean5 = diagnosticGroup1.matches(jSError4);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup6 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray8 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError9 = com.google.javascript.jscomp.JSError.make(diagnosticType7, strArray8);
        boolean boolean10 = diagnosticGroup6.matches(jSError9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup11 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType12 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray13 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError14 = com.google.javascript.jscomp.JSError.make(diagnosticType12, strArray13);
        boolean boolean15 = diagnosticGroup11.matches(jSError14);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup16 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray18 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError19 = com.google.javascript.jscomp.JSError.make(diagnosticType17, strArray18);
        boolean boolean20 = diagnosticGroup16.matches(jSError19);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray23 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError24 = com.google.javascript.jscomp.JSError.make(diagnosticType22, strArray23);
        boolean boolean25 = diagnosticGroup21.matches(jSError24);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup26 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray27 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup6, diagnosticGroup11, diagnosticGroup16, diagnosticGroup21, diagnosticGroup26 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = new com.google.javascript.jscomp.DiagnosticGroup("hi!", diagnosticGroupArray27);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(jSError4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup6);
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(jSError9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup11);
        org.junit.Assert.assertNotNull(diagnosticType12);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(jSError14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup16);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(jSError19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertNotNull(diagnosticType22);
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertNotNull(jSError24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup26);
        org.junit.Assert.assertNotNull(diagnosticGroupArray27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType1 = com.google.javascript.rhino.jstype.ObjectType.cast(jSType0);
        org.junit.Assert.assertNull(objectType1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean11 = node10.isRegExp();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean14 = node13.isEmpty();
        com.google.javascript.rhino.Node node15 = node12.copyInformationFromForTree(node13);
        boolean boolean16 = node15.isLocalResultCall();
        node10.addChildrenToFront(node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.add(node5, node10);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str23 = node18.checkTreeEquals(node22);
        try {
            com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.caseNode(node3, node22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str23.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.throwNode(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot5);
        boolean boolean7 = node3.isCast();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType10 = node9.getJSType();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean15 = node14.isRegExp();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean18 = node17.isEmpty();
        com.google.javascript.rhino.Node node19 = node16.copyInformationFromForTree(node17);
        boolean boolean20 = node19.isLocalResultCall();
        node14.addChildrenToFront(node19);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.add(node9, node14);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str27 = node22.checkTreeEquals(node26);
        try {
            com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.propdef(node3, node26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jSType10);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str27.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        fileLevelJsDocBuilder1.append("(InputId: )");
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.cast(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType1, strArray2);
        boolean boolean4 = diagnosticGroup0.matches(jSError3);
        int int5 = jSError3.getNodeSourceOffset();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        try {
            java.lang.String str8 = jSError3.format(checkLevel6, messageFormatter7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.var(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isRegExp();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean9 = node8.isEmpty();
        com.google.javascript.rhino.Node node10 = node7.copyInformationFromForTree(node8);
        boolean boolean11 = node10.isLocalResultCall();
        node5.addChildrenToFront(node10);
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.caseNode(node0, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        boolean boolean5 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType3 = node2.getJSType();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean8 = node7.isRegExp();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean11 = node10.isEmpty();
        com.google.javascript.rhino.Node node12 = node9.copyInformationFromForTree(node10);
        boolean boolean13 = node12.isLocalResultCall();
        node7.addChildrenToFront(node12);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.add(node2, node7);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str20 = node15.checkTreeEquals(node19);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean23 = node22.isEmpty();
        com.google.javascript.rhino.Node node24 = node21.copyInformationFromForTree(node22);
        boolean boolean25 = node24.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot26 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult27 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node24, astRoot26);
        boolean boolean28 = node24.isCast();
        try {
            com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.hook(node0, node19, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str20.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        node0.putIntProp((int) (byte) 1, 38);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean9 = node8.isRegExp();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean12 = node11.isEmpty();
        com.google.javascript.rhino.Node node13 = node10.copyInformationFromForTree(node11);
        boolean boolean14 = node13.isLocalResultCall();
        node8.addChildrenToFront(node13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.add(node3, node8);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType19 = node18.getJSType();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean24 = node23.isRegExp();
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean27 = node26.isEmpty();
        com.google.javascript.rhino.Node node28 = node25.copyInformationFromForTree(node26);
        boolean boolean29 = node28.isLocalResultCall();
        node23.addChildrenToFront(node28);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.add(node18, node23);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.IR.breakNode();
        node36.setType((int) (byte) 10);
        com.google.javascript.rhino.Node node40 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType41 = node40.getJSType();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean46 = node45.isRegExp();
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean49 = node48.isEmpty();
        com.google.javascript.rhino.Node node50 = node47.copyInformationFromForTree(node48);
        boolean boolean51 = node50.isLocalResultCall();
        node45.addChildrenToFront(node50);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.add(node40, node45);
        boolean boolean54 = node53.isTry();
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean56 = node55.isCase();
        com.google.javascript.rhino.Node[] nodeArray57 = new com.google.javascript.rhino.Node[] { node16, node31, node35, node36, node53, node55 };
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList58 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean59 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList58, nodeArray57);
        com.google.javascript.jscomp.NodeTraversal.Callback callback60 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverseRoots((com.google.javascript.jscomp.AbstractCompiler) compiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList58, callback60);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(jSType19);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNull(jSType41);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(nodeArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.setAliasAllStrings(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TYPE_INVALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags15 = null;
        try {
            node14.setSideEffectFlags(sideEffectFlags15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = null;
        try {
            jSModule1.addFirst(compilerInput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        compilerOptions0.syntheticBlockEndMarker = "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n";
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isDo();
        try {
            boolean boolean7 = googleCodingConvention1.isInlinableFunction(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            compiler1.report(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isParamList();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        try {
            com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.and(node3, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.ifNode(node0, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        java.lang.String str4 = compilerOptions0.renamePrefixNamespace;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        node0.setType((int) (byte) 10);
        try {
            node0.setDouble((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.CHECK));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        com.google.javascript.jscomp.CompilerOptions.Reach reach6 = null;
        try {
            compilerOptions0.setRemoveUnusedVariables(reach6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean9 = node8.isRegExp();
        node8.setDouble((double) (-1.0f));
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.var(node3, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.renamePrefix = "(InputId: )";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        boolean boolean2 = node0.isAssignAdd();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.nullNode();
        node5.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean12 = node11.isDo();
        com.google.javascript.rhino.InputId inputId14 = new com.google.javascript.rhino.InputId("");
        node11.setInputId(inputId14);
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(10);
        boolean boolean18 = node17.isVar();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean20 = node19.isEmpty();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean22 = node21.isContinue();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean25 = node24.isEmpty();
        com.google.javascript.rhino.Node node26 = node23.copyInformationFromForTree(node24);
        boolean boolean27 = node26.isLocalResultCall();
        int int28 = node26.getSourcePosition();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean33 = node32.isRegExp();
        com.google.javascript.rhino.Node node35 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType36 = node35.getJSType();
        boolean boolean37 = node32.isEquivalentToShallow(node35);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.falseNode();
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean43 = node42.isRegExp();
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean46 = node45.isEmpty();
        com.google.javascript.rhino.Node node47 = node44.copyInformationFromForTree(node45);
        boolean boolean48 = node47.isLocalResultCall();
        node42.addChildrenToFront(node47);
        boolean boolean50 = node47.isInc();
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder52 = node51.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean54 = node53.isCase();
        boolean boolean55 = node53.isIn();
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean58 = node57.isEmpty();
        com.google.javascript.rhino.Node node59 = node56.copyInformationFromForTree(node57);
        node57.setLength(0);
        com.google.javascript.rhino.Node[] nodeArray62 = new com.google.javascript.rhino.Node[] { node3, node5, node11, node17, node19, node21, node26, node35, node38, node47, node51, node53, node57 };
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList63 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList63, nodeArray62);
        try {
            com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.IR.paramList((java.util.List<com.google.javascript.rhino.Node>) nodeList63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(jSType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(nodeArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot5);
        com.google.javascript.rhino.head.ast.AstRoot astRoot7 = parseResult6.oldAst;
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(astRoot7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        try {
            java.lang.String str2 = com.google.javascript.rhino.SimpleErrorReporter.getMessage1("(InputId: )", (java.lang.Object) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property (InputId: )");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.exprResult(node3);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        try {
            java.util.Collection<java.lang.String> strCollection2 = googleCodingConvention1.getIndirectlyDeclaredProperties();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean4 = node3.isEmpty();
        com.google.javascript.rhino.Node node5 = node2.copyInformationFromForTree(node3);
        try {
            com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(55, node1, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        try {
            boolean boolean3 = googleCodingConvention1.isSuperClassReference("(InputId: )");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.hasChildren();
        com.google.javascript.rhino.InputId inputId3 = node0.getInputId();
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.neg(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(inputId3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_VOID));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.optimizeParameters = false;
        compilerOptions0.setIdGeneratorsMap("InputId: ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        boolean boolean9 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node0.setJSType(jSType7);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        boolean boolean11 = node9.isGetElem();
        boolean boolean12 = node9.isParamList();
        try {
            com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.eq(node0, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.JSModule[] jSModuleArray8 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList9 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList9, jSModuleArray8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList9);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(jSModuleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(jSModuleArray11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setManageClosureDependencies(true);
        com.google.javascript.jscomp.DependencyOptions dependencyOptions13 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        boolean boolean11 = compilerOptions0.lineBreak;
        compilerOptions0.crossModuleMethodMotion = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isVar();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node1.useSourceInfoIfMissingFromForTree(node3);
        try {
            node5.setQuotedString();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: not a StringNode");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isAnd();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node3.isVar();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node7 = node3.useSourceInfoIfMissingFromForTree(node5);
        com.google.javascript.rhino.Node node8 = null;
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.hook(node0, node7, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertNotNull(node7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.nullNode();
        node0.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean4 = node3.isDebugger();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        boolean boolean7 = node5.hasChildren();
        com.google.javascript.rhino.InputId inputId8 = node5.getInputId();
        com.google.javascript.rhino.Node node9 = node3.copyInformationFromForTree(node5);
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.regexp(node0, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(inputId8);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        int int5 = node3.getSourcePosition();
        try {
            node3.setDouble((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: CONTINUE is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        try {
            com.google.javascript.jscomp.SymbolTable symbolTable4 = compiler1.buildKnownSymbolTable();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.name("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.getprop(node3, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = com.google.javascript.rhino.Node.CHANGE_TIME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        boolean boolean5 = googleCodingConvention1.isValidEnumKey("hi!");
        try {
            java.lang.String str6 = googleCodingConvention1.getExportPropertyFunction();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str4 = compilerInput3.getName();
        java.lang.String str5 = compilerInput3.getName();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str4.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str5.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node6 = null;
        try {
            node3.addChildToFront(node6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        compilerOptions0.devirtualizePrototypeMethods = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        compilerOptions0.setAliasAllStrings(true);
        boolean boolean6 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.returnNode(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        boolean boolean4 = node3.isVar();
        node0.addChildrenToBack(node3);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean10 = node9.isRegExp();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean13 = node12.isEmpty();
        com.google.javascript.rhino.Node node14 = node11.copyInformationFromForTree(node12);
        boolean boolean15 = node14.isLocalResultCall();
        node9.addChildrenToFront(node14);
        try {
            node3.addChildrenToFront(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isQualifiedName();
        boolean boolean7 = node1.isAssign();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean9 = node8.isAnd();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean14 = node13.isRegExp();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean17 = node16.isEmpty();
        com.google.javascript.rhino.Node node18 = node15.copyInformationFromForTree(node16);
        boolean boolean19 = node18.isLocalResultCall();
        node13.addChildrenToFront(node18);
        com.google.javascript.rhino.head.ast.AstRoot astRoot21 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult22 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node18, astRoot21);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean25 = node24.isEmpty();
        com.google.javascript.rhino.Node node26 = node23.copyInformationFromForTree(node24);
        com.google.javascript.rhino.Node node27 = node18.useSourceInfoFrom(node24);
        try {
            com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.IR.tryCatchFinally(node1, node8, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_NAMES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.PassConfig passConfig3 = null;
        try {
            compiler1.setPassConfig(passConfig3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str19 = node14.checkTreeEquals(node18);
        boolean boolean20 = node18.isDelProp();
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str19.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.breakNode();
        node2.setType((int) (byte) 10);
        java.util.Map<java.lang.String, java.lang.String> strMap5 = null;
        try {
            googleCodingConvention1.checkForCallingConventionDefiningCalls(node2, strMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoFrom(node14);
        try {
            double double18 = node17.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: CONTINUE is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setCollapseObjectLiterals(true);
        java.lang.String str13 = compilerOptions0.sourceMapOutputPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler8 = compilerOptions0.getAliasTransformationHandler();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(aliasTransformationHandler8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.setMessageBundle(messageBundle9);
        com.google.javascript.jscomp.VariableMap variableMap11 = null;
        compilerOptions0.setReplaceStringsInputMap(variableMap11);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        loggerErrorManager9.generateReport();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        com.google.javascript.jscomp.CompilerOptions.Reach reach11 = null;
        try {
            compilerOptions0.setInlineFunctions(reach11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean8 = node7.isDo();
        com.google.javascript.rhino.InputId inputId10 = new com.google.javascript.rhino.InputId("");
        node7.setInputId(inputId10);
        boolean boolean13 = node7.getBooleanProp(0);
        try {
            boolean boolean14 = googleCodingConvention1.isVarArgsParameter(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: NUMBER 100.0 97 [input_id: InputId: ] is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.devirtualizePrototypeMethods = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = loggerErrorManager9.getWarnings();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withCharset(charset1);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder2.withCharset(charset3);
        java.io.InputStream inputStream6 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile7 = builder2.buildFromInputStream("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", inputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder2);
        org.junit.Assert.assertNotNull(builder4);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        compilerOptions0.checkRequires = checkLevel3;
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean3 = node2.isDebugger();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node4.getJsDocBuilderForNode();
        boolean boolean6 = node4.hasChildren();
        com.google.javascript.rhino.InputId inputId7 = node4.getInputId();
        com.google.javascript.rhino.Node node8 = node2.copyInformationFromForTree(node4);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        node2.setJSType(jSType9);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean15 = node14.isRegExp();
        com.google.javascript.rhino.Node node17 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType18 = node17.getJSType();
        boolean boolean19 = node14.isEquivalentToShallow(node17);
        boolean boolean20 = node2.isEquivalentToShallow(node17);
        try {
            boolean boolean21 = googleCodingConvention1.isInlinableFunction(node17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(inputId7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(jSType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.util.Collection<com.google.javascript.jscomp.JSModule> jSModuleCollection0 = null;
        try {
            com.google.javascript.jscomp.JSModule[] jSModuleArray1 = com.google.javascript.jscomp.JSModule.sortJsModules(jSModuleCollection0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        sourceFile3.setOriginalPath("hi!");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean5 = node4.isRegExp();
        boolean boolean6 = node4.isArrayLit();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean11 = node10.isRegExp();
        boolean boolean12 = node10.isParamList();
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean17 = node16.isRegExp();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean20 = node19.isEmpty();
        com.google.javascript.rhino.Node node21 = node18.copyInformationFromForTree(node19);
        boolean boolean22 = node21.isLocalResultCall();
        node16.addChildrenToFront(node21);
        com.google.javascript.rhino.head.ast.AstRoot astRoot24 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult25 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node21, astRoot24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean27 = node26.isCase();
        boolean boolean28 = node26.isIn();
        boolean boolean29 = node26.isVarArgs();
        node26.setChangeTime((int) '#');
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean33 = node32.isEmpty();
        boolean boolean34 = node32.isOptionalArg();
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean36 = node35.isDebugger();
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder38 = node37.getJsDocBuilderForNode();
        boolean boolean39 = node37.hasChildren();
        com.google.javascript.rhino.InputId inputId40 = node37.getInputId();
        com.google.javascript.rhino.Node node41 = node35.copyInformationFromForTree(node37);
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        node35.setJSType(jSType42);
        com.google.javascript.rhino.Node[] nodeArray44 = new com.google.javascript.rhino.Node[] { node4, node10, node21, node26, node32, node35 };
        try {
            com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node(56, nodeArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(inputId40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(nodeArray44);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        boolean boolean5 = googleCodingConvention1.isValidEnumKey("hi!");
        try {
            java.lang.String str6 = googleCodingConvention1.getGlobalObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setUnaliasableGlobals("(InputId: )");
        compilerOptions0.setMoveFunctionDeclarations(true);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            com.google.javascript.jscomp.Region region5 = compiler1.getSourceRegion("(InputId: )", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isRegExp();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean9 = node8.isEmpty();
        com.google.javascript.rhino.Node node10 = node7.copyInformationFromForTree(node8);
        boolean boolean11 = node10.isLocalResultCall();
        node5.addChildrenToFront(node10);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean14 = node13.isEmpty();
        boolean boolean15 = node13.isGetElem();
        boolean boolean16 = node13.isParamList();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable17 = node13.children();
        com.google.javascript.rhino.Node node18 = null;
        try {
            com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node(10, node1, node10, node13, node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(nodeIterable17);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        com.google.javascript.jscomp.CompilerOptions.Reach reach0 = com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY;
        org.junit.Assert.assertTrue("'" + reach0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY + "'", reach0.equals(com.google.javascript.jscomp.CompilerOptions.Reach.LOCAL_ONLY));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.jscomp.AstValidator.ViolationHandler violationHandler0 = null;
        com.google.javascript.jscomp.AstValidator astValidator1 = new com.google.javascript.jscomp.AstValidator(violationHandler0);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.nullNode();
        node2.setIsSyntheticBlock(false);
        try {
            astValidator1.validateCodeRoot(node2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoFrom(node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean20 = node19.isEmpty();
        com.google.javascript.rhino.Node node21 = node18.copyInformationFromForTree(node19);
        node19.setLength(0);
        boolean boolean24 = node19.isCall();
        boolean boolean25 = node19.isSwitch();
        try {
            com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.regexp(node8, node19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.SourceFile sourceFile1 = new com.google.javascript.jscomp.SourceFile("hi!");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode4 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray8 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        com.google.javascript.jscomp.parsing.Config config11 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode4, false, (java.util.Set<java.lang.String>) strSet9);
        com.google.javascript.rhino.head.ErrorReporter errorReporter12 = null;
        java.util.logging.Logger logger13 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult14 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile1, "InputId: ", config11, errorReporter12, logger13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + languageMode4 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode4.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(config11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel9;
        java.lang.String str11 = compilerOptions0.locale;
        boolean boolean12 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = com.google.javascript.rhino.Node.STATIC_SOURCE_FILE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isCase();
        boolean boolean2 = node0.isIn();
        boolean boolean3 = node0.isWith();
        com.google.javascript.rhino.jstype.JSType jSType4 = node0.getJSType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSType4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        compilerOptions0.disambiguateProperties = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy11);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode13 = null;
        compilerOptions0.setTracerMode(tracerMode13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.setDisambiguateProperties(false);
        compilerOptions0.setClosurePass(true);
        boolean boolean10 = compilerOptions0.optimizeParameters;
        compilerOptions0.setSummaryDetailLevel((-1));
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode1 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.fromString("(InputId: )");
        org.junit.Assert.assertNull(languageMode1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        java.util.Set<java.lang.String> strSet11 = objectType10.getOwnPropertyNames();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType12 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType5, objectType10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.GLOBAL_THIS;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable4 = diagnosticGroup3.getTypes();
        try {
            boolean boolean5 = diagnosticGroupWarningsGuard2.disables(diagnosticGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISPLACED_TYPE_ANNOTATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.resetWarningsGuard();
        compilerOptions0.setCoalesceVariableNames(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setSyntheticBlockStartMarker("InputId: ");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP;
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.STRIP));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isAnd();
        try {
            int int3 = node0.getExistingIntProp(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: missing prop: 2");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap15 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node3.isNumber();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.Node node15 = null;
        int int16 = node1.getIndexOfChild(node15);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean18 = node17.isDebugger();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder20 = node19.getJsDocBuilderForNode();
        boolean boolean21 = node19.hasChildren();
        com.google.javascript.rhino.InputId inputId22 = node19.getInputId();
        com.google.javascript.rhino.Node node23 = node17.copyInformationFromForTree(node19);
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        node17.setJSType(jSType24);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean27 = node26.isContinue();
        boolean boolean28 = node26.isNoSideEffectsCall();
        try {
            com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.tryCatchFinally(node15, node17, node26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(inputId22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType1, strArray2);
        try {
            com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap0 = null;
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean5 = node4.isRegExp();
        boolean boolean6 = node4.isParamList();
        try {
            com.google.javascript.jscomp.NodeUtil.verifyScopeChanges(nodeMap0, node4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node0.setJSType(jSType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean13 = node12.isRegExp();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        boolean boolean17 = node12.isEquivalentToShallow(node15);
        boolean boolean18 = node0.isEquivalentToShallow(node15);
        com.google.javascript.rhino.Node node19 = null;
        try {
            com.google.javascript.rhino.Node node20 = node15.useSourceInfoFrom(node19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isCall();
        int int7 = node1.getType();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "InputId: ", 47, (int) '#');
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean9 = node8.isRegExp();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean12 = node11.isEmpty();
        com.google.javascript.rhino.Node node13 = node10.copyInformationFromForTree(node11);
        boolean boolean14 = node13.isLocalResultCall();
        node8.addChildrenToFront(node13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean17 = node16.isNull();
        try {
            com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.ifNode(node4, node13, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode0 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.InputId inputId6 = new com.google.javascript.rhino.InputId("");
        node3.setInputId(inputId6);
        boolean boolean9 = node3.getBooleanProp(0);
        boolean boolean10 = node3.isVar();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        boolean boolean7 = node6.isSyntheticBlock();
        node6.putBooleanProp(55, false);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isParamList();
        boolean boolean6 = node3.isObjectLit();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.aliasableStrings;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.jstype.ObjectType objectType2 = null;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        boolean boolean9 = objectType7.canBeCalled();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter10 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter10, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType17.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter24 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        java.util.Set<java.lang.String> strSet34 = objectType33.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSTypeRegistry48.getNativeObjectType(jSTypeNative49);
        com.google.javascript.rhino.jstype.JSType jSType51 = objectType50.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] { objectType23, objectType28, objectType33, objectType39, objectType45, jSType51 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType53 = jSTypeRegistry12.createTemplatizedType(objectType17, jSTypeArray52);
        com.google.javascript.rhino.jstype.FunctionType functionType54 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType55 = null;
        try {
            googleCodingConvention1.applyDelegateRelationship(objectType2, objectType7, objectType17, functionType54, functionType55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(strSet34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(templatizedType53);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.computeFunctionSideEffects = false;
        boolean boolean5 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        com.google.javascript.rhino.jstype.FunctionType functionType4 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType5 = null;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        try {
            googleCodingConvention1.applySingletonGetter(functionType4, functionType5, objectType10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.setOutputCharset("(InputId: )");
        compilerOptions0.setAliasExternals(false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = parseResult12.oldAst;
        com.google.javascript.rhino.head.ast.AstRoot astRoot14 = parseResult12.oldAst;
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(astRoot13);
        org.junit.Assert.assertNull(astRoot14);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.checkControlStructures = true;
        compilerOptions0.setDefineToBooleanLiteral("InputId: ", false);
        compilerOptions0.optimizeReturns = true;
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter19 = compiler1.getReverseAbstractInterpreter();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter19);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        try {
            java.lang.String[] strArray4 = compiler1.toSourceArray();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 'a');
        compilerOptions0.optimizeArgumentsArray = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        int int4 = node0.getSourceOffset();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType4 = node3.getJSType();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean9 = node8.isRegExp();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean12 = node11.isEmpty();
        com.google.javascript.rhino.Node node13 = node10.copyInformationFromForTree(node11);
        boolean boolean14 = node13.isLocalResultCall();
        node8.addChildrenToFront(node13);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.add(node3, node8);
        try {
            java.util.Map<com.google.javascript.rhino.Node, com.google.javascript.rhino.Node> nodeMap17 = com.google.javascript.jscomp.NodeUtil.mapMainToClone(node0, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        try {
            boolean boolean5 = com.google.javascript.jscomp.NodeUtil.isLValue(node3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        com.google.javascript.jscomp.ErrorFormat errorFormat9 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat9;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(errorFormat9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.Node node0 = null;
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean2 = node1.isCase();
        boolean boolean3 = node1.isIn();
        boolean boolean4 = node1.isWith();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean9 = node8.isDo();
        com.google.javascript.rhino.InputId inputId11 = new com.google.javascript.rhino.InputId("");
        node8.setInputId(inputId11);
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult14 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot13);
        try {
            com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.ifNode(node0, node1, node8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy11);
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean8 = node7.isRegExp();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean11 = node10.isEmpty();
        com.google.javascript.rhino.Node node12 = node9.copyInformationFromForTree(node10);
        boolean boolean13 = node12.isLocalResultCall();
        node7.addChildrenToFront(node12);
        java.util.Map<java.lang.String, java.lang.String> strMap15 = null;
        try {
            googleCodingConvention1.checkForCallingConventionDefiningCalls(node12, strMap15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.setMessageBundle(messageBundle9);
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = compilerOptions0.anonymousFunctionNaming;
        java.util.Set<java.lang.String> strSet7 = compilerOptions0.aliasableStrings;
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.aliasExternals = false;
        compilerOptions0.setConvertToDottedProperties(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler1.getSourceMap();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean6 = node5.isContinue();
        boolean boolean7 = node5.isNoSideEffectsCall();
        com.google.javascript.jscomp.NodeTraversal.Callback callback8 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node5, callback8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        compilerOptions0.setRuntimeTypeCheckLogFunction("(InputId: )");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        compilerOptions0.setAnonymousFunctionNaming(anonymousFunctionNamingPolicy6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.jqueryPass = false;
        boolean boolean8 = compilerOptions0.jqueryPass;
        boolean boolean9 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        simpleErrorReporter0.warning("", "(InputId: )", 48, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        try {
            double double4 = node3.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: CONTINUE is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.jscomp.JSModule jSModule4 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile6 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str7 = sourceFile6.getCode();
        jSModule4.addFirst(sourceFile6);
        boolean boolean9 = sourceFile6.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(sourceFile6, true);
        boolean boolean12 = sourceFile6.isExtern();
        try {
            com.google.javascript.rhino.Node node13 = compiler1.parse(sourceFile6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        java.util.Map<java.lang.String, java.lang.Object> strMap11 = null;
        compilerOptions0.setTweakReplacements(strMap11);
        boolean boolean13 = compilerOptions0.optimizeReturns;
        compilerOptions0.setAliasableGlobals("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        java.lang.Object obj7 = compilerOptions0.clone();
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions0.reportMissingOverride = checkLevel8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        boolean boolean5 = googleCodingConvention1.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean10 = node9.isRegExp();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean13 = node12.isEmpty();
        com.google.javascript.rhino.Node node14 = node11.copyInformationFromForTree(node12);
        boolean boolean15 = node14.isLocalResultCall();
        node9.addChildrenToFront(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean21 = node20.isRegExp();
        boolean boolean22 = node20.isComma();
        try {
            java.lang.String str23 = googleCodingConvention1.extractClassNameIfProvide(node9, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        boolean boolean15 = node14.isTry();
        boolean boolean16 = node14.isSwitch();
        boolean boolean17 = node14.isTypeOf();
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        com.google.javascript.jscomp.JsAst jsAst6 = new com.google.javascript.jscomp.JsAst(sourceFile3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot5);
        try {
            com.google.javascript.rhino.Node node7 = node3.detachFromParent();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format12 = compilerOptions9.sourceMapFormat;
        compilerOptions9.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions9.checkGlobalThisLevel;
        compilerOptions0.checkProvides = checkLevel15;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(format12);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.markAsCompiled = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        compilerOptions6.setAngularPass(true);
        boolean boolean10 = compilerOptions6.gatherCssNames;
        compilerOptions6.setOptimizeReturns(false);
        compilerOptions6.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode16 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray20 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        com.google.javascript.jscomp.parsing.Config config23 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode16, false, (java.util.Set<java.lang.String>) strSet21);
        compilerOptions6.stripTypes = strSet21;
        compilerOptions0.aliasableStrings = strSet21;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + languageMode16 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode16.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(config23);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.smartNameRemoval;
        compilerOptions0.inlineConstantVars = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        compilerOptions0.setComputeFunctionSideEffects(true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(true);
        compilerOptions0.setAppNameStr("(InputId: )");
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.setDisambiguateProperties(false);
        compilerOptions0.setIdeMode(false);
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        org.junit.Assert.assertNotNull(format3);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        boolean boolean9 = compilerOptions0.getCheckDeterminism();
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setGeneratePseudoNames(false);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions10.checkUnreachableCode;
        compilerOptions0.checkGlobalThisLevel = checkLevel13;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.setDisambiguateProperties(false);
        compilerOptions0.setClosurePass(true);
        boolean boolean10 = compilerOptions0.optimizeParameters;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap11 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap11;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.AstValidator astValidator0 = new com.google.javascript.jscomp.AstValidator();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean5 = node4.isRegExp();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean8 = node7.isEmpty();
        com.google.javascript.rhino.Node node9 = node6.copyInformationFromForTree(node7);
        boolean boolean10 = node9.isLocalResultCall();
        node4.addChildrenToFront(node9);
        com.google.javascript.rhino.head.ast.AstRoot astRoot12 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult13 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node9, astRoot12);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean16 = node15.isEmpty();
        com.google.javascript.rhino.Node node17 = node14.copyInformationFromForTree(node15);
        com.google.javascript.rhino.Node node18 = node9.useSourceInfoFrom(node15);
        try {
            astValidator0.validateCodeRoot(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Expected BLOCK but was CONTINUE Reference node CONTINUE");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.printInputDelimiter = false;
        boolean boolean5 = compilerOptions0.crossModuleMethodMotion;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isRegExp();
        node5.setDouble((double) (-1.0f));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        boolean boolean11 = node9.isGetElem();
        boolean boolean12 = node9.isParamList();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable13 = node9.children();
        try {
            java.lang.String str14 = googleCodingConvention1.extractClassNameIfRequire(node5, node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(nodeIterable13);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.enableExternExports(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.setOutputCharset("(InputId: )");
        java.util.Map<java.lang.String, java.lang.Object> strMap5 = null;
        compilerOptions0.setDefineReplacements(strMap5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.aliasStringsBlacklist = "Named type with empty name component";
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setUnaliasableGlobals("(InputId: )");
        compilerOptions0.setAngularPass(true);
        compilerOptions0.setReportPath("Object");
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = com.google.javascript.rhino.Node.SLASH_V;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 54 + "'", int0 == 54);
    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str4 = sourceFile3.getCode();
//        jSModule1.addFirst(sourceFile3);
//        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile9 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str10 = sourceFile9.getCode();
//        jSModule7.addFirst(sourceFile9);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
//        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] { jSModule17 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
//        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph15.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph22 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        com.google.javascript.jscomp.DependencyOptions dependencyOptions23 = null;
//        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile27 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str28 = sourceFile27.getCode();
//        jSModule25.addFirst(sourceFile27);
//        boolean boolean30 = sourceFile27.isExtern();
//        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(sourceFile27, true);
//        com.google.javascript.jscomp.SourceAst sourceAst33 = compilerInput32.getAst();
//        com.google.javascript.jscomp.SourceAst sourceAst34 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(sourceAst34, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        com.google.javascript.jscomp.JSModule jSModule38 = compilerInput37.getModule();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray39 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput32, compilerInput37 };
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList40 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList40, compilerInputArray39);
//        try {
//            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList42 = jSModuleGraph22.manageDependencies(dependencyOptions23, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: hi!");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(jSModuleArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(jSModule21);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(sourceAst33);
//        org.junit.Assert.assertNull(jSModule38);
//        org.junit.Assert.assertNotNull(compilerInputArray39);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        compilerOptions0.setMarkAsCompiled(true);
        compilerOptions0.lineBreak = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        boolean boolean7 = compilerOptions0.markAsCompiled;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setUnaliasableGlobals("(InputId: )");
        compilerOptions0.setInlineLocalFunctions(true);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node2 = node0.getChildAtIndex(0);
        try {
            com.google.javascript.rhino.Node node3 = node2.cloneNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        java.util.List<java.lang.String> strList3 = simpleErrorReporter0.warnings();
        org.junit.Assert.assertNull(strList3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean8 = node7.isRegExp();
        boolean boolean9 = node7.isComma();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.exprResult(node7);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean12 = node11.isContinue();
        com.google.javascript.rhino.Node node14 = new com.google.javascript.rhino.Node(10);
        boolean boolean15 = node14.isVar();
        node11.addChildrenToBack(node14);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.string("");
        com.google.javascript.rhino.Node[] nodeArray19 = new com.google.javascript.rhino.Node[] { node0, node10, node14, node18 };
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.paramList(nodeArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(nodeArray19);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        compilerOptions0.setInstrumentationTemplate("InputId: ");
        compilerOptions0.generatePseudoNames = true;
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(astRoot5);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.Node node0 = null;
        try {
            com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.exprResult(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.jqueryPass = false;
        compilerOptions0.setRemoveTryCatchFinally(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        compilerOptions0.setMarkAsCompiled(true);
        com.google.javascript.jscomp.DependencyOptions dependencyOptions7 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str4 = compilerInput3.getName();
        boolean boolean5 = compilerInput3.isExtern();
        try {
            int int7 = compilerInput3.getLineOffset((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str4.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        compilerOptions0.inlineLocalFunctions = true;
        compilerOptions0.sourceMapOutputPath = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel5 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.setInputDelimiter("InputId: ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(detailLevel5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList44 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap46 = jSTypeRegistry2.createTemplateTypeMap(templateTypeList44, jSTypeList45);
        boolean boolean47 = templateTypeMap46.isEmpty();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertNotNull(templateTypeMap46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        boolean boolean46 = templatizedType43.isNativeObjectType();
        java.lang.String str47 = templatizedType43.getDisplayName();
        boolean boolean48 = templatizedType43.isOrdinaryFunction();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Object" + "'", str47.equals("Object"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        compilerOptions0.setInstrumentationTemplate("InputId: ");
        compilerOptions0.setPropertyAffinity(false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList14 = objectType10.getTemplateTypes();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNull(jSTypeList14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str19 = node14.checkTreeEquals(node18);
        boolean boolean20 = node18.isDo();
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str19.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        int int6 = jSModule1.getDepth();
        jSModule1.removeAll();
        jSModule1.clearAsts();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        boolean boolean14 = jSType13.isCheckedUnknownType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.rhino.jstype.TernaryValue ternaryValue1 = com.google.javascript.jscomp.NodeUtil.isStrWhiteSpaceChar(29);
        org.junit.Assert.assertNotNull(ternaryValue1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter7 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSTypeRegistry9.getNativeObjectType(jSTypeNative10);
        com.google.javascript.rhino.jstype.JSType jSType12 = objectType11.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        java.util.Set<java.lang.String> strSet28 = objectType27.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType33.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = objectType44.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] { objectType17, objectType22, objectType27, objectType33, objectType39, jSType45 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType47 = jSTypeRegistry6.createTemplatizedType(objectType11, jSTypeArray46);
        boolean boolean48 = templatizedType47.hasReferenceName();
        boolean boolean49 = templatizedType47.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList50 = templatizedType47.getTemplateTypes();
        com.google.javascript.rhino.jstype.EnumElementType enumElementType51 = templatizedType47.toMaybeEnumElementType();
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType52 = jSTypeRegistry2.createFunctionTypeWithNewThisType(functionType3, (com.google.javascript.rhino.jstype.ObjectType) enumElementType51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertNotNull(templatizedType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(jSTypeList50);
        org.junit.Assert.assertNull(enumElementType51);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable7 = node2.siblings();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(nodeIterable7);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        boolean boolean4 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback20);
        com.google.javascript.jscomp.Scope scope22 = nodeTraversal21.getScope();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(scope22);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.rhino.Node node1 = null;
        try {
            com.google.javascript.rhino.Node node2 = new com.google.javascript.rhino.Node(43, node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.hasChildren();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.number(0.0d);
        boolean boolean5 = node4.isTry();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder7 = node6.getJsDocBuilderForNode();
        boolean boolean8 = node6.hasChildren();
        com.google.javascript.rhino.InputId inputId9 = node6.getInputId();
        boolean boolean10 = node6.isTry();
        try {
            node0.addChildAfter(node4, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(inputId9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.RAW_SIZE));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        boolean boolean9 = compilerOptions0.getCheckDeterminism();
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler10 = null;
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler10);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        java.util.Set<java.lang.String> strSet8 = objectType7.getOwnPropertyNames();
        compilerOptions0.setStripTypePrefixes(strSet8);
        boolean boolean10 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(strSet8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        java.lang.String str14 = jSType13.toAnnotationString();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter15 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter15, false);
        com.google.javascript.rhino.jstype.JSType jSType19 = jSTypeRegistry17.getType("Object");
        com.google.javascript.rhino.jstype.JSType jSType20 = jSType13.getGreatestSubtype(jSType19);
        com.google.javascript.rhino.jstype.JSType jSType21 = jSType20.unboxesTo();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "function (...[*]): ?" + "'", str14.equals("function (...[*]): ?"));
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertNotNull(jSType20);
        org.junit.Assert.assertNull(jSType21);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isParamList();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType8 = node7.getJSType();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean13 = node12.isRegExp();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean16 = node15.isEmpty();
        com.google.javascript.rhino.Node node17 = node14.copyInformationFromForTree(node15);
        boolean boolean18 = node17.isLocalResultCall();
        node12.addChildrenToFront(node17);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.add(node7, node12);
        com.google.javascript.rhino.Node node21 = null;
        int int22 = node7.getIndexOfChild(node21);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType25 = node24.getJSType();
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean30 = node29.isRegExp();
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean33 = node32.isEmpty();
        com.google.javascript.rhino.Node node34 = node31.copyInformationFromForTree(node32);
        boolean boolean35 = node34.isLocalResultCall();
        node29.addChildrenToFront(node34);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.IR.add(node24, node29);
        try {
            com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.IR.ifNode(node3, node7, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(jSType8);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNull(jSType25);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(node37);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        try {
            java.lang.String str4 = googleCodingConvention1.getExportSymbolFunction();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setCollapseObjectLiterals(true);
        boolean boolean13 = compilerOptions0.removeUnusedClassProperties;
        com.google.javascript.jscomp.ErrorFormat errorFormat14 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        compilerOptions0.errorFormat = errorFormat14;
        compilerOptions0.instrumentationTemplate = "(InputId: )";
        compilerOptions0.setIdeMode(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(errorFormat14);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean3 = node2.isAnd();
        boolean boolean4 = node2.isTypeOf();
        node2.setLineno((int) (short) 100);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.getelem(node1, node2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setConvertToDottedProperties(false);
        compilerOptions0.setExternExports(false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder2 = node1.getJsDocBuilderForNode();
        boolean boolean3 = node1.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.string("");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean7 = node6.isDebugger();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder9 = node8.getJsDocBuilderForNode();
        boolean boolean10 = node8.hasChildren();
        com.google.javascript.rhino.InputId inputId11 = node8.getInputId();
        com.google.javascript.rhino.Node node12 = node6.copyInformationFromForTree(node8);
        com.google.javascript.rhino.jstype.JSType jSType13 = null;
        node6.setJSType(jSType13);
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType17 = node16.getJSType();
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean22 = node21.isRegExp();
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean25 = node24.isEmpty();
        com.google.javascript.rhino.Node node26 = node23.copyInformationFromForTree(node24);
        boolean boolean27 = node26.isLocalResultCall();
        node21.addChildrenToFront(node26);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.IR.add(node16, node21);
        boolean boolean30 = node16.isReturn();
        try {
            com.google.javascript.rhino.Node node31 = new com.google.javascript.rhino.Node((int) (byte) 100, node1, node5, node6, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(inputId11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNull(jSType17);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        boolean boolean15 = node1.isAssignAdd();
        boolean boolean16 = node1.isName();
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        jSModule1.clearAsts();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setFoldConstants(true);
        boolean boolean13 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        boolean boolean4 = node3.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult6 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node3, astRoot5);
        boolean boolean7 = node3.isCast();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = node8.getChildAtIndex(0);
        boolean boolean11 = node8.isHook();
        com.google.javascript.rhino.Node node12 = node3.copyInformationFrom(node8);
        boolean boolean13 = node12.isArrayLit();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str4 = sourceFile3.getCode();
//        jSModule1.addFirst(sourceFile3);
//        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile9 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str10 = sourceFile9.getCode();
//        jSModule7.addFirst(sourceFile9);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
//        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
//        java.lang.String[] strArray21 = new java.lang.String[] { "", "InputId: ", "hi!" };
//        java.util.ArrayList<java.lang.String> strList22 = new java.util.ArrayList<java.lang.String>();
//        boolean boolean23 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList22, strArray21);
//        compilerOptions16.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList22);
//        com.google.javascript.jscomp.SourceAst sourceAst25 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(sourceAst25, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        java.lang.String str29 = compilerInput28.getName();
//        boolean boolean30 = compilerInput28.isExtern();
//        com.google.javascript.jscomp.JSModule jSModule32 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile34 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str35 = sourceFile34.getCode();
//        jSModule32.addFirst(sourceFile34);
//        boolean boolean37 = sourceFile34.isExtern();
//        com.google.javascript.jscomp.CompilerInput compilerInput39 = new com.google.javascript.jscomp.CompilerInput(sourceFile34, true);
//        com.google.javascript.jscomp.SourceAst sourceAst40 = compilerInput39.getAst();
//        com.google.javascript.jscomp.JSModule jSModule42 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile44 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str45 = sourceFile44.getCode();
//        jSModule42.addFirst(sourceFile44);
//        boolean boolean47 = sourceFile44.isExtern();
//        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(sourceFile44, true);
//        com.google.javascript.jscomp.SourceAst sourceAst50 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput53 = new com.google.javascript.jscomp.CompilerInput(sourceAst50, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        com.google.javascript.jscomp.SourceAst sourceAst54 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput57 = new com.google.javascript.jscomp.CompilerInput(sourceAst54, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        java.lang.String str58 = compilerInput57.getName();
//        java.lang.String str59 = compilerInput57.getName();
//        com.google.javascript.jscomp.SourceAst sourceAst60 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput63 = new com.google.javascript.jscomp.CompilerInput(sourceAst60, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        com.google.javascript.jscomp.SourceAst sourceAst64 = null;
//        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(sourceAst64, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
//        java.lang.String str68 = compilerInput67.getName();
//        com.google.javascript.jscomp.JSModule jSModule70 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile72 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str73 = sourceFile72.getCode();
//        jSModule70.addFirst(sourceFile72);
//        boolean boolean75 = sourceFile72.isExtern();
//        com.google.javascript.jscomp.CompilerInput compilerInput77 = new com.google.javascript.jscomp.CompilerInput(sourceFile72, true);
//        com.google.javascript.jscomp.SourceAst sourceAst78 = compilerInput77.getAst();
//        com.google.javascript.jscomp.CompilerInput[] compilerInputArray79 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput28, compilerInput39, compilerInput49, compilerInput53, compilerInput57, compilerInput63, compilerInput67, compilerInput77 };
//        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList80 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
//        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList80, compilerInputArray79);
//        try {
//            java.util.List<com.google.javascript.jscomp.CompilerInput> compilerInputList82 = jSModuleGraph15.manageDependencies((java.util.List<java.lang.String>) strList22, (java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList80);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(jSModuleArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(strArray21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str29.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(sourceAst40);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str58.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str59.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str68.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
//        org.junit.Assert.assertNull(str73);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(sourceAst78);
//        org.junit.Assert.assertNotNull(compilerInputArray79);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.SUSPICIOUS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 'a');
        compilerOptions0.prettyPrint = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean10 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean6 = node5.isRegExp();
        boolean boolean7 = node5.isArrayLit();
        boolean boolean8 = node5.isGetProp();
        boolean boolean9 = node5.isNull();
        try {
            boolean boolean10 = googleCodingConvention1.isPropertyTestFunction(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        compilerOptions0.setSummaryDetailLevel(4095);
        org.junit.Assert.assertNotNull(format3);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        compilerOptions0.setMarkAsCompiled(true);
        compilerOptions0.collapseProperties = true;
        java.util.Set<java.lang.String> strSet10 = compilerOptions0.stripNameSuffixes;
        compilerOptions0.setCollapseVariableDeclarations(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState3 = compiler1.getState();
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNotNull(intermediateState3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((int) (short) 10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean3 = node2.isContinue();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = jSTypeRegistry6.getNativeObjectType(jSTypeNative7);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter12 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter12, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry14.getNativeObjectType(jSTypeNative15);
        com.google.javascript.rhino.jstype.JSType jSType17 = objectType16.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        java.util.Set<java.lang.String> strSet33 = objectType32.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter34 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType38 = jSTypeRegistry36.getNativeObjectType(jSTypeNative37);
        com.google.javascript.rhino.jstype.JSType jSType39 = objectType38.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.jstype.JSType jSType50 = objectType49.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] { objectType22, objectType27, objectType32, objectType38, objectType44, jSType50 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType52 = jSTypeRegistry11.createTemplatizedType(objectType16, jSTypeArray51);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection53 = jSTypeRegistry6.getDirectImplementors(objectType16);
        com.google.javascript.rhino.jstype.JSType jSType54 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry6);
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType55 = jSType54.toMaybeTemplatizedType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(templatizedType52);
        org.junit.Assert.assertNotNull(functionTypeCollection53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertNull(templatizedType55);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.hasChildren();
        com.google.javascript.rhino.InputId inputId3 = node0.getInputId();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean11 = node10.isRegExp();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean14 = node13.isEmpty();
        com.google.javascript.rhino.Node node15 = node12.copyInformationFromForTree(node13);
        boolean boolean16 = node15.isLocalResultCall();
        node10.addChildrenToFront(node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.add(node5, node10);
        boolean boolean19 = node5.isReturn();
        try {
            com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.tryCatch(node0, node5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(inputId3);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isExprResult();
        double double5 = node3.getDouble();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry2.getNativeType(jSTypeNative44);
        boolean boolean47 = jSType45.hasProperty("hi!");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        compilerOptions0.setDisambiguateProperties(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.moveFunctionDeclarations = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        compilerOptions12.removeDeadCode = false;
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        try {
            compiler1.rebuildInputsFromModules();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        try {
            com.google.javascript.jscomp.CodingConvention codingConvention4 = compiler1.getCodingConvention();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing0 = com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF;
        boolean boolean1 = tweakProcessing0.isOn();
        org.junit.Assert.assertTrue("'" + tweakProcessing0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing0.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            com.google.javascript.jscomp.SymbolTable symbolTable2 = compiler1.buildKnownSymbolTable();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isExprResult();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.exprResult(node3);
        java.lang.String str6 = node5.toString();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EXPR_RESULT" + "'", str6.equals("EXPR_RESULT"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.hasChildren();
        boolean boolean3 = node0.isFunction();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str4 = compilerInput3.getName();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str4.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        try {
            com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention2 = new com.google.javascript.jscomp.ClosureCodingConvention(codingConvention0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.jqueryPass = false;
        boolean boolean8 = compilerOptions0.inlineLocalFunctions;
        boolean boolean9 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel10;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        boolean boolean9 = compilerOptions0.getCheckDeterminism();
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        node3.setDouble((double) (-1.0f));
        boolean boolean7 = node3.wasEmptyNode();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.ideMode = false;
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.jscomp.SourceMap.Format format0 = com.google.javascript.jscomp.SourceMap.Format.DEFAULT;
        org.junit.Assert.assertNotNull(format0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        java.lang.String str4 = composeWarningsGuard3.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType5 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray6 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType5, strArray6);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = composeWarningsGuard3.level(jSError7);
        java.lang.Object obj9 = null;
        boolean boolean10 = jSError7.equals(obj9);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(diagnosticType5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(jSError7);
        org.junit.Assert.assertNull(checkLevel8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.generateExports = true;
        compilerOptions0.setSkipAllPasses(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isQualifiedName();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean8 = node7.isAnd();
        try {
            com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.getprop(node1, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        boolean boolean15 = node1.isReturn();
        com.google.javascript.rhino.Node node16 = null;
        try {
            com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.sub(node1, node16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        boolean boolean9 = compilerOptions0.getCheckDeterminism();
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.setGeneratePseudoNames(false);
        compilerOptions10.setRewriteNewDateGoogNow(true);
        boolean boolean15 = compilerOptions10.isRemoveUnusedClassProperties();
        compilerOptions10.setExtractPrototypeMemberDeclarations(false);
        compilerOptions10.setRuntimeTypeCheckLogFunction("InputId: ");
        com.google.javascript.jscomp.CheckLevel checkLevel20 = compilerOptions10.checkGlobalNamesLevel;
        compilerOptions0.aggressiveVarCheck = checkLevel20;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + checkLevel20 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel20.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        java.lang.String str4 = com.google.javascript.jscomp.NodeUtil.getNearestFunctionName(node1);
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean6 = node5.isDebugger();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder8 = node7.getJsDocBuilderForNode();
        boolean boolean9 = node7.hasChildren();
        com.google.javascript.rhino.InputId inputId10 = node7.getInputId();
        com.google.javascript.rhino.Node node11 = node5.copyInformationFromForTree(node7);
        try {
            com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.doNode(node1, node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(inputId10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = templatizedType43.getCtorImplementedInterfaces();
        boolean boolean48 = templatizedType43.isNoResolvedType();
        boolean boolean49 = templatizedType43.isInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.setFoldConstants(true);
        compilerOptions0.setExtractPrototypeMemberDeclarations(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = compilerOptions0.sourceMapDetailLevel;
        compilerOptions0.inlineConstantVars = true;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(detailLevel6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        com.google.javascript.rhino.jstype.TemplateType[] templateTypeArray44 = new com.google.javascript.rhino.jstype.TemplateType[] {};
        java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList45 = new java.util.ArrayList<com.google.javascript.rhino.jstype.TemplateType>();
        boolean boolean46 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList45, templateTypeArray44);
        jSTypeRegistry2.setTemplateTypeNames((java.util.List<com.google.javascript.rhino.jstype.TemplateType>) templateTypeList45);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter48 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry50 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter48, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter51 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry53 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter51, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative54 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType55 = jSTypeRegistry53.getNativeObjectType(jSTypeNative54);
        com.google.javascript.rhino.jstype.JSType jSType56 = objectType55.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter57 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry59 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter57, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType61 = jSTypeRegistry59.getNativeObjectType(jSTypeNative60);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter62 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry64 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter62, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType66 = jSTypeRegistry64.getNativeObjectType(jSTypeNative65);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter67 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry69 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter67, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative70 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType71 = jSTypeRegistry69.getNativeObjectType(jSTypeNative70);
        java.util.Set<java.lang.String> strSet72 = objectType71.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter73 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry75 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter73, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative76 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType77 = jSTypeRegistry75.getNativeObjectType(jSTypeNative76);
        com.google.javascript.rhino.jstype.JSType jSType78 = objectType77.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter79 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry81 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter79, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative82 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType83 = jSTypeRegistry81.getNativeObjectType(jSTypeNative82);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter84 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry86 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter84, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative87 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType88 = jSTypeRegistry86.getNativeObjectType(jSTypeNative87);
        com.google.javascript.rhino.jstype.JSType jSType89 = objectType88.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray90 = new com.google.javascript.rhino.jstype.JSType[] { objectType61, objectType66, objectType71, objectType77, objectType83, jSType89 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType91 = jSTypeRegistry50.createTemplatizedType(objectType55, jSTypeArray90);
        boolean boolean92 = templatizedType91.hasReferenceName();
        boolean boolean93 = templatizedType91.isConstructor();
        boolean boolean94 = templatizedType91.isNativeObjectType();
        java.lang.String str95 = templatizedType91.getDisplayName();
        com.google.javascript.rhino.jstype.JSType jSType96 = jSTypeRegistry2.createDefaultObjectUnion((com.google.javascript.rhino.jstype.JSType) templatizedType91);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertNotNull(templateTypeArray44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative54 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative54.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType55);
        org.junit.Assert.assertNotNull(jSType56);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType61);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType66);
        org.junit.Assert.assertTrue("'" + jSTypeNative70 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative70.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType71);
        org.junit.Assert.assertNotNull(strSet72);
        org.junit.Assert.assertTrue("'" + jSTypeNative76 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative76.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + jSTypeNative82 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative82.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType83);
        org.junit.Assert.assertTrue("'" + jSTypeNative87 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative87.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType88);
        org.junit.Assert.assertNotNull(jSType89);
        org.junit.Assert.assertNotNull(jSTypeArray90);
        org.junit.Assert.assertNotNull(templatizedType91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "Object" + "'", str95.equals("Object"));
        org.junit.Assert.assertNotNull(jSType96);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isCall();
        com.google.javascript.rhino.Node node7 = node1.getLastSibling();
        java.lang.String str8 = com.google.javascript.jscomp.NodeUtil.getSourceName(node7);
        boolean boolean9 = node7.isString();
        boolean boolean10 = node7.isFor();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isOrdinaryFunction();
        boolean boolean7 = objectType4.isString();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy11);
        java.io.PrintStream printStream13 = null;
        com.google.javascript.jscomp.Compiler compiler14 = new com.google.javascript.jscomp.Compiler(printStream13);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker15 = null;
        compiler14.tracker = performanceTracker15;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray17 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile21 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str22 = sourceFile21.getCode();
        jSModule19.addFirst(sourceFile21);
        com.google.javascript.jscomp.JSModule[] jSModuleArray24 = new com.google.javascript.jscomp.JSModule[] { jSModule19 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions25.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle28 = compilerOptions25.messageBundle;
        compiler14.init(jSSourceFileArray17, jSModuleArray24, compilerOptions25);
        com.google.javascript.jscomp.ErrorManager errorManager30 = compiler14.getErrorManager();
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) errorManager30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertNotNull(jSSourceFileArray17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(jSModuleArray24);
        org.junit.Assert.assertNull(messageBundle28);
        org.junit.Assert.assertNotNull(errorManager30);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        com.google.javascript.jscomp.CheckLevel checkLevel9 = compilerOptions0.checkMissingReturn;
        compilerOptions0.setInputDelimiter("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel9 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel9.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter47 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry49.getNativeObjectType(jSTypeNative50);
        boolean boolean52 = objectType51.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter53 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry55.getNativeObjectType(jSTypeNative56);
        com.google.javascript.rhino.jstype.JSType jSType58 = objectType57.collapseUnion();
        boolean boolean59 = objectType57.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType60 = objectType51.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType57);
        templatizedType43.matchConstraint((com.google.javascript.rhino.jstype.JSType) objectType57);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSType60);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        compilerOptions6.setAngularPass(true);
        boolean boolean10 = compilerOptions6.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = null;
        compilerOptions6.setPropertyRenaming(propertyRenamingPolicy11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        compilerOptions6.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager15);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler1.getWarnings();
        com.google.javascript.jscomp.Scope scope19 = compiler1.getTopScope();
        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler1.getWarnings();
        com.google.javascript.rhino.head.ast.AstRoot astRoot22 = null;
        compiler1.setOldParseTree("WARNING - Exceeded max number of optimization iterations: {0}\n", astRoot22);
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNull(scope19);
        org.junit.Assert.assertNotNull(jSErrorArray20);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry7.getNativeObjectType(jSTypeNative8);
        boolean boolean10 = objectType9.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        boolean boolean17 = objectType15.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType9.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType15);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = objectType15.getTemplateTypes();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType15 };
        com.google.javascript.rhino.Node node21 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray20);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode22 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        jSTypeRegistry2.setResolveMode(resolveMode22);
        jSTypeRegistry2.identifyNonNullableName("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNull(jSTypeList19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + resolveMode22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode22.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        boolean boolean5 = googleCodingConvention1.isValidEnumKey("hi!");
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node7.isVar();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder10 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node11 = node7.useSourceInfoIfMissingFromForTree(node9);
        try {
            java.lang.String str12 = googleCodingConvention1.getSingletonGetterClassName(node9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder10);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 'a');
        compilerOptions0.prettyPrint = false;
        compilerOptions0.setMarkAsCompiled(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        try {
            boolean boolean6 = com.google.javascript.jscomp.NodeUtil.isLValue(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        compilerOptions0.setDevirtualizePrototypeMethods(true);
        boolean boolean9 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.empty();
        org.junit.Assert.assertNotNull(node0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean3 = node2.isContinue();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = jSTypeRegistry6.getNativeObjectType(jSTypeNative7);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter12 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter12, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry14.getNativeObjectType(jSTypeNative15);
        com.google.javascript.rhino.jstype.JSType jSType17 = objectType16.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        java.util.Set<java.lang.String> strSet33 = objectType32.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter34 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType38 = jSTypeRegistry36.getNativeObjectType(jSTypeNative37);
        com.google.javascript.rhino.jstype.JSType jSType39 = objectType38.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.jstype.JSType jSType50 = objectType49.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] { objectType22, objectType27, objectType32, objectType38, objectType44, jSType50 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType52 = jSTypeRegistry11.createTemplatizedType(objectType16, jSTypeArray51);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection53 = jSTypeRegistry6.getDirectImplementors(objectType16);
        com.google.javascript.rhino.jstype.JSType jSType54 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry6);
        java.lang.String str55 = jSType54.getDisplayName();
        com.google.javascript.rhino.JSDocInfo jSDocInfo56 = jSType54.getJSDocInfo();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(templatizedType52);
        org.junit.Assert.assertNotNull(functionTypeCollection53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Object" + "'", str55.equals("Object"));
        org.junit.Assert.assertNull(jSDocInfo56);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(54);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        int int15 = node14.getLength();
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.assumeClosuresOnlyCaptureReferences();
        compilerOptions7.setAngularPass(true);
        boolean boolean11 = compilerOptions7.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = null;
        compilerOptions7.setPropertyRenaming(propertyRenamingPolicy12);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode15 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray19 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        com.google.javascript.jscomp.parsing.Config config22 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode15, false, (java.util.Set<java.lang.String>) strSet20);
        compilerOptions7.aliasableStrings = strSet20;
        compilerOptions0.setCssRenamingWhitelist((java.util.Set<java.lang.String>) strSet20);
        compilerOptions0.inlineFunctions = true;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + languageMode15 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode15.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(config22);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.VariableMap variableMap3 = null;
        compilerOptions0.setInputPropertyMap(variableMap3);
        compilerOptions0.locale = "InputId: ";
        compilerOptions0.setOptimizeParameters(false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean4 = node3.isEmpty();
        com.google.javascript.rhino.Node node5 = node2.copyInformationFromForTree(node3);
        node3.setLength(0);
        boolean boolean8 = node3.isCall();
        com.google.javascript.rhino.JSDocInfo jSDocInfo9 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNodeDeclaration(codingConvention0, "Named type with empty name component: InputId: ", node3, jSDocInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry51.getNativeObjectType(jSTypeNative52);
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType53.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter55 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry57.getNativeObjectType(jSTypeNative58);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter60 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter60, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry62.getNativeObjectType(jSTypeNative63);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter65 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry67.getNativeObjectType(jSTypeNative68);
        java.util.Set<java.lang.String> strSet70 = objectType69.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter71 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter71, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative74 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry73.getNativeObjectType(jSTypeNative74);
        com.google.javascript.rhino.jstype.JSType jSType76 = objectType75.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter77 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSTypeRegistry79.getNativeObjectType(jSTypeNative80);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter82 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter82, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry84.getNativeObjectType(jSTypeNative85);
        com.google.javascript.rhino.jstype.JSType jSType87 = objectType86.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] { objectType59, objectType64, objectType69, objectType75, objectType81, jSType87 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType89 = jSTypeRegistry48.createTemplatizedType(objectType53, jSTypeArray88);
        boolean boolean90 = templatizedType89.hasReferenceName();
        boolean boolean91 = templatizedType89.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList92 = templatizedType89.getTemplateTypes();
        boolean boolean94 = templatizedType89.isPropertyTypeDeclared("InputId: ");
        templatizedType43.matchConstraint((com.google.javascript.rhino.jstype.JSType) templatizedType89);
        com.google.javascript.rhino.jstype.JSType jSType96 = templatizedType89.collapseUnion();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + jSTypeNative74 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative74.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertNotNull(templatizedType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(jSTypeList92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(jSType96);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.setOutputCharset("(InputId: )");
        compilerOptions0.setLocale("function (...[*]): ?");
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = jSTypeRegistry10.getNativeObjectType(jSTypeNative11);
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType12.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter24 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        java.util.Set<java.lang.String> strSet29 = objectType28.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter30 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry32.getNativeObjectType(jSTypeNative33);
        com.google.javascript.rhino.jstype.JSType jSType35 = objectType34.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType45.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] { objectType18, objectType23, objectType28, objectType34, objectType40, jSType46 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType48 = jSTypeRegistry7.createTemplatizedType(objectType12, jSTypeArray47);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope52 = null;
        com.google.javascript.rhino.jstype.JSType jSType53 = objectType12.forceResolve((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, jSTypeStaticScope52);
        boolean boolean54 = objectType4.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) objectType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(templatizedType48);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.setLineBreak(true);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray9 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList10 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList10, warningsGuardArray9);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard12 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList10);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard13 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList10);
        compilerOptions0.setWarningsGuard(composeWarningsGuard13);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry51.getNativeObjectType(jSTypeNative52);
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType53.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter55 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry57.getNativeObjectType(jSTypeNative58);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter60 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter60, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry62.getNativeObjectType(jSTypeNative63);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter65 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry67.getNativeObjectType(jSTypeNative68);
        java.util.Set<java.lang.String> strSet70 = objectType69.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter71 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter71, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative74 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry73.getNativeObjectType(jSTypeNative74);
        com.google.javascript.rhino.jstype.JSType jSType76 = objectType75.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter77 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSTypeRegistry79.getNativeObjectType(jSTypeNative80);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter82 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter82, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry84.getNativeObjectType(jSTypeNative85);
        com.google.javascript.rhino.jstype.JSType jSType87 = objectType86.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] { objectType59, objectType64, objectType69, objectType75, objectType81, jSType87 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType89 = jSTypeRegistry48.createTemplatizedType(objectType53, jSTypeArray88);
        boolean boolean90 = templatizedType89.hasReferenceName();
        boolean boolean91 = templatizedType89.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList92 = templatizedType89.getTemplateTypes();
        boolean boolean94 = templatizedType89.isPropertyTypeDeclared("InputId: ");
        templatizedType43.matchConstraint((com.google.javascript.rhino.jstype.JSType) templatizedType89);
        java.util.Set<java.lang.String> strSet96 = templatizedType43.getOwnPropertyNames();
        com.google.javascript.rhino.JSDocInfo jSDocInfo98 = null;
        templatizedType43.setPropertyJSDocInfo("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", jSDocInfo98);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + jSTypeNative74 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative74.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertNotNull(templatizedType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(jSTypeList92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(strSet96);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        com.google.javascript.rhino.jstype.JSType jSType7 = null;
        node0.setJSType(jSType7);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean13 = node12.isRegExp();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType16 = node15.getJSType();
        boolean boolean17 = node12.isEquivalentToShallow(node15);
        boolean boolean18 = node0.isEquivalentToShallow(node15);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.exprResult(node15);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        boolean boolean15 = objectType10.hasProperty("EXPR_RESULT");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        compilerOptions0.setConvertToDottedProperties(false);
        java.lang.String str6 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format10 = compilerOptions7.sourceMapFormat;
        compilerOptions7.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions7.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean15 = compilerOptions14.assumeClosuresOnlyCaptureReferences();
        compilerOptions14.setAngularPass(true);
        boolean boolean18 = compilerOptions14.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy19 = null;
        compilerOptions14.setPropertyRenaming(propertyRenamingPolicy19);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode22 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray26 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet27 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet27, strArray26);
        com.google.javascript.jscomp.parsing.Config config29 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode22, false, (java.util.Set<java.lang.String>) strSet27);
        compilerOptions14.aliasableStrings = strSet27;
        compilerOptions7.setCssRenamingWhitelist((java.util.Set<java.lang.String>) strSet27);
        com.google.javascript.jscomp.CompilerOptions.Reach reach32 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions7.setRemoveUnusedVariable(reach32);
        compilerOptions0.setRemoveUnusedVariables(reach32);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(format10);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + languageMode22 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode22.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(config29);
        org.junit.Assert.assertTrue("'" + reach32 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach32.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType45 = jSTypeRegistry2.getNativeType(jSTypeNative44);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter47 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry49.getNativeObjectType(jSTypeNative50);
        boolean boolean52 = objectType51.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter53 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter53, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative56 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType57 = jSTypeRegistry55.getNativeObjectType(jSTypeNative56);
        com.google.javascript.rhino.jstype.JSType jSType58 = objectType57.collapseUnion();
        boolean boolean59 = objectType57.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType60 = objectType51.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType57);
        boolean boolean61 = objectType57.isInterface();
        try {
            jSTypeRegistry2.overwriteDeclaredType("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", (com.google.javascript.rhino.jstype.JSType) objectType57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative56 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative56.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType57);
        org.junit.Assert.assertNotNull(jSType58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        int int6 = jSModule1.getDepth();
        jSModule1.removeAll();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet8 = jSModule1.getAllDependencies();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(jSModuleSet8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean8 = compilerOptions7.assumeClosuresOnlyCaptureReferences();
        compilerOptions7.setAngularPass(true);
        boolean boolean11 = compilerOptions7.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy12 = null;
        compilerOptions7.setPropertyRenaming(propertyRenamingPolicy12);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode15 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray19 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet20 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet20, strArray19);
        com.google.javascript.jscomp.parsing.Config config22 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode15, false, (java.util.Set<java.lang.String>) strSet20);
        compilerOptions7.aliasableStrings = strSet20;
        compilerOptions0.setCssRenamingWhitelist((java.util.Set<java.lang.String>) strSet20);
        compilerOptions0.enableExternExports(true);
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode27 = com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY;
        compilerOptions0.setTracer(tracerMode27);
        boolean boolean29 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + languageMode15 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode15.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(config22);
        org.junit.Assert.assertTrue("'" + tracerMode27 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY + "'", tracerMode27.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = jSTypeRegistry10.getNativeObjectType(jSTypeNative11);
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType12.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter24 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        java.util.Set<java.lang.String> strSet29 = objectType28.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter30 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry32.getNativeObjectType(jSTypeNative33);
        com.google.javascript.rhino.jstype.JSType jSType35 = objectType34.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType45.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] { objectType18, objectType23, objectType28, objectType34, objectType40, jSType46 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType48 = jSTypeRegistry7.createTemplatizedType(objectType12, jSTypeArray47);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection49 = jSTypeRegistry2.getDirectImplementors(objectType12);
        boolean boolean50 = objectType12.isDict();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(templatizedType48);
        org.junit.Assert.assertNotNull(functionTypeCollection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.setFoldConstants(true);
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap8 = null;
        compilerOptions0.setCssRenamingMap(cssRenamingMap8);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy10 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy10);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy10.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withCharset(charset1);
        java.io.File file3 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile4 = builder0.buildFromFile(file3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(builder2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isAnd();
        boolean boolean2 = node0.isTypeOf();
        node0.setLineno((int) (short) 100);
        boolean boolean5 = node0.isReturn();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.SourceMap sourceMap4 = compiler1.getSourceMap();
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState5 = compiler1.getState();
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions6.setGeneratePseudoNames(false);
        compilerOptions6.setRuntimeTypeCheck(false);
        compiler1.initOptions(compilerOptions6);
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = compiler1.getOldParseTreeByName("");
        java.io.PrintStream printStream14 = null;
        com.google.javascript.jscomp.Compiler compiler15 = new com.google.javascript.jscomp.Compiler(printStream14);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker16 = null;
        compiler15.tracker = performanceTracker16;
        com.google.javascript.rhino.head.ast.AstRoot astRoot19 = compiler15.getOldParseTreeByName("InputId: ");
        com.google.javascript.jscomp.CompilerOptions compilerOptions20 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean21 = compilerOptions20.assumeClosuresOnlyCaptureReferences();
        compilerOptions20.setAngularPass(true);
        boolean boolean24 = compilerOptions20.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy25 = null;
        compilerOptions20.setPropertyRenaming(propertyRenamingPolicy25);
        com.google.javascript.jscomp.MessageFormatter messageFormatter27 = null;
        java.util.logging.Logger logger28 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager29 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter27, logger28);
        compilerOptions20.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager29);
        compiler15.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager29);
        com.google.javascript.jscomp.JSError[] jSErrorArray32 = compiler15.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions33 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions33.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format36 = compilerOptions33.sourceMapFormat;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig37 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions33);
        compiler15.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig37);
        try {
            compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: this.passes has already been assigned");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(sourceMap4);
        org.junit.Assert.assertNotNull(intermediateState5);
        org.junit.Assert.assertNull(astRoot13);
        org.junit.Assert.assertNull(astRoot19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(jSErrorArray32);
        org.junit.Assert.assertNotNull(format36);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        compilerOptions0.setUnaliasableGlobals("(InputId: )");
        compilerOptions0.setAngularPass(true);
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ES5_STRICT;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.InputId inputId6 = new com.google.javascript.rhino.InputId("");
        node3.setInputId(inputId6);
        boolean boolean8 = node3.isVar();
        boolean boolean9 = node3.isLocalResultCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.setDefineToStringLiteral("EXPR_RESULT", "function (...[*]): ?");
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isComma();
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(10);
        boolean boolean8 = node7.isVar();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder10 = node9.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node11 = node7.useSourceInfoIfMissingFromForTree(node9);
        com.google.javascript.rhino.Node node12 = node3.srcref(node9);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        compilerOptions0.removeUnusedLocalVars = false;
        compilerOptions0.resetWarningsGuard();
        boolean boolean9 = compilerOptions0.assumeStrictThis();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_STRUCT_DICT_INHERITENCE;
        java.lang.Iterable<com.google.javascript.jscomp.DiagnosticType> diagnosticTypeIterable1 = diagnosticGroup0.getTypes();
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticTypeIterable1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        java.io.PrintStream printStream6 = null;
        com.google.javascript.jscomp.Compiler compiler7 = new com.google.javascript.jscomp.Compiler(printStream6);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker8 = null;
        compiler7.tracker = performanceTracker8;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray10 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile14 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str15 = sourceFile14.getCode();
        jSModule12.addFirst(sourceFile14);
        com.google.javascript.jscomp.JSModule[] jSModuleArray17 = new com.google.javascript.jscomp.JSModule[] { jSModule12 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions18.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle21 = compilerOptions18.messageBundle;
        compiler7.init(jSSourceFileArray10, jSModuleArray17, compilerOptions18);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray24 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile23 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean26 = compilerOptions25.assumeClosuresOnlyCaptureReferences();
        compilerOptions25.setAngularPass(true);
        boolean boolean29 = compilerOptions25.gatherCssNames;
        compilerOptions25.setOptimizeReturns(false);
        compilerOptions25.setConvertToDottedProperties(true);
        compilerOptions25.disambiguateProperties = false;
        compilerOptions25.setManageClosureDependencies(true);
        try {
            com.google.javascript.jscomp.Result result38 = compiler1.compile(jSSourceFileArray10, jSSourceFileArray24, compilerOptions25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertNotNull(jSSourceFileArray10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(jSModuleArray17);
        org.junit.Assert.assertNull(messageBundle21);
        org.junit.Assert.assertNotNull(jSSourceFileArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        boolean boolean46 = templatizedType43.isNativeObjectType();
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap47 = templatizedType43.getTemplateTypeMap();
        com.google.javascript.rhino.jstype.TemplateType templateType48 = null;
        boolean boolean49 = templateTypeMap47.hasTemplateKey(templateType48);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(templateTypeMap47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        compilerOptions6.setAngularPass(true);
        boolean boolean10 = compilerOptions6.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = null;
        compilerOptions6.setPropertyRenaming(propertyRenamingPolicy11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        compilerOptions6.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager15);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler1.getWarnings();
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions19.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format22 = compilerOptions19.sourceMapFormat;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig23 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions19);
        compiler1.setPassConfig((com.google.javascript.jscomp.PassConfig) defaultPassConfig23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile25 = null;
        java.io.PrintStream printStream26 = null;
        com.google.javascript.jscomp.Compiler compiler27 = new com.google.javascript.jscomp.Compiler(printStream26);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker28 = null;
        compiler27.tracker = performanceTracker28;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray30 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule32 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile34 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str35 = sourceFile34.getCode();
        jSModule32.addFirst(sourceFile34);
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = new com.google.javascript.jscomp.JSModule[] { jSModule32 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions38 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions38.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle41 = compilerOptions38.messageBundle;
        compiler27.init(jSSourceFileArray30, jSModuleArray37, compilerOptions38);
        com.google.javascript.jscomp.CompilerOptions compilerOptions43 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions43.syntheticBlockEndMarker = "(InputId: )";
        java.lang.String str46 = compilerOptions43.syntheticBlockStartMarker;
        compilerOptions43.setRemoveUnusedVars(false);
        try {
            com.google.javascript.jscomp.Result result49 = compiler1.compile(jSSourceFile25, jSModuleArray37, compilerOptions43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNotNull(format22);
        org.junit.Assert.assertNotNull(jSSourceFileArray30);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertNotNull(jSModuleArray37);
        org.junit.Assert.assertNull(messageBundle41);
        org.junit.Assert.assertNull(str46);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        boolean boolean47 = templatizedType43.hasAnyTemplateTypesInternal();
        boolean boolean49 = templatizedType43.isPropertyTypeInferred("Named type with empty name component: InputId: ");
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        compilerOptions0.setMarkAsCompiled(true);
        compilerOptions0.inlineVariables = false;
        compilerOptions0.setGeneratePseudoNames(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        com.google.javascript.jscomp.JSError[] jSErrorArray11 = loggerErrorManager9.getErrors();
        loggerErrorManager9.generateReport();
        int int13 = loggerErrorManager9.getWarningCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSErrorArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.setLabelRenaming(true);
        compilerOptions0.aliasStringsBlacklist = "function (...[*]): ?";
        compilerOptions0.inputDelimiter = "Not declared as a type name";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        com.google.javascript.rhino.Node node6 = compiler1.getRoot();
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        compilerOptions0.setMarkAsCompiled(true);
        java.lang.String str7 = compilerOptions0.renamePrefixNamespace;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.crossModuleCodeMotion;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isInc();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = compiler1.tracker;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray3 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = null;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray5 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        boolean boolean8 = compilerOptions6.deadAssignmentElimination;
        try {
            compiler1.init(jSSourceFileArray3, jSSourceFileArray5, compilerOptions6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(performanceTracker2);
        org.junit.Assert.assertNotNull(jSSourceFileArray3);
        org.junit.Assert.assertNotNull(jSSourceFileArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        boolean boolean2 = node0.isOr();
        com.google.javascript.rhino.jstype.JSType jSType3 = node0.getJSType();
        java.lang.Appendable appendable4 = null;
        try {
            node0.appendStringTree(appendable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSType3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter19.setColorize(false);
        lightweightMessageFormatter19.setColorize(false);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str4 = compilerInput3.getName();
        boolean boolean5 = compilerInput3.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput3.getSourceAst();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str4.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(sourceAst6);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            int int6 = compilerInput3.getLineOffset(0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup2 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup[] diagnosticGroupArray3 = new com.google.javascript.jscomp.DiagnosticGroup[] { diagnosticGroup1, diagnosticGroup2 };
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = new com.google.javascript.jscomp.DiagnosticGroup("WARNING - Exceeded max number of optimization iterations: {0}\n", diagnosticGroupArray3);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticGroup2);
        org.junit.Assert.assertNotNull(diagnosticGroupArray3);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        java.lang.String str0 = com.google.javascript.jscomp.Compiler.getReleaseDate();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "2019/06/10 12:41" + "'", str0.equals("2019/06/10 12:41"));
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean3 = node2.isContinue();
        boolean boolean4 = node2.isThrow();
        node1.addChildrenToBack(node2);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isInc();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean13 = node12.isEmpty();
        boolean boolean14 = node12.isGetElem();
        boolean boolean15 = node12.isParamList();
        try {
            com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.IR.tryCatch(node8, node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        compilerOptions0.checkMissingGetCssNameBlacklist = "hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.aggressiveVarCheck = checkLevel6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isComma();
        boolean boolean6 = node3.isCase();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.string("2019/06/10 12:41");
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec2 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean4 = node3.isContinue();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry7.getNativeObjectType(jSTypeNative8);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter10 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter10, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType17.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter24 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        java.util.Set<java.lang.String> strSet34 = objectType33.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.jstype.JSType jSType40 = objectType39.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative49 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType50 = jSTypeRegistry48.getNativeObjectType(jSTypeNative49);
        com.google.javascript.rhino.jstype.JSType jSType51 = objectType50.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray52 = new com.google.javascript.rhino.jstype.JSType[] { objectType23, objectType28, objectType33, objectType39, objectType45, jSType51 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType53 = jSTypeRegistry12.createTemplatizedType(objectType17, jSTypeArray52);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection54 = jSTypeRegistry7.getDirectImplementors(objectType17);
        com.google.javascript.rhino.jstype.JSType jSType55 = assertInstanceofSpec2.getAssertedType(node3, jSTypeRegistry7);
        com.google.javascript.rhino.Node[] nodeArray56 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.IR.objectlit(nodeArray56);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.IR.script(nodeArray56);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.newNode(node3, nodeArray56);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node(0, nodeArray56, (int) (byte) 0, 47);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(strSet34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNotNull(jSType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertTrue("'" + jSTypeNative49 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative49.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType50);
        org.junit.Assert.assertNotNull(jSType51);
        org.junit.Assert.assertNotNull(jSTypeArray52);
        org.junit.Assert.assertNotNull(templatizedType53);
        org.junit.Assert.assertNotNull(functionTypeCollection54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(nodeArray56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry7.getNativeObjectType(jSTypeNative8);
        boolean boolean10 = objectType9.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        boolean boolean17 = objectType15.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType9.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType15);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = objectType15.getTemplateTypes();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType15 };
        com.google.javascript.rhino.Node node21 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray20);
        com.google.javascript.jscomp.CompilerOptions compilerOptions23 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions23.checkControlStructures = true;
        compilerOptions23.setDefineToBooleanLiteral("InputId: ", false);
        node21.putProp(12, (java.lang.Object) false);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNull(jSTypeList19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(node21);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        try {
            boolean boolean7 = googleCodingConvention1.isVarArgsParameter(node5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSType6);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("Not declared as a type name");
        com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceFile1);
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        boolean boolean6 = sourceFile3.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, true);
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput8.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8);
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        com.google.javascript.jscomp.JSModule jSModule15 = compilerInput14.getModule();
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile19 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str20 = sourceFile19.getCode();
        jSModule17.addFirst(sourceFile19);
        boolean boolean22 = sourceFile19.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput24 = new com.google.javascript.jscomp.CompilerInput(sourceFile19, true);
        com.google.javascript.jscomp.SourceAst sourceAst25 = compilerInput24.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput24);
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile30 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str31 = sourceFile30.getCode();
        jSModule28.addFirst(sourceFile30);
        boolean boolean33 = sourceFile30.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(sourceFile30, true);
        com.google.javascript.jscomp.SourceAst sourceAst36 = compilerInput35.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput35);
        com.google.javascript.jscomp.SourceAst sourceAst38 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput41 = new com.google.javascript.jscomp.CompilerInput(sourceAst38, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str42 = compilerInput41.getName();
        com.google.javascript.jscomp.JSModule jSModule44 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile46 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str47 = sourceFile46.getCode();
        jSModule44.addFirst(sourceFile46);
        boolean boolean49 = sourceFile46.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput51 = new com.google.javascript.jscomp.CompilerInput(sourceFile46, true);
        com.google.javascript.jscomp.SourceAst sourceAst52 = compilerInput51.getAst();
        com.google.javascript.jscomp.SourceAst sourceAst53 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput56 = new com.google.javascript.jscomp.CompilerInput(sourceAst53, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        com.google.javascript.jscomp.JSModule jSModule57 = compilerInput56.getModule();
        com.google.javascript.jscomp.JSModule jSModule59 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile61 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str62 = sourceFile61.getCode();
        jSModule59.addFirst(sourceFile61);
        boolean boolean64 = sourceFile61.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput66 = new com.google.javascript.jscomp.CompilerInput(sourceFile61, true);
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray67 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput10, compilerInput14, compilerInput26, compilerInput37, compilerInput41, compilerInput51, compilerInput56, compilerInput66 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList68 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean69 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList68, compilerInputArray67);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies70 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setCompiler to be called first: hi!");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sourceAst9);
        org.junit.Assert.assertNull(jSModule15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(sourceAst25);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(sourceAst36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str42.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(sourceAst52);
        org.junit.Assert.assertNull(jSModule57);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(compilerInputArray67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.setFoldConstants(true);
        compilerOptions0.setCollapsePropertiesOnExternTypes(true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.CompilerOptions.Reach reach0 = com.google.javascript.jscomp.CompilerOptions.Reach.NONE;
        org.junit.Assert.assertTrue("'" + reach0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.NONE + "'", reach0.equals(com.google.javascript.jscomp.CompilerOptions.Reach.NONE));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isAllType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter22 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSTypeRegistry24.getNativeObjectType(jSTypeNative25);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry29.getNativeObjectType(jSTypeNative30);
        java.util.Set<java.lang.String> strSet32 = objectType31.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType37.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter44 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry46.getNativeObjectType(jSTypeNative47);
        com.google.javascript.rhino.jstype.JSType jSType49 = objectType48.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { objectType21, objectType26, objectType31, objectType37, objectType43, jSType49 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType51 = jSTypeRegistry10.createTemplatizedType(objectType15, jSTypeArray50);
        boolean boolean52 = templatizedType51.hasReferenceName();
        boolean boolean53 = templatizedType51.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = templatizedType51.getTemplateTypes();
        boolean boolean55 = templatizedType51.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(10);
        boolean boolean58 = node57.isVar();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder60 = node59.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node61 = node57.useSourceInfoIfMissingFromForTree(node59);
        boolean boolean62 = objectType4.defineSynthesizedProperty("Named type with empty name component: InputId: ", (com.google.javascript.rhino.jstype.JSType) templatizedType51, node61);
        boolean boolean63 = node61.isContinue();
        boolean boolean64 = node61.isDelProp();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(strSet32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(templatizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(jSTypeList54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setExtractPrototypeMemberDeclarations(false);
        com.google.javascript.jscomp.SourceMap.Format format6 = compilerOptions3.sourceMapFormat;
        compilerOptions0.sourceMapFormat = format6;
        org.junit.Assert.assertNotNull(format6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        boolean boolean11 = compilerOptions0.lineBreak;
        compilerOptions0.closurePass = false;
        compilerOptions0.renamePrefixNamespace = "Named type with empty name component";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        boolean boolean47 = templatizedType43.isInstanceType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSType jSType53 = jSTypeRegistry51.getType("Object");
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.IR.nullNode();
        boolean boolean55 = templatizedType43.defineDeclaredProperty("Named type with empty name component", jSType53, node54);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(jSType53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.generatePseudoNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.setMessageBundle(messageBundle9);
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.setDefineToNumberLiteral("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", 12);
        compilerOptions0.exportTestFunctions = false;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.String str1 = com.google.javascript.rhino.jstype.ObjectType.createDelegateSuffix("2019/06/10 12:41");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(2019/06/10 12:41)" + "'", str1.equals("(2019/06/10 12:41)"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        java.lang.String str3 = compilerOptions0.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet4 = compilerOptions0.stripTypes;
        com.google.javascript.jscomp.DependencyOptions dependencyOptions5 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(strSet4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isNew();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean16 = node15.isRegExp();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean19 = node18.isEmpty();
        com.google.javascript.rhino.Node node20 = node17.copyInformationFromForTree(node18);
        boolean boolean21 = node20.isLocalResultCall();
        node15.addChildrenToFront(node20);
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFromForTree(node15);
        node8.setType(0);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isNew();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean16 = node15.isRegExp();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean19 = node18.isEmpty();
        com.google.javascript.rhino.Node node20 = node17.copyInformationFromForTree(node18);
        boolean boolean21 = node20.isLocalResultCall();
        node15.addChildrenToFront(node20);
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFromForTree(node15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions25 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray30 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList31 = new java.util.ArrayList<java.lang.String>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList31, strArray30);
        compilerOptions25.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList31);
        com.google.javascript.jscomp.MessageBundle messageBundle34 = null;
        compilerOptions25.setMessageBundle(messageBundle34);
        node8.putProp((int) (byte) 10, (java.lang.Object) messageBundle34);
        com.google.javascript.rhino.Node node38 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType39 = node38.getJSType();
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean44 = node43.isRegExp();
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean47 = node46.isEmpty();
        com.google.javascript.rhino.Node node48 = node45.copyInformationFromForTree(node46);
        boolean boolean49 = node48.isLocalResultCall();
        node43.addChildrenToFront(node48);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.IR.add(node38, node43);
        boolean boolean52 = node51.isTry();
        boolean boolean53 = node51.isSwitch();
        node8.addChildToBack(node51);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(jSType39);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str4 = sourceFile3.getCode();
//        jSModule1.addFirst(sourceFile3);
//        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile9 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str10 = sourceFile9.getCode();
//        jSModule7.addFirst(sourceFile9);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
//        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] { jSModule17 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
//        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph15.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph22 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile26 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str27 = sourceFile26.getCode();
//        jSModule24.addFirst(sourceFile26);
//        com.google.javascript.jscomp.JSModule jSModule30 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile32 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str33 = sourceFile32.getCode();
//        jSModule30.addFirst(sourceFile32);
//        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile38 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str39 = sourceFile38.getCode();
//        jSModule36.addFirst(sourceFile38);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray41 = new com.google.javascript.jscomp.JSModule[] { jSModule30, jSModule36 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList42 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean43 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList42, jSModuleArray41);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph44 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList42);
//        com.google.javascript.jscomp.JSModule jSModule46 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray47 = new com.google.javascript.jscomp.JSModule[] { jSModule46 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList48 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList48, jSModuleArray47);
//        com.google.javascript.jscomp.JSModule jSModule50 = jSModuleGraph44.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList48);
//        java.lang.String str51 = jSModule50.toString();
//        boolean boolean52 = jSModuleGraph22.dependsOn(jSModule24, jSModule50);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(jSModuleArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(jSModule21);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertNotNull(jSModuleArray41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray47);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
//        org.junit.Assert.assertNotNull(jSModule50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.syntheticBlockEndMarker = "(InputId: )";
        java.lang.String str11 = compilerOptions8.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet12 = compilerOptions8.stripTypes;
        compilerOptions0.stripNameSuffixes = strSet12;
        boolean boolean14 = compilerOptions0.inlineGetters;
        compilerOptions0.resetWarningsGuard();
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(strSet12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.setLabelRenaming(true);
        compilerOptions0.setAliasKeywords(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node2 = node0.getChildAtIndex(0);
        try {
            boolean boolean3 = node2.wasEmptyNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(node2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        boolean boolean11 = node8.isNew();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean16 = node15.isRegExp();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean19 = node18.isEmpty();
        com.google.javascript.rhino.Node node20 = node17.copyInformationFromForTree(node18);
        boolean boolean21 = node20.isLocalResultCall();
        node15.addChildrenToFront(node20);
        com.google.javascript.rhino.Node node23 = node8.useSourceInfoIfMissingFromForTree(node15);
        boolean boolean24 = node15.isTypeOf();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.setDeadAssignmentElimination(true);
        compilerOptions0.gatherCssNames = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.setMessageBundle(messageBundle9);
        compilerOptions0.crossModuleMethodMotion = true;
        compilerOptions0.setDefineToNumberLiteral("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", 12);
        com.google.javascript.jscomp.ErrorFormat errorFormat16 = compilerOptions0.errorFormat;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(errorFormat16);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        boolean boolean5 = node3.isFor();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray3 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError4 = com.google.javascript.jscomp.JSError.make(diagnosticType2, strArray3);
        boolean boolean5 = diagnosticGroup1.matches(jSError4);
        boolean boolean6 = diagnosticGroup0.matches(jSError4);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(jSError4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node2 = node0.getChildAtIndex(0);
        boolean boolean3 = node0.isHook();
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.not(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        java.lang.String str5 = jSType4.toDebugHashCodeString();
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{-1939501217}" + "'", str5.equals("{-1939501217}"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = compilerOptions0.anonymousFunctionNaming;
        compilerOptions0.setRuntimeTypeCheckLogFunction("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        boolean boolean9 = compilerOptions0.optimizeParameters;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setExtractPrototypeMemberDeclarations(false);
        java.lang.String str3 = compilerOptions0.renamePrefix;
        boolean boolean4 = compilerOptions0.checkSuspiciousCode;
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.setGeneratePseudoNames(false);
        compilerOptions5.setRewriteNewDateGoogNow(true);
        boolean boolean10 = compilerOptions5.isRemoveUnusedClassProperties();
        compilerOptions5.setMarkAsCompiled(true);
        compilerOptions5.collapseProperties = true;
        java.util.Set<java.lang.String> strSet15 = compilerOptions5.stripNameSuffixes;
        com.google.javascript.jscomp.CompilerOptions.AliasTransformationHandler aliasTransformationHandler16 = compilerOptions5.getAliasTransformationHandler();
        compilerOptions0.setAliasTransformationHandler(aliasTransformationHandler16);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(aliasTransformationHandler16);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        boolean boolean6 = compilerOptions0.jqueryPass;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = templatizedType43.getCtorImplementedInterfaces();
        boolean boolean48 = templatizedType43.isNoResolvedType();
        java.lang.String str49 = templatizedType43.getDisplayName();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Object" + "'", str49.equals("Object"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.generateExports = false;
        boolean boolean4 = compilerOptions0.ambiguateProperties;
        com.google.javascript.jscomp.CompilerOptions.TweakProcessing tweakProcessing5 = compilerOptions0.getTweakProcessing();
        compilerOptions0.setOptimizeParameters(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + tweakProcessing5 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF + "'", tweakProcessing5.equals(com.google.javascript.jscomp.CompilerOptions.TweakProcessing.OFF));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel9;
        java.lang.String str11 = compilerOptions0.locale;
        compilerOptions0.setClosurePass(true);
        compilerOptions0.computeFunctionSideEffects = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.MessageBundle messageBundle9 = null;
        compilerOptions0.setMessageBundle(messageBundle9);
        boolean boolean11 = compilerOptions0.checkControlStructures;
        boolean boolean12 = compilerOptions0.recordFunctionInformation;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = true;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        boolean boolean17 = compiler1.isIdeMode();
        java.lang.String str18 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback19);
        com.google.javascript.jscomp.CompilerInput compilerInput21 = nodeTraversal20.getInput();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNull(compilerInput21);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter7 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSTypeRegistry9.getNativeObjectType(jSTypeNative10);
        com.google.javascript.rhino.jstype.JSType jSType12 = objectType11.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        java.util.Set<java.lang.String> strSet28 = objectType27.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType33.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = objectType44.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] { objectType17, objectType22, objectType27, objectType33, objectType39, jSType45 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType47 = jSTypeRegistry6.createTemplatizedType(objectType11, jSTypeArray46);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection48 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) templatizedType47);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder49 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertNotNull(templatizedType47);
        org.junit.Assert.assertNotNull(functionTypeCollection48);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        boolean boolean47 = templatizedType43.isInstanceType();
        com.google.javascript.rhino.jstype.ObjectType objectType48 = templatizedType43.getReferencedType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(objectType48);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry51.getNativeObjectType(jSTypeNative52);
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType53.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter55 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry57.getNativeObjectType(jSTypeNative58);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter60 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter60, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry62.getNativeObjectType(jSTypeNative63);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter65 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry67.getNativeObjectType(jSTypeNative68);
        java.util.Set<java.lang.String> strSet70 = objectType69.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter71 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter71, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative74 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry73.getNativeObjectType(jSTypeNative74);
        com.google.javascript.rhino.jstype.JSType jSType76 = objectType75.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter77 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSTypeRegistry79.getNativeObjectType(jSTypeNative80);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter82 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter82, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry84.getNativeObjectType(jSTypeNative85);
        com.google.javascript.rhino.jstype.JSType jSType87 = objectType86.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] { objectType59, objectType64, objectType69, objectType75, objectType81, jSType87 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType89 = jSTypeRegistry48.createTemplatizedType(objectType53, jSTypeArray88);
        boolean boolean90 = templatizedType89.hasReferenceName();
        boolean boolean91 = templatizedType89.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList92 = templatizedType89.getTemplateTypes();
        boolean boolean94 = templatizedType89.isPropertyTypeDeclared("InputId: ");
        templatizedType43.matchConstraint((com.google.javascript.rhino.jstype.JSType) templatizedType89);
        com.google.javascript.rhino.jstype.UnionType unionType96 = templatizedType89.toMaybeUnionType();
        boolean boolean97 = templatizedType89.hasReferenceName();
        com.google.javascript.rhino.jstype.JSType jSType99 = templatizedType89.getRestrictedTypeGivenToBooleanOutcome(false);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + jSTypeNative74 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative74.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertNotNull(templatizedType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(jSTypeList92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNull(unionType96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(jSType99);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node3 = node1.getChildAtIndex(0);
        com.google.javascript.rhino.Node[] nodeArray4 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.objectlit(nodeArray4);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.paramList(nodeArray4);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(8, node1, node6, (-1), 51);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNull(node3);
        org.junit.Assert.assertNotNull(nodeArray4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        boolean boolean11 = compilerOptions0.lineBreak;
        compilerOptions0.setAliasStringsBlacklist("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        java.lang.String str8 = compilerOptions0.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.assumeClosuresOnlyCaptureReferences();
        compilerOptions9.setAngularPass(true);
        boolean boolean13 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = null;
        compilerOptions9.setPropertyRenaming(propertyRenamingPolicy14);
        boolean boolean16 = compilerOptions9.deadAssignmentElimination;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray22 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList23 = new java.util.ArrayList<java.lang.String>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList23, strArray22);
        compilerOptions17.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList23);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy26 = compilerOptions17.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions compilerOptions27 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean28 = compilerOptions27.assumeClosuresOnlyCaptureReferences();
        compilerOptions27.setAngularPass(true);
        boolean boolean31 = compilerOptions27.gatherCssNames;
        compilerOptions27.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel34 = null;
        compilerOptions27.checkUnreachableCode = checkLevel34;
        compilerOptions27.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy38 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions27.setPropertyRenaming(propertyRenamingPolicy38);
        compilerOptions9.setRenamingPolicy(variableRenamingPolicy26, propertyRenamingPolicy38);
        compilerOptions0.variableRenaming = variableRenamingPolicy26;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy26 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy26.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy38 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy38.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.Node[] nodeArray0 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.objectlit(nodeArray0);
        boolean boolean2 = node1.isTry();
        boolean boolean3 = node1.isSwitch();
        boolean boolean4 = node1.isIf();
        org.junit.Assert.assertNotNull(nodeArray0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        try {
            java.lang.String str2 = googleCodingConvention1.getGlobalObject();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isExprResult();
        boolean boolean5 = node3.isSwitch();
        boolean boolean6 = node3.isAdd();
        boolean boolean7 = node3.isIn();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.MessageFormatter messageFormatter7 = null;
        java.util.logging.Logger logger8 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager9 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter7, logger8);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager9);
        int int11 = loggerErrorManager9.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray12 = loggerErrorManager9.getWarnings();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.setOutputCharset("(InputId: )");
        java.lang.String str5 = compilerOptions0.locale;
        com.google.javascript.jscomp.VariableMap variableMap6 = null;
        compilerOptions0.setInputPropertyMap(variableMap6);
        boolean boolean8 = compilerOptions0.printInputDelimiter;
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        java.lang.String str4 = compilerInput3.getName();
        boolean boolean5 = compilerInput3.isExtern();
        com.google.javascript.jscomp.SourceAst sourceAst6 = compilerInput3.getAst();
        boolean boolean7 = compilerInput3.isExtern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str4.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(sourceAst6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        java.lang.String str19 = node14.checkTreeEquals(node18);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean24 = node23.isRegExp();
        boolean boolean25 = node23.isArrayLit();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile26 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node23);
        java.lang.String str27 = node14.checkTreeEquals(node23);
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str19.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(staticSourceFile26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n" + "'", str27.equals("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = jSTypeRegistry10.getNativeObjectType(jSTypeNative11);
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType12.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter24 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry26 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter24, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative27 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType28 = jSTypeRegistry26.getNativeObjectType(jSTypeNative27);
        java.util.Set<java.lang.String> strSet29 = objectType28.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter30 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry32.getNativeObjectType(jSTypeNative33);
        com.google.javascript.rhino.jstype.JSType jSType35 = objectType34.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType45.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray47 = new com.google.javascript.rhino.jstype.JSType[] { objectType18, objectType23, objectType28, objectType34, objectType40, jSType46 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType48 = jSTypeRegistry7.createTemplatizedType(objectType12, jSTypeArray47);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection49 = jSTypeRegistry2.getDirectImplementors(objectType12);
        boolean boolean50 = objectType12.isTemplateType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertTrue("'" + jSTypeNative27 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative27.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType28);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertNotNull(jSTypeArray47);
        org.junit.Assert.assertNotNull(templatizedType48);
        org.junit.Assert.assertNotNull(functionTypeCollection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder5 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        boolean boolean11 = objectType10.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter12 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter12, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry14.getNativeObjectType(jSTypeNative15);
        com.google.javascript.rhino.jstype.JSType jSType17 = objectType16.collapseUnion();
        boolean boolean18 = objectType16.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType19 = objectType10.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType16);
        java.lang.String str20 = jSType19.toAnnotationString();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter21 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter21, false);
        com.google.javascript.rhino.jstype.JSType jSType25 = jSTypeRegistry23.getType("Object");
        com.google.javascript.rhino.jstype.JSType jSType26 = jSType19.getGreatestSubtype(jSType25);
        boolean boolean27 = functionParamBuilder5.addVarArgs(jSType19);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(jSType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "function (...[*]): ?" + "'", str20.equals("function (...[*]): ?"));
        org.junit.Assert.assertNotNull(jSType25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel9;
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType13 = node12.getJSType();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean18 = node17.isRegExp();
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean21 = node20.isEmpty();
        com.google.javascript.rhino.Node node22 = node19.copyInformationFromForTree(node20);
        boolean boolean23 = node22.isLocalResultCall();
        node17.addChildrenToFront(node22);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.add(node12, node17);
        com.google.javascript.jscomp.CompilerOptions compilerOptions26 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions26.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format29 = compilerOptions26.sourceMapFormat;
        compilerOptions26.setProcessCommonJSModules(true);
        compilerOptions26.devirtualizePrototypeMethods = true;
        java.lang.String str34 = compilerOptions26.instrumentationTemplate;
        compilerOptions26.inlineConstantVars = true;
        java.lang.String[] strArray39 = new java.lang.String[] { "", "InputId: " };
        java.util.LinkedHashSet<java.lang.String> strSet40 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet40, strArray39);
        compilerOptions26.stripTypes = strSet40;
        node17.setDirectives((java.util.Set<java.lang.String>) strSet40);
        compilerOptions0.setCssRenamingWhitelist((java.util.Set<java.lang.String>) strSet40);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSType13);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(format29);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNotNull(strArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode0 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3;
        org.junit.Assert.assertTrue("'" + languageMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3 + "'", languageMode0.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT3));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType21.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        java.util.Set<java.lang.String> strSet38 = objectType37.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.jstype.JSType jSType44 = objectType43.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter50 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter50, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSTypeRegistry52.getNativeObjectType(jSTypeNative53);
        com.google.javascript.rhino.jstype.JSType jSType55 = objectType54.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] { objectType27, objectType32, objectType37, objectType43, objectType49, jSType55 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType57 = jSTypeRegistry16.createTemplatizedType(objectType21, jSTypeArray56);
        boolean boolean58 = templatizedType57.hasReferenceName();
        boolean boolean59 = templatizedType57.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList60 = templatizedType57.getTemplateTypes();
        boolean boolean62 = templatizedType57.isPropertyTypeDeclared("InputId: ");
        boolean boolean63 = objectType4.canCastTo((com.google.javascript.rhino.jstype.JSType) templatizedType57);
        boolean boolean65 = objectType4.hasProperty("Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n");
        java.util.Set<java.lang.String> strSet66 = objectType4.getOwnPropertyNames();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(strSet38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(templatizedType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeList60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(strSet66);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.setFoldConstants(true);
        compilerOptions0.setRemoveUnusedVars(true);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode10 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions0.setLanguageOut(languageMode10);
        compilerOptions0.reserveRawExports = false;
        org.junit.Assert.assertTrue("'" + languageMode10 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode10.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String[] strArray5 = new java.lang.String[] { "", "InputId: ", "hi!" };
        java.util.ArrayList<java.lang.String> strList6 = new java.util.ArrayList<java.lang.String>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList6, strArray5);
        compilerOptions0.setReplaceStringsConfiguration("InputId: ", (java.util.List<java.lang.String>) strList6);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy9 = compilerOptions0.variableRenaming;
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode10 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        compilerOptions0.setTracerMode(tracerMode10);
        boolean boolean12 = compilerOptions0.computeFunctionSideEffects;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = compilerOptions0.checkRequires;
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy9 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy9.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + tracerMode10 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode10.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + checkLevel13 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel13.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceFile3);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode10 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode10, false, (java.util.Set<java.lang.String>) strSet15);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode20 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray24 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet25 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet25, strArray24);
        com.google.javascript.jscomp.parsing.Config config27 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode20, false, (java.util.Set<java.lang.String>) strSet25);
        com.google.javascript.jscomp.parsing.Config config28 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode10, false, (java.util.Set<java.lang.String>) strSet25);
        com.google.javascript.rhino.head.ErrorReporter errorReporter29 = null;
        java.util.logging.Logger logger30 = null;
        try {
            com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult31 = com.google.javascript.jscomp.parsing.ParserRunner.parse((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile3, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", config28, errorReporter29, logger30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + languageMode10 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode10.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(config17);
        org.junit.Assert.assertTrue("'" + languageMode20 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode20.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(config27);
        org.junit.Assert.assertNotNull(config28);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("Named type with empty name component");
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.setDisambiguateProperties(false);
        compilerOptions0.setClosurePass(true);
        boolean boolean10 = compilerOptions0.optimizeParameters;
        boolean boolean11 = compilerOptions0.preferLineBreakAtEndOfFile;
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str4 = sourceFile3.getCode();
//        jSModule1.addFirst(sourceFile3);
//        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.SourceFile sourceFile9 = new com.google.javascript.jscomp.SourceFile("hi!");
//        java.lang.String str10 = sourceFile9.getCode();
//        jSModule7.addFirst(sourceFile9);
//        com.google.javascript.jscomp.JSModule[] jSModuleArray12 = new com.google.javascript.jscomp.JSModule[] { jSModule1, jSModule7 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList13 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList13, jSModuleArray12);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph15 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList13);
//        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("hi!");
//        com.google.javascript.jscomp.JSModule[] jSModuleArray18 = new com.google.javascript.jscomp.JSModule[] { jSModule17 };
//        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList19 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
//        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19, jSModuleArray18);
//        com.google.javascript.jscomp.JSModule jSModule21 = jSModuleGraph15.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph22 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList19);
//        jSModuleGraph22.coalesceDuplicateFiles();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertNotNull(jSModuleArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(jSModuleArray18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(jSModule21);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        compilerOptions0.setMarkAsCompiled(false);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setGeneratePseudoNames(false);
        compilerOptions9.setRuntimeTypeCheck(false);
        compilerOptions9.disableRuntimeTypeCheck();
        compilerOptions9.setFoldConstants(true);
        compilerOptions9.setRemoveUnusedVars(true);
        com.google.javascript.jscomp.CompilerOptions.LanguageMode languageMode19 = com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT;
        compilerOptions9.setLanguageOut(languageMode19);
        compilerOptions0.setLanguageOut(languageMode19);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + languageMode19 + "' != '" + com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT + "'", languageMode19.equals(com.google.javascript.jscomp.CompilerOptions.LanguageMode.ECMASCRIPT5_STRICT));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean3 = node2.isEmpty();
        com.google.javascript.rhino.Node node4 = node1.copyInformationFromForTree(node2);
        boolean boolean5 = node2.isWith();
        com.google.javascript.rhino.Node node6 = null;
        try {
            com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(1, node2, node6, 39, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        boolean boolean2 = node0.isNoSideEffectsCall();
        try {
            com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.neg(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.setIdeMode(true);
        com.google.javascript.jscomp.DependencyOptions dependencyOptions8 = null;
        try {
            compilerOptions0.setDependencyOptions(dependencyOptions8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        boolean boolean14 = objectType10.isInterface();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter15 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter15, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative18 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType19 = jSTypeRegistry17.getNativeObjectType(jSTypeNative18);
        boolean boolean20 = objectType19.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter21 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSTypeRegistry23.getNativeObjectType(jSTypeNative24);
        com.google.javascript.rhino.jstype.JSType jSType26 = objectType25.collapseUnion();
        boolean boolean27 = objectType25.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType28 = objectType19.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType25);
        java.lang.String str29 = jSType28.toAnnotationString();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter30 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter30, false);
        com.google.javascript.rhino.jstype.JSType jSType34 = jSTypeRegistry32.getType("Object");
        com.google.javascript.rhino.jstype.JSType jSType35 = jSType28.getGreatestSubtype(jSType34);
        com.google.javascript.rhino.jstype.JSType jSType36 = objectType10.getGreatestSubtype(jSType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative18 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative18.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertNotNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "function (...[*]): ?" + "'", str29.equals("function (...[*]): ?"));
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertNotNull(jSType36);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        compilerOptions0.setAliasAllStrings(true);
        compilerOptions0.setGenerateExports(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec1 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean3 = node2.isContinue();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative7 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType8 = jSTypeRegistry6.getNativeObjectType(jSTypeNative7);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter12 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter12, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative15 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType16 = jSTypeRegistry14.getNativeObjectType(jSTypeNative15);
        com.google.javascript.rhino.jstype.JSType jSType17 = objectType16.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        java.util.Set<java.lang.String> strSet33 = objectType32.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter34 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry36 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter34, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative37 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType38 = jSTypeRegistry36.getNativeObjectType(jSTypeNative37);
        com.google.javascript.rhino.jstype.JSType jSType39 = objectType38.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.jstype.JSType jSType50 = objectType49.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray51 = new com.google.javascript.rhino.jstype.JSType[] { objectType22, objectType27, objectType32, objectType38, objectType44, jSType50 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType52 = jSTypeRegistry11.createTemplatizedType(objectType16, jSTypeArray51);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection53 = jSTypeRegistry6.getDirectImplementors(objectType16);
        com.google.javascript.rhino.jstype.JSType jSType54 = assertInstanceofSpec1.getAssertedType(node2, jSTypeRegistry6);
        boolean boolean55 = jSType54.isStringObjectType();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative7 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative7.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative15 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative15.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType16);
        org.junit.Assert.assertNotNull(jSType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertNotNull(strSet33);
        org.junit.Assert.assertTrue("'" + jSTypeNative37 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative37.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType38);
        org.junit.Assert.assertNotNull(jSType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertNotNull(jSType50);
        org.junit.Assert.assertNotNull(jSTypeArray51);
        org.junit.Assert.assertNotNull(templatizedType52);
        org.junit.Assert.assertNotNull(functionTypeCollection53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isValidEnumKey("(InputId: )");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap3 = compilerOptions0.customPasses;
        compilerOptions0.setAliasAllStrings(true);
        boolean boolean6 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isQualifiedName();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean8 = node7.isContinue();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(10);
        boolean boolean11 = node10.isVar();
        node7.addChildrenToBack(node10);
        try {
            node1.addChildrenToFront(node10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType6 = objectType4.toMaybeTemplatizedType();
        try {
            boolean boolean8 = templatizedType6.hasOwnProperty("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertNull(templatizedType6);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        boolean boolean47 = templatizedType43.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.JSDocInfo jSDocInfo49 = null;
        templatizedType43.setPropertyJSDocInfo("EXPR_RESULT", jSDocInfo49);
        boolean boolean51 = templatizedType43.isInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.setOutputJsStringUsage(true);
        compilerOptions0.computeFunctionSideEffects = true;
        compilerOptions0.setCrossModuleMethodMotion(true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy5 = null;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy5);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode8 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray12 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet13 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet13, strArray12);
        com.google.javascript.jscomp.parsing.Config config15 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode8, false, (java.util.Set<java.lang.String>) strSet13);
        compilerOptions0.aliasableStrings = strSet13;
        compilerOptions0.inlineLocalFunctions = false;
        com.google.javascript.jscomp.VariableMap variableMap19 = null;
        compilerOptions0.setInputAnonymousFunctionNamingMap(variableMap19);
        boolean boolean21 = compilerOptions0.moveFunctionDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + languageMode8 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode8.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(config15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = null;
        try {
            boolean boolean4 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter19.setColorize(false);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType23, strArray24);
        boolean boolean26 = diagnosticGroup22.matches(jSError25);
        java.lang.String str27 = jSError25.toString();
        java.lang.String str28 = lightweightMessageFormatter19.formatWarning(jSError25);
        int int29 = jSError25.getNodeLength();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str27.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "WARNING - Exceeded max number of optimization iterations: {0}\n" + "'", str28.equals("WARNING - Exceeded max number of optimization iterations: {0}\n"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isCall();
        com.google.javascript.rhino.Node node7 = node1.getLastSibling();
        java.lang.String str8 = com.google.javascript.jscomp.NodeUtil.getSourceName(node7);
        boolean boolean9 = node7.isString();
        boolean boolean10 = node7.isCase();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType3 = null;
        try {
            googleCodingConvention0.applySingletonGetter(functionType1, functionType2, objectType3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isCall();
        com.google.javascript.rhino.Node node7 = node1.getLastSibling();
        int int9 = node7.getIntProp((-1));
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setCommonJSModulePathPrefix("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isAllType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter22 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSTypeRegistry24.getNativeObjectType(jSTypeNative25);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry29.getNativeObjectType(jSTypeNative30);
        java.util.Set<java.lang.String> strSet32 = objectType31.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType37.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter44 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry46.getNativeObjectType(jSTypeNative47);
        com.google.javascript.rhino.jstype.JSType jSType49 = objectType48.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { objectType21, objectType26, objectType31, objectType37, objectType43, jSType49 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType51 = jSTypeRegistry10.createTemplatizedType(objectType15, jSTypeArray50);
        boolean boolean52 = templatizedType51.hasReferenceName();
        boolean boolean53 = templatizedType51.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = templatizedType51.getTemplateTypes();
        boolean boolean55 = templatizedType51.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(10);
        boolean boolean58 = node57.isVar();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder60 = node59.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node61 = node57.useSourceInfoIfMissingFromForTree(node59);
        boolean boolean62 = objectType4.defineSynthesizedProperty("Named type with empty name component: InputId: ", (com.google.javascript.rhino.jstype.JSType) templatizedType51, node61);
        boolean boolean63 = node61.isContinue();
        try {
            com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.IR.defaultCase(node61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(strSet32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(templatizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(jSTypeList54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions1.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions1.sourceMapFormat;
        compilerOptions1.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions1.checkGlobalThisLevel;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard8 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel7);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt18 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1, sourceExcerpt18);
        com.google.javascript.jscomp.SourceMap sourceMap20 = compiler1.getSourceMap();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertNull(sourceMap20);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        boolean boolean6 = compilerOptions0.checkControlStructures;
        compilerOptions0.renamePrefix = "hi!";
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoFrom(node14);
        boolean boolean18 = node17.isGetProp();
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean23 = node22.isRegExp();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType26 = node25.getJSType();
        boolean boolean27 = node22.isEquivalentToShallow(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean32 = node31.isRegExp();
        boolean boolean33 = node31.isArrayLit();
        com.google.javascript.rhino.jstype.StaticSourceFile staticSourceFile34 = com.google.javascript.jscomp.NodeUtil.getSourceFile(node31);
        try {
            node17.replaceChildAfter(node25, node31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(jSType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(staticSourceFile34);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        node0.setType((int) (byte) 10);
        boolean boolean3 = node0.isNumber();
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType6 = node5.getJSType();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean11 = node10.isRegExp();
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean14 = node13.isEmpty();
        com.google.javascript.rhino.Node node15 = node12.copyInformationFromForTree(node13);
        boolean boolean16 = node15.isLocalResultCall();
        node10.addChildrenToFront(node15);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.IR.add(node5, node10);
        boolean boolean19 = node5.isAssignAdd();
        node5.setSourceFileForTesting("hi!");
        java.lang.String str22 = node5.getQualifiedName();
        boolean boolean23 = node0.isEquivalentToShallow(node5);
        try {
            double double24 = node0.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSType6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        boolean boolean5 = node3.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setManageClosureDependencies(true);
        com.google.javascript.jscomp.VariableMap variableMap13 = null;
        compilerOptions0.setInputVariableMap(variableMap13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isAllType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter22 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSTypeRegistry24.getNativeObjectType(jSTypeNative25);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry29.getNativeObjectType(jSTypeNative30);
        java.util.Set<java.lang.String> strSet32 = objectType31.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType37.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter44 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry46.getNativeObjectType(jSTypeNative47);
        com.google.javascript.rhino.jstype.JSType jSType49 = objectType48.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { objectType21, objectType26, objectType31, objectType37, objectType43, jSType49 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType51 = jSTypeRegistry10.createTemplatizedType(objectType15, jSTypeArray50);
        boolean boolean52 = templatizedType51.hasReferenceName();
        boolean boolean53 = templatizedType51.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = templatizedType51.getTemplateTypes();
        boolean boolean55 = templatizedType51.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(10);
        boolean boolean58 = node57.isVar();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder60 = node59.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node61 = node57.useSourceInfoIfMissingFromForTree(node59);
        boolean boolean62 = objectType4.defineSynthesizedProperty("Named type with empty name component: InputId: ", (com.google.javascript.rhino.jstype.JSType) templatizedType51, node61);
        boolean boolean63 = templatizedType51.isStringObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(strSet32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(templatizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(jSTypeList54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType2 = node1.getJSType();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        node6.addChildrenToFront(node11);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.add(node1, node6);
        com.google.javascript.rhino.JSDocInfo jSDocInfo15 = null;
        com.google.javascript.rhino.Node node16 = node6.setJSDocInfo(jSDocInfo15);
        com.google.javascript.jscomp.JSModule jSModule18 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile20 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str21 = sourceFile20.getCode();
        jSModule18.addFirst(sourceFile20);
        int int23 = jSModule18.getDepth();
        jSModule18.removeAll();
        com.google.javascript.jscomp.SourceFile sourceFile26 = new com.google.javascript.jscomp.SourceFile("hi!");
        jSModule18.add(sourceFile26);
        node6.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile26);
        org.junit.Assert.assertNull(jSType2);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        java.lang.String str20 = compiler1.toSource();
        compiler1.reportCodeChange();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = templatizedType43.getCtorImplementedInterfaces();
        boolean boolean48 = templatizedType43.isNoResolvedType();
        boolean boolean49 = templatizedType43.isOrdinaryFunction();
        boolean boolean50 = templatizedType43.isUnknownType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        compilerOptions0.setDevirtualizePrototypeMethods(true);
        compilerOptions0.setSmartNameRemoval(true);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy11;
        compilerOptions0.crossModuleCodeMotion = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isVar();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node1.useSourceInfoIfMissingFromForTree(node3);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node5.getJsDocBuilderForNode();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        boolean boolean3 = googleCodingConvention1.isConstant("InputId: ");
        boolean boolean5 = googleCodingConvention1.isValidEnumKey("hi!");
        boolean boolean7 = googleCodingConvention1.isValidEnumKey("Named type with empty name component: InputId: ");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType1 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray2 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError3 = com.google.javascript.jscomp.JSError.make(diagnosticType1, strArray2);
        boolean boolean4 = diagnosticGroup0.matches(jSError3);
        java.lang.String str5 = jSError3.sourceName;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(jSError3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.setProcessCommonJSModules(true);
        compilerOptions0.devirtualizePrototypeMethods = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.assumeClosuresOnlyCaptureReferences();
        compilerOptions8.setAngularPass(true);
        boolean boolean12 = compilerOptions8.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy13 = null;
        compilerOptions8.setPropertyRenaming(propertyRenamingPolicy13);
        com.google.javascript.jscomp.MessageFormatter messageFormatter15 = null;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter15, logger16);
        compilerOptions8.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager17);
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager17);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        int int6 = jSModule1.getDepth();
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile10 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str11 = sourceFile10.getCode();
        jSModule8.addFirst(sourceFile10);
        boolean boolean13 = sourceFile10.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(sourceFile10, true);
        com.google.javascript.rhino.InputId inputId16 = compilerInput15.getInputId();
        jSModule1.remove(compilerInput15);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(inputId16);
    }
}

