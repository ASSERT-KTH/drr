import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        boolean boolean2 = node0.isOptionalArg();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean5 = node4.isEmpty();
        com.google.javascript.rhino.Node node6 = node3.copyInformationFromForTree(node4);
        node4.setLength(0);
        boolean boolean9 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node10 = node0.useSourceInfoIfMissingFrom(node4);
        node10.setSourceFileForTesting("{-1939501217}");
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.jstype.ObjectType objectType6 = com.google.javascript.rhino.jstype.ObjectType.cast((com.google.javascript.rhino.jstype.JSType) objectType4);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative11 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType12 = jSTypeRegistry10.getNativeObjectType(jSTypeNative11);
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType12.collapseUnion();
        boolean boolean14 = objectType12.isAllType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter16 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter16, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        com.google.javascript.rhino.jstype.JSType jSType24 = objectType23.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter30 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry32 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter30, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative33 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType34 = jSTypeRegistry32.getNativeObjectType(jSTypeNative33);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        java.util.Set<java.lang.String> strSet40 = objectType39.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter41 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry43 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter41, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative44 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType45 = jSTypeRegistry43.getNativeObjectType(jSTypeNative44);
        com.google.javascript.rhino.jstype.JSType jSType46 = objectType45.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter47 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry49.getNativeObjectType(jSTypeNative50);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter52 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter52, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative55 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType56 = jSTypeRegistry54.getNativeObjectType(jSTypeNative55);
        com.google.javascript.rhino.jstype.JSType jSType57 = objectType56.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] { objectType29, objectType34, objectType39, objectType45, objectType51, jSType57 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType59 = jSTypeRegistry18.createTemplatizedType(objectType23, jSTypeArray58);
        boolean boolean60 = templatizedType59.hasReferenceName();
        boolean boolean61 = templatizedType59.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList62 = templatizedType59.getTemplateTypes();
        boolean boolean63 = templatizedType59.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.Node node65 = new com.google.javascript.rhino.Node(10);
        boolean boolean66 = node65.isVar();
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder68 = node67.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node69 = node65.useSourceInfoIfMissingFromForTree(node67);
        boolean boolean70 = objectType12.defineSynthesizedProperty("Named type with empty name component: InputId: ", (com.google.javascript.rhino.jstype.JSType) templatizedType59, node69);
        java.util.Set<java.lang.String> strSet71 = objectType12.getOwnPropertyNames();
        com.google.javascript.rhino.Node node73 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType74 = node73.getJSType();
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean79 = node78.isRegExp();
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean82 = node81.isEmpty();
        com.google.javascript.rhino.Node node83 = node80.copyInformationFromForTree(node81);
        boolean boolean84 = node83.isLocalResultCall();
        node78.addChildrenToFront(node83);
        com.google.javascript.rhino.Node node86 = com.google.javascript.rhino.IR.add(node73, node78);
        com.google.javascript.rhino.Node node87 = null;
        int int88 = node73.getIndexOfChild(node87);
        boolean boolean89 = objectType6.defineSynthesizedProperty("WARNING - Exceeded max number of optimization iterations: {0}\n", (com.google.javascript.rhino.jstype.JSType) objectType12, node73);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(objectType6);
        org.junit.Assert.assertTrue("'" + jSTypeNative11 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative11.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType12);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(jSType24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertTrue("'" + jSTypeNative33 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative33.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertNotNull(strSet40);
        org.junit.Assert.assertTrue("'" + jSTypeNative44 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative44.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType45);
        org.junit.Assert.assertNotNull(jSType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + jSTypeNative55 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative55.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType56);
        org.junit.Assert.assertNotNull(jSType57);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(templatizedType59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(jSTypeList62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(strSet71);
        org.junit.Assert.assertNull(jSType74);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(node86);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean2 = node1.isEmpty();
        com.google.javascript.rhino.Node node3 = node0.copyInformationFromForTree(node1);
        node1.setLength(0);
        boolean boolean6 = node1.isCall();
        boolean boolean7 = node1.isGetProp();
        boolean boolean8 = node1.isAnd();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(node1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        int int0 = com.google.javascript.rhino.Node.LENGTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        com.google.javascript.rhino.Node node7 = node2.getLastSibling();
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean10 = node9.isEmpty();
        com.google.javascript.rhino.Node node11 = node8.copyInformationFromForTree(node9);
        boolean boolean12 = node11.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot13 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult14 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node11, astRoot13);
        node7.addChildToFront(node11);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.setGeneratePseudoNames(false);
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions3.checkUnreachableCode;
        com.google.javascript.jscomp.DiagnosticType diagnosticType8 = com.google.javascript.jscomp.DiagnosticType.make("Named type with empty name component", checkLevel6, "InputId: ");
        java.lang.String str9 = diagnosticType8.key;
        java.lang.String[] strArray12 = new java.lang.String[] { "hi!", "EXPR_RESULT" };
        com.google.javascript.jscomp.JSError jSError13 = com.google.javascript.jscomp.JSError.make("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)", node1, diagnosticType8, strArray12);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Named type with empty name component" + "'", str9.equals("Named type with empty name component"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(jSError13);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.TWEAKS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        com.google.javascript.jscomp.JSModule jSModule4 = compilerInput3.getModule();
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSModule4);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        com.google.javascript.jscomp.SourceFile.Builder builder0 = new com.google.javascript.jscomp.SourceFile.Builder();
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder2 = builder0.withCharset(charset1);
        java.nio.charset.Charset charset3 = null;
        com.google.javascript.jscomp.SourceFile.Builder builder4 = builder2.withCharset(charset3);
        com.google.javascript.jscomp.SourceFile.Builder builder6 = builder4.withOriginalPath("Object");
        org.junit.Assert.assertNotNull(builder2);
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertNotNull(builder6);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile3 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str4 = sourceFile3.getCode();
        jSModule1.addFirst(sourceFile3);
        boolean boolean6 = sourceFile3.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceFile3, true);
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput8.getAst();
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput8);
        try {
            java.lang.String str11 = compilerInput8.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(sourceAst9);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        boolean boolean17 = compiler1.isIdeMode();
        java.lang.String str18 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback19);
        com.google.javascript.jscomp.JSModule jSModule21 = nodeTraversal20.getModule();
        com.google.javascript.jscomp.CompilerInput compilerInput22 = nodeTraversal20.getInput();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNull(jSModule21);
        org.junit.Assert.assertNull(compilerInput22);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        compiler1.disableThreads();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isDo();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("");
        node6.setInputId(inputId9);
        java.lang.String str11 = inputId9.toString();
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput12 = compiler1.getInput(inputId9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "InputId: " + "'", str11.equals("InputId: "));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.lineBreak = true;
        boolean boolean8 = compilerOptions0.smartNameRemoval;
        com.google.javascript.jscomp.CheckLevel checkLevel9 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel9;
        java.lang.String str11 = compilerOptions0.locale;
        boolean boolean12 = compilerOptions0.removeTryCatchFinally;
        compilerOptions0.setOptimizeCalls(false);
        compilerOptions0.setSourceMapOutputPath("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType3 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType4 = null;
        try {
            googleCodingConvention1.applySubclassRelationship(functionType2, functionType3, subclassType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        boolean boolean17 = compiler1.isIdeMode();
        java.lang.String str18 = compiler1.getAstDotGraph();
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal20 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback19);
        java.lang.String str21 = nodeTraversal20.getSourceName();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention1 = new com.google.javascript.jscomp.GoogleCodingConvention(codingConvention0);
        try {
            boolean boolean4 = googleCodingConvention1.isExported("hi!", true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CONSTANT_PROPERTY;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable47 = templatizedType43.getCtorImplementedInterfaces();
        boolean boolean48 = templatizedType43.isNoResolvedType();
        boolean boolean49 = templatizedType43.hasAnyTemplateTypesInternal();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertNotNull(objectTypeIterable47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        int int0 = com.google.javascript.rhino.Node.INPUT_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.CodingConvention codingConvention20 = compiler1.getCodingConvention();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(codingConvention20);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.jqueryPass = false;
        boolean boolean8 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        java.util.Set<java.lang.String> strSet14 = objectType13.getOwnPropertyNames();
        compilerOptions0.aliasableStrings = strSet14;
        boolean boolean16 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType5 = jSTypeRegistry2.createAnonymousObjectType(jSDocInfo4);
        org.junit.Assert.assertNotNull(objectType5);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoFrom(node14);
        com.google.javascript.jscomp.JSModule jSModule19 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile21 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str22 = sourceFile21.getCode();
        jSModule19.addFirst(sourceFile21);
        boolean boolean24 = sourceFile21.isExtern();
        node14.setStaticSourceFile((com.google.javascript.rhino.jstype.StaticSourceFile) sourceFile21);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel4;
        compilerOptions0.jqueryPass = false;
        boolean boolean8 = compilerOptions0.inlineLocalFunctions;
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        java.util.Set<java.lang.String> strSet14 = objectType13.getOwnPropertyNames();
        compilerOptions0.aliasableStrings = strSet14;
        com.google.javascript.jscomp.CompilerOptions compilerOptions16 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions16.setGeneratePseudoNames(false);
        compilerOptions16.setRewriteNewDateGoogNow(true);
        boolean boolean21 = compilerOptions16.isRemoveUnusedClassProperties();
        compilerOptions16.setExtractPrototypeMemberDeclarations(false);
        compilerOptions16.setRuntimeTypeCheckLogFunction("InputId: ");
        com.google.javascript.jscomp.CheckLevel checkLevel26 = compilerOptions16.checkGlobalNamesLevel;
        compilerOptions0.setCheckUnreachableCode(checkLevel26);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + checkLevel26 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel26.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList46 = templatizedType43.getTemplateTypes();
        boolean boolean47 = templatizedType43.matchesUint32Context();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(jSTypeList46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isAllType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter8 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter8, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter22 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry24 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter22, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative25 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType26 = jSTypeRegistry24.getNativeObjectType(jSTypeNative25);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry29.getNativeObjectType(jSTypeNative30);
        java.util.Set<java.lang.String> strSet32 = objectType31.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        com.google.javascript.rhino.jstype.JSType jSType38 = objectType37.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter44 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry46.getNativeObjectType(jSTypeNative47);
        com.google.javascript.rhino.jstype.JSType jSType49 = objectType48.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] { objectType21, objectType26, objectType31, objectType37, objectType43, jSType49 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType51 = jSTypeRegistry10.createTemplatizedType(objectType15, jSTypeArray50);
        boolean boolean52 = templatizedType51.hasReferenceName();
        boolean boolean53 = templatizedType51.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList54 = templatizedType51.getTemplateTypes();
        boolean boolean55 = templatizedType51.hasAnyTemplateTypesInternal();
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node(10);
        boolean boolean58 = node57.isVar();
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder60 = node59.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node61 = node57.useSourceInfoIfMissingFromForTree(node59);
        boolean boolean62 = objectType4.defineSynthesizedProperty("Named type with empty name component: InputId: ", (com.google.javascript.rhino.jstype.JSType) templatizedType51, node61);
        boolean boolean63 = templatizedType51.isUnknownType();
        com.google.javascript.rhino.jstype.BooleanLiteralSet booleanLiteralSet64 = templatizedType51.getPossibleToBooleanOutcomes();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertTrue("'" + jSTypeNative25 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative25.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType26);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(strSet32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(jSType38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertNotNull(jSType49);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(templatizedType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(jSTypeList54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + booleanLiteralSet64 + "' != '" + com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE + "'", booleanLiteralSet64.equals(com.google.javascript.rhino.jstype.BooleanLiteralSet.TRUE));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry7.getNativeObjectType(jSTypeNative8);
        boolean boolean10 = objectType9.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        boolean boolean17 = objectType15.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType9.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType15);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = objectType15.getTemplateTypes();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType15 };
        com.google.javascript.rhino.Node node21 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray20);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode22 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        jSTypeRegistry2.setResolveMode(resolveMode22);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder24 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean27 = node26.isEmpty();
        com.google.javascript.rhino.Node node28 = node25.copyInformationFromForTree(node26);
        boolean boolean29 = node28.isLocalResultCall();
        com.google.javascript.rhino.head.ast.AstRoot astRoot30 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult31 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node28, astRoot30);
        com.google.javascript.jscomp.CompilerOptions compilerOptions32 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions32.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format35 = compilerOptions32.sourceMapFormat;
        compilerOptions32.setProcessCommonJSModules(true);
        compilerOptions32.devirtualizePrototypeMethods = true;
        java.lang.String str40 = compilerOptions32.instrumentationTemplate;
        com.google.javascript.jscomp.CompilerOptions compilerOptions41 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions41.syntheticBlockEndMarker = "(InputId: )";
        java.lang.String str44 = compilerOptions41.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet45 = compilerOptions41.stripTypes;
        compilerOptions32.setCssRenamingWhitelist(strSet45);
        com.google.javascript.jscomp.CompilerOptions compilerOptions47 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions47.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format50 = compilerOptions47.sourceMapFormat;
        compilerOptions47.setProcessCommonJSModules(true);
        compilerOptions47.devirtualizePrototypeMethods = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions55.syntheticBlockEndMarker = "(InputId: )";
        java.lang.String str58 = compilerOptions55.syntheticBlockStartMarker;
        java.util.Set<java.lang.String> strSet59 = compilerOptions55.stripTypes;
        compilerOptions47.stripNameSuffixes = strSet59;
        compilerOptions32.setIdGenerators(strSet59);
        node28.setDirectives(strSet59);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder63 = functionBuilder24.withSourceNode(node28);
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNull(jSTypeList19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + resolveMode22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode22.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(format35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(strSet45);
        org.junit.Assert.assertNotNull(format50);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(strSet59);
        org.junit.Assert.assertNotNull(functionBuilder63);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode1 = com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY;
        compilerOptions0.setTracer(tracerMode1);
        compilerOptions0.setMarkNoSideEffectCalls(true);
        org.junit.Assert.assertTrue("'" + tracerMode1 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY + "'", tracerMode1.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.TIMING_ONLY));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        lightweightMessageFormatter19.setColorize(false);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup22 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray24 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make(diagnosticType23, strArray24);
        boolean boolean26 = diagnosticGroup22.matches(jSError25);
        java.lang.String str27 = jSError25.toString();
        java.lang.String str28 = lightweightMessageFormatter19.formatWarning(jSError25);
        int int29 = jSError25.getLineNumber();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup22);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)" + "'", str27.equals("JSC_OPTIMIZE_LOOP_ERROR. Exceeded max number of optimization iterations: {0} at (unknown source) line (unknown line) : (unknown column)"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "WARNING - Exceeded max number of optimization iterations: {0}\n" + "'", str28.equals("WARNING - Exceeded max number of optimization iterations: {0}\n"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        node3.setDouble((double) (-1.0f));
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.pos(node3);
        boolean boolean8 = node3.isSyntheticBlock();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "Node tree inequality:\nTree1:\nADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nTree2:\nNUMBER 100.0 97\n\n\nSubtree1: ADD\n    BITXOR\n    NUMBER 100.0 97\n        CONTINUE\n\n\nSubtree2: NUMBER 100.0 97\n", true);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        compilerOptions6.setAngularPass(true);
        boolean boolean10 = compilerOptions6.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = null;
        compilerOptions6.setPropertyRenaming(propertyRenamingPolicy11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        compilerOptions6.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager15);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.assumeClosuresOnlyCaptureReferences();
        compilerOptions18.setAngularPass(true);
        boolean boolean22 = compilerOptions18.gatherCssNames;
        compilerOptions18.setOptimizeReturns(false);
        compilerOptions18.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode28 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray32 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet33 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet33, strArray32);
        com.google.javascript.jscomp.parsing.Config config35 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode28, false, (java.util.Set<java.lang.String>) strSet33);
        compilerOptions18.stripTypes = strSet33;
        compilerOptions18.setTweakToStringLiteral("Named type with empty name component", "");
        compiler1.initOptions(compilerOptions18);
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + languageMode28 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode28.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(config35);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node(10);
        com.google.javascript.rhino.jstype.JSType jSType7 = node6.getJSType();
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean12 = node11.isRegExp();
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        boolean boolean17 = node16.isLocalResultCall();
        node11.addChildrenToFront(node16);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.IR.add(node6, node11);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter21 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry23 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter21, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative24 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType25 = jSTypeRegistry23.getNativeObjectType(jSTypeNative24);
        boolean boolean26 = objectType25.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter27 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter27, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative30 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType31 = jSTypeRegistry29.getNativeObjectType(jSTypeNative30);
        com.google.javascript.rhino.jstype.JSType jSType32 = objectType31.collapseUnion();
        boolean boolean33 = objectType31.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType25.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType31);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter38 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry40 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter38, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative41 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType42 = jSTypeRegistry40.getNativeObjectType(jSTypeNative41);
        com.google.javascript.rhino.jstype.JSType jSType43 = objectType42.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter44 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter44, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative47 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType48 = jSTypeRegistry46.getNativeObjectType(jSTypeNative47);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry51.getNativeObjectType(jSTypeNative52);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter54 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry56 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter54, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative57 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType58 = jSTypeRegistry56.getNativeObjectType(jSTypeNative57);
        java.util.Set<java.lang.String> strSet59 = objectType58.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter60 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter60, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry62.getNativeObjectType(jSTypeNative63);
        com.google.javascript.rhino.jstype.JSType jSType65 = objectType64.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter66 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry68 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter66, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative69 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType70 = jSTypeRegistry68.getNativeObjectType(jSTypeNative69);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter71 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter71, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative74 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry73.getNativeObjectType(jSTypeNative74);
        com.google.javascript.rhino.jstype.JSType jSType76 = objectType75.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] { objectType48, objectType53, objectType58, objectType64, objectType70, jSType76 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType78 = jSTypeRegistry37.createTemplatizedType(objectType42, jSTypeArray77);
        boolean boolean79 = templatizedType78.hasReferenceName();
        boolean boolean80 = templatizedType78.isConstructor();
        boolean boolean81 = objectType31.canCastTo((com.google.javascript.rhino.jstype.JSType) templatizedType78);
        try {
            com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry2.createFromTypeNodes(node19, "Named type with empty name component", (com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType>) objectType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: ADD");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNull(jSType7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + jSTypeNative24 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative24.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative30 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative30.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType31);
        org.junit.Assert.assertNotNull(jSType32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative41 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative41.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType42);
        org.junit.Assert.assertNotNull(jSType43);
        org.junit.Assert.assertTrue("'" + jSTypeNative47 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative47.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType48);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertTrue("'" + jSTypeNative57 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative57.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType58);
        org.junit.Assert.assertNotNull(strSet59);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertNotNull(jSType65);
        org.junit.Assert.assertTrue("'" + jSTypeNative69 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative69.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType70);
        org.junit.Assert.assertTrue("'" + jSTypeNative74 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative74.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(templatizedType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.optimizeArgumentsArray = true;
        compilerOptions0.printInputDelimiter = false;
        compilerOptions0.setInlineLocalVariables(false);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean1 = node0.isEmpty();
        boolean boolean2 = node0.isOr();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean4 = node3.isCase();
        boolean boolean5 = node3.isIn();
        boolean boolean6 = node3.isVarArgs();
        node3.setChangeTime((int) '#');
        node0.addChildrenToBack(node3);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.markNoSideEffectCalls = false;
        compilerOptions0.setDeadAssignmentElimination(true);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.JSError[] jSErrorArray2 = loggerErrorManager1.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getErrors();
        org.junit.Assert.assertNotNull(jSErrorArray2);
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRewriteNewDateGoogNow(true);
        boolean boolean5 = compilerOptions0.isRemoveUnusedClassProperties();
        compilerOptions0.setRemoveUnusedPrototypeProperties(true);
        com.google.javascript.jscomp.CheckLevel checkLevel8 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType21.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        java.util.Set<java.lang.String> strSet38 = objectType37.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.jstype.JSType jSType44 = objectType43.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter50 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter50, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSTypeRegistry52.getNativeObjectType(jSTypeNative53);
        com.google.javascript.rhino.jstype.JSType jSType55 = objectType54.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] { objectType27, objectType32, objectType37, objectType43, objectType49, jSType55 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType57 = jSTypeRegistry16.createTemplatizedType(objectType21, jSTypeArray56);
        boolean boolean58 = templatizedType57.hasReferenceName();
        boolean boolean59 = templatizedType57.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList60 = templatizedType57.getTemplateTypes();
        boolean boolean62 = templatizedType57.isPropertyTypeDeclared("InputId: ");
        boolean boolean63 = objectType4.canCastTo((com.google.javascript.rhino.jstype.JSType) templatizedType57);
        boolean boolean64 = templatizedType57.isResolved();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(strSet38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(templatizedType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(jSTypeList60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        com.google.javascript.rhino.Node[] nodeArray1 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.objectlit(nodeArray1);
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((-1), nodeArray1, (int) (byte) 1, (int) (short) 1);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.objectlit(nodeArray1);
        org.junit.Assert.assertNotNull(nodeArray1);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(node6);
    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test42");
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
//        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
//        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
//        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
//        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
//        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
//        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
//        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
//        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
//        boolean boolean44 = templatizedType43.hasReferenceName();
//        boolean boolean45 = templatizedType43.isConstructor();
//        boolean boolean46 = templatizedType43.isNativeObjectType();
//        java.lang.String str47 = templatizedType43.getDisplayName();
//        java.lang.String str48 = templatizedType43.toDebugHashCodeString();
//        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType7);
//        org.junit.Assert.assertNotNull(jSType8);
//        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType13);
//        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType18);
//        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType23);
//        org.junit.Assert.assertNotNull(strSet24);
//        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType29);
//        org.junit.Assert.assertNotNull(jSType30);
//        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType35);
//        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
//        org.junit.Assert.assertNotNull(objectType40);
//        org.junit.Assert.assertNotNull(jSType41);
//        org.junit.Assert.assertNotNull(jSTypeArray42);
//        org.junit.Assert.assertNotNull(templatizedType43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Object" + "'", str47.equals("Object"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{proxy:function (this:{-1939501217}, {908813108}): {1518208692}}" + "'", str48.equals("{proxy:function (this:{-1939501217}, {908813108}): {1518208692}}"));
//    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        compilerOptions12.setIgnoreCajaProperties(true);
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        com.google.javascript.jscomp.ErrorManager errorManager17 = compiler1.getErrorManager();
        boolean boolean18 = compiler1.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter19 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler1);
        com.google.javascript.jscomp.NodeTraversal.Callback callback20 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal21 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler1, callback20);
        com.google.javascript.rhino.Node node22 = nodeTraversal21.getEnclosingFunction();
        boolean boolean23 = nodeTraversal21.hasScope();
        try {
            com.google.javascript.rhino.Node node24 = nodeTraversal21.getScopeRoot();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertNotNull(errorManager17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        boolean boolean44 = templatizedType43.hasReferenceName();
        boolean boolean45 = templatizedType43.isConstructor();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter46 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry48 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter46, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter49 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry51 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter49, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative52 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType53 = jSTypeRegistry51.getNativeObjectType(jSTypeNative52);
        com.google.javascript.rhino.jstype.JSType jSType54 = objectType53.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter55 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry57 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter55, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative58 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType59 = jSTypeRegistry57.getNativeObjectType(jSTypeNative58);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter60 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry62 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter60, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative63 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType64 = jSTypeRegistry62.getNativeObjectType(jSTypeNative63);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter65 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter65, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative68 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry67.getNativeObjectType(jSTypeNative68);
        java.util.Set<java.lang.String> strSet70 = objectType69.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter71 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry73 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter71, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative74 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry73.getNativeObjectType(jSTypeNative74);
        com.google.javascript.rhino.jstype.JSType jSType76 = objectType75.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter77 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter77, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative80 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType81 = jSTypeRegistry79.getNativeObjectType(jSTypeNative80);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter82 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry84 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter82, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative85 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry84.getNativeObjectType(jSTypeNative85);
        com.google.javascript.rhino.jstype.JSType jSType87 = objectType86.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray88 = new com.google.javascript.rhino.jstype.JSType[] { objectType59, objectType64, objectType69, objectType75, objectType81, jSType87 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType89 = jSTypeRegistry48.createTemplatizedType(objectType53, jSTypeArray88);
        boolean boolean90 = templatizedType89.hasReferenceName();
        boolean boolean91 = templatizedType89.isConstructor();
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList92 = templatizedType89.getTemplateTypes();
        boolean boolean94 = templatizedType89.isPropertyTypeDeclared("InputId: ");
        templatizedType43.matchConstraint((com.google.javascript.rhino.jstype.JSType) templatizedType89);
        boolean boolean96 = templatizedType89.isInstanceType();
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative52 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative52.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType53);
        org.junit.Assert.assertNotNull(jSType54);
        org.junit.Assert.assertTrue("'" + jSTypeNative58 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative58.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType59);
        org.junit.Assert.assertTrue("'" + jSTypeNative63 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative63.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType64);
        org.junit.Assert.assertTrue("'" + jSTypeNative68 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative68.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + jSTypeNative74 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative74.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSType76);
        org.junit.Assert.assertTrue("'" + jSTypeNative80 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative80.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + jSTypeNative85 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative85.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertNotNull(jSTypeArray88);
        org.junit.Assert.assertNotNull(templatizedType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(jSTypeList92);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isDo();
        com.google.javascript.rhino.InputId inputId6 = new com.google.javascript.rhino.InputId("");
        node3.setInputId(inputId6);
        boolean boolean8 = node3.isVar();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean11 = node10.isEmpty();
        com.google.javascript.rhino.Node node12 = node9.copyInformationFromForTree(node10);
        node10.setLength(0);
        boolean boolean15 = node10.isQualifiedName();
        com.google.javascript.rhino.Node node16 = node3.srcref(node10);
        node3.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        boolean boolean5 = objectType4.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter6 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter6, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative9 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType10 = jSTypeRegistry8.getNativeObjectType(jSTypeNative9);
        com.google.javascript.rhino.jstype.JSType jSType11 = objectType10.collapseUnion();
        boolean boolean12 = objectType10.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType13 = objectType4.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType10);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter17 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter17, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative20 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType21 = jSTypeRegistry19.getNativeObjectType(jSTypeNative20);
        com.google.javascript.rhino.jstype.JSType jSType22 = objectType21.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative36 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType37 = jSTypeRegistry35.getNativeObjectType(jSTypeNative36);
        java.util.Set<java.lang.String> strSet38 = objectType37.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter39 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry41 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter39, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative42 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType43 = jSTypeRegistry41.getNativeObjectType(jSTypeNative42);
        com.google.javascript.rhino.jstype.JSType jSType44 = objectType43.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter45 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry47 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter45, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative48 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType49 = jSTypeRegistry47.getNativeObjectType(jSTypeNative48);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter50 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry52 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter50, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative53 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType54 = jSTypeRegistry52.getNativeObjectType(jSTypeNative53);
        com.google.javascript.rhino.jstype.JSType jSType55 = objectType54.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray56 = new com.google.javascript.rhino.jstype.JSType[] { objectType27, objectType32, objectType37, objectType43, objectType49, jSType55 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType57 = jSTypeRegistry16.createTemplatizedType(objectType21, jSTypeArray56);
        boolean boolean58 = templatizedType57.hasReferenceName();
        boolean boolean59 = templatizedType57.isConstructor();
        boolean boolean60 = objectType10.canCastTo((com.google.javascript.rhino.jstype.JSType) templatizedType57);
        boolean boolean62 = templatizedType57.removeProperty("");
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative9 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative9.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType10);
        org.junit.Assert.assertNotNull(jSType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative20 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative20.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType21);
        org.junit.Assert.assertNotNull(jSType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative36 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative36.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType37);
        org.junit.Assert.assertNotNull(strSet38);
        org.junit.Assert.assertTrue("'" + jSTypeNative42 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative42.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType43);
        org.junit.Assert.assertNotNull(jSType44);
        org.junit.Assert.assertTrue("'" + jSTypeNative48 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative48.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType49);
        org.junit.Assert.assertTrue("'" + jSTypeNative53 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative53.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType54);
        org.junit.Assert.assertNotNull(jSType55);
        org.junit.Assert.assertNotNull(jSTypeArray56);
        org.junit.Assert.assertNotNull(templatizedType57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_TYPE));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.assumeClosuresOnlyCaptureReferences();
        compilerOptions9.setAngularPass(true);
        boolean boolean13 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = null;
        compilerOptions9.setPropertyRenaming(propertyRenamingPolicy14);
        com.google.javascript.jscomp.MessageFormatter messageFormatter16 = null;
        java.util.logging.Logger logger17 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager18 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter16, logger17);
        compilerOptions9.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager18);
        int int20 = loggerErrorManager18.getWarningCount();
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager18);
        double double22 = loggerErrorManager18.getTypedPercent();
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType23.defaultLevel;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup25 = com.google.javascript.jscomp.DiagnosticGroups.CONST;
        com.google.javascript.jscomp.DiagnosticType diagnosticType26 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String[] strArray27 = new java.lang.String[] {};
        com.google.javascript.jscomp.JSError jSError28 = com.google.javascript.jscomp.JSError.make(diagnosticType26, strArray27);
        boolean boolean29 = diagnosticGroup25.matches(jSError28);
        try {
            loggerErrorManager18.println(checkLevel24, jSError28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup25);
        org.junit.Assert.assertNotNull(diagnosticType26);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(jSError28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.breakNode();
        boolean boolean1 = node0.isDebugger();
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder3 = node2.getJsDocBuilderForNode();
        boolean boolean4 = node2.hasChildren();
        com.google.javascript.rhino.InputId inputId5 = node2.getInputId();
        com.google.javascript.rhino.Node node6 = node0.copyInformationFromForTree(node2);
        try {
            com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.IR.exprResult(node0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(inputId5);
        org.junit.Assert.assertNotNull(node6);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker4 = null;
        compiler3.tracker = performanceTracker4;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray6 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule8 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile10 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str11 = sourceFile10.getCode();
        jSModule8.addFirst(sourceFile10);
        com.google.javascript.jscomp.JSModule[] jSModuleArray13 = new com.google.javascript.jscomp.JSModule[] { jSModule8 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions14 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions14.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle17 = compilerOptions14.messageBundle;
        compiler3.init(jSSourceFileArray6, jSModuleArray13, compilerOptions14);
        com.google.javascript.jscomp.ErrorManager errorManager19 = compiler3.getErrorManager();
        boolean boolean20 = compiler3.acceptEcmaScript5();
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter21 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback22 = null;
        com.google.javascript.jscomp.NodeTraversal nodeTraversal23 = new com.google.javascript.jscomp.NodeTraversal((com.google.javascript.jscomp.AbstractCompiler) compiler3, callback22);
        com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec assertInstanceofSpec25 = new com.google.javascript.jscomp.ClosureCodingConvention.AssertInstanceofSpec("");
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean27 = node26.isContinue();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter28 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter28, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative31 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType32 = jSTypeRegistry30.getNativeObjectType(jSTypeNative31);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter33 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry35 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter33, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter42 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry44 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter42, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative45 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType46 = jSTypeRegistry44.getNativeObjectType(jSTypeNative45);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter47 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry49 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter47, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative50 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType51 = jSTypeRegistry49.getNativeObjectType(jSTypeNative50);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter52 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter52, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative55 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType56 = jSTypeRegistry54.getNativeObjectType(jSTypeNative55);
        java.util.Set<java.lang.String> strSet57 = objectType56.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter58 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry60 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter58, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType62 = jSTypeRegistry60.getNativeObjectType(jSTypeNative61);
        com.google.javascript.rhino.jstype.JSType jSType63 = objectType62.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter64 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry66 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter64, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative67 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType68 = jSTypeRegistry66.getNativeObjectType(jSTypeNative67);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter69 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry71 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter69, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative72 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType73 = jSTypeRegistry71.getNativeObjectType(jSTypeNative72);
        com.google.javascript.rhino.jstype.JSType jSType74 = objectType73.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] { objectType46, objectType51, objectType56, objectType62, objectType68, jSType74 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType76 = jSTypeRegistry35.createTemplatizedType(objectType40, jSTypeArray75);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection77 = jSTypeRegistry30.getDirectImplementors(objectType40);
        com.google.javascript.rhino.jstype.JSType jSType78 = assertInstanceofSpec25.getAssertedType(node26, jSTypeRegistry30);
        com.google.javascript.rhino.Node[] nodeArray79 = new com.google.javascript.rhino.Node[] {};
        com.google.javascript.rhino.Node node80 = com.google.javascript.rhino.IR.objectlit(nodeArray79);
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.IR.script(nodeArray79);
        com.google.javascript.rhino.Node node82 = com.google.javascript.rhino.IR.newNode(node26, nodeArray79);
        nodeTraversal23.traverseRoots(nodeArray79);
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.IR.call(node0, nodeArray79);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(jSSourceFileArray6);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(jSModuleArray13);
        org.junit.Assert.assertNull(messageBundle17);
        org.junit.Assert.assertNotNull(errorManager19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + jSTypeNative31 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative31.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType32);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertTrue("'" + jSTypeNative45 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative45.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType46);
        org.junit.Assert.assertTrue("'" + jSTypeNative50 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative50.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType51);
        org.junit.Assert.assertTrue("'" + jSTypeNative55 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative55.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType56);
        org.junit.Assert.assertNotNull(strSet57);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType62);
        org.junit.Assert.assertNotNull(jSType63);
        org.junit.Assert.assertTrue("'" + jSTypeNative67 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative67.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType68);
        org.junit.Assert.assertTrue("'" + jSTypeNative72 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative72.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType73);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertNotNull(templatizedType76);
        org.junit.Assert.assertNotNull(functionTypeCollection77);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(nodeArray79);
        org.junit.Assert.assertNotNull(node80);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node84);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isRegExp();
        node6.setDouble((double) (-1.0f));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.IR.pos(node6);
        try {
            com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.IR.label(node0, node6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setRemoveClosureAsserts(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.assumeClosuresOnlyCaptureReferences();
        compilerOptions3.setAngularPass(true);
        boolean boolean7 = compilerOptions3.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions3.setPropertyRenaming(propertyRenamingPolicy8);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode11 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray15 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet16 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet16, strArray15);
        com.google.javascript.jscomp.parsing.Config config18 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode11, false, (java.util.Set<java.lang.String>) strSet16);
        compilerOptions3.aliasableStrings = strSet16;
        compilerOptions0.setReplaceStringsReservedStrings((java.util.Set<java.lang.String>) strSet16);
        com.google.javascript.jscomp.CompilerOptions compilerOptions21 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean22 = compilerOptions21.assumeClosuresOnlyCaptureReferences();
        compilerOptions21.setAngularPass(true);
        boolean boolean25 = compilerOptions21.gatherCssNames;
        compilerOptions21.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel28 = null;
        compilerOptions21.checkUnreachableCode = checkLevel28;
        compilerOptions21.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy32 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions21.setPropertyRenaming(propertyRenamingPolicy32);
        com.google.javascript.jscomp.CheckLevel checkLevel34 = compilerOptions21.checkGlobalThisLevel;
        compilerOptions0.setCheckMissingReturn(checkLevel34);
        java.lang.String str36 = compilerOptions0.renamePrefixNamespace;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + languageMode11 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode11.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(config18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy32 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy32.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + checkLevel34 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel34.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str36);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.markAsCompiled = false;
        compilerOptions0.setRemoveUnusedPrototypePropertiesInExterns(true);
        org.junit.Assert.assertNotNull(format3);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        boolean boolean2 = node0.isNoSideEffectsCall();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean7 = node6.isDo();
        com.google.javascript.rhino.InputId inputId9 = new com.google.javascript.rhino.InputId("");
        node6.setInputId(inputId9);
        boolean boolean11 = node6.isAssign();
        com.google.javascript.rhino.Node node12 = node0.srcref(node6);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.rhino.head.ast.AstRoot astRoot5 = compiler1.getOldParseTreeByName("InputId: ");
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.assumeClosuresOnlyCaptureReferences();
        compilerOptions6.setAngularPass(true);
        boolean boolean10 = compilerOptions6.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = null;
        compilerOptions6.setPropertyRenaming(propertyRenamingPolicy11);
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = null;
        java.util.logging.Logger logger14 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager15 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter13, logger14);
        compilerOptions6.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager15);
        compiler1.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager15);
        com.google.javascript.jscomp.JSError[] jSErrorArray18 = compiler1.getWarnings();
        com.google.javascript.jscomp.Scope scope19 = compiler1.getTopScope();
        com.google.javascript.jscomp.JSError[] jSErrorArray20 = compiler1.getWarnings();
        com.google.javascript.jscomp.JSError[] jSErrorArray21 = compiler1.getErrors();
        org.junit.Assert.assertNull(astRoot5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(jSErrorArray18);
        org.junit.Assert.assertNull(scope19);
        org.junit.Assert.assertNotNull(jSErrorArray20);
        org.junit.Assert.assertNotNull(jSErrorArray21);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node(10);
        boolean boolean2 = node1.isVar();
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder4 = node3.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node5 = node1.useSourceInfoIfMissingFromForTree(node3);
        node5.setWasEmptyNode(true);
        boolean boolean8 = node5.isQualifiedName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder4);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder1 = node0.getJsDocBuilderForNode();
        boolean boolean2 = node0.hasChildren();
        boolean boolean3 = node0.isComma();
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.assumeClosuresOnlyCaptureReferences();
        compilerOptions9.setAngularPass(true);
        boolean boolean13 = compilerOptions9.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy14 = null;
        compilerOptions9.setPropertyRenaming(propertyRenamingPolicy14);
        com.google.javascript.jscomp.MessageFormatter messageFormatter16 = null;
        java.util.logging.Logger logger17 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager18 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter16, logger17);
        compilerOptions9.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager18);
        int int20 = loggerErrorManager18.getWarningCount();
        compilerOptions0.setErrorHandler((com.google.javascript.jscomp.ErrorHandler) loggerErrorManager18);
        compilerOptions0.setSummaryDetailLevel(56);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode10 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode10, false, (java.util.Set<java.lang.String>) strSet15);
        compilerOptions0.stripTypes = strSet15;
        com.google.javascript.jscomp.CompilerOptions compilerOptions19 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean20 = compilerOptions19.assumeClosuresOnlyCaptureReferences();
        compilerOptions19.generateExports = false;
        compilerOptions19.setProcessObjectPropertyString(false);
        compilerOptions19.removeUnusedLocalVars = false;
        compilerOptions19.resetWarningsGuard();
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy28 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions19.variableRenaming = variableRenamingPolicy28;
        compilerOptions0.variableRenaming = variableRenamingPolicy28;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + languageMode10 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode10.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(config17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy28 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy28.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter7 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSTypeRegistry9.getNativeObjectType(jSTypeNative10);
        com.google.javascript.rhino.jstype.JSType jSType12 = objectType11.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        java.util.Set<java.lang.String> strSet28 = objectType27.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType33.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = objectType44.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] { objectType17, objectType22, objectType27, objectType33, objectType39, jSType45 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType47 = jSTypeRegistry6.createTemplatizedType(objectType11, jSTypeArray46);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection48 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) templatizedType47);
        boolean boolean49 = templatizedType47.isRecordType();
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertNotNull(templatizedType47);
        org.junit.Assert.assertNotNull(functionTypeCollection48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber(100.0d, (int) 'a', (int) (byte) 100);
        boolean boolean4 = node3.isRegExp();
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean7 = node6.isEmpty();
        com.google.javascript.rhino.Node node8 = node5.copyInformationFromForTree(node6);
        boolean boolean9 = node8.isLocalResultCall();
        node3.addChildrenToFront(node8);
        com.google.javascript.rhino.head.ast.AstRoot astRoot11 = null;
        com.google.javascript.jscomp.parsing.ParserRunner.ParseResult parseResult12 = new com.google.javascript.jscomp.parsing.ParserRunner.ParseResult(node8, astRoot11);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.IR.continueNode();
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.IR.falseNode();
        boolean boolean15 = node14.isEmpty();
        com.google.javascript.rhino.Node node16 = node13.copyInformationFromForTree(node14);
        com.google.javascript.rhino.Node node17 = node8.useSourceInfoFrom(node14);
        boolean boolean18 = node17.isGetProp();
        node17.setSourceEncodedPositionForTree(0);
        com.google.javascript.rhino.Node node21 = node17.getNext();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node21);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        boolean boolean11 = compilerOptions0.lineBreak;
        boolean boolean12 = compilerOptions0.shouldColorizeErrorOutput();
        boolean boolean13 = compilerOptions0.assumeStrictThis();
        compilerOptions0.setCrossModuleMethodMotion(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter4 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter4, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter7 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter7, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType11 = jSTypeRegistry9.getNativeObjectType(jSTypeNative10);
        com.google.javascript.rhino.jstype.JSType jSType12 = objectType11.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter13 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry15 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter13, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative16 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType17 = jSTypeRegistry15.getNativeObjectType(jSTypeNative16);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter18 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter18, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative21 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType22 = jSTypeRegistry20.getNativeObjectType(jSTypeNative21);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter23 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter23, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative26 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType27 = jSTypeRegistry25.getNativeObjectType(jSTypeNative26);
        java.util.Set<java.lang.String> strSet28 = objectType27.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter29 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter29, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative32 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType33 = jSTypeRegistry31.getNativeObjectType(jSTypeNative32);
        com.google.javascript.rhino.jstype.JSType jSType34 = objectType33.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter35 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter35, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative38 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType39 = jSTypeRegistry37.getNativeObjectType(jSTypeNative38);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter40 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry42 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter40, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative43 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType44 = jSTypeRegistry42.getNativeObjectType(jSTypeNative43);
        com.google.javascript.rhino.jstype.JSType jSType45 = objectType44.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray46 = new com.google.javascript.rhino.jstype.JSType[] { objectType17, objectType22, objectType27, objectType33, objectType39, jSType45 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType47 = jSTypeRegistry6.createTemplatizedType(objectType11, jSTypeArray46);
        java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection48 = jSTypeRegistry2.getDirectImplementors((com.google.javascript.rhino.jstype.ObjectType) templatizedType47);
        com.google.javascript.rhino.jstype.ObjectType objectType49 = templatizedType47.getImplicitPrototype();
        boolean boolean50 = templatizedType47.isNativeObjectType();
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType11);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertTrue("'" + jSTypeNative16 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative16.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType17);
        org.junit.Assert.assertTrue("'" + jSTypeNative21 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative21.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType22);
        org.junit.Assert.assertTrue("'" + jSTypeNative26 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative26.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType27);
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + jSTypeNative32 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative32.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType33);
        org.junit.Assert.assertNotNull(jSType34);
        org.junit.Assert.assertTrue("'" + jSTypeNative38 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative38.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType39);
        org.junit.Assert.assertTrue("'" + jSTypeNative43 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative43.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType44);
        org.junit.Assert.assertNotNull(jSType45);
        org.junit.Assert.assertNotNull(jSTypeArray46);
        org.junit.Assert.assertNotNull(templatizedType47);
        org.junit.Assert.assertNotNull(functionTypeCollection48);
        org.junit.Assert.assertNull(objectType49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode10 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet15 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean16 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet15, strArray14);
        com.google.javascript.jscomp.parsing.Config config17 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode10, false, (java.util.Set<java.lang.String>) strSet15);
        compilerOptions0.stripTypes = strSet15;
        compilerOptions0.setTweakToStringLiteral("Named type with empty name component", "");
        compilerOptions0.setLineBreak(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + languageMode10 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode10.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(config17);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType4 = jSTypeRegistry2.getNativeObjectType(jSTypeNative3);
        com.google.javascript.rhino.jstype.JSType jSType5 = objectType4.collapseUnion();
        boolean boolean6 = objectType4.isAllType();
        boolean boolean7 = objectType4.isTemplatizedType();
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType4);
        org.junit.Assert.assertNotNull(jSType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setGeneratePseudoNames(false);
        compilerOptions0.setRuntimeTypeCheck(false);
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.gatherCssNames = false;
        compilerOptions0.setOutputJsStringUsage(true);
        com.google.javascript.jscomp.CompilerOptions compilerOptions10 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions10.syntheticBlockEndMarker = "(InputId: )";
        com.google.javascript.jscomp.SourceMap.Format format13 = compilerOptions10.sourceMapFormat;
        compilerOptions10.setProcessCommonJSModules(true);
        com.google.javascript.jscomp.CheckLevel checkLevel16 = compilerOptions10.checkGlobalThisLevel;
        com.google.javascript.jscomp.CompilerOptions compilerOptions17 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean18 = compilerOptions17.assumeClosuresOnlyCaptureReferences();
        compilerOptions17.setAngularPass(true);
        boolean boolean21 = compilerOptions17.gatherCssNames;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy22 = null;
        compilerOptions17.setPropertyRenaming(propertyRenamingPolicy22);
        com.google.javascript.jscomp.parsing.Config.LanguageMode languageMode25 = com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5;
        java.lang.String[] strArray29 = new java.lang.String[] { "", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet30 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet30, strArray29);
        com.google.javascript.jscomp.parsing.Config config32 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false, languageMode25, false, (java.util.Set<java.lang.String>) strSet30);
        compilerOptions17.aliasableStrings = strSet30;
        compilerOptions10.setCssRenamingWhitelist((java.util.Set<java.lang.String>) strSet30);
        com.google.javascript.jscomp.CompilerOptions.Reach reach35 = com.google.javascript.jscomp.CompilerOptions.Reach.ALL;
        compilerOptions10.setRemoveUnusedVariable(reach35);
        compilerOptions0.setInlineFunctions(reach35);
        org.junit.Assert.assertNotNull(format13);
        org.junit.Assert.assertTrue("'" + checkLevel16 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel16.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + languageMode25 + "' != '" + com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5 + "'", languageMode25.equals(com.google.javascript.jscomp.parsing.Config.LanguageMode.ECMASCRIPT5));
        org.junit.Assert.assertNotNull(strArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(config32);
        org.junit.Assert.assertTrue("'" + reach35 + "' != '" + com.google.javascript.jscomp.CompilerOptions.Reach.ALL + "'", reach35.equals(com.google.javascript.jscomp.CompilerOptions.Reach.ALL));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("EXPR_RESULT", false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setAmbiguateProperties(true);
        java.util.List<com.google.javascript.jscomp.SourceMap.LocationMapping> locationMappingList5 = compilerOptions0.sourceMapLocationMappings;
        compilerOptions0.generateExports = true;
        boolean boolean8 = compilerOptions0.generatePseudoNames;
        compilerOptions0.setAliasKeywords(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locationMappingList5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        com.google.javascript.rhino.Node node0 = com.google.javascript.rhino.IR.continueNode();
        boolean boolean1 = node0.isContinue();
        boolean boolean2 = node0.isNoSideEffectsCall();
        node0.setCharno(55);
        org.junit.Assert.assertNotNull(node0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test71");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.checkUnreachableCode = checkLevel7;
        compilerOptions0.setRuntimeTypeCheck(false);
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setPropertyRenaming(propertyRenamingPolicy11);
        compilerOptions0.markAsCompiled = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        boolean boolean2 = compilerOptions0.generateExports;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 'a');
        compilerOptions0.prettyPrint = false;
        boolean boolean8 = compilerOptions0.optimizeCalls;
        boolean boolean9 = compilerOptions0.aliasKeywords;
        compilerOptions0.setPreferSingleQuotes(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker2 = null;
        compiler1.tracker = performanceTracker2;
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray4 = new com.google.javascript.jscomp.JSSourceFile[] {};
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.SourceFile sourceFile8 = new com.google.javascript.jscomp.SourceFile("hi!");
        java.lang.String str9 = sourceFile8.getCode();
        jSModule6.addFirst(sourceFile8);
        com.google.javascript.jscomp.JSModule[] jSModuleArray11 = new com.google.javascript.jscomp.JSModule[] { jSModule6 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions12 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions12.optimizeArgumentsArray = true;
        com.google.javascript.jscomp.MessageBundle messageBundle15 = compilerOptions12.messageBundle;
        compiler1.init(jSSourceFileArray4, jSModuleArray11, compilerOptions12);
        boolean boolean17 = compiler1.isIdeMode();
        com.google.javascript.jscomp.type.ReverseAbstractInterpreter reverseAbstractInterpreter18 = compiler1.getReverseAbstractInterpreter();
        compiler1.rebuildInputsFromModules();
        org.junit.Assert.assertNotNull(jSSourceFileArray4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(jSModuleArray11);
        org.junit.Assert.assertNull(messageBundle15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(reverseAbstractInterpreter18);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.assumeClosuresOnlyCaptureReferences();
        compilerOptions0.setAngularPass(true);
        boolean boolean4 = compilerOptions0.gatherCssNames;
        compilerOptions0.setOptimizeReturns(false);
        compilerOptions0.setConvertToDottedProperties(true);
        compilerOptions0.disambiguateProperties = false;
        compilerOptions0.setCheckDeterminism(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("Object");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter5 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter5, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative8 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry7.getNativeObjectType(jSTypeNative8);
        boolean boolean10 = objectType9.isEmptyType();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter11 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter11, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative14 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType15 = jSTypeRegistry13.getNativeObjectType(jSTypeNative14);
        com.google.javascript.rhino.jstype.JSType jSType16 = objectType15.collapseUnion();
        boolean boolean17 = objectType15.canBeCalled();
        com.google.javascript.rhino.jstype.JSType jSType18 = objectType9.getGreatestSubtype((com.google.javascript.rhino.jstype.JSType) objectType15);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList19 = objectType15.getTemplateTypes();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] { objectType15 };
        com.google.javascript.rhino.Node node21 = jSTypeRegistry2.createParametersWithVarArgs(jSTypeArray20);
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode22 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES;
        jSTypeRegistry2.setResolveMode(resolveMode22);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder24 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder26 = functionBuilder24.withName("(InputId: )");
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative8 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative8.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + jSTypeNative14 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative14.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType15);
        org.junit.Assert.assertNotNull(jSType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSType18);
        org.junit.Assert.assertNull(jSTypeList19);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertTrue("'" + resolveMode22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES + "'", resolveMode22.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_NAMES));
        org.junit.Assert.assertNotNull(functionBuilder26);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter0 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter0, false);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter3 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter3, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType7 = jSTypeRegistry5.getNativeObjectType(jSTypeNative6);
        com.google.javascript.rhino.jstype.JSType jSType8 = objectType7.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter9 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry11 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter9, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative12 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType13 = jSTypeRegistry11.getNativeObjectType(jSTypeNative12);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter14 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter14, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative17 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType18 = jSTypeRegistry16.getNativeObjectType(jSTypeNative17);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter19 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter19, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative22 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType23 = jSTypeRegistry21.getNativeObjectType(jSTypeNative22);
        java.util.Set<java.lang.String> strSet24 = objectType23.getOwnPropertyNames();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter25 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry27 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter25, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative28 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType29 = jSTypeRegistry27.getNativeObjectType(jSTypeNative28);
        com.google.javascript.rhino.jstype.JSType jSType30 = objectType29.collapseUnion();
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter31 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter31, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative34 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType35 = jSTypeRegistry33.getNativeObjectType(jSTypeNative34);
        com.google.javascript.rhino.SimpleErrorReporter simpleErrorReporter36 = new com.google.javascript.rhino.SimpleErrorReporter();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry38 = new com.google.javascript.rhino.jstype.JSTypeRegistry((com.google.javascript.rhino.ErrorReporter) simpleErrorReporter36, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative39 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType40 = jSTypeRegistry38.getNativeObjectType(jSTypeNative39);
        com.google.javascript.rhino.jstype.JSType jSType41 = objectType40.collapseUnion();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray42 = new com.google.javascript.rhino.jstype.JSType[] { objectType13, objectType18, objectType23, objectType29, objectType35, jSType41 };
        com.google.javascript.rhino.jstype.TemplatizedType templatizedType43 = jSTypeRegistry2.createTemplatizedType(objectType7, jSTypeArray42);
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.TemplateType> templateTypeList44 = null;
        com.google.common.collect.ImmutableList<com.google.javascript.rhino.jstype.JSType> jSTypeList45 = null;
        com.google.javascript.rhino.jstype.TemplateTypeMap templateTypeMap46 = jSTypeRegistry2.createTemplateTypeMap(templateTypeList44, jSTypeList45);
        com.google.javascript.rhino.jstype.TemplateType templateType47 = null;
        boolean boolean48 = templateTypeMap46.hasTemplateKey(templateType47);
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType7);
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + jSTypeNative12 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative12.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType13);
        org.junit.Assert.assertTrue("'" + jSTypeNative17 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative17.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType18);
        org.junit.Assert.assertTrue("'" + jSTypeNative22 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative22.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType23);
        org.junit.Assert.assertNotNull(strSet24);
        org.junit.Assert.assertTrue("'" + jSTypeNative28 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative28.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType29);
        org.junit.Assert.assertNotNull(jSType30);
        org.junit.Assert.assertTrue("'" + jSTypeNative34 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative34.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType35);
        org.junit.Assert.assertTrue("'" + jSTypeNative39 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative39.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(objectType40);
        org.junit.Assert.assertNotNull(jSType41);
        org.junit.Assert.assertNotNull(jSTypeArray42);
        org.junit.Assert.assertNotNull(templatizedType43);
        org.junit.Assert.assertNotNull(templateTypeMap46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }
}

