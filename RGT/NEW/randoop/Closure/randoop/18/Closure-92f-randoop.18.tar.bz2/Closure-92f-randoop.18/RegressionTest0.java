import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("hi!");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput1 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "hi!", "" };
        try {
            com.google.javascript.jscomp.JSError jSError5 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = null;
        com.google.javascript.jscomp.DefaultPassConfig defaultPassConfig1 = new com.google.javascript.jscomp.DefaultPassConfig(compilerOptions0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Node.IS_OPTIONAL_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 43 + "'", int0 == 43);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = com.google.javascript.rhino.Node.ORIGINALNAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 39 + "'", int0 == 39);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "");
        try {
            com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(49, node10, node12, node15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node15);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.NO_DUPLICATE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        com.google.javascript.rhino.jstype.JSType jSType0 = null;
        com.google.javascript.rhino.jstype.JSType jSType1 = null;
        boolean boolean2 = com.google.javascript.rhino.jstype.JSType.isEquivalent(jSType0, jSType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Node.CONTINUE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "");
        try {
            double double3 = node2.getDouble();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR  is not a number node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("", "TYPEOF ", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.Context.VERSION_DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = com.google.javascript.rhino.Node.NAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 33 + "'", int0 == 33);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("TYPEOF ", "", "TYPEOF ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TYPEOF ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double0 = com.google.javascript.rhino.ScriptRuntime.negativeZero;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + (-0.0d) + "'", double0 == (-0.0d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = com.google.javascript.rhino.Node.TARGETBLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        try {
            node4.setSideEffectFlags(29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got TYPEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = com.google.javascript.rhino.Context.FEATURE_E4X;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("TYPEOF ", "TYPEOF ", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TYPEOF ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("TYPEOF ", "", "hi!", (int) (short) 100, "hi!", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.getName();
        java.lang.String str4 = sourceFile2.getOriginalPath();
        java.lang.String str6 = sourceFile2.getLine(47);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        com.google.javascript.rhino.Context context0 = null;
        try {
            com.google.javascript.rhino.ScriptRuntime.storeUint32Result(context0, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        try {
//            com.google.javascript.rhino.Context.reportError("");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.IMMEDIATE));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("hi!", "hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        java.lang.Object obj18 = node16.getProp(1);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = com.google.javascript.rhino.Node.COLUMN_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative1 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE;
        try {
            java.lang.String str4 = com.google.javascript.rhino.ScriptRuntime.getMessage3("TYPEOF ", (java.lang.Object) jSTypeNative1, (java.lang.Object) 49, (java.lang.Object) jSTypeNative3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TYPEOF ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative1 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative1.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_TYPE));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_TYPE));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            com.google.javascript.rhino.Context.reportWarning("TYPEOF ");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("hi!", (java.lang.Object) diagnosticGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        boolean boolean3 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = com.google.javascript.rhino.Node.DECR_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder1, (java.lang.Object) node57, (java.lang.Object) jSTypeNative60);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node72 = node66.clonePropsFrom(node71);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node78 = node66.copyInformationFromForTree(node77);
        boolean boolean79 = node57.checkTreeEqualsSilent(node66);
        node66.setIsSyntheticBlock(false);
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags82 = null;
        try {
            node66.setSideEffectFlags(sideEffectFlags82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException61);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_ALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Context.FEATURE_DYNAMIC_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString((java.lang.Object) 10.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_FUNCTION_TYPE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_TYPE));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_2;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = node24.copyInformationFromForTree(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = node41.clonePropsFrom(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node52.clonePropsFrom(node57);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node63.clonePropsFrom(node68);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node75 = node63.copyInformationFromForTree(node74);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((-1), node35, node47, node57, node74);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException78 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder18, (java.lang.Object) node74, (java.lang.Object) jSTypeNative77);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node89 = node83.clonePropsFrom(node88);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node95 = node83.copyInformationFromForTree(node94);
        boolean boolean96 = node74.checkTreeEqualsSilent(node83);
        boolean boolean97 = node83.isSyntheticBlock();
        boolean boolean98 = node16.checkTreeEqualsSilent(node83);
        int int99 = node16.getLineno();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException78);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + (-1) + "'", int99 == (-1));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags62 = null;
        try {
            node61.setSideEffectFlags(sideEffectFlags62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = com.google.javascript.rhino.Node.PROPERTY_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("TYPEOF \n", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_TYPE));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Node.LABEL_ID_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        node57.putProp(0, (java.lang.Object) 33);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(10, "TYPEOF ", 32, (int) (short) 10);
        node4.setLineno(28);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node12 = node4.getNext();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(node12);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder1, (java.lang.Object) node57, (java.lang.Object) jSTypeNative60);
        boolean boolean62 = node57.hasOneChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder63 = node57.getJsDocBuilderForNode();
        fileLevelJsDocBuilder63.append("10");
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder63);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node18.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node18.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node57.clonePropsFrom(node62);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node57.copyInformationFromForTree(node68);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((-1), node29, node41, node51, node68);
        com.google.javascript.rhino.Node node71 = node70.cloneTree();
        node70.setCharno((int) '#');
        com.google.javascript.rhino.Node node74 = node70.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable75 = node74.siblings();
        try {
            node4.replaceChild(node12, node74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(nodeIterable75);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
        java.lang.String str22 = node9.checkTreeEquals(node15);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.JSError jSError4 = null;
        try {
            loggerErrorManager1.report(checkLevel3, jSError4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter3 = context1.setErrorReporter(errorReporter2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.SKIP_INDEXES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            com.google.javascript.jscomp.SourceFile sourceFile5 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_PARAMETER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        node38.setType(48);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("10");
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "", 3);
        try {
            evaluatorException3.initSourceName("TYPEOF ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Node.LOCAL_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-3) + "'", int0 == (-3));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SOURCELESS;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        loggerErrorManager1.setTypedPercent((double) 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        com.google.javascript.jscomp.DiagnosticGroups diagnosticGroups0 = new com.google.javascript.jscomp.DiagnosticGroups();
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        com.google.javascript.jscomp.CheckLevel checkLevel2 = com.google.javascript.jscomp.CheckLevel.ERROR;
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            loggerErrorManager1.report(checkLevel2, jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        try {
//            context1.removeActivationName("");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder18 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry17);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = node24.copyInformationFromForTree(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = node41.clonePropsFrom(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node52.clonePropsFrom(node57);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node63.clonePropsFrom(node68);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node75 = node63.copyInformationFromForTree(node74);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((-1), node35, node47, node57, node74);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative77 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException78 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder18, (java.lang.Object) node74, (java.lang.Object) jSTypeNative77);
        com.google.javascript.rhino.Node node83 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node88 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node89 = node83.clonePropsFrom(node88);
        com.google.javascript.rhino.Node node94 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node95 = node83.copyInformationFromForTree(node94);
        boolean boolean96 = node74.checkTreeEqualsSilent(node83);
        boolean boolean97 = node83.isSyntheticBlock();
        boolean boolean98 = node16.checkTreeEqualsSilent(node83);
        node83.setQuotedString();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertTrue("'" + jSTypeNative77 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative77.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException78);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node89);
        org.junit.Assert.assertNotNull(node94);
        org.junit.Assert.assertNotNull(node95);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile("");
        org.junit.Assert.assertNotNull(sourceFile1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        try {
            com.google.javascript.jscomp.JSModule jSModule7 = jSModuleGraph3.getDeepestCommonDependencyInclusive((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5);
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: null");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.getName();
        java.lang.String str5 = sourceFile2.getLine(32);
        sourceFile2.setOriginalPath("hi!");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        try {
//            context1.setLanguageVersion((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromCode("", "", "hi!");
        java.io.Reader reader8 = sourceFile7.getCodeReader();
        java.lang.String str9 = sourceFile7.getName();
        try {
            compilerInput3.setSourceFile(sourceFile7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile7);
        org.junit.Assert.assertNotNull(reader8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(10, "TYPEOF ", 32, (int) (short) 10);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        java.lang.Object obj65 = node63.getProp(29);
        try {
            com.google.javascript.rhino.Node node66 = node4.removeChildAfter(node63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(obj65);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromGenerator("", generator1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        com.google.javascript.jscomp.ErrorManager errorManager0 = null;
        try {
            com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(errorManager0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: the error manager cannot be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        node4.setCharno((int) ' ');
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.resolve(errorReporter76, jSTypeStaticScope77);
        boolean boolean79 = jSType78.isNoObjectType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder8 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry7);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative67 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException68 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder8, (java.lang.Object) node64, (java.lang.Object) jSTypeNative67);
        com.google.javascript.rhino.Node node73 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node79 = node73.clonePropsFrom(node78);
        com.google.javascript.rhino.Node node84 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node85 = node73.copyInformationFromForTree(node84);
        boolean boolean86 = node64.checkTreeEqualsSilent(node73);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder87 = node64.new FileLevelJsDocBuilder();
        java.lang.String str88 = defaultCodingConvention0.getSingletonGetterClassName(node64);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertTrue("'" + jSTypeNative67 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative67.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException68);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node84);
        org.junit.Assert.assertNotNull(node85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNull(str88);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter5 = context1.setErrorReporter(errorReporter4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REFERENCE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.MULTILINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        java.util.Map<java.lang.String, com.google.javascript.rhino.jstype.JSType> strMap70 = null;
        try {
            com.google.javascript.rhino.jstype.RecordType recordType71 = jSTypeRegistry2.createRecordType(strMap70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        try {
            java.util.List<java.lang.String> strList9 = jSModule8.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = node3.getAncestors();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder5 = node3.new FileLevelJsDocBuilder();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(ancestorIterable4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = com.google.javascript.rhino.Node.BREAK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int0 = com.google.javascript.rhino.Node.IS_DISPATCHER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        try {
            node61.setSideEffectFlags((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got TYPEOF");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        boolean boolean81 = functionType74.isInstanceType();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType74.getIndexType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(jSType82);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList0 = null;
        try {
            com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleList0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node16.cloneTree();
        com.google.javascript.rhino.JSDocInfo jSDocInfo59 = null;
        node58.setJSDocInfo(jSDocInfo59);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo78, false);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = functionType74.getConstructor();
        try {
            boolean boolean82 = functionType81.isInterface();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(functionType81);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo78, false);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = functionType74.getConstructor();
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate82 = null;
        try {
            boolean boolean83 = functionType81.setValidator(jSTypePredicate82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(functionType81);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "TYPEOF \n", 18);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        java.lang.String str62 = node57.getQualifiedName();
        java.lang.String str63 = node57.getQualifiedName();
        boolean boolean64 = node57.hasChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            com.google.javascript.rhino.EcmaError ecmaError6 = com.google.javascript.rhino.ScriptRuntime.constructError("TYPEOF ", "TYPEOF \n", "TYPEOF \n", (-2), "Not declared as a type name", (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.JSType jSType79 = jSType78.restrictByNotNullOrUndefined();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(jSType79);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            java.lang.String str5 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup4;
        boolean boolean7 = composeWarningsGuard3.enables(diagnosticGroup4);
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup4;
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = com.google.javascript.rhino.Node.QUOTED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 35 + "'", int0 == 35);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECT_FLAGS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Object obj0 = null;
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.toString(obj0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, (int) (short) 0, 22);
        int int5 = scriptOrFnNode3.getParamOrVarIndex("");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder1, (java.lang.Object) node57, (java.lang.Object) jSTypeNative60);
        java.lang.Throwable[] throwableArray62 = runtimeException61.getSuppressed();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException61);
        org.junit.Assert.assertNotNull(throwableArray62);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo79, true);
        boolean boolean82 = functionType74.isObject();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.JSDocInfo jSDocInfo71 = null;
        objectType69.setPropertyJSDocInfo("Not declared as a type name", jSDocInfo71, true);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean79 = functionType74.matchesStringContext();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "", "hi!");
        java.lang.String str4 = sourceFile3.getName();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.UNKNOWN_NAME;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Unknown class name" + "'", str0.equals("Unknown class name"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        try {
            java.lang.String str9 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.resolve(errorReporter76, jSTypeStaticScope77);
        com.google.javascript.rhino.jstype.JSType jSType79 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType80 = functionType74.getGreatestSubtype(jSType79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType78);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        try {
            com.google.javascript.rhino.Context.checkLanguageVersion(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = com.google.javascript.rhino.Node.FLAG_LOCAL_RESULTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.rhino.Node[] nodeArray1 = null;
        try {
            com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(43, nodeArray1, 48, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_CONST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        node57.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder64 = node57.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node65 = null;
        try {
            node57.addChildToFront(node65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        try {
            java.util.Collection<java.lang.String> strCollection4 = compilerInput3.getProvides();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        boolean boolean4 = node3.hasOneChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        java.lang.String str1 = diagnosticType0.key;
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str1.equals("JSC_OPTIMIZE_LOOP_ERROR"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope77, "Not declared as a type name", "TYPEOF ", 41, (int) (short) 0);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSType82);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.rhino.FunctionNode functionNode3 = new com.google.javascript.rhino.FunctionNode("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", (int) '#', (int) (byte) 100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean8 = defaultCodingConvention0.isExported("10");
        java.lang.String str9 = defaultCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.UNSPECIFIED));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        boolean boolean81 = functionType74.isInstanceType();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType74.autoboxesTo();
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope84 = null;
        com.google.javascript.rhino.jstype.JSType jSType85 = functionType74.resolve(errorReporter83, jSTypeStaticScope84);
        java.lang.String str86 = functionType74.getTemplateTypeName();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNull(str86);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder1, (java.lang.Object) node57, (java.lang.Object) jSTypeNative60);
        boolean boolean62 = node57.hasOneChild();
        boolean boolean63 = node57.hasChildren();
        boolean boolean64 = node57.hasChildren();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException1 = com.google.javascript.rhino.Context.reportRuntimeError("null");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: null");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = node3.getAncestors();
        java.util.Iterator<com.google.javascript.rhino.Node> nodeItor5 = ancestorIterable4.iterator();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(ancestorIterable4);
        org.junit.Assert.assertNotNull(nodeItor5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.getName();
        java.lang.String str4 = sourceFile2.getOriginalPath();
        java.lang.String str6 = sourceFile2.getLine(7);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(35, 4095, (int) '4');
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.DATE_FUNCTION_TYPE));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = null;
        try {
            com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard1 = new com.google.javascript.jscomp.ComposeWarningsGuard(warningsGuardArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("JSC_OPTIMIZE_LOOP_ERROR", '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("10");
        jSModule1.removeAll();
        java.lang.String str3 = jSModule1.getName();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("Unknown class name", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = objectType79.hasOwnProperty("10");
        boolean boolean82 = objectType79.isResolved();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.resolve(errorReporter76, jSTypeStaticScope77);
        boolean boolean79 = jSType78.isNoType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newExpr(node10);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = node17.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node17.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = node56.clonePropsFrom(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = node56.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((-1), node28, node40, node50, node67);
        com.google.javascript.rhino.Node node70 = node69.cloneTree();
        node69.setCharno((int) '#');
        java.lang.RuntimeException runtimeException73 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node10, (java.lang.Object) '#');
        boolean boolean74 = node5.isEquivalentTo(node10);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(runtimeException73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.lang.Object obj1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder3 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry2);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative62 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException63 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder3, (java.lang.Object) node59, (java.lang.Object) jSTypeNative62);
        boolean boolean64 = node59.hasOneChild();
        boolean boolean65 = node59.hasChildren();
        try {
            java.lang.String str66 = com.google.javascript.rhino.ScriptRuntime.getMessage2("hi!", obj1, (java.lang.Object) boolean65);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertTrue("'" + jSTypeNative62 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative62.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = node8.clonePropsFrom(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node8.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node25.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node47.copyInformationFromForTree(node58);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1), node19, node31, node41, node58);
        com.google.javascript.rhino.Node node61 = node60.cloneTree();
        node60.setCharno((int) '#');
        node60.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope68 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType69 = jSTypeRegistry2.createFromTypeNodes(node60, "TYPEOF ", jSTypeStaticScope68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: ERROR");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node61);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup1 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup1;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        java.lang.RuntimeException runtimeException4 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) 4095, (java.lang.Object) diagnosticGroup1, (java.lang.Object) jSTypeNative3);
        org.junit.Assert.assertNotNull(diagnosticGroup1);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
        org.junit.Assert.assertNotNull(runtimeException4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            com.google.javascript.jscomp.Region region6 = compilerInput3.getRegion((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.JSError[] jSErrorArray9 = loggerErrorManager7.getErrors();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(jSErrorArray9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_INSTANCE_TYPE));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile3);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile7, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray15 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile7, jSSourceFile12 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, jSSourceFileArray15);
        java.nio.charset.Charset charset19 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile20 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset19);
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile20);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        java.nio.charset.Charset charset26 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset26);
        java.nio.charset.Charset charset29 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset29);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile20, jSSourceFile24, jSSourceFile27, jSSourceFile30 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList32 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, jSSourceFileArray31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = null;
        try {
            compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList16, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, compilerOptions34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertNotNull(jSSourceFileArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(jSSourceFile20);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.SourceFile sourceFile7 = com.google.javascript.jscomp.SourceFile.fromFile("", charset6);
        try {
            compilerInput3.setSourceFile(sourceFile7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(sourceFile7);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node6.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node23.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node45.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((-1), node17, node29, node39, node56);
        com.google.javascript.rhino.Node node59 = node58.cloneTree();
        node58.setCharno((int) '#');
        com.google.javascript.rhino.Node node62 = node58.removeFirstChild();
        java.lang.RuntimeException runtimeException63 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) tracerMode0, (java.lang.Object) node62);
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(runtimeException63);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("TYPEOF ", "10");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property TYPEOF ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "hi!", true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE;
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) jSTypeNative0);
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_TYPE));
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = com.google.javascript.rhino.Node.BRACELESS_TYPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 40 + "'", int0 == 40);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.UNKNOWN_TYPE));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            com.google.javascript.rhino.Context.checkOptimizationLevel(32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Optimization level outside [-1..9]: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("TYPEOF ", (int) (byte) 10, (int) (byte) 10);
        com.google.javascript.rhino.Node node4 = node3.getParent();
        com.google.javascript.rhino.Node node5 = node3.getFirstChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "{1813971029}");
        java.lang.String str3 = ecmaError2.getErrorMessage();
        java.lang.String str4 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{1813971029}" + "'", str3.equals("{1813971029}"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Not declared as a type name" + "'", str4.equals("Not declared as a type name"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        jSTypeRegistry2.forwardDeclareType("");
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.Node node1 = null;
        try {
            boolean boolean2 = closureCodingConvention0.isPropertyTestFunction(node1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.level;
        java.lang.String[] strArray5 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError6 = com.google.javascript.jscomp.JSError.make("10", 43, 35, diagnosticType3, strArray5);
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = null;
        try {
            int int8 = diagnosticType3.compareTo(diagnosticType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(jSError6);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newNumber((double) ' ');
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        boolean boolean81 = functionType74.isInstanceType();
        com.google.javascript.rhino.jstype.FunctionPrototypeType functionPrototypeType82 = null;
        boolean boolean83 = functionType74.setPrototype(functionPrototypeType82);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.SourceAst sourceAst4 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNull(sourceAst4);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo78, false);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = functionType74.getConstructor();
        try {
            boolean boolean82 = functionType81.hasInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(functionType81);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = null;
        boolean boolean3 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = functionType74.isPropertyTypeDeclared("TYPEOF \n");
        int int82 = functionType74.getPropertiesCount();
        java.util.Set<java.lang.String> strSet83 = functionType74.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(strSet83);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("", "", "hi!");
        java.lang.String str4 = sourceFile3.toString();
        java.lang.String str5 = sourceFile3.toString();
        java.lang.String str6 = sourceFile3.toString();
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("JSC_OPTIMIZE_LOOP_ERROR", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry9.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType78, jSTypeArray80);
        boolean boolean82 = functionParamBuilder6.addRequiredParams(jSTypeArray80);
        com.google.javascript.rhino.Node node83 = jSTypeRegistry2.createParameters(jSTypeArray80);
        com.google.javascript.rhino.Node node84 = node83.getFirstChild();
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertNull(node84);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "{1813971029}");
        java.lang.String str3 = ecmaError2.getSourceName();
        java.lang.Throwable[] throwableArray4 = ecmaError2.getSuppressed();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope80 = null;
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry79.getForgivingType(jSTypeStaticScope80, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        boolean boolean87 = functionType74.defineDeclaredProperty("TYPEOF ", jSType85, true);
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList88 = null;
        try {
            functionType74.setImplementedInterfaces(objectTypeList88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        boolean boolean2 = defaultCodingConvention0.isPrivate("JSC_OPTIMIZE_LOOP_ERROR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile3 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset2);
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile3);
        java.nio.charset.Charset charset6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset6);
        java.nio.charset.Charset charset9 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile10 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset9);
        com.google.javascript.jscomp.CompilerInput compilerInput11 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile10);
        java.lang.String str12 = jSSourceFile10.getName();
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray13 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile3, jSSourceFile7, jSSourceFile10 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList14 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, jSSourceFileArray13);
        java.nio.charset.Charset charset17 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset17);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile21 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile27 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray31 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile18, jSSourceFile21, jSSourceFile24, jSSourceFile27, jSSourceFile30 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList32 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, jSSourceFileArray31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions34 = null;
        try {
            com.google.javascript.jscomp.Result result35 = compiler0.compile((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList14, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList32, compilerOptions34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile3);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFile10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFileArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertNotNull(jSSourceFile21);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile27);
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertNotNull(jSSourceFileArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        com.google.javascript.jscomp.JSModule[] jSModuleArray10 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList11 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList11, jSModuleArray10);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph13 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList11);
        com.google.javascript.jscomp.JSModule jSModule15 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule17 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule18 = jSModuleGraph13.getDeepestCommonDependencyInclusive(jSModule15, jSModule17);
        int int19 = jSModule15.getDepth();
        java.lang.String str20 = jSModule15.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput25 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile23, false);
        jSModule15.addFirst(compilerInput25);
        try {
            jSModule5.addFirst(compilerInput25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(jSModuleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(jSModule18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable5 = node4.getAncestors();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder6 = node4.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable11 = node10.getAncestors();
        com.google.javascript.rhino.Node[] nodeArray12 = new com.google.javascript.rhino.Node[] { node4, node10 };
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node(6, nodeArray12);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(ancestorIterable5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(ancestorIterable11);
        org.junit.Assert.assertNotNull(nodeArray12);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        int int13 = jSModule9.getDepth();
        java.lang.String str14 = jSModule9.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        jSModule9.addFirst(compilerInput19);
        compilerInput3.setModule(jSModule9);
        com.google.javascript.jscomp.JSModule jSModule23 = new com.google.javascript.jscomp.JSModule("10");
        jSModule23.removeAll();
        com.google.javascript.jscomp.SourceAst sourceAst25 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput28 = new com.google.javascript.jscomp.CompilerInput(sourceAst25, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray29 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList30 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList30, jSModuleArray29);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph32 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList30);
        com.google.javascript.jscomp.JSModule jSModule34 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule36 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule37 = jSModuleGraph32.getDeepestCommonDependencyInclusive(jSModule34, jSModule36);
        int int38 = jSModule34.getDepth();
        java.lang.String str39 = jSModule34.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput44 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42, false);
        jSModule34.addFirst(compilerInput44);
        compilerInput28.setModule(jSModule34);
        com.google.javascript.jscomp.deps.DependencyInfo[] dependencyInfoArray47 = new com.google.javascript.jscomp.deps.DependencyInfo[] { compilerInput3, jSModule23, compilerInput28 };
        java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoList48 = new java.util.ArrayList<com.google.javascript.jscomp.deps.DependencyInfo>();
        boolean boolean49 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList48, dependencyInfoArray47);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo> dependencyInfoSortedDependencies50 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.deps.DependencyInfo>((java.util.List<com.google.javascript.jscomp.deps.DependencyInfo>) dependencyInfoList48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSModuleArray29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(jSModule37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertNotNull(dependencyInfoArray47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.Node node5 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope7 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType9 = jSTypeRegistry2.createFromTypeNodes(node5, "Unknown class name", jSTypeStaticScope7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
//        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
//        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
//        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
//        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
//        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
//        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
//        com.google.javascript.rhino.Node node65 = node64.cloneTree();
//        node64.setCharno((int) '#');
//        node64.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
//        boolean boolean76 = functionType74.isInterface();
//        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType74.getJSDocInfo();
//        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.getRestrictedTypeGivenToBooleanOutcome(false);
//        java.lang.String str82 = jSType81.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(node12);
//        org.junit.Assert.assertNotNull(node17);
//        org.junit.Assert.assertNotNull(node18);
//        org.junit.Assert.assertNotNull(node23);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNotNull(node34);
//        org.junit.Assert.assertNotNull(node35);
//        org.junit.Assert.assertNotNull(node40);
//        org.junit.Assert.assertNotNull(node45);
//        org.junit.Assert.assertNotNull(node46);
//        org.junit.Assert.assertNotNull(node51);
//        org.junit.Assert.assertNotNull(node56);
//        org.junit.Assert.assertNotNull(node57);
//        org.junit.Assert.assertNotNull(node62);
//        org.junit.Assert.assertNotNull(node63);
//        org.junit.Assert.assertNotNull(node65);
//        org.junit.Assert.assertNotNull(objectType72);
//        org.junit.Assert.assertNotNull(jSTypeArray73);
//        org.junit.Assert.assertNotNull(functionType74);
//        org.junit.Assert.assertNull(functionTypeList75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertNotNull(jSType78);
//        org.junit.Assert.assertNull(jSDocInfo79);
//        org.junit.Assert.assertNotNull(jSType81);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "function (this:me, {1353026226}): me" + "'", str82.equals("function (this:me, {1353026226}): me"));
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getErrors();
        int int4 = loggerErrorManager1.getWarningCount();
        com.google.javascript.jscomp.JSError[] jSErrorArray5 = loggerErrorManager1.getWarnings();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(jSErrorArray5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean8 = defaultCodingConvention0.isExported("10");
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node13.clonePropsFrom(node18);
        try {
            boolean boolean20 = defaultCodingConvention0.isOptionalParameter(node18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType74.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = functionType74.getJSDocInfo();
        java.lang.String str78 = functionType74.getNormalizedReferenceName();
        boolean boolean79 = functionType74.isResolved();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertNull(jSDocInfo77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = functionType74.hasOwnProperty("hi!");
        boolean boolean82 = functionType74.isInstanceType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = objectType79.hasOwnProperty("10");
        com.google.javascript.rhino.jstype.JSType jSType82 = objectType79.restrictByNotNullOrUndefined();
        boolean boolean83 = objectType79.isNominalType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.beans.PropertyChangeListener propertyChangeListener3 = null;
//        try {
//            context1.removePropertyChangeListener(propertyChangeListener3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean8 = defaultCodingConvention0.isExported("10");
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        node66.setCharno((int) '#');
        com.google.javascript.rhino.Node node70 = node66.removeFirstChild();
        java.lang.String str71 = node66.getQualifiedName();
        try {
            boolean boolean72 = defaultCodingConvention0.isVarArgsParameter(node66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(str71);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType7, strArray14);
        int int16 = jSError15.getCharno();
        java.lang.String str17 = jSError15.description;
        loggerErrorManager1.println(checkLevel3, jSError15);
        java.lang.String str19 = jSError15.description;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str17.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str19.equals("Exceeded max number of optimization iterations: "));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "", 3);
        java.lang.String str4 = evaluatorException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EvaluatorException: hi! (#3)" + "'", str4.equals("com.google.javascript.rhino.EvaluatorException: hi! (#3)"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean79 = jSType78.isRecordType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry2.createNamedType("10", "10", (int) (short) -1, 0);
        com.google.javascript.rhino.ErrorReporter errorReporter83 = jSTypeRegistry2.getErrorReporter();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNull(errorReporter83);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromCode("hi!", "Not declared as a type name", "TYPEOF \n");
        org.junit.Assert.assertNotNull(sourceFile3);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType74.getJSDocInfo();
        com.google.common.base.Predicate<com.google.javascript.rhino.jstype.JSType> jSTypePredicate80 = null;
        try {
            boolean boolean81 = functionType74.setValidator(jSTypePredicate80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNull(jSDocInfo79);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 1, (int) (short) 100, 6);
        java.lang.Object obj4 = scriptOrFnNode3.getCompilerData();
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry2.createNamedType("10", "10", (int) (short) -1, 0);
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType82);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        node28.detachChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType74.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = functionType74.getJSDocInfo();
        java.lang.String str78 = functionType74.getNormalizedReferenceName();
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertNull(jSDocInfo77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertNotNull(objectType79);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable58 = node16.children();
        com.google.javascript.rhino.Node node59 = node16.getParent();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(nodeIterable58);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule5.getThisAndAllDependencies();
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph18.getDeepestCommonDependencyInclusive(jSModule20, jSModule22);
        int int24 = jSModule20.getDepth();
        java.lang.String str25 = jSModule20.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        jSModule20.addFirst(compilerInput30);
        compilerInput14.setModule(jSModule20);
        jSModule5.remove(compilerInput14);
        try {
            java.lang.String str35 = compilerInput14.getLine(7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        boolean boolean17 = node4.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        int int14 = node12.getIntProp((int) (short) 1);
        try {
            boolean boolean15 = closureCodingConvention0.isPropertyTestFunction(node12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node63.clonePropsFrom(node68);
        java.lang.String[] strArray71 = new java.lang.String[] { "TYPEOF \n" };
        java.util.LinkedHashSet<java.lang.String> strSet72 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet72, strArray71);
        node68.setDirectives((java.util.Set<java.lang.String>) strSet72);
        node58.setDirectives((java.util.Set<java.lang.String>) strSet72);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int0 = com.google.javascript.rhino.Node.POST_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
//        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
//        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
//        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
//        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
//        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
//        com.google.javascript.rhino.Node node62 = node61.cloneTree();
//        node61.setCharno((int) '#');
//        node61.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
//        com.google.javascript.rhino.JSDocInfo jSDocInfo70 = objectType69.getJSDocInfo();
//        boolean boolean71 = objectType69.isNominalType();
//        java.lang.String str72 = objectType69.toDebugHashCodeString();
//        boolean boolean74 = objectType69.hasOwnProperty("");
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(node14);
//        org.junit.Assert.assertNotNull(node15);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNotNull(node32);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNotNull(node42);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertNotNull(node48);
//        org.junit.Assert.assertNotNull(node53);
//        org.junit.Assert.assertNotNull(node54);
//        org.junit.Assert.assertNotNull(node59);
//        org.junit.Assert.assertNotNull(node60);
//        org.junit.Assert.assertNotNull(node62);
//        org.junit.Assert.assertNotNull(objectType69);
//        org.junit.Assert.assertNull(jSDocInfo70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "{130370559}" + "'", str72.equals("{130370559}"));
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.ErrorFormat errorFormat0 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        org.junit.Assert.assertNotNull(errorFormat0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType77 = functionType74.findPropertyType("TYPEOF \n");
        boolean boolean79 = functionType74.isPropertyInExterns("TYPEOF ");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getWarningCount();
        int int3 = loggerErrorManager1.getWarningCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry2.createAnonymousObjectType();
        jSTypeRegistry2.identifyEnumName("");
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("", "com.google.javascript.rhino.EvaluatorException: hi! (#3)", "null");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.lang.String str1 = closureCodingConvention0.getDelegateSuperclassName();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo79, true);
        boolean boolean82 = functionType74.isNativeObjectType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, 31, 34);
        java.lang.String str4 = scriptOrFnNode3.getSourceName();
        int int6 = scriptOrFnNode3.getParamOrVarIndex("Not declared as a type name");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        try {
            java.lang.String str4 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(false);
        context0.setGeneratingSource(false);
        java.lang.Object obj5 = context0.getDebuggerContextData();
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        int int13 = jSModule9.getDepth();
        java.lang.String str14 = jSModule9.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        jSModule9.addFirst(compilerInput19);
        compilerInput3.setModule(jSModule9);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile24 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput26 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile24, false);
        java.nio.charset.Charset charset28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset28);
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile29);
        try {
            jSModule9.addAfter(compilerInput26, compilerInput30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSSourceFile24);
        org.junit.Assert.assertNotNull(jSSourceFile29);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        int int0 = com.google.javascript.rhino.jstype.JSType.NOT_ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.EMPTY_TYPE_COMPONENT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Named type with empty name component" + "'", str0.equals("Named type with empty name component"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("Unknown class name");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("10");
        java.util.List<java.lang.String> strList2 = jSModule1.getRequires();
        org.junit.Assert.assertNotNull(strList2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode1 = new com.google.javascript.rhino.ScriptOrFnNode(39);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative2 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE;
        java.lang.RuntimeException runtimeException3 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) 39, (java.lang.Object) jSTypeNative2);
        org.junit.Assert.assertTrue("'" + jSTypeNative2 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE + "'", jSTypeNative2.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(runtimeException3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        com.google.javascript.rhino.Node node59 = node57.cloneNode();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = com.google.javascript.rhino.Node.COLUMN_BITS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        boolean boolean81 = functionType74.isInstanceType();
        boolean boolean82 = functionType74.hasInstanceType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_FUNCTION_TYPE));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        boolean boolean59 = node57.isUnscopedQualifiedName();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder60 = node57.getJsDocBuilderForNode();
        fileLevelJsDocBuilder60.append("Not declared as a type name");
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder60);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(true);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        java.util.logging.Logger logger5 = null;
        try {
            com.google.javascript.rhino.Node node6 = com.google.javascript.jscomp.parsing.ParserRunner.parse("{130370559}", "", config3, errorReporter4, logger5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        java.lang.String str10 = jSModule5.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile13 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile13, false);
        jSModule5.addFirst(compilerInput15);
        com.google.javascript.jscomp.Region region18 = compilerInput15.getRegion(16);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile13);
        org.junit.Assert.assertNull(region18);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        try {
            com.google.javascript.rhino.Context.reportWarning("Exceeded max number of optimization iterations: ", "", 0, "", (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        int int58 = node28.getChildCount();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_EXPRESSION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        boolean boolean11 = jSTypeRegistry2.canPropertyBeDefined(jSType9, "TYPEOF \n");
        com.google.javascript.rhino.Node node12 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope14 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType16 = jSTypeRegistry2.createFromTypeNodes(node12, "Unknown class name", jSTypeStaticScope14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, 31, 34);
        java.lang.String str4 = scriptOrFnNode3.getSourceName();
        java.util.Set<java.lang.String> strSet5 = scriptOrFnNode3.getDirectives();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(strSet5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        int int3 = loggerErrorManager1.getErrorCount();
        int int4 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        java.nio.charset.Charset charset11 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile12 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset11);
        com.google.javascript.jscomp.CompilerInput compilerInput13 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile12);
        jSModule5.addFirst(jSSourceFile12);
        java.lang.String str15 = jSModule5.getName();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10" + "'", str15.equals("10"));
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        try {
//            context1.addPropertyChangeListener(propertyChangeListener5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.getName();
        java.lang.String str5 = sourceFile2.getLine(32);
        java.lang.String str6 = sourceFile2.getName();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        boolean boolean2 = context1.isGeneratingDebug();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        jSTypeRegistry2.clearTemplateTypeName();
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.JSDocInfo jSDocInfo80 = objectType79.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType81 = jSTypeRegistry2.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType79);
        boolean boolean82 = objectType79.isEnumElementType();
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNull(jSDocInfo80);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, 31, 34);
        int int4 = scriptOrFnNode3.getEncodedSourceEnd();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        boolean boolean81 = functionType74.isInterface();
        boolean boolean82 = functionType74.isFunctionType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_FUNCTION_TYPE));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isSealed();
//        boolean boolean2 = context0.isSealed();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        node66.setCharno((int) '#');
        node66.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType73 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType74 = jSTypeRegistry7.createObjectType("TYPEOF \n", node66, objectType73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry4.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType73, jSTypeArray75);
        boolean boolean77 = functionParamBuilder1.addRequiredParams(jSTypeArray75);
        boolean boolean78 = functionParamBuilder1.hasVarArgs();
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(objectType74);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.unboxesTo();
        try {
            boolean boolean82 = jSType81.isString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(jSType81);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node1 = new com.google.javascript.rhino.Node((-2));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node16.cloneTree();
        boolean boolean59 = node16.wasEmptyNode();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int0 = com.google.javascript.rhino.Node.DIRECTCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.VOID_TYPE));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("Not declared as a type name", "{1813971029}");
        ecmaError2.initLineSource("Not declared as a type name");
        org.junit.Assert.assertNotNull(ecmaError2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType7, strArray14);
        int int16 = jSError15.getCharno();
        java.lang.String str17 = jSError15.description;
        loggerErrorManager1.println(checkLevel3, jSError15);
        int int19 = loggerErrorManager1.getErrorCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str17.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
//        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
//        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
//        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
//        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
//        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
//        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
//        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
//        com.google.javascript.rhino.Node node62 = node61.cloneTree();
//        node61.setCharno((int) '#');
//        node61.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
//        java.lang.String str70 = objectType69.toDebugHashCodeString();
//        org.junit.Assert.assertNotNull(node9);
//        org.junit.Assert.assertNotNull(node14);
//        org.junit.Assert.assertNotNull(node15);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertNotNull(node26);
//        org.junit.Assert.assertNotNull(node31);
//        org.junit.Assert.assertNotNull(node32);
//        org.junit.Assert.assertNotNull(node37);
//        org.junit.Assert.assertNotNull(node42);
//        org.junit.Assert.assertNotNull(node43);
//        org.junit.Assert.assertNotNull(node48);
//        org.junit.Assert.assertNotNull(node53);
//        org.junit.Assert.assertNotNull(node54);
//        org.junit.Assert.assertNotNull(node59);
//        org.junit.Assert.assertNotNull(node60);
//        org.junit.Assert.assertNotNull(node62);
//        org.junit.Assert.assertNotNull(objectType69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{1479088659}" + "'", str70.equals("{1479088659}"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException66 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder6, (java.lang.Object) node62, (java.lang.Object) jSTypeNative65);
        java.lang.String str67 = defaultCodingConvention0.identifyTypeDefAssign(node62);
        boolean boolean69 = defaultCodingConvention0.isPrivate("");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("JSC_OPTIMIZE_LOOP_ERROR");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property JSC_OPTIMIZE_LOOP_ERROR");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.INVALID_CASTS = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("TYPEOF ", charset1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isBooleanValueType();
        boolean boolean77 = functionType74.isNumber();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType74.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = functionType74.getJSDocInfo();
        boolean boolean78 = functionType74.isNativeObjectType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertNull(jSDocInfo77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder62 = node57.getJsDocBuilderForNode();
        boolean boolean63 = node57.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.groupVariableDeclarations = false;
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, 31, 34);
        java.lang.String str4 = scriptOrFnNode3.getSourceName();
        int int5 = scriptOrFnNode3.getEncodedSourceEnd();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(false);
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        try {
            context0.addPropertyChangeListener(propertyChangeListener3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.Compiler compiler4 = new com.google.javascript.jscomp.Compiler();
        try {
            com.google.javascript.rhino.Node node5 = compilerInput3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean7 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node9 = node5.getAncestor(0);
        boolean boolean10 = node9.isOptionalArg();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.groupVariableDeclarations;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        com.google.javascript.rhino.Node node63 = node61.cloneTree();
        com.google.javascript.rhino.Node node64 = com.google.javascript.jscomp.NodeUtil.newExpr(node63);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = null;
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "com.google.javascript.rhino.EvaluatorException: hi! (#3)", "hi!", "{130370559}", "TYPEOF \n" };
        try {
            com.google.javascript.jscomp.JSError jSError7 = com.google.javascript.jscomp.JSError.make(diagnosticType0, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("10");
        jSModule1.removeAll();
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler();
        compiler3.disableThreads();
        try {
            jSModule1.sortInputsByDeps(compiler3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative10 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: com.google.javascript.rhino.jstype.FunctionPrototypeType cannot be cast to com.google.javascript.rhino.jstype.FunctionType");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + jSTypeNative10 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE + "'", jSTypeNative10.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_PROTOTYPE));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        java.lang.String str3 = sourceFile2.getName();
        java.lang.String str5 = sourceFile2.getLine(32);
        java.lang.String str6 = sourceFile2.getOriginalPath();
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.crossModuleMethodMotion = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("Named type with empty name component", (int) (short) 0, 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node10.hasSideEffects();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        java.lang.String str7 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        jSTypeRegistry2.clearTemplateTypeName();
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap5 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNull(cssRenamingMap5);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph18.getDeepestCommonDependencyInclusive(jSModule20, jSModule22);
        int int24 = jSModule20.getDepth();
        java.lang.String str25 = jSModule20.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        jSModule20.addFirst(compilerInput30);
        compilerInput14.setModule(jSModule20);
        boolean boolean33 = jSModuleGraph3.dependsOn(jSModule10, jSModule20);
        jSModuleGraph3.coalesceDuplicateFiles();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        functionType74.setPropertyJSDocInfo("hi!", jSDocInfo82, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = null;
        functionType74.setPropertyJSDocInfo("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", jSDocInfo86, false);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable89 = functionType74.getParameters();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNotNull(nodeIterable89);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isFunctionPrototypeType();
        java.util.Set<java.lang.String> strSet81 = functionType74.getOwnPropertyNames();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(strSet81);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isSealed();
//        boolean boolean2 = context0.isGeneratingDebug();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.checkMethods = checkLevel3;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        boolean boolean10 = compilerOptions0.extractPrototypeMemberDeclarations;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        java.util.logging.Logger logger5 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager6 = new com.google.javascript.jscomp.LoggerErrorManager(logger5);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        int int0 = com.google.javascript.rhino.Node.FLAG_THIS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) (short) 100, "TYPEOF \n", 18, (int) (byte) 100);
        node6.removeProp(27);
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node13.clonePropsFrom(node18);
        boolean boolean20 = node13.isQualifiedName();
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node26.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = node65.clonePropsFrom(node70);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node77 = node65.copyInformationFromForTree(node76);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((-1), node37, node49, node59, node76);
        com.google.javascript.rhino.Node node79 = node78.cloneTree();
        node78.setCharno((int) '#');
        com.google.javascript.rhino.Node node82 = node78.removeFirstChild();
        com.google.javascript.rhino.Node node83 = node13.copyInformationFrom(node78);
        try {
            com.google.javascript.rhino.Node node84 = new com.google.javascript.rhino.Node(39, node1, node6, node13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node83);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node12 = node4.getLastSibling();
        boolean boolean14 = node12.getBooleanProp(28);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) (short) 100, "TYPEOF \n", 18, (int) (byte) 100);
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention21 = new com.google.javascript.jscomp.DefaultCodingConvention();
        java.lang.String str22 = defaultCodingConvention21.getExportSymbolFunction();
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node37.copyInformationFromForTree(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = node65.clonePropsFrom(node70);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node81 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node82 = node76.clonePropsFrom(node81);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node88 = node76.copyInformationFromForTree(node87);
        com.google.javascript.rhino.Node node89 = new com.google.javascript.rhino.Node((-1), node48, node60, node70, node87);
        com.google.javascript.rhino.Node node90 = node89.cloneTree();
        java.lang.Object obj92 = node90.getProp(29);
        node27.addChildAfter(node31, node90);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship94 = defaultCodingConvention21.getDelegateRelationship(node27);
        com.google.javascript.rhino.Node node95 = new com.google.javascript.rhino.Node(26, node27);
        node12.addChildAfter(node19, node95);
        java.lang.RuntimeException runtimeException98 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node95, (java.lang.Object) (-1.0f));
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node81);
        org.junit.Assert.assertNotNull(node82);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node88);
        org.junit.Assert.assertNotNull(node90);
        org.junit.Assert.assertNull(obj92);
        org.junit.Assert.assertNull(delegateRelationship94);
        org.junit.Assert.assertNotNull(runtimeException98);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.checkMissingGetCssNameBlacklist = "goog.exportSymbol";
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap9 = compilerOptions0.cssRenamingMap;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(cssRenamingMap9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        boolean boolean62 = node61.hasChildren();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.flowSensitiveInlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.markNoSideEffectCalls = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "hi!", 4);
        java.lang.String str4 = evaluatorException3.sourceName();
        try {
            evaluatorException3.initLineNumber(48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        int int2 = loggerErrorManager1.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType7 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = diagnosticType7.level;
        java.lang.String[] strArray14 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError15 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType7, strArray14);
        int int16 = jSError15.getCharno();
        java.lang.String str17 = jSError15.description;
        loggerErrorManager1.println(checkLevel3, jSError15);
        java.lang.String str19 = jSError15.sourceName;
        java.lang.String str20 = jSError15.sourceName;
        java.lang.String str21 = jSError15.sourceName;
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType7);
        org.junit.Assert.assertTrue("'" + checkLevel8 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel8.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(jSError15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 25 + "'", int16 == 25);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str17.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        boolean boolean5 = compilerInput4.isExtern();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        java.lang.Object obj65 = node63.getProp(29);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = defaultCodingConvention0.getDelegateRelationship(node63);
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) (short) 100, "TYPEOF \n", 18, (int) (byte) 100);
        node71.removeProp(27);
        java.lang.String str74 = defaultCodingConvention0.identifyTypeDefAssign(node71);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNull(str74);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.JSDocInfo jSDocInfo70 = objectType69.getJSDocInfo();
        boolean boolean71 = objectType69.isRegexpType();
        boolean boolean72 = objectType69.isBooleanObjectType();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNull(jSDocInfo70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = node3.getAncestors();
        boolean boolean5 = node3.isSyntheticBlock();
        com.google.javascript.rhino.Node node6 = node3.removeFirstChild();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(ancestorIterable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph18.getDeepestCommonDependencyInclusive(jSModule20, jSModule22);
        int int24 = jSModule20.getDepth();
        java.lang.String str25 = jSModule20.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        jSModule20.addFirst(compilerInput30);
        compilerInput14.setModule(jSModule20);
        boolean boolean33 = jSModuleGraph3.dependsOn(jSModule10, jSModule20);
        com.google.javascript.jscomp.JSModule jSModule35 = new com.google.javascript.jscomp.JSModule("10");
        java.util.List<java.lang.String> strList36 = jSModule35.getRequires();
        com.google.javascript.jscomp.JSModule[] jSModuleArray37 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList38, jSModuleArray37);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph40 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList38);
        com.google.javascript.jscomp.JSModule jSModule42 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule44 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule45 = jSModuleGraph40.getDeepestCommonDependencyInclusive(jSModule42, jSModule44);
        int int46 = jSModule42.getDepth();
        java.lang.String str47 = jSModule42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile50 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput52 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile50, false);
        jSModule42.addFirst(compilerInput52);
        com.google.javascript.jscomp.JSModule[] jSModuleArray54 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList55 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean56 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList55, jSModuleArray54);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph57 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList55);
        com.google.javascript.jscomp.JSModule jSModule59 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule61 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule62 = jSModuleGraph57.getDeepestCommonDependencyInclusive(jSModule59, jSModule61);
        int int63 = jSModule59.getDepth();
        java.nio.charset.Charset charset65 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile66 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset65);
        com.google.javascript.jscomp.CompilerInput compilerInput67 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile66);
        jSModule59.addFirst(jSSourceFile66);
        java.lang.String str69 = jSModule59.getName();
        com.google.javascript.jscomp.JSModule[] jSModuleArray70 = new com.google.javascript.jscomp.JSModule[] { jSModule10, jSModule35, jSModule42, jSModule59 };
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph71 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray70);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(strList36);
        org.junit.Assert.assertNotNull(jSModuleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(jSModule45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10" + "'", str47.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile50);
        org.junit.Assert.assertNotNull(jSModuleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(jSModule62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "10" + "'", str69.equals("10"));
        org.junit.Assert.assertNotNull(jSModuleArray70);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative60 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException61 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder1, (java.lang.Object) node57, (java.lang.Object) jSTypeNative60);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node72 = node66.clonePropsFrom(node71);
        com.google.javascript.rhino.Node node77 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node78 = node66.copyInformationFromForTree(node77);
        boolean boolean79 = node57.checkTreeEqualsSilent(node66);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder80 = node57.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.Node node81 = node57.removeFirstChild();
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertTrue("'" + jSTypeNative60 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative60.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException61);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNull(node81);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.optimizeArgumentsArray = false;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy8 = null;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy8;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean3 = compilerOptions0.collapseAnonymousFunctions;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap4 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap4;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        jSTypeRegistry2.resetForTypeCheck();
        jSTypeRegistry2.incrementGeneration();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative72 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        com.google.javascript.rhino.jstype.FunctionType functionType73 = jSTypeRegistry2.getNativeFunctionType(jSTypeNative72);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertTrue("'" + jSTypeNative72 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative72.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
        org.junit.Assert.assertNotNull(functionType73);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("{1813971029}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        int int3 = ecmaError2.columnNumber();
        java.lang.String str4 = ecmaError2.sourceName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy4 = com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy3, propertyRenamingPolicy4);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC + "'", propertyRenamingPolicy4.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.AGGRESSIVE_HEURISTIC));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        jSTypeRegistry2.resetForTypeCheck();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope71 = null;
        com.google.javascript.rhino.jstype.JSType jSType76 = jSTypeRegistry2.getType(jSTypeStaticScope71, "function (this:me, {1353026226}): me", "10", (-3), (int) (byte) -1);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType76);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType74.getParameterType();
        try {
            boolean boolean77 = jSType76.matchesInt32Context();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType76);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.crossModuleMethodMotion = false;
        boolean boolean5 = compilerOptions0.closurePass;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node22 = node16.clonePropsFrom(node21);
//        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node28 = node16.copyInformationFromForTree(node27);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
//        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
//        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node61 = node55.clonePropsFrom(node60);
//        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node67 = node55.copyInformationFromForTree(node66);
//        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1), node27, node39, node49, node66);
//        com.google.javascript.rhino.Node node69 = node68.cloneTree();
//        node68.setCharno((int) '#');
//        node68.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType75 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry9.createObjectType("TYPEOF \n", node68, objectType75);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType75, jSTypeArray77);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList79 = functionType78.getSubTypes();
//        boolean boolean80 = functionType78.isInterface();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable81 = functionType78.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType83 = functionType78.findPropertyType("hi!");
//        boolean boolean85 = functionType78.isPropertyTypeDeclared("TYPEOF ");
//        com.google.javascript.rhino.jstype.JSType jSType86 = jSTypeRegistry3.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType78);
//        context0.removeThreadLocal((java.lang.Object) jSType86);
//        boolean boolean88 = jSType86.isNullType();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNotNull(node38);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNotNull(node44);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertNotNull(node50);
//        org.junit.Assert.assertNotNull(node55);
//        org.junit.Assert.assertNotNull(node60);
//        org.junit.Assert.assertNotNull(node61);
//        org.junit.Assert.assertNotNull(node66);
//        org.junit.Assert.assertNotNull(node67);
//        org.junit.Assert.assertNotNull(node69);
//        org.junit.Assert.assertNotNull(objectType76);
//        org.junit.Assert.assertNotNull(jSTypeArray77);
//        org.junit.Assert.assertNotNull(functionType78);
//        org.junit.Assert.assertNull(functionTypeList79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable81);
//        org.junit.Assert.assertNull(jSType83);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(jSType86);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("10");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 10");
        } catch (java.lang.RuntimeException e) {
        }
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        int int5 = context1.getInstructionObserverThreshold();
//        boolean boolean6 = context1.isGeneratingDebugChanged();
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("{1813971029}");
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.OFF + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.OFF));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope78, "hi!", "Not declared as a type name", (int) 'a', 7);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative84 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType85 = jSTypeRegistry2.getNativeObjectType(jSTypeNative84);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertTrue("'" + jSTypeNative84 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative84.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
        org.junit.Assert.assertNotNull(objectType85);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 49);
        org.junit.Assert.assertNotNull(runtimeException1);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        boolean boolean2 = context1.isSealed();
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.setErrorReporter(errorReporter3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry9.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType78, jSTypeArray80);
        boolean boolean82 = functionParamBuilder6.addRequiredParams(jSTypeArray80);
        com.google.javascript.rhino.Node node83 = jSTypeRegistry2.createParameters(jSTypeArray80);
        boolean boolean85 = jSTypeRegistry2.hasNamespace("TYPEOF \n");
        jSTypeRegistry2.resetForTypeCheck();
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(node83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray4 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList5 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5, warningsGuardArray4);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard7 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList5);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.ignoreCajaProperties = true;
        boolean boolean10 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType74.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.getRestrictedTypeGivenToBooleanOutcome(false);
        boolean boolean82 = jSType81.matchesUint32Context();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNull(jSDocInfo79);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry79 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope80 = null;
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry79.getForgivingType(jSTypeStaticScope80, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        boolean boolean87 = functionType74.defineDeclaredProperty("TYPEOF ", jSType85, true);
        boolean boolean88 = jSType85.isStringValueType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        java.lang.String str5 = compilerOptions0.checkMissingGetCssNameBlacklist;
        com.google.javascript.jscomp.CompilerOptions compilerOptions6 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean7 = compilerOptions6.checkEs5Strict;
        compilerOptions6.coalesceVariableNames = false;
        boolean boolean10 = compilerOptions6.isExternExportsEnabled();
        boolean boolean11 = compilerOptions6.inferTypesInGlobalScope;
        boolean boolean12 = compilerOptions6.prettyPrint;
        boolean boolean13 = compilerOptions6.optimizeArgumentsArray;
        com.google.javascript.rhino.ErrorReporter errorReporter14 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter14, false);
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry19 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17, false);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node26.copyInformationFromForTree(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = node65.clonePropsFrom(node70);
        com.google.javascript.rhino.Node node76 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node77 = node65.copyInformationFromForTree(node76);
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((-1), node37, node49, node59, node76);
        com.google.javascript.rhino.Node node79 = node78.cloneTree();
        node78.setCharno((int) '#');
        node78.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType85 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType86 = jSTypeRegistry19.createObjectType("TYPEOF \n", node78, objectType85);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray87 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType88 = jSTypeRegistry16.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType85, jSTypeArray87);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList89 = functionType88.getSubTypes();
        boolean boolean90 = functionType88.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable91 = functionType88.getAllImplementedInterfaces();
        boolean boolean92 = functionType88.isEnumType();
        boolean boolean93 = functionType88.isInstanceType();
        java.util.Set<java.lang.String> strSet94 = functionType88.getOwnPropertyNames();
        compilerOptions6.stripNameSuffixes = strSet94;
        compilerOptions0.setIdGenerators(strSet94);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertNotNull(objectType86);
        org.junit.Assert.assertNotNull(jSTypeArray87);
        org.junit.Assert.assertNotNull(functionType88);
        org.junit.Assert.assertNull(functionTypeList89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(strSet94);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("Named type with empty name component", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType82 = jSTypeRegistry2.createNamedType("10", "10", (int) (short) -1, 0);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode86 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 1, (int) (short) 100, 6);
        int int88 = scriptOrFnNode86.addVar("");
        java.lang.String[] strArray89 = scriptOrFnNode86.getParamAndVarNames();
        int int90 = scriptOrFnNode86.getParamCount();
        int int91 = scriptOrFnNode86.getRegexpCount();
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope93 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType95 = jSTypeRegistry2.createFromTypeNodes((com.google.javascript.rhino.Node) scriptOrFnNode86, "NAME hi!", jSTypeStaticScope93, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: EOL [source name: null] [encoded source length: 0] [base line: -1] [end line: -1] 100");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
        org.junit.Assert.assertNotNull(strArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("TYPEOF \n");
        com.google.javascript.rhino.jstype.JSType jSType6 = null;
        try {
            jSTypeRegistry2.registerPropertyOnType("NAME hi!", jSType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(jSType4);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        boolean boolean75 = functionType74.isCheckedUnknownType();
        boolean boolean76 = functionType74.isObject();
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType74.resolve(errorReporter77, jSTypeStaticScope78);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(jSType79);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("");
        try {
            java.lang.String str3 = functionNode1.getParamOrVarName(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: 4 ∉ [0, 0)");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.optimizeArgumentsArray = false;
        boolean boolean8 = compilerOptions0.collapseProperties;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        java.lang.String str4 = node3.getQualifiedName();
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        java.lang.String str19 = node14.toString(false, true, true);
        com.google.javascript.rhino.Node node20 = com.google.javascript.jscomp.NodeUtil.newExpr(node14);
        try {
            node3.addChildrenToFront(node14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TYPEOF " + "'", str19.equals("TYPEOF "));
        org.junit.Assert.assertNotNull(node20);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        boolean boolean79 = jSType78.isArrayType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope78, "hi!", "Not declared as a type name", (int) 'a', 7);
        jSTypeRegistry2.forwardDeclareType("function (this:me, {1353026226}): me");
        boolean boolean87 = jSTypeRegistry2.hasNamespace("");
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.SourceFile sourceFile4 = com.google.javascript.jscomp.SourceFile.fromCode("", "", "hi!");
        java.io.Reader reader5 = sourceFile4.getCodeReader();
        com.google.javascript.jscomp.SourceFile sourceFile6 = com.google.javascript.jscomp.SourceFile.fromReader("TYPEOF ", reader5);
        org.junit.Assert.assertNotNull(sourceFile4);
        org.junit.Assert.assertNotNull(reader5);
        org.junit.Assert.assertNotNull(sourceFile6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry9.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType78, jSTypeArray80);
        boolean boolean82 = functionParamBuilder6.addRequiredParams(jSTypeArray80);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.createUnionType(jSTypeArray80);
        jSTypeRegistry2.clearTemplateTypeName();
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(jSType83);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.MessageFormatter messageFormatter5 = null;
        java.util.logging.Logger logger6 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager7 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter5, logger6);
        compilerInput3.setErrorManager((com.google.javascript.jscomp.ErrorManager) loggerErrorManager7);
        com.google.javascript.jscomp.SourceAst sourceAst9 = compilerInput3.getSourceAst();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(sourceAst9);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative65 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException66 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder6, (java.lang.Object) node62, (java.lang.Object) jSTypeNative65);
        java.lang.String str67 = defaultCodingConvention0.identifyTypeDefAssign(node62);
        com.google.javascript.rhino.Node node68 = node62.removeChildren();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertTrue("'" + jSTypeNative65 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative65.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException66);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNull(node68);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) 10, (byte) 100, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray13;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.tightenTypes = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.collapseAnonymousFunctions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int0 = com.google.javascript.rhino.Node.CASEARRAY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean3 = compilerOptions0.smartNameRemoval;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        boolean boolean75 = functionType74.isArrayType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) 10, (byte) 100, (byte) 10 };
        compilerOptions0.inputPropertyMapSerialized = byteArray13;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.setDefineToNumberLiteral("{1813971029}", 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.convertToDottedProperties = false;
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        boolean boolean10 = compilerOptions0.strictMessageReplacement;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkEs5Strict = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node4.copyInformationFromForTree(node15);
        node4.setType(16);
        boolean boolean19 = node4.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, 17, 33);
        boolean[] booleanArray4 = scriptOrFnNode3.getParamAndVarConst();
        org.junit.Assert.assertNotNull(booleanArray4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.syntheticBlockEndMarker = "NAME hi!";
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        compilerOptions0.setProcessObjectPropertyString(true);
        compilerOptions0.generatePseudoNames = true;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(21, "hi!");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = node15.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node66 = node54.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((-1), node26, node38, node48, node65);
        com.google.javascript.rhino.Node node68 = node67.cloneTree();
        node67.setCharno((int) '#');
        node67.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType74 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry8.createObjectType("TYPEOF \n", node67, objectType74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry5.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType74, jSTypeArray76);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList78 = functionType77.getSubTypes();
        boolean boolean79 = functionType77.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType77.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType77.findPropertyType("hi!");
        boolean boolean84 = functionType77.isPropertyTypeDeclared("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry2.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType77);
        com.google.javascript.rhino.jstype.JSType jSType87 = functionType77.getPropertyType("10");
        boolean boolean88 = functionType77.isNativeObjectType();
        boolean boolean89 = functionType77.isStringObjectType();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(functionTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isRecordType();
        boolean boolean81 = functionType74.matchesStringContext();
        boolean boolean82 = functionType74.isUnknownType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        functionType74.setPropertyJSDocInfo("hi!", jSDocInfo82, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = null;
        functionType74.setPropertyJSDocInfo("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", jSDocInfo86, false);
        boolean boolean89 = functionType74.isFunctionType();
        try {
            com.google.javascript.rhino.jstype.ObjectType objectType90 = functionType74.getInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.jstype.JSType jSType76 = functionType74.getParameterType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo77 = functionType74.getJSDocInfo();
        java.lang.String str78 = functionType74.getNormalizedReferenceName();
        boolean boolean79 = functionType74.isReturnTypeInferred();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNull(jSType76);
        org.junit.Assert.assertNull(jSDocInfo77);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.JSType jSType77 = jSTypeRegistry2.getType("TYPEOF ");
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope78 = null;
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.getType(jSTypeStaticScope78, "hi!", "Not declared as a type name", 0, 26);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNull(jSType77);
        org.junit.Assert.assertNotNull(jSType83);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isNumberValueType();
        boolean boolean79 = functionType74.isObject();
        boolean boolean80 = functionType74.isArrayType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("{1813971029}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        java.lang.String str3 = ecmaError2.getScriptStackTrace();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "<No stack trace available>" + "'", str3.equals("<No stack trace available>"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.unboxesTo();
        boolean boolean82 = functionType74.hasCachedValues();
        int int83 = functionType74.getMaxArguments();
        boolean boolean84 = functionType74.isResolved();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(jSType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        jSTypeRegistry2.clearTemplateTypeName();
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = node15.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node66 = node54.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((-1), node26, node38, node48, node65);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope69 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType70 = jSTypeRegistry2.createFromTypeNodes(node65, "", jSTypeStaticScope69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: TYPEOF ");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = node8.clonePropsFrom(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node8.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node25.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node47.copyInformationFromForTree(node58);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1), node19, node31, node41, node58);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder2, (java.lang.Object) node58, (java.lang.Object) jSTypeNative61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node73 = node67.clonePropsFrom(node72);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node79 = node67.copyInformationFromForTree(node78);
        boolean boolean80 = node58.checkTreeEqualsSilent(node67);
        boolean boolean81 = closureCodingConvention0.isOptionalParameter(node67);
        com.google.javascript.rhino.Node node87 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node92 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node93 = node87.clonePropsFrom(node92);
        com.google.javascript.rhino.Node node96 = new com.google.javascript.rhino.Node(16, node93, 19, (int) (short) 1);
        boolean boolean97 = closureCodingConvention0.isVarArgsParameter(node93);
        boolean boolean99 = closureCodingConvention0.isConstant("Not declared as a type name");
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(node87);
        org.junit.Assert.assertNotNull(node92);
        org.junit.Assert.assertNotNull(node93);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getImplementedInterfaces();
        boolean boolean81 = functionType74.isArrayType();
        boolean boolean82 = functionType74.matchesNumberContext();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean2 = googleCodingConvention0.isConstantKey("goog.exportSymbol");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.lang.Object obj3 = context1.getDebuggerContextData();
//        boolean boolean4 = context1.isGeneratingDebugChanged();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup5;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
//        context1.removeThreadLocal((java.lang.Object) diagnosticGroup5);
//        context1.removeThreadLocal((java.lang.Object) 10.0f);
//        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
//        int int23 = node21.getIntProp((int) (short) 1);
//        node21.setString("");
//        java.lang.Object obj26 = context1.getThreadLocal((java.lang.Object) node21);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertNull(obj3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertNotNull(node15);
//        org.junit.Assert.assertNotNull(node20);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNull(obj26);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, (int) (short) 0, 22);
        scriptOrFnNode3.setEndLineno(29);
        int int6 = scriptOrFnNode3.getParamCount();
        boolean boolean7 = scriptOrFnNode3.isNoSideEffectsCall();
        scriptOrFnNode3.setIsSyntheticBlock(true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(false);
        context0.setGeneratingSource(false);
        context0.setInstructionObserverThreshold((int) (short) 10);
        java.util.Locale locale7 = context0.getLocale();
        org.junit.Assert.assertNotNull(locale7);
    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        java.util.Locale locale5 = context1.getLocale();
//        long long6 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context1);
//        try {
//            context1.setCompileFunctionsWithDynamicScope(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertNotNull(locale5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("Not declared as a type name", "");
        java.lang.String str3 = diagnosticType2.key;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType2.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Not declared as a type name" + "'", str3.equals("Not declared as a type name"));
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        compilerOptions0.setDefineToNumberLiteral("NAME hi!", 10);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry3 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
//        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node22 = node16.clonePropsFrom(node21);
//        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node28 = node16.copyInformationFromForTree(node27);
//        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
//        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
//        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node61 = node55.clonePropsFrom(node60);
//        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node67 = node55.copyInformationFromForTree(node66);
//        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1), node27, node39, node49, node66);
//        com.google.javascript.rhino.Node node69 = node68.cloneTree();
//        node68.setCharno((int) '#');
//        node68.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType75 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry9.createObjectType("TYPEOF \n", node68, objectType75);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType75, jSTypeArray77);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList79 = functionType78.getSubTypes();
//        boolean boolean80 = functionType78.isInterface();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable81 = functionType78.getAllImplementedInterfaces();
//        com.google.javascript.rhino.jstype.JSType jSType83 = functionType78.findPropertyType("hi!");
//        boolean boolean85 = functionType78.isPropertyTypeDeclared("TYPEOF ");
//        com.google.javascript.rhino.jstype.JSType jSType86 = jSTypeRegistry3.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType78);
//        context0.removeThreadLocal((java.lang.Object) jSType86);
//        long long88 = com.google.javascript.rhino.ScriptRuntime.lastUint32Result(context0);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(node16);
//        org.junit.Assert.assertNotNull(node21);
//        org.junit.Assert.assertNotNull(node22);
//        org.junit.Assert.assertNotNull(node27);
//        org.junit.Assert.assertNotNull(node28);
//        org.junit.Assert.assertNotNull(node33);
//        org.junit.Assert.assertNotNull(node38);
//        org.junit.Assert.assertNotNull(node39);
//        org.junit.Assert.assertNotNull(node44);
//        org.junit.Assert.assertNotNull(node49);
//        org.junit.Assert.assertNotNull(node50);
//        org.junit.Assert.assertNotNull(node55);
//        org.junit.Assert.assertNotNull(node60);
//        org.junit.Assert.assertNotNull(node61);
//        org.junit.Assert.assertNotNull(node66);
//        org.junit.Assert.assertNotNull(node67);
//        org.junit.Assert.assertNotNull(node69);
//        org.junit.Assert.assertNotNull(objectType76);
//        org.junit.Assert.assertNotNull(jSTypeArray77);
//        org.junit.Assert.assertNotNull(functionType78);
//        org.junit.Assert.assertNull(functionTypeList79);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
//        org.junit.Assert.assertNotNull(objectTypeIterable81);
//        org.junit.Assert.assertNull(jSType83);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(jSType86);
//        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 0L + "'", long88 == 0L);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("", charset1);
        try {
            java.io.Reader reader3 = sourceFile2.getCodeReader();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message:  (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph8.getDeepestCommonDependencyInclusive(jSModule10, jSModule12);
        compilerInput4.setModule(jSModule12);
        com.google.javascript.jscomp.SourceAst sourceAst15 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput18 = new com.google.javascript.jscomp.CompilerInput(sourceAst15, "TYPEOF ", false);
        boolean boolean19 = compilerInput18.isExtern();
        jSModule12.add(compilerInput18);
        com.google.javascript.jscomp.SourceAst sourceAst21 = compilerInput18.getSourceAst();
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jSModule13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(sourceAst21);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        functionType74.setPropertyJSDocInfo("hi!", jSDocInfo82, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = null;
        functionType74.setPropertyJSDocInfo("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", jSDocInfo86, false);
        com.google.javascript.rhino.jstype.ObjectType objectType89 = functionType74.toObjectType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNotNull(objectType89);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("");
        int int2 = functionNode1.getParamCount();
        int int3 = functionNode1.getParamCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        java.lang.String str10 = jSModule5.getName();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet11 = jSModule5.getThisAndAllDependencies();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10" + "'", str10.equals("10"));
        org.junit.Assert.assertNotNull(jSModuleSet11);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        try {
            com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.typeError2("null", "10", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property null");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.SourceAst sourceAst2 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput5 = new com.google.javascript.jscomp.CompilerInput(sourceAst2, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray6 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList7 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList7, jSModuleArray6);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph9 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList7);
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule14 = jSModuleGraph9.getDeepestCommonDependencyInclusive(jSModule11, jSModule13);
        int int15 = jSModule11.getDepth();
        java.lang.String str16 = jSModule11.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput21 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile19, false);
        jSModule11.addFirst(compilerInput21);
        compilerInput5.setModule(jSModule11);
        try {
            java.lang.String[] strArray24 = compiler0.toSourceArray(jSModule11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSModuleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(jSModule14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("TYPEOF \n");
        int int2 = functionNode1.getFunctionType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("{130370559}");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

