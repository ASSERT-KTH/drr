import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry9.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType78, jSTypeArray80);
        boolean boolean82 = functionParamBuilder6.addRequiredParams(jSTypeArray80);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.createUnionType(jSTypeArray80);
        jSTypeRegistry2.incrementGeneration();
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(jSType83);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.generatePseudoNames;
        java.lang.String str6 = compilerOptions0.renamePrefix;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode4 = new com.google.javascript.rhino.ScriptOrFnNode(0, (int) (short) 0, 22);
        scriptOrFnNode4.setEndLineno(29);
        int int7 = scriptOrFnNode4.getParamCount();
        try {
            boolean boolean8 = googleCodingConvention0.isPropertyTestFunction((com.google.javascript.rhino.Node) scriptOrFnNode4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        compiler0.reportCodeChange();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.reserveRawExports = true;
        boolean boolean5 = compilerOptions0.optimizeParameters;
        compilerOptions0.gatherCssNames = false;
        java.lang.String str8 = compilerOptions0.reportPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("");
        boolean boolean2 = functionNode1.hasOneChild();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType74.findPropertyType("hi!");
        boolean boolean80 = functionType74.hasReferenceName();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertNull(jSType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setReturnsTainted();
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getImplementedInterfaces();
        boolean boolean81 = functionType74.hasReferenceName();
        java.util.List<com.google.javascript.rhino.jstype.ObjectType> objectTypeList82 = null;
        try {
            functionType74.setImplementedInterfaces(objectTypeList82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.JSDocInfo jSDocInfo70 = objectType69.getJSDocInfo();
        boolean boolean71 = objectType69.isAllType();
        boolean boolean72 = objectType69.isInstanceType();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNull(jSDocInfo70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("TYPEOF \n");
        functionNode1.putBooleanProp(28, true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("Not declared as a type name", 41, (int) '4');
        int int4 = node3.getLineno();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        com.google.javascript.jscomp.CheckLevel checkLevel0 = com.google.javascript.jscomp.CheckLevel.WARNING;
        org.junit.Assert.assertTrue("'" + checkLevel0 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel0.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter68 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        java.util.logging.Logger logger69 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager70 = new com.google.javascript.jscomp.LoggerErrorManager((com.google.javascript.jscomp.MessageFormatter) lightweightMessageFormatter68, logger69);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isFunctionPrototypeType();
        boolean boolean81 = functionType74.matchesUint32Context();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        com.google.javascript.jscomp.DiagnosticType diagnosticType71 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel72 = diagnosticType71.level;
        java.lang.String[] strArray78 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError79 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType71, strArray78);
        compiler0.report(jSError79);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(diagnosticType71);
        org.junit.Assert.assertTrue("'" + checkLevel72 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel72.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray78);
        org.junit.Assert.assertNotNull(jSError79);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        byte[] byteArray8 = compilerOptions0.inputVariableMapSerialized;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(byteArray8);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        java.lang.Object obj69 = node67.getProp(29);
        node4.addChildAfter(node8, node67);
        boolean boolean71 = node67.isVarArgs();
        com.google.javascript.rhino.Node node72 = node67.cloneTree();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(obj69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(node72);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray0 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList1 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1, warningsGuardArray0);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard3 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup4 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup4;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup4;
        boolean boolean7 = composeWarningsGuard3.enables(diagnosticGroup4);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard3 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard12 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        org.junit.Assert.assertNotNull(warningsGuardArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        compilerOptions0.smartNameRemoval = false;
        compilerOptions0.aliasAllStrings = false;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions0.checkFunctions;
        compilerOptions0.skipAllCompilerPasses();
        boolean boolean12 = compilerOptions0.isExternExportsEnabled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        context1.seal((java.lang.Object) 3);
        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
        java.util.Locale locale5 = context1.getLocale();
        java.util.Locale locale6 = context1.getLocale();
        try {
            context1.setInstructionObserverThreshold(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNull(errorReporter4);
        org.junit.Assert.assertNotNull(locale5);
        org.junit.Assert.assertNotNull(locale6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        int int68 = compiler0.getErrorCount();
        int int69 = compiler0.getErrorCount();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 3 + "'", int69 == 3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder2 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry1);
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = node8.clonePropsFrom(node13);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node8.copyInformationFromForTree(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node25.clonePropsFrom(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node47.copyInformationFromForTree(node58);
        com.google.javascript.rhino.Node node60 = new com.google.javascript.rhino.Node((-1), node19, node31, node41, node58);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative61 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        java.lang.RuntimeException runtimeException62 = com.google.javascript.rhino.ScriptRuntime.undefWriteError((java.lang.Object) functionParamBuilder2, (java.lang.Object) node58, (java.lang.Object) jSTypeNative61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node72 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node73 = node67.clonePropsFrom(node72);
        com.google.javascript.rhino.Node node78 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node79 = node67.copyInformationFromForTree(node78);
        boolean boolean80 = node58.checkTreeEqualsSilent(node67);
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder81 = node58.new FileLevelJsDocBuilder();
        try {
            java.util.List<java.lang.String> strList82 = closureCodingConvention0.identifyTypeDeclarationCall(node58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertTrue("'" + jSTypeNative61 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative61.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
        org.junit.Assert.assertNotNull(runtimeException62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node78);
        org.junit.Assert.assertNotNull(node79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.optimizeArgumentsArray = false;
        compilerOptions0.allowLegacyJsMessages = true;
        compilerOptions0.enableRuntimeTypeCheck("Exceeded max number of optimization iterations: ");
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray12 = new com.google.javascript.jscomp.WarningsGuard[] {};
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList13 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13, warningsGuardArray12);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard15 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray16 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard15 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList17 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17, warningsGuardArray16);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard19 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList17);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard19);
        java.lang.String str21 = compilerOptions0.reportPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(warningsGuardArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        boolean boolean77 = functionType74.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.JSType jSType78 = null;
        boolean boolean79 = functionType74.isEquivalentTo(jSType78);
        boolean boolean80 = functionType74.isNativeObjectType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        compilerOptions0.foldConstants = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.inlineConstantVars = true;
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder62 = node57.getJsDocBuilderForNode();
        java.lang.String[] strArray71 = new java.lang.String[] { "<No stack trace available>", "null", "hi!", "goog.exportSymbol", "TYPEOF \n", "JSC_OPTIMIZE_LOOP_ERROR", "com.google.javascript.rhino.EvaluatorException: hi! (#3)", "Not declared as a type name" };
        java.util.LinkedHashSet<java.lang.String> strSet72 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet72, strArray71);
        node57.setDirectives((java.util.Set<java.lang.String>) strSet72);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder62);
        org.junit.Assert.assertNotNull(strArray71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int0 = com.google.javascript.rhino.Node.LASTUSE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 24 + "'", int0 == 24);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node4 = node3.getLastSibling();
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope8 = null;
        com.google.javascript.rhino.jstype.JSType jSType13 = jSTypeRegistry7.getForgivingType(jSTypeStaticScope8, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        jSTypeRegistry7.clearTemplateTypeName();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = node24.copyInformationFromForTree(node35);
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = node41.clonePropsFrom(node46);
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node52.clonePropsFrom(node57);
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node63.clonePropsFrom(node68);
        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node75 = node63.copyInformationFromForTree(node74);
        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((-1), node35, node47, node57, node74);
        com.google.javascript.rhino.Node node77 = node76.cloneTree();
        node76.setCharno((int) '#');
        node76.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry17.createObjectType("TYPEOF \n", node76, objectType83);
        com.google.javascript.rhino.JSDocInfo jSDocInfo85 = objectType84.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType86 = jSTypeRegistry7.createNullableType((com.google.javascript.rhino.jstype.JSType) objectType84);
        node4.setJSType(jSType86);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(jSType13);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(node75);
        org.junit.Assert.assertNotNull(node77);
        org.junit.Assert.assertNotNull(objectType84);
        org.junit.Assert.assertNull(jSDocInfo85);
        org.junit.Assert.assertNotNull(jSType86);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("{130370559}", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkDuplicateMessages = false;
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.lang.Object obj3 = context1.getDebuggerContextData();
//        context1.setCompileFunctionsWithDynamicScope(false);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertNull(obj3);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean7 = compilerOptions0.checkCaja;
        compilerOptions0.disableRuntimeTypeCheck();
        boolean boolean9 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.crossModuleMethodMotion = false;
        boolean boolean5 = compilerOptions0.inlineLocalFunctions;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean9 = compilerOptions0.extractPrototypeMemberDeclarations;
        com.google.javascript.jscomp.ErrorFormat errorFormat10 = com.google.javascript.jscomp.ErrorFormat.LEGACY;
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider11 = null;
        com.google.javascript.jscomp.MessageFormatter messageFormatter13 = errorFormat10.toFormatter(sourceExcerptProvider11, false);
        compilerOptions0.errorFormat = errorFormat10;
        com.google.javascript.jscomp.CheckLevel checkLevel15 = compilerOptions0.checkUnreachableCode;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(errorFormat10);
        org.junit.Assert.assertNotNull(messageFormatter13);
        org.junit.Assert.assertTrue("'" + checkLevel15 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel15.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        context0.setGeneratingSource(false);
        context0.setGeneratingSource(false);
        context0.setInstructionObserverThreshold((int) (short) 10);
        boolean boolean7 = context0.isGeneratingDebugChanged();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getImplementedInterfaces();
        boolean boolean81 = functionType74.isArrayType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable82 = functionType74.getImplementedInterfaces();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable82);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("");
        functionNode1.setEncodedSourceBounds(46, 37);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        int int13 = jSModule9.getDepth();
        java.lang.String str14 = jSModule9.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        jSModule9.addFirst(compilerInput19);
        compilerInput3.setModule(jSModule9);
        com.google.javascript.jscomp.JSModule[] jSModuleArray22 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList23 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList23, jSModuleArray22);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph25 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList23);
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule29 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule30 = jSModuleGraph25.getDeepestCommonDependencyInclusive(jSModule27, jSModule29);
        int int31 = jSModule27.getDepth();
        java.nio.charset.Charset charset33 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile34 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset33);
        com.google.javascript.jscomp.CompilerInput compilerInput35 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile34);
        jSModule27.addFirst(jSSourceFile34);
        jSModule9.add(jSSourceFile34);
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNotNull(jSModuleArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(jSModule30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile34);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.Node node60 = node59.cloneTree();
        java.util.Set<java.lang.String> strSet61 = node59.getDirectives();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship62 = closureCodingConvention0.getClassesDefinedByCall(node59);
        java.lang.Appendable appendable63 = null;
        try {
            node59.appendStringTree(appendable63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(strSet61);
        org.junit.Assert.assertNull(subclassRelationship62);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.lang.Object obj3 = context1.getDebuggerContextData();
//        boolean boolean4 = context1.isGeneratingDebugChanged();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup5;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
//        context1.removeThreadLocal((java.lang.Object) diagnosticGroup5);
//        context1.removeThreadLocal((java.lang.Object) 10.0f);
//        context1.setInstructionObserverThreshold(130);
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertNull(obj3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        try {
//            context1.removeActivationName("language version");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        try {
//            com.google.javascript.rhino.Context.reportError("function (this:me, {1353026226}): me");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: function (this:me, {1353026226}): me");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.generateExports = false;
        boolean boolean9 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable4 = node3.getAncestors();
        com.google.javascript.rhino.jstype.JSType jSType5 = node3.getJSType();
        com.google.javascript.rhino.Node node7 = node3.getAncestor(7);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(ancestorIterable4);
        org.junit.Assert.assertNull(jSType5);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType74.getJSDocInfo();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.getRestrictedTypeGivenToBooleanOutcome(false);
        boolean boolean82 = functionType74.isOrdinaryFunction();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNull(jSDocInfo79);
        org.junit.Assert.assertNotNull(jSType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("goog.exportSymbol", "hi!", "Unknown class name", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property goog.exportSymbol");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        java.lang.Object obj69 = node67.getProp(29);
        node4.addChildAfter(node8, node67);
        com.google.javascript.rhino.Node node71 = null;
        try {
            node8.addChildToBack(node71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(obj69);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSType jSType77 = objectType76.restrictByNotNullOrUndefined();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSType77);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        com.google.javascript.rhino.jstype.JSType jSType59 = node57.getJSType();
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags60 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags60.setThrows();
        try {
            node57.setSideEffectFlags(sideEffectFlags60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got ERROR");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNull(jSType59);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.prettyPrint = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.rhino.jstype.FunctionType functionType1 = null;
        com.google.javascript.rhino.jstype.FunctionType functionType2 = null;
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType3 = null;
        defaultCodingConvention0.applySubclassRelationship(functionType1, functionType2, subclassType3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        java.lang.Object obj65 = node63.getProp(29);
        com.google.javascript.jscomp.CodingConvention.DelegateRelationship delegateRelationship66 = defaultCodingConvention0.getDelegateRelationship(node63);
        boolean boolean68 = defaultCodingConvention0.isConstant("<No stack trace available>");
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNull(obj65);
        org.junit.Assert.assertNull(delegateRelationship66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node2 = null;
        boolean boolean3 = closureCodingConvention0.isVarArgsParameter(node2);
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node11.clonePropsFrom(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = node11.copyInformationFromForTree(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = node28.clonePropsFrom(node33);
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = node39.clonePropsFrom(node44);
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node50.clonePropsFrom(node55);
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = node50.copyInformationFromForTree(node61);
        com.google.javascript.rhino.Node node63 = new com.google.javascript.rhino.Node((-1), node22, node34, node44, node61);
        com.google.javascript.rhino.Node node64 = node63.cloneTree();
        node63.setCharno((int) '#');
        com.google.javascript.rhino.Node node67 = node63.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable68 = node67.siblings();
        java.lang.String str69 = node67.toStringTree();
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node(100, node67, 3, 29);
        java.lang.String str73 = closureCodingConvention0.extractClassNameIfRequire(node4, node67);
        boolean boolean74 = node67.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(nodeIterable68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "TYPEOF \n" + "'", str69.equals("TYPEOF \n"));
        org.junit.Assert.assertNull(str73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("10");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property 10");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property Not declared as a type name");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = objectType79.hasOwnProperty("10");
        com.google.javascript.rhino.jstype.JSType jSType82 = objectType79.getParameterType();
        boolean boolean83 = objectType79.isCheckedUnknownType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        functionType74.setPropertyJSDocInfo("hi!", jSDocInfo82, false);
        boolean boolean85 = functionType74.isNumberValueType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.lang.Object obj3 = null;
//        context1.seal(obj3);
//        try {
//            context1.setGeneratingSource(true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkUnusedPropertiesEarly;
        compilerOptions0.decomposeExpressions = false;
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4, false);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node16.clonePropsFrom(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node16.copyInformationFromForTree(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node55.clonePropsFrom(node60);
        com.google.javascript.rhino.Node node66 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node67 = node55.copyInformationFromForTree(node66);
        com.google.javascript.rhino.Node node68 = new com.google.javascript.rhino.Node((-1), node27, node39, node49, node66);
        com.google.javascript.rhino.Node node69 = node68.cloneTree();
        node68.setCharno((int) '#');
        node68.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType75 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry9.createObjectType("TYPEOF \n", node68, objectType75);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray77 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType78 = jSTypeRegistry6.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType75, jSTypeArray77);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList79 = functionType78.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter80 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope81 = null;
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType78.resolve(errorReporter80, jSTypeStaticScope81);
        java.util.Set<java.lang.String> strSet83 = functionType78.getOwnPropertyNames();
        compilerOptions0.stripTypes = strSet83;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSTypeArray77);
        org.junit.Assert.assertNotNull(functionType78);
        org.junit.Assert.assertNull(functionTypeList79);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNotNull(strSet83);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        java.lang.String str81 = functionType74.getNormalizedReferenceName();
        boolean boolean82 = functionType74.isInstanceType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        int int12 = node10.getIntProp((int) (short) 1);
        com.google.javascript.rhino.Node node13 = node10.getParent();
        java.lang.String str14 = node10.getString();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        com.google.javascript.rhino.FunctionNode functionNode2 = new com.google.javascript.rhino.FunctionNode("");
        int int4 = functionNode2.getParamOrVarIndex("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        node62.setCharno((int) '#');
        com.google.javascript.rhino.Node node66 = node62.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable67 = node66.siblings();
        java.lang.String str68 = node66.toStringTree();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(26, (com.google.javascript.rhino.Node) functionNode2, node66, 32, 7);
        int int72 = functionNode2.getParamCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeIterable67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "TYPEOF \n" + "'", str68.equals("TYPEOF \n"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("goog.exportSymbol", "");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions0.reportPath = "NAME hi!";
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative3 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getNativeType(jSTypeNative3);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, true);
        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry10 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter8, false);
        com.google.javascript.rhino.ErrorReporter errorReporter11 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter11, false);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node20.clonePropsFrom(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node20.copyInformationFromForTree(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node59.clonePropsFrom(node64);
        com.google.javascript.rhino.Node node70 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node71 = node59.copyInformationFromForTree(node70);
        com.google.javascript.rhino.Node node72 = new com.google.javascript.rhino.Node((-1), node31, node43, node53, node70);
        com.google.javascript.rhino.Node node73 = node72.cloneTree();
        node72.setCharno((int) '#');
        node72.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType80 = jSTypeRegistry13.createObjectType("TYPEOF \n", node72, objectType79);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray81 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType82 = jSTypeRegistry10.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType79, jSTypeArray81);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList83 = functionType82.getSubTypes();
        boolean boolean84 = functionType82.isInterface();
        boolean boolean85 = functionType82.isReturnTypeInferred();
        com.google.javascript.rhino.jstype.JSType jSType86 = null;
        boolean boolean87 = functionType82.isEquivalentTo(jSType86);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry89 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder90 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry89);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray91 = new com.google.javascript.rhino.jstype.JSType[] {};
        boolean boolean92 = functionParamBuilder90.addRequiredParams(jSTypeArray91);
        com.google.javascript.rhino.jstype.FunctionType functionType93 = jSTypeRegistry7.createFunctionType(jSType86, true, jSTypeArray91);
        com.google.javascript.rhino.jstype.JSType jSType94 = jSTypeRegistry2.createUnionType(jSTypeArray91);
        org.junit.Assert.assertTrue("'" + jSTypeNative3 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative3.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
        org.junit.Assert.assertNotNull(jSType4);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertNotNull(jSTypeArray81);
        org.junit.Assert.assertNotNull(functionType82);
        org.junit.Assert.assertNull(functionTypeList83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(jSTypeArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertNotNull(functionType93);
        org.junit.Assert.assertNotNull(jSType94);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        jSSourceFile1.setOriginalPath("language version");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config3 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter4 = null;
        try {
            com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "JSC_OPTIMIZE_LOOP_ERROR", config3, errorReporter4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(config3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isObject();
        boolean boolean79 = functionType74.isFunctionType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        boolean boolean81 = functionType74.isNumberValueType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.util.logging.Logger logger0 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager1 = new com.google.javascript.jscomp.LoggerErrorManager(logger0);
        double double2 = loggerErrorManager1.getTypedPercent();
        com.google.javascript.jscomp.JSError[] jSErrorArray3 = loggerErrorManager1.getErrors();
        loggerErrorManager1.generateReport();
        loggerErrorManager1.setTypedPercent((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(jSErrorArray3);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("{130370559}", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = null;
        functionType74.setPropertyJSDocInfo("hi!", jSDocInfo82, false);
        com.google.javascript.rhino.JSDocInfo jSDocInfo86 = null;
        functionType74.setPropertyJSDocInfo("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", jSDocInfo86, false);
        boolean boolean89 = functionType74.isFunctionType();
        com.google.javascript.rhino.jstype.JSType jSType90 = functionType74.unboxesTo();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable91 = functionType74.getCtorImplementedInterfaces();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNull(jSType90);
        org.junit.Assert.assertNotNull(objectTypeIterable91);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromCode("<No stack trace available>", "function (this:me, {1353026226}): me");
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable62 = node61.siblings();
        boolean boolean63 = node61.hasSideEffects();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(nodeIterable62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput65 = compiler0.newExternInput("TYPEOF ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.hasInstanceType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.renamePrefix = "{130370559}";
        boolean boolean5 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.reportMissingOverride;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter68 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        lightweightMessageFormatter68.setColorize(false);
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.setDefineToDoubleLiteral("TYPEOF \n", (double) (short) 0);
        boolean boolean6 = compilerOptions0.prettyPrint;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkRequires;
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        com.google.javascript.rhino.jstype.ObjectType objectType9 = jSTypeRegistry2.createAnonymousObjectType();
        boolean boolean10 = objectType9.isUnionType();
        org.junit.Assert.assertNotNull(jSType8);
        org.junit.Assert.assertNotNull(objectType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.Node node60 = node59.cloneTree();
        java.util.Set<java.lang.String> strSet61 = node59.getDirectives();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship62 = closureCodingConvention0.getClassesDefinedByCall(node59);
        boolean boolean64 = closureCodingConvention0.isConstantKey("Exceeded max number of optimization iterations: ");
        java.lang.String str65 = closureCodingConvention0.getExportSymbolFunction();
        java.lang.String str66 = closureCodingConvention0.getAbstractMethodName();
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(strSet61);
        org.junit.Assert.assertNull(subclassRelationship62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "goog.exportSymbol" + "'", str65.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "goog.abstractMethod" + "'", str66.equals("goog.abstractMethod"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkEs5Strict = false;
        compilerOptions0.specializeInitialModule = true;
        boolean boolean11 = compilerOptions0.checkTypes;
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions0.crossModuleCodeMotion = false;
        boolean boolean7 = compilerOptions0.checkCaja;
        compilerOptions0.prettyPrint = true;
        java.lang.String[] strArray25 = new java.lang.String[] { "", "{1479088659}", "<No stack trace available>", "Exceeded max number of optimization iterations: ", "{1813971029}", "Not declared as a type name", "com.google.javascript.rhino.EvaluatorException: hi! (#3)", "{1813971029}", "Named type with empty name component", "language version", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}", "null", "Unknown class name", "{1479088659}" };
        java.util.ArrayList<java.lang.String> strList26 = new java.util.ArrayList<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList26, strArray25);
        compilerOptions0.setReplaceStringsConfiguration("TYPEOF ", (java.util.List<java.lang.String>) strList26);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput4 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2, false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList6 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList6, jSModuleArray5);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph8 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList6);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule13 = jSModuleGraph8.getDeepestCommonDependencyInclusive(jSModule10, jSModule12);
        compilerInput4.setModule(jSModule12);
        try {
            java.lang.String str15 = compilerInput4.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(jSModule13);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        java.util.Locale locale5 = context1.getLocale();
//        java.util.Locale locale6 = context1.getLocale();
//        boolean boolean7 = context1.isGeneratingSource();
//        try {
//            context1.addActivationName("Not declared as a type name");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertNotNull(locale5);
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.Scope scope1 = compiler0.getTopScope();
        com.google.javascript.jscomp.JSModule[] jSModuleArray2 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList3 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList3, jSModuleArray2);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph5 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList3);
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule10 = jSModuleGraph5.getDeepestCommonDependencyInclusive(jSModule7, jSModule9);
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.SourceAst sourceAst13 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(sourceAst13, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray17 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList18 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList18, jSModuleArray17);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph20 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList18);
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule24 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule25 = jSModuleGraph20.getDeepestCommonDependencyInclusive(jSModule22, jSModule24);
        int int26 = jSModule22.getDepth();
        java.lang.String str27 = jSModule22.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile30 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput32 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile30, false);
        jSModule22.addFirst(compilerInput32);
        compilerInput16.setModule(jSModule22);
        boolean boolean35 = jSModuleGraph5.dependsOn(jSModule12, jSModule22);
        int int36 = jSModule12.getDepth();
        try {
            java.lang.String[] strArray37 = compiler0.toSourceArray(jSModule12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(scope1);
        org.junit.Assert.assertNotNull(jSModuleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(jSModule10);
        org.junit.Assert.assertNotNull(jSModuleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(jSModule25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.RuntimeException runtimeException1 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) "Named type with empty name component");
        org.junit.Assert.assertNotNull(runtimeException1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.lineBreak;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.CssRenamingMap cssRenamingMap9 = null;
        compilerOptions0.cssRenamingMap = cssRenamingMap9;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.JSType jSType70 = objectType69.unboxesTo();
        boolean boolean71 = objectType69.isNativeObjectType();
        boolean boolean72 = objectType69.isDateType();
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNull(jSType70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        boolean boolean5 = compilerOptions0.labelRenaming;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        compilerOptions0.inlineLocalFunctions = true;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention2 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal3 = null;
        com.google.javascript.rhino.Node node7 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast8 = defaultCodingConvention2.getObjectLiteralCast(nodeTraversal3, node7);
        try {
            com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship9 = closureCodingConvention0.getClassesDefinedByCall(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNull(objectLiteralCast8);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        com.google.javascript.rhino.Context context0 = new com.google.javascript.rhino.Context();
        boolean boolean2 = context0.isActivationNeeded("");
        java.util.Locale locale3 = context0.getLocale();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(locale3);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        java.util.Locale locale5 = context1.getLocale();
//        java.util.Locale locale6 = context1.getLocale();
//        boolean boolean7 = context1.isGeneratingSource();
//        boolean boolean8 = context1.isGeneratingDebugChanged();
//        try {
//            context1.setInstructionObserverThreshold(27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertNotNull(locale5);
//        org.junit.Assert.assertNotNull(locale6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy3;
        boolean boolean5 = compilerOptions0.aliasAllStrings;
        compilerOptions0.smartNameRemoval = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        jSSourceFile2.clearCachedSource();
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newExpr(node3);
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        node62.setCharno((int) '#');
        java.lang.RuntimeException runtimeException66 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) node3, (java.lang.Object) '#');
        java.lang.String str70 = node3.toString(false, false, true);
        com.google.javascript.rhino.Node node71 = node3.removeChildren();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(runtimeException66);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "NAME hi!" + "'", str70.equals("NAME hi!"));
        org.junit.Assert.assertNull(node71);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            com.google.javascript.rhino.Context.reportWarning("NAME hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setThrows();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray70 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType71 = jSTypeRegistry2.createUnionType(jSTypeNativeArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString((int) (byte) 10, "");
        node2.setQuotedString();
        com.google.javascript.rhino.JSDocInfo jSDocInfo4 = null;
        node2.setJSDocInfo(jSDocInfo4);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 1, (int) (short) 100, 6);
        int int5 = scriptOrFnNode3.addVar("");
        java.lang.String[] strArray6 = scriptOrFnNode3.getParamAndVarNames();
        int int7 = scriptOrFnNode3.getParamCount();
        int int8 = scriptOrFnNode3.getEndLineno();
        int int9 = scriptOrFnNode3.getEncodedSourceStart();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = functionType74.getJSDocInfo();
        com.google.javascript.rhino.jstype.ObjectType objectType80 = functionType74.getImplicitPrototype();
        boolean boolean81 = objectType80.matchesNumberContext();
        java.lang.String str82 = objectType80.getNormalizedReferenceName();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNull(jSDocInfo79);
        org.junit.Assert.assertNotNull(objectType80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Function" + "'", str82.equals("Function"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType74.findPropertyType("hi!");
        boolean boolean81 = functionType74.isPropertyTypeDeclared("TYPEOF ");
        com.google.javascript.rhino.JSDocInfo jSDocInfo82 = functionType74.getJSDocInfo();
        boolean boolean84 = functionType74.isPropertyInExterns("<No stack trace available>");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertNull(jSType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNull(jSDocInfo82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(16, "Exceeded max number of optimization iterations: ");
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray4 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList5 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList5, jSModuleArray4);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph7 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList5);
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule12 = jSModuleGraph7.getDeepestCommonDependencyInclusive(jSModule9, jSModule11);
        int int13 = jSModule9.getDepth();
        java.lang.String str14 = jSModule9.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile17 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput19 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile17, false);
        jSModule9.addFirst(compilerInput19);
        compilerInput3.setModule(jSModule9);
        com.google.javascript.jscomp.SourceAst sourceAst22 = compilerInput3.getSourceAst();
        org.junit.Assert.assertNotNull(jSModuleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(jSModule12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile17);
        org.junit.Assert.assertNull(sourceAst22);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.reportCodeChange();
        compiler0.disableThreads();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = node17.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node17.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = node56.clonePropsFrom(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = node56.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((-1), node28, node40, node50, node67);
        com.google.javascript.rhino.Node node70 = node69.cloneTree();
        java.lang.Object obj72 = node70.getProp(29);
        node7.addChildAfter(node11, node70);
        java.lang.String str77 = node7.toString(true, false, false);
        com.google.javascript.jscomp.NodeTraversal.Callback callback78 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler0, node7, callback78);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNull(obj72);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "TYPEOF " + "'", str77.equals("TYPEOF "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("", "Exceeded max number of optimization iterations: ");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = node15.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node66 = node54.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((-1), node26, node38, node48, node65);
        com.google.javascript.rhino.Node node68 = node67.cloneTree();
        node67.setCharno((int) '#');
        node67.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType74 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry8.createObjectType("TYPEOF \n", node67, objectType74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry5.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType74, jSTypeArray76);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList78 = functionType77.getSubTypes();
        boolean boolean79 = functionType77.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType77.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType77.findPropertyType("hi!");
        boolean boolean84 = functionType77.isPropertyTypeDeclared("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry2.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType77);
        boolean boolean86 = functionType77.canBeCalled();
        boolean boolean87 = functionType77.matchesStringContext();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(functionTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        com.google.javascript.rhino.Node node7 = node5.getLastChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertNull(node7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        java.lang.String str7 = compilerOptions0.jsOutputFile;
        boolean boolean8 = compilerOptions0.computeFunctionSideEffects;
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        boolean boolean3 = compilerOptions0.labelRenaming;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy4 = compilerOptions0.anonymousFunctionNaming;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy4 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy4.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isDateType();
        com.google.javascript.rhino.jstype.JSType jSType79 = functionType74.getIndexType();
        try {
            boolean boolean80 = jSType79.isInstanceType();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(jSType79);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        boolean boolean3 = compilerOptions0.labelRenaming;
        boolean boolean4 = compilerOptions0.devirtualizePrototypeMethods;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        compilerOptions0.smartNameRemoval = false;
        compilerOptions0.aliasAllStrings = false;
        compilerOptions0.disableRuntimeTypeCheck();
        compilerOptions0.instrumentForCoverage = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isNumberValueType();
        boolean boolean79 = functionType74.isObject();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        boolean boolean5 = compilerOptions0.lineBreak;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_CLASS;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a constructor" + "'", str0.equals("Not declared as a constructor"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        compilerOptions0.checkUnusedPropertiesEarly = false;
        compilerOptions0.aliasAllStrings = false;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph18.getDeepestCommonDependencyInclusive(jSModule20, jSModule22);
        int int24 = jSModule20.getDepth();
        java.lang.String str25 = jSModule20.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        jSModule20.addFirst(compilerInput30);
        compilerInput14.setModule(jSModule20);
        boolean boolean33 = jSModuleGraph3.dependsOn(jSModule10, jSModule20);
        int int34 = jSModule10.getDepth();
        int int35 = jSModule10.getDepth();
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = objectType79.hasOwnProperty("10");
        com.google.javascript.rhino.jstype.JSType jSType82 = objectType79.restrictByNotNullOrUndefined();
        com.google.javascript.rhino.jstype.JSType jSType83 = jSType82.autoboxesTo();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertNotNull(jSType82);
        org.junit.Assert.assertNull(jSType83);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = node9.clonePropsFrom(node14);
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node9.copyInformationFromForTree(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = node26.clonePropsFrom(node31);
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = node37.clonePropsFrom(node42);
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = node48.clonePropsFrom(node53);
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node48.copyInformationFromForTree(node59);
        com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node((-1), node20, node32, node42, node59);
        com.google.javascript.rhino.Node node62 = node61.cloneTree();
        node61.setCharno((int) '#');
        node61.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType68 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType69 = jSTypeRegistry2.createObjectType("TYPEOF \n", node61, objectType68);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope70 = null;
        com.google.javascript.rhino.jstype.JSType jSType75 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope70, "", "TYPEOF \n", 32, (int) ' ');
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = jSTypeRegistry2.createAnonymousObjectType();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative78 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry2.getNativeObjectType(jSTypeNative78);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(objectType69);
        org.junit.Assert.assertNotNull(jSType75);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + jSTypeNative78 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative78.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
        org.junit.Assert.assertNotNull(objectType79);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("NAME hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property NAME hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.printInputDelimiter;
        compilerOptions0.smartNameRemoval = false;
        compilerOptions0.removeUnusedPrototypePropertiesInExterns = false;
        compilerOptions0.aliasAllStrings = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.brokenClosureRequiresLevel = checkLevel5;
        compilerOptions0.ideMode = false;
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        boolean boolean8 = compilerOptions0.markNoSideEffectCalls;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.checkEs5Strict;
        compilerOptions3.coalesceVariableNames = false;
        boolean boolean7 = compilerOptions3.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap8 = null;
        compilerOptions3.customPasses = customPassExecutionTimeMultimap8;
        boolean boolean10 = compilerOptions3.inlineLocalVariables;
        compilerOptions3.optimizeParameters = false;
        com.google.javascript.jscomp.DiagnosticType diagnosticType13 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType17 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel18 = diagnosticType17.level;
        java.lang.String[] strArray24 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError25 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType17, strArray24);
        int int26 = diagnosticType13.compareTo(diagnosticType17);
        java.lang.String str27 = diagnosticType17.key;
        com.google.javascript.jscomp.CheckLevel checkLevel28 = diagnosticType17.level;
        compilerOptions3.brokenClosureRequiresLevel = checkLevel28;
        com.google.javascript.jscomp.DiagnosticType diagnosticType30 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.DiagnosticType diagnosticType34 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel35 = diagnosticType34.level;
        java.lang.String[] strArray41 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError42 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType34, strArray41);
        int int43 = diagnosticType30.compareTo(diagnosticType34);
        java.lang.String str44 = diagnosticType34.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType48 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel49 = diagnosticType48.level;
        java.lang.String[] strArray50 = com.google.javascript.rhino.ScriptRuntime.emptyStrings;
        com.google.javascript.jscomp.JSError jSError51 = com.google.javascript.jscomp.JSError.make("10", 43, 35, diagnosticType48, strArray50);
        com.google.javascript.jscomp.JSError jSError52 = com.google.javascript.jscomp.JSError.make("{130370559}", 5, 0, checkLevel28, diagnosticType34, strArray50);
        int int53 = jSError52.lineNumber;
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(diagnosticType13);
        org.junit.Assert.assertNotNull(diagnosticType17);
        org.junit.Assert.assertTrue("'" + checkLevel18 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel18.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(jSError25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR" + "'", str27.equals("JSC_OPTIMIZE_LOOP_ERROR"));
        org.junit.Assert.assertTrue("'" + checkLevel28 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel28.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticType30);
        org.junit.Assert.assertNotNull(diagnosticType34);
        org.junit.Assert.assertTrue("'" + checkLevel35 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel35.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(jSError42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str44.equals("JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType48);
        org.junit.Assert.assertTrue("'" + checkLevel49 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel49.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray50);
        org.junit.Assert.assertNotNull(jSError51);
        org.junit.Assert.assertNotNull(jSError52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5 + "'", int53 == 5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter6, false);
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node21 = node15.clonePropsFrom(node20);
        com.google.javascript.rhino.Node node26 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = node15.copyInformationFromForTree(node26);
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = node32.clonePropsFrom(node37);
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = node43.clonePropsFrom(node48);
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node60 = node54.clonePropsFrom(node59);
        com.google.javascript.rhino.Node node65 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node66 = node54.copyInformationFromForTree(node65);
        com.google.javascript.rhino.Node node67 = new com.google.javascript.rhino.Node((-1), node26, node38, node48, node65);
        com.google.javascript.rhino.Node node68 = node67.cloneTree();
        node67.setCharno((int) '#');
        node67.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType74 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType75 = jSTypeRegistry8.createObjectType("TYPEOF \n", node67, objectType74);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray76 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType77 = jSTypeRegistry5.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType74, jSTypeArray76);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList78 = functionType77.getSubTypes();
        boolean boolean79 = functionType77.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType77.getAllImplementedInterfaces();
        com.google.javascript.rhino.jstype.JSType jSType82 = functionType77.findPropertyType("hi!");
        boolean boolean84 = functionType77.isPropertyTypeDeclared("TYPEOF ");
        com.google.javascript.rhino.jstype.JSType jSType85 = jSTypeRegistry2.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType77);
        com.google.javascript.rhino.jstype.JSType jSType87 = functionType77.getPropertyType("10");
        boolean boolean88 = functionType77.isNativeObjectType();
        boolean boolean89 = functionType77.isAllType();
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(objectType75);
        org.junit.Assert.assertNotNull(jSTypeArray76);
        org.junit.Assert.assertNotNull(functionType77);
        org.junit.Assert.assertNull(functionTypeList78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertNull(jSType82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(jSType85);
        org.junit.Assert.assertNotNull(jSType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.crossModuleMethodMotion = false;
        boolean boolean10 = compilerOptions0.instrumentForCoverage;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        com.google.javascript.rhino.Context context0 = null;
        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
        java.util.Locale locale2 = context1.getLocale();
        java.util.Locale locale3 = context1.getLocale();
        org.junit.Assert.assertNotNull(context1);
        org.junit.Assert.assertNotNull(locale2);
        org.junit.Assert.assertNotNull(locale3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "hi!", 4);
        evaluatorException3.initColumnNumber(19);
        int int6 = evaluatorException3.lineNumber();
        try {
            evaluatorException3.initLineNumber((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = node17.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node17.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = node56.clonePropsFrom(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = node56.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((-1), node28, node40, node50, node67);
        com.google.javascript.rhino.Node node70 = node69.cloneTree();
        node69.setCharno((int) '#');
        com.google.javascript.rhino.Node node73 = node69.removeFirstChild();
        com.google.javascript.rhino.Node node74 = node4.copyInformationFrom(node69);
        int int75 = node69.getCharno();
        com.google.javascript.rhino.Node node76 = com.google.javascript.jscomp.NodeUtil.newExpr(node69);
        try {
            int int78 = node76.getExistingIntProp((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(node76);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isDateType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo80 = functionType74.getOwnPropertyJSDocInfo("TYPEOF ");
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable81 = functionType74.getImplementedInterfaces();
        com.google.javascript.rhino.Node node82 = functionType74.getParametersNode();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(jSDocInfo80);
        org.junit.Assert.assertNotNull(objectTypeIterable81);
        org.junit.Assert.assertNotNull(node82);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.appNameStr = "language version";
        boolean boolean9 = compilerOptions0.tightenTypes;
        java.lang.String str10 = compilerOptions0.aliasStringsBlacklist;
        boolean boolean11 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = compilerOptions0.checkMissingGetCssNameLevel;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel5 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel5.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        com.google.javascript.jscomp.CompilerInput compilerInput69 = compiler0.getInput("10");
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(compilerInput69);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, true);
        com.google.javascript.rhino.jstype.JSType jSType4 = jSTypeRegistry2.getType("TYPEOF \n");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative5 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        com.google.javascript.rhino.jstype.JSTypeNative[] jSTypeNativeArray6 = new com.google.javascript.rhino.jstype.JSTypeNative[] { jSTypeNative5 };
        com.google.javascript.rhino.jstype.JSType jSType7 = jSTypeRegistry2.createUnionType(jSTypeNativeArray6);
        org.junit.Assert.assertNull(jSType4);
        org.junit.Assert.assertTrue("'" + jSTypeNative5 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative5.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
        org.junit.Assert.assertNotNull(jSTypeNativeArray6);
        org.junit.Assert.assertNotNull(jSType7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node12 = node4.getLastSibling();
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node18.clonePropsFrom(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node18.copyInformationFromForTree(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node57.clonePropsFrom(node62);
        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node69 = node57.copyInformationFromForTree(node68);
        com.google.javascript.rhino.Node node70 = new com.google.javascript.rhino.Node((-1), node29, node41, node51, node68);
        com.google.javascript.rhino.Node node71 = node70.cloneTree();
        node70.setCharno((int) '#');
        com.google.javascript.rhino.Node node74 = node70.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable75 = node74.siblings();
        java.lang.String str76 = node74.toStringTree();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable77 = node74.siblings();
        boolean boolean78 = node12.isEquivalentTo(node74);
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node71);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertNotNull(nodeIterable75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "TYPEOF \n" + "'", str76.equals("TYPEOF \n"));
        org.junit.Assert.assertNotNull(nodeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        java.lang.String str4 = googleCodingConvention0.getExportSymbolFunction();
        boolean boolean7 = googleCodingConvention0.isExported("goog.exportSymbol", true);
        boolean boolean9 = googleCodingConvention0.isValidEnumKey("Named type with empty name component");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        java.lang.String str5 = compilerOptions0.checkMissingGetCssNameBlacklist;
        java.util.Set<java.lang.String> strSet6 = null;
        try {
            compilerOptions0.setIdGenerators(strSet6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node6.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = functionParamBuilder1.newParameterFromNode(node6);
        boolean boolean20 = functionParamBuilder1.hasVarArgs();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 0, 31, 34);
        java.lang.String str25 = scriptOrFnNode24.getSourceName();
        com.google.javascript.rhino.Node node26 = functionParamBuilder1.newParameterFromNode((com.google.javascript.rhino.Node) scriptOrFnNode24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node31 = com.google.javascript.jscomp.NodeUtil.newExpr(node30);
        com.google.javascript.rhino.JSDocInfo jSDocInfo32 = node30.getJSDocInfo();
        try {
            node26.removeChild(node30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNull(jSDocInfo32);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.renamePrefix = "Unknown class name";
        compilerOptions7.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions7.crossModuleCodeMotion = false;
        compilerOptions7.appNameStr = "language version";
        boolean boolean16 = compilerOptions7.tightenTypes;
        compilerOptions7.nameReferenceReportPath = "NAME hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel19 = compilerOptions7.checkGlobalThisLevel;
        compilerOptions0.checkShadowVars = checkLevel19;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        java.lang.String str4 = googleCodingConvention0.getExportSymbolFunction();
        boolean boolean7 = googleCodingConvention0.isExported("goog.exportSymbol", true);
        boolean boolean9 = googleCodingConvention0.isPrivate("{130370559}");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        com.google.javascript.rhino.FunctionNode functionNode1 = new com.google.javascript.rhino.FunctionNode("");
        functionNode1.removeParamOrVar("10");
        com.google.javascript.rhino.Node node8 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node14 = node8.clonePropsFrom(node13);
        int int16 = node14.getIntProp((int) (short) 1);
        com.google.javascript.rhino.Node node17 = node14.getParent();
        com.google.javascript.rhino.JSDocInfo jSDocInfo18 = node14.getJSDocInfo();
        com.google.javascript.rhino.Node node19 = com.google.javascript.jscomp.NodeUtil.newExpr(node14);
        boolean boolean20 = functionNode1.checkTreeTypeAwareEqualsSilent(node14);
        int int21 = functionNode1.getParamAndVarCount();
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNull(node17);
        org.junit.Assert.assertNull(jSDocInfo18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkMethods;
        compilerOptions0.inlineGetters = true;
        java.lang.String str5 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.checkEs5Strict = false;
        boolean boolean9 = compilerOptions0.extractPrototypeMemberDeclarations;
        compilerOptions0.removeEmptyFunctions = false;
        compilerOptions0.aliasStringsBlacklist = "null";
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticType3.level;
        java.lang.String[] strArray10 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError11 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType3, strArray10);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = diagnosticType3.defaultLevel;
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(jSError11);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        java.util.Locale locale2 = context1.getLocale();
//        java.lang.Object obj3 = context1.getDebuggerContextData();
//        boolean boolean4 = context1.isGeneratingDebugChanged();
//        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES;
//        com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION = diagnosticGroup5;
//        com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL = diagnosticGroup5;
//        context1.removeThreadLocal((java.lang.Object) diagnosticGroup5);
//        context1.removeThreadLocal((java.lang.Object) 10.0f);
//        int int11 = context1.getOptimizationLevel();
//        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12, false);
//        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
//        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry17 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15, false);
//        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
//        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node36 = node24.copyInformationFromForTree(node35);
//        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node47 = node41.clonePropsFrom(node46);
//        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node58 = node52.clonePropsFrom(node57);
//        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node68 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node69 = node63.clonePropsFrom(node68);
//        com.google.javascript.rhino.Node node74 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
//        com.google.javascript.rhino.Node node75 = node63.copyInformationFromForTree(node74);
//        com.google.javascript.rhino.Node node76 = new com.google.javascript.rhino.Node((-1), node35, node47, node57, node74);
//        com.google.javascript.rhino.Node node77 = node76.cloneTree();
//        node76.setCharno((int) '#');
//        node76.putBooleanProp((int) (byte) 100, false);
//        com.google.javascript.rhino.jstype.ObjectType objectType83 = null;
//        com.google.javascript.rhino.jstype.ObjectType objectType84 = jSTypeRegistry17.createObjectType("TYPEOF \n", node76, objectType83);
//        com.google.javascript.rhino.jstype.JSType[] jSTypeArray85 = new com.google.javascript.rhino.jstype.JSType[] {};
//        com.google.javascript.rhino.jstype.FunctionType functionType86 = jSTypeRegistry14.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType83, jSTypeArray85);
//        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList87 = functionType86.getSubTypes();
//        boolean boolean88 = functionType86.isInterface();
//        com.google.javascript.rhino.jstype.JSType jSType90 = functionType86.getRestrictedTypeGivenToBooleanOutcome(true);
//        com.google.javascript.rhino.jstype.ObjectType objectType91 = functionType86.getTypeOfThis();
//        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable92 = functionType86.getAllImplementedInterfaces();
//        com.google.javascript.rhino.JSDocInfo jSDocInfo94 = null;
//        functionType86.setPropertyJSDocInfo("hi!", jSDocInfo94, false);
//        int int97 = functionType86.getPropertiesCount();
//        try {
//            context1.unseal((java.lang.Object) functionType86);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNotNull(locale2);
//        org.junit.Assert.assertNull(obj3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(diagnosticGroup5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(node24);
//        org.junit.Assert.assertNotNull(node29);
//        org.junit.Assert.assertNotNull(node30);
//        org.junit.Assert.assertNotNull(node35);
//        org.junit.Assert.assertNotNull(node36);
//        org.junit.Assert.assertNotNull(node41);
//        org.junit.Assert.assertNotNull(node46);
//        org.junit.Assert.assertNotNull(node47);
//        org.junit.Assert.assertNotNull(node52);
//        org.junit.Assert.assertNotNull(node57);
//        org.junit.Assert.assertNotNull(node58);
//        org.junit.Assert.assertNotNull(node63);
//        org.junit.Assert.assertNotNull(node68);
//        org.junit.Assert.assertNotNull(node69);
//        org.junit.Assert.assertNotNull(node74);
//        org.junit.Assert.assertNotNull(node75);
//        org.junit.Assert.assertNotNull(node77);
//        org.junit.Assert.assertNotNull(objectType84);
//        org.junit.Assert.assertNotNull(jSTypeArray85);
//        org.junit.Assert.assertNotNull(functionType86);
//        org.junit.Assert.assertNull(functionTypeList87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(jSType90);
//        org.junit.Assert.assertNotNull(objectType91);
//        org.junit.Assert.assertNotNull(objectTypeIterable92);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        compilerOptions0.checkEs5Strict = true;
        compilerOptions0.collapseProperties = false;
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        boolean boolean8 = compilerOptions0.aliasKeywords;
        byte[] byteArray9 = compilerOptions0.inputVariableMapSerialized;
        compilerOptions0.inlineGetters = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(byteArray9);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        com.google.javascript.jscomp.MessageFormatter messageFormatter0 = null;
        java.util.logging.Logger logger1 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager2 = new com.google.javascript.jscomp.LoggerErrorManager(messageFormatter0, logger1);
        com.google.javascript.jscomp.CheckLevel checkLevel3 = null;
        com.google.javascript.jscomp.JSError jSError4 = null;
        try {
            loggerErrorManager2.println(checkLevel3, jSError4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.ErrorReporter errorReporter2 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter2, false);
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry7 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5, false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        node66.setCharno((int) '#');
        node66.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType73 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType74 = jSTypeRegistry7.createObjectType("TYPEOF \n", node66, objectType73);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray75 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType76 = jSTypeRegistry4.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType73, jSTypeArray75);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList77 = functionType76.getSubTypes();
        boolean boolean78 = functionType76.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType80 = functionType76.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType81 = functionType76.getTypeOfThis();
        boolean boolean82 = functionType76.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType83 = functionType76.unboxesTo();
        boolean boolean84 = functionType76.hasCachedValues();
        try {
            boolean boolean85 = functionParamBuilder1.addVarArgs((com.google.javascript.rhino.jstype.JSType) functionType76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(objectType74);
        org.junit.Assert.assertNotNull(jSTypeArray75);
        org.junit.Assert.assertNotNull(functionType76);
        org.junit.Assert.assertNull(functionTypeList77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(jSType80);
        org.junit.Assert.assertNotNull(objectType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(jSType83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) (short) 100, "TYPEOF \n", 18, (int) (byte) 100);
        node4.setWasEmptyNode(false);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setMutatesArguments();
        boolean boolean3 = sideEffectFlags0.areAllFlagsSet();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        java.util.logging.Logger logger3 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager4 = new com.google.javascript.jscomp.LoggerErrorManager(logger3);
        int int5 = loggerErrorManager4.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel6 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType10 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = diagnosticType10.level;
        java.lang.String[] strArray17 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError18 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType10, strArray17);
        int int19 = jSError18.getCharno();
        java.lang.String str20 = jSError18.description;
        loggerErrorManager4.println(checkLevel6, jSError18);
        int int22 = jSError18.lineNumber;
        boolean boolean23 = diagnosticGroup0.matches(jSError18);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType10);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(jSError18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 25 + "'", int19 == 25);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str20.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 47 + "'", int22 == 47);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isRecordType();
        boolean boolean81 = functionType74.isInstanceType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        jSTypeRegistry2.setLastGeneration(true);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder6 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry9 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7, false);
        com.google.javascript.rhino.ErrorReporter errorReporter10 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry12 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter10, false);
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node25 = node19.clonePropsFrom(node24);
        com.google.javascript.rhino.Node node30 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node31 = node19.copyInformationFromForTree(node30);
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node42 = node36.clonePropsFrom(node41);
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node53 = node47.clonePropsFrom(node52);
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node64 = node58.clonePropsFrom(node63);
        com.google.javascript.rhino.Node node69 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node70 = node58.copyInformationFromForTree(node69);
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((-1), node30, node42, node52, node69);
        com.google.javascript.rhino.Node node72 = node71.cloneTree();
        node71.setCharno((int) '#');
        node71.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType78 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType79 = jSTypeRegistry12.createObjectType("TYPEOF \n", node71, objectType78);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray80 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType81 = jSTypeRegistry9.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType78, jSTypeArray80);
        boolean boolean82 = functionParamBuilder6.addRequiredParams(jSTypeArray80);
        com.google.javascript.rhino.jstype.JSType jSType83 = jSTypeRegistry2.createUnionType(jSTypeArray80);
        com.google.javascript.rhino.jstype.JSType jSType85 = jSType83.getRestrictedTypeGivenToBooleanOutcome(true);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node69);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node72);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(jSTypeArray80);
        org.junit.Assert.assertNotNull(functionType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertNotNull(jSType83);
        org.junit.Assert.assertNotNull(jSType85);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromCode("goog.abstractMethod", "com.google.javascript.rhino.EvaluatorException: hi! (#3)");
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy3 = compilerOptions0.variableRenaming;
        compilerOptions0.syntheticBlockStartMarker = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy3 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy3.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("com.google.javascript.rhino.EvaluatorException: hi! (#3)");
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        boolean boolean2 = functionParamBuilder1.hasVarArgs();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        compilerOptions0.collapseProperties = false;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap9 = compilerOptions0.customPasses;
        org.junit.Assert.assertNull(customPassExecutionTimeMultimap9);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        compilerOptions0.setDefineToDoubleLiteral("TYPEOF \n", (double) (short) 0);
        compilerOptions0.strictMessageReplacement = false;
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        try {
            com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.typeError1("{1813971029}", "language version");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property {1813971029}");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        int int68 = compiler0.getErrorCount();
        com.google.javascript.jscomp.SourceMap sourceMap69 = compiler0.getSourceMap();
        try {
            compiler0.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
        org.junit.Assert.assertNull(sourceMap69);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setThrows();
        sideEffectFlags0.setMutatesArguments();
        sideEffectFlags0.setReturnsTainted();
        sideEffectFlags0.setAllFlags();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("10", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.seal((java.lang.Object) 3);
//        com.google.javascript.rhino.ErrorReporter errorReporter4 = context1.getErrorReporter();
//        java.util.Locale locale5 = context1.getLocale();
//        com.google.javascript.rhino.ErrorReporter errorReporter6 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter7 = context1.setErrorReporter(errorReporter6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
//        } catch (java.lang.IllegalStateException e) {
//        }
//        org.junit.Assert.assertNotNull(context1);
//        org.junit.Assert.assertNull(errorReporter4);
//        org.junit.Assert.assertNotNull(locale5);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.reserveRawExports = true;
        boolean boolean5 = compilerOptions0.collapseAnonymousFunctions;
        compilerOptions0.setDefineToDoubleLiteral("", (double) 18);
        boolean boolean9 = compilerOptions0.checkCaja;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        com.google.javascript.rhino.Context context0 = null;
//        com.google.javascript.rhino.Context context1 = com.google.javascript.rhino.Context.enter(context0);
//        context1.setLanguageVersion(100);
//        org.junit.Assert.assertNotNull(context1);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        boolean boolean77 = functionType74.isReturnTypeInferred();
        com.google.javascript.rhino.JSDocInfo jSDocInfo79 = null;
        functionType74.setPropertyJSDocInfo("null", jSDocInfo79, true);
        boolean boolean83 = functionType74.isPropertyTypeDeclared("language version");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        boolean boolean2 = compilerOptions0.instrumentForCoverageOnly;
        compilerOptions0.smartNameRemoval = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.inlineFunctions = false;
        boolean boolean3 = compilerOptions0.inlineConstantVars;
        compilerOptions0.computeFunctionSideEffects = true;
        boolean boolean6 = compilerOptions0.crossModuleMethodMotion;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.checkFunctions;
        compilerOptions0.removeDeadCode = true;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.locale = "Named type with empty name component";
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions9.setManageClosureDependencies(true);
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions9.checkUnreachableCode;
        compilerOptions0.checkFunctions = checkLevel12;
        compilerOptions0.markNoSideEffectCalls = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node6.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node23.clonePropsFrom(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node45.copyInformationFromForTree(node56);
        com.google.javascript.rhino.Node node58 = new com.google.javascript.rhino.Node((-1), node17, node29, node39, node56);
        node29.setVarArgs(true);
        try {
            com.google.javascript.rhino.Node node61 = new com.google.javascript.rhino.Node(9, node29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: new child has existing parent");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        boolean boolean5 = googleCodingConvention0.isConstantKey("function (): ?");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions0.crossModuleCodeMotion = false;
        compilerOptions0.appNameStr = "language version";
        boolean boolean9 = compilerOptions0.tightenTypes;
        compilerOptions0.nameReferenceReportPath = "NAME hi!";
        com.google.javascript.jscomp.CheckLevel checkLevel12 = compilerOptions0.checkGlobalThisLevel;
        compilerOptions0.moveFunctionDeclarations = false;
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + checkLevel12 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel12.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean7 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node9 = node5.getAncestor(0);
        node5.setLineno(48);
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = node4.clonePropsFrom(node9);
        boolean boolean11 = node4.isQualifiedName();
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node23 = node17.clonePropsFrom(node22);
        com.google.javascript.rhino.Node node28 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = node17.copyInformationFromForTree(node28);
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = node34.clonePropsFrom(node39);
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = node45.clonePropsFrom(node50);
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node62 = node56.clonePropsFrom(node61);
        com.google.javascript.rhino.Node node67 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node68 = node56.copyInformationFromForTree(node67);
        com.google.javascript.rhino.Node node69 = new com.google.javascript.rhino.Node((-1), node28, node40, node50, node67);
        com.google.javascript.rhino.Node node70 = node69.cloneTree();
        node69.setCharno((int) '#');
        com.google.javascript.rhino.Node node73 = node69.removeFirstChild();
        com.google.javascript.rhino.Node node74 = node4.copyInformationFrom(node69);
        int int75 = node69.getCharno();
        com.google.javascript.rhino.Node node76 = com.google.javascript.jscomp.NodeUtil.newExpr(node69);
        boolean boolean77 = node76.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNotNull(node68);
        org.junit.Assert.assertNotNull(node70);
        org.junit.Assert.assertNotNull(node73);
        org.junit.Assert.assertNotNull(node74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
        org.junit.Assert.assertNotNull(node76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        compilerOptions0.collapseAnonymousFunctions = true;
        boolean boolean5 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.decomposeExpressions = false;
        compilerOptions0.checkCaja = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo78, false);
        boolean boolean81 = functionType74.matchesUint32Context();
        com.google.javascript.rhino.jstype.JSType jSType82 = null;
        try {
            boolean boolean83 = functionType74.canTestForEqualityWith(jSType82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node6.copyInformationFromForTree(node17);
        com.google.javascript.rhino.Node node19 = functionParamBuilder1.newParameterFromNode(node6);
        com.google.javascript.rhino.Node node20 = functionParamBuilder1.build();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode24 = new com.google.javascript.rhino.ScriptOrFnNode((int) (short) 1, (int) (short) 100, 6);
        int int26 = scriptOrFnNode24.addVar("");
        java.lang.String[] strArray27 = scriptOrFnNode24.getParamAndVarNames();
        java.lang.RuntimeException runtimeException28 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) functionParamBuilder1, (java.lang.Object) strArray27);
        boolean boolean29 = functionParamBuilder1.hasVarArgs();
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(runtimeException28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, (int) (short) 0, 22);
        scriptOrFnNode3.setEndLineno(29);
        int int6 = scriptOrFnNode3.getParamCount();
        boolean boolean7 = scriptOrFnNode3.isNoSideEffectsCall();
        com.google.javascript.rhino.Node.AncestorIterable ancestorIterable8 = scriptOrFnNode3.getAncestors();
        scriptOrFnNode3.removeParamOrVar("hi!");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(ancestorIterable8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.util.Set<java.lang.String> strSet80 = functionType74.getOwnPropertyNames();
        java.lang.String str81 = functionType74.getNormalizedReferenceName();
        java.lang.String str82 = functionType74.getTemplateTypeName();
        boolean boolean84 = functionType74.isPropertyInExterns("language version");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(strSet80);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertNull(str82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionParamBuilder functionParamBuilder1 = new com.google.javascript.rhino.jstype.FunctionParamBuilder(jSTypeRegistry0);
        com.google.javascript.rhino.Node node6 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = node6.clonePropsFrom(node11);
        int int14 = node12.getIntProp((int) (short) 1);
        com.google.javascript.rhino.Node node15 = node12.getParent();
        com.google.javascript.rhino.Node node16 = functionParamBuilder1.newParameterFromNode(node12);
        org.junit.Assert.assertNotNull(node6);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNull(node15);
        org.junit.Assert.assertNotNull(node16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        boolean boolean5 = googleCodingConvention0.isConstantKey("Exceeded max number of optimization iterations: ");
        boolean boolean7 = googleCodingConvention0.isConstant("com.google.javascript.rhino.EvaluatorException: hi! (#3)");
        boolean boolean9 = googleCodingConvention0.isSuperClassReference("<No stack trace available>");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder0 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        java.lang.String str1 = codeBuilder0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.ObjectType objectType77 = functionType74.toObjectType();
        boolean boolean78 = functionType74.isDateType();
        com.google.javascript.rhino.JSDocInfo jSDocInfo80 = functionType74.getOwnPropertyJSDocInfo("TYPEOF ");
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable81 = functionType74.getImplementedInterfaces();
        boolean boolean82 = functionType74.isReturnTypeInferred();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectType77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(jSDocInfo80);
        org.junit.Assert.assertNotNull(objectTypeIterable81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(24, (int) (byte) 0, 42);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        com.google.javascript.jscomp.ClosureCodingConvention closureCodingConvention0 = new com.google.javascript.jscomp.ClosureCodingConvention();
        java.util.Collection<com.google.javascript.jscomp.CodingConvention.AssertionFunctionSpec> assertionFunctionSpecCollection1 = closureCodingConvention0.getAssertionFunctions();
        com.google.javascript.rhino.Node node7 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node13 = node7.clonePropsFrom(node12);
        com.google.javascript.rhino.Node node18 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = node7.copyInformationFromForTree(node18);
        com.google.javascript.rhino.Node node24 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node30 = node24.clonePropsFrom(node29);
        com.google.javascript.rhino.Node node35 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node41 = node35.clonePropsFrom(node40);
        com.google.javascript.rhino.Node node46 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node52 = node46.clonePropsFrom(node51);
        com.google.javascript.rhino.Node node57 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = node46.copyInformationFromForTree(node57);
        com.google.javascript.rhino.Node node59 = new com.google.javascript.rhino.Node((-1), node18, node30, node40, node57);
        com.google.javascript.rhino.Node node60 = node59.cloneTree();
        java.util.Set<java.lang.String> strSet61 = node59.getDirectives();
        com.google.javascript.jscomp.CodingConvention.SubclassRelationship subclassRelationship62 = closureCodingConvention0.getClassesDefinedByCall(node59);
        boolean boolean64 = closureCodingConvention0.isPrivate("Unknown class name");
        org.junit.Assert.assertNotNull(assertionFunctionSpecCollection1);
        org.junit.Assert.assertNotNull(node7);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node13);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node30);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node41);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node52);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNull(strSet61);
        org.junit.Assert.assertNull(subclassRelationship62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        com.google.javascript.rhino.Node node3 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("{1813971029}", 0, 0);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("goog.exportSymbol", "Named type with empty name component", 39);
        try {
            evaluatorException3.initLineNumber(4095);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.JSDocInfo jSDocInfo78 = null;
        functionType74.setPropertyJSDocInfo("", jSDocInfo78, false);
        com.google.javascript.rhino.jstype.FunctionType functionType81 = functionType74.getConstructor();
        try {
            com.google.javascript.rhino.jstype.JSType jSType82 = functionType81.unboxesTo();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(functionType81);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        com.google.javascript.rhino.Node node5 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node11 = node5.clonePropsFrom(node10);
        com.google.javascript.rhino.Node node16 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = node5.copyInformationFromForTree(node16);
        com.google.javascript.rhino.Node node22 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node28 = node22.clonePropsFrom(node27);
        com.google.javascript.rhino.Node node33 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node39 = node33.clonePropsFrom(node38);
        com.google.javascript.rhino.Node node44 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node50 = node44.clonePropsFrom(node49);
        com.google.javascript.rhino.Node node55 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = node44.copyInformationFromForTree(node55);
        com.google.javascript.rhino.Node node57 = new com.google.javascript.rhino.Node((-1), node16, node28, node38, node55);
        com.google.javascript.rhino.Node node58 = node57.cloneTree();
        node57.setCharno((int) '#');
        com.google.javascript.rhino.Node node61 = node57.removeFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder62 = node57.getJsDocBuilderForNode();
        com.google.javascript.rhino.Node node63 = node57.getLastChild();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node11);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node28);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node39);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node50);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(fileLevelJsDocBuilder62);
        org.junit.Assert.assertNotNull(node63);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isRecordType();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.unboxesTo();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(jSType81);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        boolean boolean3 = compilerOptions0.removeTryCatchFinally;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.prettyPrint;
        boolean boolean7 = compilerOptions0.optimizeArgumentsArray;
        compilerOptions0.ideMode = false;
        boolean boolean10 = compilerOptions0.inlineConstantVars;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        compiler0.disableThreads();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromCode("goog.abstractMethod", "com.google.javascript.rhino.EvaluatorException: hi! (#3)");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray8 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile7 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean10 = compilerOptions9.checkEs5Strict;
        compilerOptions9.coalesceVariableNames = false;
        boolean boolean13 = compilerOptions9.isExternExportsEnabled();
        boolean boolean14 = compilerOptions9.printInputDelimiter;
        compilerOptions9.smartNameRemoval = false;
        compilerOptions9.aliasAllStrings = false;
        compilerOptions9.disableRuntimeTypeCheck();
        com.google.javascript.jscomp.Result result20 = compiler0.compile(jSSourceFile4, jSSourceFileArray8, compilerOptions9);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter21 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertNotNull(jSSourceFileArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(result20);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 28, 28, 6);
        boolean boolean4 = node3.isNoSideEffectsCall();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean81 = functionType74.isPropertyTypeDeclared("TYPEOF \n");
        boolean boolean83 = functionType74.isPropertyTypeDeclared("hi!");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        com.google.javascript.jscomp.CheckLevel checkLevel2 = compilerOptions0.checkMethods;
        compilerOptions0.inlineGetters = true;
        boolean boolean5 = compilerOptions0.checkControlStructures;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + checkLevel2 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel2.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getAllImplementedInterfaces();
        boolean boolean81 = functionType74.isInterface();
        boolean boolean82 = functionType74.isArrayType();
        com.google.javascript.rhino.ErrorReporter errorReporter83 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope84 = null;
        com.google.javascript.rhino.jstype.JSType jSType85 = functionType74.resolve(errorReporter83, jSTypeStaticScope84);
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(jSType85);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("{1813971029}", "JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        int int3 = ecmaError2.getColumnNumber();
        java.lang.String str4 = ecmaError2.toString();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.google.javascript.rhino.EcmaError: {1813971029}: JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}" + "'", str4.equals("com.google.javascript.rhino.EcmaError: {1813971029}: JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState64 = compiler0.getState();
        compiler0.reportCodeChange();
        com.google.javascript.rhino.Node node66 = compiler0.getRoot();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(intermediateState64);
        org.junit.Assert.assertNull(node66);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        boolean boolean6 = compilerOptions0.crossModuleCodeMotion;
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy7 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy7;
        java.lang.String str9 = compilerOptions0.jsOutputFile;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy7 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy7.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.isExternExportsEnabled();
        boolean boolean5 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.optimizeArgumentsArray = false;
        compilerOptions0.allowLegacyJsMessages = true;
        compilerOptions0.exportTestFunctions = false;
        boolean boolean12 = compilerOptions0.inlineVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node8 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.rhino.Node node14 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node19 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node20 = node14.clonePropsFrom(node19);
        com.google.javascript.rhino.Node node25 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node26 = node14.copyInformationFromForTree(node25);
        com.google.javascript.rhino.Node node31 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node36 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node37 = node31.clonePropsFrom(node36);
        com.google.javascript.rhino.Node node42 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node47 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node48 = node42.clonePropsFrom(node47);
        com.google.javascript.rhino.Node node53 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node58 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node59 = node53.clonePropsFrom(node58);
        com.google.javascript.rhino.Node node64 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node65 = node53.copyInformationFromForTree(node64);
        com.google.javascript.rhino.Node node66 = new com.google.javascript.rhino.Node((-1), node25, node37, node47, node64);
        com.google.javascript.rhino.Node node67 = node66.cloneTree();
        java.lang.Object obj69 = node67.getProp(29);
        node4.addChildAfter(node8, node67);
        boolean boolean71 = node67.hasMoreThanOneChild();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node8);
        org.junit.Assert.assertNotNull(node14);
        org.junit.Assert.assertNotNull(node19);
        org.junit.Assert.assertNotNull(node20);
        org.junit.Assert.assertNotNull(node25);
        org.junit.Assert.assertNotNull(node26);
        org.junit.Assert.assertNotNull(node31);
        org.junit.Assert.assertNotNull(node36);
        org.junit.Assert.assertNotNull(node37);
        org.junit.Assert.assertNotNull(node42);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNotNull(node48);
        org.junit.Assert.assertNotNull(node53);
        org.junit.Assert.assertNotNull(node58);
        org.junit.Assert.assertNotNull(node59);
        org.junit.Assert.assertNotNull(node64);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(node67);
        org.junit.Assert.assertNull(obj69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        boolean boolean3 = googleCodingConvention0.isExported("", false);
        java.lang.String str4 = googleCodingConvention0.getExportSymbolFunction();
        java.lang.String str5 = googleCodingConvention0.getExportSymbolFunction();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "goog.exportSymbol" + "'", str4.equals("goog.exportSymbol"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "goog.exportSymbol" + "'", str5.equals("goog.exportSymbol"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("{130370559}");
        com.google.javascript.jscomp.JSModule[] jSModuleArray2 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList3 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList3, jSModuleArray2);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph5 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList3);
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule10 = jSModuleGraph5.getDeepestCommonDependencyInclusive(jSModule7, jSModule9);
        jSModule1.addDependency(jSModule7);
        org.junit.Assert.assertNotNull(jSModuleArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(jSModule10);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        java.lang.String str7 = compilerOptions0.jsOutputFile;
        com.google.javascript.jscomp.SourceMap.Format format8 = compilerOptions0.sourceMapFormat;
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(format8);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope3 = null;
        com.google.javascript.rhino.jstype.JSType jSType8 = jSTypeRegistry2.getForgivingType(jSTypeStaticScope3, "TYPEOF ", "TYPEOF \n", (int) (byte) 100, 45);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder9 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry2);
        org.junit.Assert.assertNotNull(jSType8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.warning("Exceeded max number of optimization iterations: ", "com.google.javascript.rhino.EcmaError: {1813971029}: JSC_OPTIMIZE_LOOP_ERROR: Exceeded max number of optimization iterations: {0}");
        org.junit.Assert.assertNotNull(diagnosticType2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        compilerOptions0.coalesceVariableNames = false;
        boolean boolean4 = compilerOptions0.aliasAllStrings;
        com.google.common.collect.Multimap<com.google.javascript.jscomp.CustomPassExecutionTime, com.google.javascript.jscomp.CompilerPass> customPassExecutionTimeMultimap5 = null;
        compilerOptions0.customPasses = customPassExecutionTimeMultimap5;
        boolean boolean7 = compilerOptions0.inlineLocalVariables;
        compilerOptions0.optimizeParameters = false;
        boolean boolean10 = compilerOptions0.inlineGetters;
        compilerOptions0.generateExports = true;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(0, (int) (short) 0, 22);
        scriptOrFnNode3.setEndLineno(29);
        int int6 = scriptOrFnNode3.getParamCount();
        scriptOrFnNode3.addParam("TYPEOF ");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        com.google.javascript.jscomp.DefaultCodingConvention defaultCodingConvention0 = new com.google.javascript.jscomp.DefaultCodingConvention();
        com.google.javascript.jscomp.NodeTraversal nodeTraversal1 = null;
        com.google.javascript.rhino.Node node5 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode("hi!", (-1), (int) (byte) 1);
        com.google.javascript.jscomp.CodingConvention.ObjectLiteralCast objectLiteralCast6 = defaultCodingConvention0.getObjectLiteralCast(nodeTraversal1, node5);
        boolean boolean7 = node5.wasEmptyNode();
        com.google.javascript.rhino.Node node9 = node5.getAncestor(0);
        int int10 = node5.getLineno();
        org.junit.Assert.assertNotNull(node5);
        org.junit.Assert.assertNull(objectLiteralCast6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkUnusedPropertiesEarly;
        java.util.Set<java.lang.String> strSet2 = compilerOptions0.stripNamePrefixes;
        boolean boolean3 = compilerOptions0.gatherCssNames;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isSealed();
//        context0.addActivationName("");
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable77 = functionType74.getAllImplementedInterfaces();
        boolean boolean78 = functionType74.isEnumType();
        boolean boolean79 = functionType74.isInstanceType();
        java.lang.Iterable<com.google.javascript.rhino.jstype.ObjectType> objectTypeIterable80 = functionType74.getImplementedInterfaces();
        boolean boolean81 = functionType74.isArrayType();
        boolean boolean82 = functionType74.isObject();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(objectTypeIterable80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        com.google.javascript.jscomp.CheckLevel checkLevel1 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType3 = com.google.javascript.jscomp.DiagnosticType.make("", checkLevel1, "Not declared as a type name");
        java.lang.String str4 = diagnosticType3.toString();
        org.junit.Assert.assertTrue("'" + checkLevel1 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel1.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ": Not declared as a type name" + "'", str4.equals(": Not declared as a type name"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.setManageClosureDependencies(true);
        java.lang.String str3 = compilerOptions0.unaliasableGlobals;
        compilerOptions0.strictMessageReplacement = false;
        compilerOptions0.setProcessObjectPropertyString(false);
        boolean boolean8 = compilerOptions0.ignoreCajaProperties;
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState64 = compiler0.getState();
        compiler0.reportCodeChange();
        com.google.javascript.jscomp.Region region68 = compiler0.getSourceRegion("{1479088659}", 130);
        com.google.javascript.jscomp.Result result69 = compiler0.getResult();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(intermediateState64);
        org.junit.Assert.assertNull(region68);
        org.junit.Assert.assertNotNull(result69);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        boolean boolean76 = functionType74.isInterface();
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.getRestrictedTypeGivenToBooleanOutcome(true);
        com.google.javascript.rhino.jstype.ObjectType objectType79 = functionType74.getTypeOfThis();
        boolean boolean80 = functionType74.isFunctionPrototypeType();
        com.google.javascript.rhino.jstype.JSType jSType81 = functionType74.unboxesTo();
        boolean boolean82 = functionType74.hasCachedValues();
        com.google.javascript.rhino.JSDocInfo jSDocInfo84 = functionType74.getOwnPropertyJSDocInfo("{1813971029}");
        boolean boolean85 = functionType74.isCheckedUnknownType();
        com.google.javascript.rhino.jstype.JSType jSType87 = functionType74.findPropertyType("Unknown class name");
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertNotNull(objectType79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNull(jSType81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNull(jSDocInfo84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(jSType87);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0, false);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3, false);
        com.google.javascript.rhino.Node node12 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node17 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node18 = node12.clonePropsFrom(node17);
        com.google.javascript.rhino.Node node23 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node24 = node12.copyInformationFromForTree(node23);
        com.google.javascript.rhino.Node node29 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node34 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node35 = node29.clonePropsFrom(node34);
        com.google.javascript.rhino.Node node40 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node45 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node46 = node40.clonePropsFrom(node45);
        com.google.javascript.rhino.Node node51 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node56 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node57 = node51.clonePropsFrom(node56);
        com.google.javascript.rhino.Node node62 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node63 = node51.copyInformationFromForTree(node62);
        com.google.javascript.rhino.Node node64 = new com.google.javascript.rhino.Node((-1), node23, node35, node45, node62);
        com.google.javascript.rhino.Node node65 = node64.cloneTree();
        node64.setCharno((int) '#');
        node64.putBooleanProp((int) (byte) 100, false);
        com.google.javascript.rhino.jstype.ObjectType objectType71 = null;
        com.google.javascript.rhino.jstype.ObjectType objectType72 = jSTypeRegistry5.createObjectType("TYPEOF \n", node64, objectType71);
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray73 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType74 = jSTypeRegistry2.createFunctionTypeWithVarArgs((com.google.javascript.rhino.jstype.JSType) objectType71, jSTypeArray73);
        java.util.List<com.google.javascript.rhino.jstype.FunctionType> functionTypeList75 = functionType74.getSubTypes();
        com.google.javascript.rhino.ErrorReporter errorReporter76 = null;
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope77 = null;
        com.google.javascript.rhino.jstype.JSType jSType78 = functionType74.resolve(errorReporter76, jSTypeStaticScope77);
        java.lang.String str79 = functionType74.toString();
        boolean boolean80 = functionType74.isTemplateType();
        org.junit.Assert.assertNotNull(node12);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(node18);
        org.junit.Assert.assertNotNull(node23);
        org.junit.Assert.assertNotNull(node24);
        org.junit.Assert.assertNotNull(node29);
        org.junit.Assert.assertNotNull(node34);
        org.junit.Assert.assertNotNull(node35);
        org.junit.Assert.assertNotNull(node40);
        org.junit.Assert.assertNotNull(node45);
        org.junit.Assert.assertNotNull(node46);
        org.junit.Assert.assertNotNull(node51);
        org.junit.Assert.assertNotNull(node56);
        org.junit.Assert.assertNotNull(node57);
        org.junit.Assert.assertNotNull(node62);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node65);
        org.junit.Assert.assertNotNull(objectType72);
        org.junit.Assert.assertNotNull(jSTypeArray73);
        org.junit.Assert.assertNotNull(functionType74);
        org.junit.Assert.assertNull(functionTypeList75);
        org.junit.Assert.assertNotNull(jSType78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "function (): ?" + "'", str79.equals("function (): ?"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("function (): ?", 49, (int) (short) 100);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.renamePrefix = "Unknown class name";
        compilerOptions0.removeUnusedPrototypeProperties = true;
        compilerOptions0.generateExports = false;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy7 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy7;
        boolean boolean9 = compilerOptions0.inlineFunctions;
        compilerOptions0.setProcessObjectPropertyString(true);
        java.lang.String str12 = compilerOptions0.syntheticBlockEndMarker;
        java.lang.String str13 = compilerOptions0.debugFunctionSideEffectsPath;
        compilerOptions0.checkUnusedPropertiesEarly = true;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy7.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        com.google.javascript.rhino.FunctionNode functionNode2 = new com.google.javascript.rhino.FunctionNode("");
        int int4 = functionNode2.getParamOrVarIndex("");
        com.google.javascript.rhino.Node node10 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node15 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node16 = node10.clonePropsFrom(node15);
        com.google.javascript.rhino.Node node21 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node22 = node10.copyInformationFromForTree(node21);
        com.google.javascript.rhino.Node node27 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node32 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node33 = node27.clonePropsFrom(node32);
        com.google.javascript.rhino.Node node38 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node43 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node44 = node38.clonePropsFrom(node43);
        com.google.javascript.rhino.Node node49 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node54 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node55 = node49.clonePropsFrom(node54);
        com.google.javascript.rhino.Node node60 = com.google.javascript.rhino.Node.newString((int) ' ', "", (int) 'a', (-1));
        com.google.javascript.rhino.Node node61 = node49.copyInformationFromForTree(node60);
        com.google.javascript.rhino.Node node62 = new com.google.javascript.rhino.Node((-1), node21, node33, node43, node60);
        com.google.javascript.rhino.Node node63 = node62.cloneTree();
        node62.setCharno((int) '#');
        com.google.javascript.rhino.Node node66 = node62.removeFirstChild();
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable67 = node66.siblings();
        java.lang.String str68 = node66.toStringTree();
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node(26, (com.google.javascript.rhino.Node) functionNode2, node66, 32, 7);
        java.util.Set<java.lang.String> strSet72 = node71.getDirectives();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(node10);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertNotNull(node21);
        org.junit.Assert.assertNotNull(node22);
        org.junit.Assert.assertNotNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertNotNull(node33);
        org.junit.Assert.assertNotNull(node38);
        org.junit.Assert.assertNotNull(node43);
        org.junit.Assert.assertNotNull(node44);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertNotNull(node54);
        org.junit.Assert.assertNotNull(node55);
        org.junit.Assert.assertNotNull(node60);
        org.junit.Assert.assertNotNull(node61);
        org.junit.Assert.assertNotNull(node63);
        org.junit.Assert.assertNotNull(node66);
        org.junit.Assert.assertNotNull(nodeIterable67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "TYPEOF \n" + "'", str68.equals("TYPEOF \n"));
        org.junit.Assert.assertNull(strSet72);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        try {
//            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.numberToString((double) 7, 100);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: illegal radix 100.");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean1 = com.google.javascript.rhino.ScriptRuntime.isJSLineTerminator(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("10");
        jSModule1.removeAll();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getAllDependencies();
        org.junit.Assert.assertNotNull(jSModuleSet3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("hi!", "hi!", 4);
        evaluatorException3.initColumnNumber(19);
        java.lang.String str6 = evaluatorException3.sourceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList1 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList1, jSModuleArray0);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph3 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList1);
        com.google.javascript.jscomp.JSModule jSModule5 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule7 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule8 = jSModuleGraph3.getDeepestCommonDependencyInclusive(jSModule5, jSModule7);
        int int9 = jSModule5.getDepth();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet10 = jSModule5.getThisAndAllDependencies();
        com.google.javascript.jscomp.SourceAst sourceAst11 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput14 = new com.google.javascript.jscomp.CompilerInput(sourceAst11, "TYPEOF ", false);
        com.google.javascript.jscomp.JSModule[] jSModuleArray15 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList16 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList16, jSModuleArray15);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph18 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList16);
        com.google.javascript.jscomp.JSModule jSModule20 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule22 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule23 = jSModuleGraph18.getDeepestCommonDependencyInclusive(jSModule20, jSModule22);
        int int24 = jSModule20.getDepth();
        java.lang.String str25 = jSModule20.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile28 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput30 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile28, false);
        jSModule20.addFirst(compilerInput30);
        compilerInput14.setModule(jSModule20);
        jSModule5.remove(compilerInput14);
        java.nio.charset.Charset charset35 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset35);
        com.google.javascript.jscomp.CompilerInput compilerInput37 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile36);
        java.lang.String str38 = jSSourceFile36.getName();
        jSModule5.add(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(jSModule8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(jSModuleSet10);
        org.junit.Assert.assertNotNull(jSModuleArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(jSModule23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10" + "'", str25.equals("10"));
        org.junit.Assert.assertNotNull(jSSourceFile28);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        com.google.javascript.jscomp.Compiler compiler0 = new com.google.javascript.jscomp.Compiler();
        com.google.javascript.jscomp.SourceMap sourceMap1 = compiler0.getSourceMap();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile4, false);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile8 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        java.nio.charset.Charset charset10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset10);
        java.nio.charset.Charset charset13 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile14 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset13);
        com.google.javascript.jscomp.CompilerInput compilerInput15 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile14);
        java.lang.String str16 = jSSourceFile14.getName();
        java.nio.charset.Charset charset18 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile19 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset18);
        com.google.javascript.jscomp.JSModule[] jSModuleArray20 = new com.google.javascript.jscomp.JSModule[] {};
        java.util.ArrayList<com.google.javascript.jscomp.JSModule> jSModuleList21 = new java.util.ArrayList<com.google.javascript.jscomp.JSModule>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleList21, jSModuleArray20);
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph23 = new com.google.javascript.jscomp.JSModuleGraph((java.util.List<com.google.javascript.jscomp.JSModule>) jSModuleList21);
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule27 = new com.google.javascript.jscomp.JSModule("10");
        com.google.javascript.jscomp.JSModule jSModule28 = jSModuleGraph23.getDeepestCommonDependencyInclusive(jSModule25, jSModule27);
        int int29 = jSModule25.getDepth();
        java.nio.charset.Charset charset31 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile32 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset31);
        com.google.javascript.jscomp.CompilerInput compilerInput33 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile32);
        jSModule25.addFirst(jSSourceFile32);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile36 = com.google.javascript.jscomp.JSSourceFile.fromFile("function (this:me, {1353026226}): me");
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray37 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile8, jSSourceFile11, jSSourceFile14, jSSourceFile19, jSSourceFile32, jSSourceFile36 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList38 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean39 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, jSSourceFileArray37);
        java.nio.charset.Charset charset41 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile42 = com.google.javascript.jscomp.JSSourceFile.fromFile("", charset41);
        com.google.javascript.jscomp.CompilerInput compilerInput43 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile42);
        java.lang.String str44 = jSSourceFile42.getName();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("", "TYPEOF \n");
        com.google.javascript.jscomp.CompilerInput compilerInput49 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile47, false);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray50 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile42, jSSourceFile47 };
        java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile> jSSourceFileList51 = new java.util.ArrayList<com.google.javascript.jscomp.JSSourceFile>();
        boolean boolean52 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, jSSourceFileArray50);
        com.google.javascript.jscomp.CompilerOptions compilerOptions53 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean54 = compilerOptions53.checkEs5Strict;
        compilerOptions53.coalesceVariableNames = false;
        boolean boolean57 = compilerOptions53.isExternExportsEnabled();
        boolean boolean58 = compilerOptions53.inferTypesInGlobalScope;
        boolean boolean59 = compilerOptions53.prettyPrint;
        boolean boolean60 = compilerOptions53.optimizeArgumentsArray;
        compilerOptions53.ignoreCajaProperties = true;
        compiler0.init((java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList38, (java.util.List<com.google.javascript.jscomp.JSSourceFile>) jSSourceFileList51, compilerOptions53);
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt64 = null;
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter65 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler0, sourceExcerpt64);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker66 = null;
        compiler0.tracker = performanceTracker66;
        int int68 = compiler0.getErrorCount();
        com.google.javascript.jscomp.SourceMap sourceMap69 = compiler0.getSourceMap();
        java.lang.String str70 = compiler0.toSource();
        org.junit.Assert.assertNull(sourceMap1);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile8);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertNotNull(jSSourceFile14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile19);
        org.junit.Assert.assertNotNull(jSModuleArray20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(jSModule28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(jSSourceFile32);
        org.junit.Assert.assertNotNull(jSSourceFile36);
        org.junit.Assert.assertNotNull(jSSourceFileArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(jSSourceFile42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
        org.junit.Assert.assertNull(sourceMap69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "" + "'", str70.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.checkEs5Strict;
        java.lang.String str2 = compilerOptions0.aliasStringsBlacklist;
        compilerOptions0.renamePrefix = "{130370559}";
        com.google.javascript.jscomp.CompilerOptions compilerOptions5 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions5.renamePrefix = "Unknown class name";
        compilerOptions5.syntheticBlockEndMarker = "com.google.javascript.rhino.EvaluatorException: hi! (#3)";
        compilerOptions5.crossModuleCodeMotion = false;
        compilerOptions5.appNameStr = "language version";
        boolean boolean14 = compilerOptions5.tightenTypes;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup15 = com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC;
        java.util.logging.Logger logger16 = null;
        com.google.javascript.jscomp.LoggerErrorManager loggerErrorManager17 = new com.google.javascript.jscomp.LoggerErrorManager(logger16);
        int int18 = loggerErrorManager17.getErrorCount();
        com.google.javascript.jscomp.CheckLevel checkLevel19 = com.google.javascript.jscomp.CheckLevel.OFF;
        com.google.javascript.jscomp.DiagnosticType diagnosticType23 = com.google.javascript.jscomp.Compiler.OPTIMIZE_LOOP_ERROR;
        com.google.javascript.jscomp.CheckLevel checkLevel24 = diagnosticType23.level;
        java.lang.String[] strArray30 = new java.lang.String[] { "", "10", "hi!", "10", "TYPEOF " };
        com.google.javascript.jscomp.JSError jSError31 = com.google.javascript.jscomp.JSError.make("", 47, 25, diagnosticType23, strArray30);
        int int32 = jSError31.getCharno();
        java.lang.String str33 = jSError31.description;
        loggerErrorManager17.println(checkLevel19, jSError31);
        int int35 = jSError31.lineNumber;
        boolean boolean36 = diagnosticGroup15.matches(jSError31);
        com.google.javascript.jscomp.CompilerOptions compilerOptions37 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean38 = compilerOptions37.checkEs5Strict;
        compilerOptions37.coalesceVariableNames = false;
        boolean boolean41 = compilerOptions37.isExternExportsEnabled();
        compilerOptions37.setNameAnonymousFunctionsOnly(false);
        com.google.javascript.jscomp.CheckLevel checkLevel44 = compilerOptions37.checkShadowVars;
        compilerOptions5.setWarningLevel(diagnosticGroup15, checkLevel44);
        compilerOptions0.reportUnknownTypes = checkLevel44;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(diagnosticGroup15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + checkLevel19 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel19.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertNotNull(diagnosticType23);
        org.junit.Assert.assertTrue("'" + checkLevel24 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel24.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(strArray30);
        org.junit.Assert.assertNotNull(jSError31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 25 + "'", int32 == 25);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Exceeded max number of optimization iterations: " + "'", str33.equals("Exceeded max number of optimization iterations: "));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 47 + "'", int35 == 47);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + checkLevel44 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel44.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }
}

