import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = com.google.javascript.rhino.Token.DEL_REF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 67 + "'", int0 == 67);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = com.google.javascript.rhino.Node.IS_NAMESPACE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = com.google.javascript.rhino.Token.SETELEM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.ALL));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = com.google.javascript.rhino.Token.TO_OBJECT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 145 + "'", int0 == 145);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES = diagnosticGroup0;
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = com.google.javascript.rhino.Token.DEBUGGER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 152 + "'", int0 == 152);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = com.google.javascript.rhino.Token.FIRST_ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = com.google.javascript.rhino.Node.CODEOFFSET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) 152, (java.lang.Object) 8);
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NULL_TYPE));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String str0 = com.google.javascript.rhino.Context.languageVersionProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "language version" + "'", str0.equals("language version"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.NON_STANDARD_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = com.google.javascript.rhino.Token.COMMA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 85 + "'", int0 == 85);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = com.google.javascript.rhino.Token.INSTANCEOF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = com.google.javascript.rhino.Token.NEW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30 + "'", int0 == 30);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = com.google.javascript.rhino.Node.TARGET_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.U2U_CONSTRUCTOR_TYPE));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.String str0 = com.google.javascript.rhino.Context.errorReporterProperty;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "error reporter" + "'", str0.equals("error reporter"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = com.google.javascript.rhino.Node.MAX_COLUMN_NUMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4095 + "'", int0 == 4095);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = com.google.javascript.rhino.Token.REF_MEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 73 + "'", int0 == 73);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidLanguageVersion(4095);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = com.google.javascript.rhino.Token.ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = com.google.javascript.rhino.Token.EQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = com.google.javascript.rhino.Token.GET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 147 + "'", int0 == 147);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_TYPE));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = com.google.javascript.rhino.Token.LP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 83 + "'", int0 == 83);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = com.google.javascript.rhino.Token.TARGET;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 127 + "'", int0 == 127);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("hi!", "language version", "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = com.google.javascript.rhino.FunctionNode.FUNCTION_STATEMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = com.google.javascript.rhino.Token.RP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 84 + "'", int0 == 84);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = com.google.javascript.rhino.Node.DIRECT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_TYPE));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = com.google.javascript.rhino.Token.LAST_BYTECODE_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 76 + "'", int0 == 76);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = com.google.javascript.rhino.Token.GET_REF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 65 + "'", int0 == 65);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_0;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_STRING_BOOLEAN));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = com.google.javascript.rhino.Node.JSDOC_INFO_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = com.google.javascript.rhino.Node.FUNCTION_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = com.google.javascript.rhino.Token.QMARK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 304 + "'", int0 == 304);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("language version");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = com.google.javascript.rhino.Node.MEMBER_TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32 + "'", int0 == 32);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = com.google.javascript.rhino.Context.FEATURE_NON_ECMA_GET_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_TYPE));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.EVAL_ERROR_TYPE));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.io.InputStream inputStream2 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromInputStream("", "hi!", inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = com.google.javascript.rhino.Token.DELPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.io.File file0 = null;
        java.nio.charset.Charset charset1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile(file0, charset1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int0 = com.google.javascript.rhino.Token.LE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.io.File file0 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile1 = com.google.javascript.jscomp.SourceFile.fromFile(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.Node node2 = null;
        try {
            com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node(83, node1, node2, (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = com.google.javascript.rhino.Token.SETPROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray3 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList4 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList4, warningsGuardArray3);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard6 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList4);
        com.google.javascript.jscomp.JSError jSError7 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel8 = composeWarningsGuard6.level(jSError7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(warningsGuardArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node4, callback5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = com.google.javascript.rhino.Token.IFNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        com.google.javascript.rhino.EvaluatorException evaluatorException4 = new com.google.javascript.rhino.EvaluatorException("", "", 0);
        com.google.javascript.jscomp.Compiler.CodeBuilder codeBuilder5 = new com.google.javascript.jscomp.Compiler.CodeBuilder();
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative6 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE;
        try {
            java.lang.String str8 = com.google.javascript.rhino.ScriptRuntime.getMessage4("", (java.lang.Object) 0, (java.lang.Object) codeBuilder5, (java.lang.Object) jSTypeNative6, (java.lang.Object) "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + jSTypeNative6 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE + "'", jSTypeNative6.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_TYPE));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = com.google.javascript.rhino.Token.FOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 115 + "'", int0 == 115);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = com.google.javascript.rhino.Token.CONTINUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 117 + "'", int0 == 117);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = com.google.javascript.rhino.Node.LAST_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = com.google.javascript.rhino.Node.OBJECT_IDS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-2) + "'", int0 == (-2));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_MODE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_TYPE));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.URI_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = com.google.javascript.rhino.Context.FEATURE_WARNING_AS_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = com.google.javascript.rhino.Token.ESCXMLATTR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 71 + "'", int0 == 71);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.FUNCTION_PROTOTYPE));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = com.google.javascript.rhino.Token.DEC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 103 + "'", int0 == 103);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.JSError jSError3 = null;
        try {
            com.google.javascript.jscomp.CheckLevel checkLevel4 = diagnosticGroupWarningsGuard2.level(jSError3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 92 + "'", int0 == 92);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_TYPE));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode resolveMode0 = com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS;
        org.junit.Assert.assertTrue("'" + resolveMode0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS + "'", resolveMode0.equals(com.google.javascript.rhino.jstype.JSTypeRegistry.ResolveMode.LAZY_EXPRESSIONS));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = null;
        try {
            jSModule1.add(jSSourceFile2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_TYPE));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        boolean boolean1 = context0.isGeneratingDebug();
        try {
            context0.unseal((java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = com.google.javascript.rhino.Node.FLAG_ARGUMENTS_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = com.google.javascript.rhino.Token.NULL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 41 + "'", int0 == 41);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        try {
//            com.google.javascript.rhino.Context.reportError("error reporter", "", 73, "", 34);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: error reporter (#73)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        com.google.javascript.rhino.EvaluatorException evaluatorException1 = new com.google.javascript.rhino.EvaluatorException("hi!");
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = com.google.javascript.rhino.Node.ISNUMBER_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node9 = node8.getFirstChild();
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node14 = node13.getFirstChild();
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node20 = node18.getChildAtIndex((int) (short) 0);
        try {
            com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(65, node4, node8, node14, node20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node9);
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertNull(node20);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ARRAY_FUNCTION_TYPE));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITXOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 88 + "'", int0 == 88);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_FUNCTION_TYPE));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int0 = com.google.javascript.rhino.Token.ENUM_ID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 60 + "'", int0 == 60);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int0 = com.google.javascript.rhino.Node.VARS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.Context.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = com.google.javascript.rhino.Token.ANNOTATION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 300 + "'", int0 == 300);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = com.google.javascript.rhino.Token.FUNCTION;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 105 + "'", int0 == 105);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = com.google.javascript.rhino.Token.VAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 118 + "'", int0 == 118);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        int int0 = com.google.javascript.rhino.Token.ASSIGN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 86 + "'", int0 == 86);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_TYPE));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node4.getFirstChild();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node10 = node9.getFirstChild();
        java.lang.String str11 = node9.toString();
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node16 = node15.getFirstChild();
        com.google.javascript.rhino.Node[] nodeArray17 = new com.google.javascript.rhino.Node[] { node4, node9, node16 };
        try {
            com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node(60, nodeArray17, 32, 65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BITXOR 84" + "'", str11.equals("BITXOR 84"));
        org.junit.Assert.assertNull(node16);
        org.junit.Assert.assertNotNull(nodeArray17);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_1;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int0 = com.google.javascript.rhino.Token.PIPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 301 + "'", int0 == 301);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = com.google.javascript.rhino.Node.EMPTY_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 38 + "'", int0 == 38);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node9 = node7.getChildAtIndex((int) (short) 0);
        try {
            com.google.javascript.rhino.Node node10 = node3.removeChildAfter(node7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: prev is not a child of this node.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(node9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GREATEST_FUNCTION_TYPE));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = com.google.javascript.rhino.Token.CATCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 120 + "'", int0 == 120);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = com.google.javascript.rhino.Node.TEMP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("language version");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int0 = com.google.javascript.rhino.Token.REGEXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int0 = com.google.javascript.rhino.Context.FEATURE_TO_STRING_AS_SOURCE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = com.google.javascript.rhino.Token.NE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NO_OBJECT_TYPE));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot astRoot0 = null;
        com.google.javascript.jscomp.parsing.Config config2 = null;
        com.google.javascript.jscomp.mozilla.rhino.ErrorReporter errorReporter3 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.parsing.IRFactory.transformTree(astRoot0, "error reporter", config2, errorReporter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = com.google.javascript.rhino.Node.FINALLY_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = com.google.javascript.rhino.Token.CATCH_SCOPE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 56 + "'", int0 == 56);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = com.google.javascript.rhino.Node.NON_SPECIALCALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = com.google.javascript.rhino.Node.LOCAL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = com.google.javascript.rhino.Node.LABEL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = com.google.javascript.rhino.ScriptOrFnNode.DUPLICATE_PARAMETER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = com.google.javascript.rhino.Token.THISFN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 61 + "'", int0 == 61);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        int int0 = com.google.javascript.rhino.Token.SUB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 22 + "'", int0 == 22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        try {
            ecmaError1.initColumnNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Object obj0 = null;
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative1 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE;
        java.lang.RuntimeException runtimeException2 = com.google.javascript.rhino.ScriptRuntime.undefCallError(obj0, (java.lang.Object) jSTypeNative1);
        org.junit.Assert.assertTrue("'" + jSTypeNative1 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE + "'", jSTypeNative1.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_TYPE));
        org.junit.Assert.assertNotNull(runtimeException2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter1 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingDebug();
//        try {
//            context0.setLanguageVersion(29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Bad language version: 29");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.getMessage0("BITXOR 84");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property BITXOR 84");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = com.google.javascript.rhino.Node.ATTRIBUTE_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = com.google.javascript.rhino.Token.EMPTY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 124 + "'", int0 == 124);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int0 = com.google.javascript.rhino.Node.RIGHT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_BITOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 87 + "'", int0 == 87);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_EVAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_LSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 90 + "'", int0 == 90);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy0 = com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED;
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED + "'", propertyRenamingPolicy0.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.ALL_UNQUOTED));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        int int0 = com.google.javascript.rhino.Token.DEFAULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 112 + "'", int0 == 112);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        com.google.javascript.jscomp.SourceExcerptProvider sourceExcerptProvider0 = null;
        com.google.javascript.jscomp.SourceExcerptProvider.SourceExcerpt sourceExcerpt1 = null;
        try {
            com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter2 = new com.google.javascript.jscomp.LightweightMessageFormatter(sourceExcerptProvider0, sourceExcerpt1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        try {
//            com.google.javascript.rhino.Context.reportError("language version");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: language version");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("BITXOR 84");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = com.google.javascript.rhino.Token.GE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule4 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList5 = jSModule4.getDependencies();
        jSModule1.addDependency(jSModule4);
        int int7 = jSModule1.getDepth();
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleList5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = com.google.javascript.rhino.Token.LC;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 81 + "'", int0 == 81);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int0 = com.google.javascript.rhino.Node.ENUM_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.OFF));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.lang.String str1 = com.google.javascript.rhino.Node.tokenToName(48);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bindname" + "'", str1.equals("bindname"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_USELESS_CODE;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int0 = com.google.javascript.rhino.Token.EOF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int0 = com.google.javascript.rhino.Node.FIXUPS_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = com.google.javascript.rhino.Token.LT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int0 = com.google.javascript.rhino.Token.ENUM_INIT_VALUES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 58 + "'", int0 == 58);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.BOOLEAN_OBJECT_TYPE));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        boolean boolean4 = node3.isSyntheticBlock();
        boolean boolean6 = node3.getBooleanProp(49);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = com.google.javascript.rhino.Token.REF_SPECIAL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 69 + "'", int0 == 69);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int0 = com.google.javascript.rhino.Token.SETPROP_OP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 135 + "'", int0 == 135);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        try {
//            com.google.javascript.rhino.Context.exit();
//            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Calling Context.exit without previous Context.enter");
//        } catch (java.lang.RuntimeException e) {
//        }
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = com.google.javascript.rhino.Context.FEATURE_RESERVED_KEYWORD_AS_IDENTIFIER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PUBLIC));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int0 = com.google.javascript.rhino.Node.SPECIALCALL_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = com.google.javascript.rhino.Token.MOD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = com.google.javascript.rhino.Token.RSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 19 + "'", int0 == 19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int0 = com.google.javascript.rhino.Token.HOOK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 98 + "'", int0 == 98);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long1 = com.google.javascript.rhino.ScriptRuntime.testUint32String("error reporter");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int0 = com.google.javascript.rhino.Token.NOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 26 + "'", int0 == 26);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int0 = com.google.javascript.rhino.Node.IS_VAR_ARGS_PARAM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.lang.Object[] objArray0 = com.google.javascript.rhino.ScriptRuntime.emptyArgs;
        org.junit.Assert.assertNotNull(objArray0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int0 = com.google.javascript.rhino.Token.NEG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        java.lang.String str1 = com.google.javascript.rhino.Token.name((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ASSIGN_MOD" + "'", str1.equals("ASSIGN_MOD"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int0 = com.google.javascript.rhino.Token.LB;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 79 + "'", int0 == 79);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int0 = com.google.javascript.rhino.Node.FLAG_NO_THROWS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        com.google.javascript.rhino.EcmaError ecmaError2 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
        java.lang.String str3 = ecmaError2.getName();
        org.junit.Assert.assertNotNull(ecmaError2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = com.google.javascript.rhino.Token.EXPORT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 106 + "'", int0 == 106);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_6;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 160 + "'", int0 == 160);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int0 = com.google.javascript.rhino.Token.ENUM_INIT_KEYS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 57 + "'", int0 == 57);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        try {
//            com.google.javascript.rhino.Context.reportError("ASSIGN_MOD");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: ASSIGN_MOD");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList7 = jSModule6.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList10 = jSModule9.getDependencies();
        jSModule6.addDependency(jSModule9);
        java.lang.String str12 = jSModule9.getName();
        compilerInput3.setModule(jSModule9);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(jSModuleList7);
        org.junit.Assert.assertNotNull(jSModuleList10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int0 = com.google.javascript.rhino.Node.BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int0 = com.google.javascript.rhino.Token.FIRST_BYTECODE_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        int int0 = com.google.javascript.rhino.Node.PARENTHESIZED_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 34 + "'", int0 == 34);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        com.google.javascript.jscomp.SourceAst sourceAst3 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput6 = new com.google.javascript.jscomp.CompilerInput(sourceAst3, "hi!", true);
        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "hi!", true);
        boolean boolean11 = compilerInput10.isExtern();
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList14 = jSModule13.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule16 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList17 = jSModule16.getDependencies();
        jSModule13.addDependency(jSModule16);
        java.lang.String str19 = jSModule16.getName();
        compilerInput10.setModule(jSModule16);
        try {
            jSModule1.addAfter(compilerInput6, compilerInput10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleList14);
        org.junit.Assert.assertNotNull(jSModuleList17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.REGEXP_TYPE));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = com.google.javascript.rhino.Token.CASE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 111 + "'", int0 == 111);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        try {
            java.lang.String str5 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        int int2 = ecmaError1.getLineNumber();
        java.lang.Throwable[] throwableArray3 = ecmaError1.getSuppressed();
        try {
            ecmaError1.initColumnNumber(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = com.google.javascript.rhino.Token.BINDNAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 48 + "'", int0 == 48);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = com.google.javascript.rhino.Context.FEATURE_LOCATION_INFORMATION_IN_ERROR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.TYPE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.CHECK_VARIABLES;
        org.junit.Assert.assertNull(diagnosticGroup0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = com.google.javascript.rhino.Node.SOURCENAME_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = com.google.javascript.rhino.Token.CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        com.google.javascript.rhino.Node node1 = com.google.javascript.rhino.Node.newString("");
        node1.setCharno(4095);
        org.junit.Assert.assertNotNull(node1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.UNKNOWN_DEFINES;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        boolean boolean5 = node3.isLocalResultCall();
        boolean boolean6 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        node10.setOptionalArg(false);
        boolean boolean15 = node10.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node21 = node19.getChildAtIndex((int) (short) 0);
        node19.setOptionalArg(false);
        node3.addChildAfter(node10, node19);
        boolean boolean25 = node10.isOptionalArg();
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double0 = com.google.javascript.rhino.ScriptRuntime.NaN;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        int int1 = sideEffectFlags0.valueOf();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler5 = null;
        try {
            compilerInput3.setCompiler(abstractCompiler5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.checkSuspiciousCode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int0 = com.google.javascript.rhino.Token.RESERVED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 123 + "'", int0 == 123);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("ASSIGN_MOD");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ASSIGN_MOD");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = com.google.javascript.rhino.Node.CATCH_SCOPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("bindname", generator1);
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayEdgeCallback0 = null;
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayFixedPointGraphTraversal1 = new com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard>(jSModuleArrayEdgeCallback0);
        com.google.javascript.jscomp.graph.DiGraph<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayDiGraph2 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray3);
        try {
            jSModuleArrayFixedPointGraphTraversal1.computeFixedPoint(jSModuleArrayDiGraph2, jSModuleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        int int0 = com.google.javascript.rhino.Node.LEFT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.UNDEFINED_VARIABLES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        int int0 = com.google.javascript.rhino.Node.VARIABLE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 23 + "'", int0 == 23);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("TypeError: hi!");
        org.junit.Assert.assertNotNull(ecmaError1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node6 = node4.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node(5, node4);
        node7.setVarArgs(true);
        boolean boolean10 = node7.hasChildren();
        try {
            node7.setSideEffectFlags(67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: setIsNoSideEffectsCall only supports CALL and NEW nodes, got GOTO");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int0 = com.google.javascript.rhino.Node.DEBUGSOURCE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayEdgeCallback0 = null;
        com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayFixedPointGraphTraversal1 = new com.google.javascript.jscomp.graph.FixedPointGraphTraversal<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard>(jSModuleArrayEdgeCallback0);
        com.google.javascript.jscomp.graph.DiGraph<com.google.javascript.jscomp.JSModule[], com.google.javascript.jscomp.WarningsGuard> jSModuleArrayDiGraph2 = null;
        com.google.javascript.jscomp.JSModule[] jSModuleArray3 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph4 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray3);
        com.google.javascript.jscomp.JSModule[][] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[][] { jSModuleArray3 };
        java.util.LinkedHashSet<com.google.javascript.jscomp.JSModule[]> jSModuleArraySet6 = new java.util.LinkedHashSet<com.google.javascript.jscomp.JSModule[]>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.JSModule[]>) jSModuleArraySet6, jSModuleArray5);
        try {
            jSModuleArrayFixedPointGraphTraversal1.computeFixedPoint(jSModuleArrayDiGraph2, (java.util.Set<com.google.javascript.jscomp.JSModule[]>) jSModuleArraySet6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray3);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError0("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property hi!");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = com.google.javascript.rhino.Node.FREE_CALL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.aliasExternals = true;
        compilerOptions0.labelRenaming = true;
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = com.google.javascript.rhino.Node.OPT_ARG_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_5;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 150 + "'", int0 == 150);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile5 = com.google.javascript.jscomp.JSSourceFile.fromFile("BITXOR 84");
        try {
            compilerInput3.setSourceFile((com.google.javascript.jscomp.SourceFile) jSSourceFile5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        com.google.javascript.rhino.JSDocInfo.Visibility visibility0 = com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE;
        org.junit.Assert.assertTrue("'" + visibility0 + "' != '" + com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE + "'", visibility0.equals(com.google.javascript.rhino.JSDocInfo.Visibility.PRIVATE));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        boolean boolean6 = compilerOptions0.generateExports;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = com.google.javascript.rhino.Token.BREAK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 116 + "'", int0 == 116);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(103, "");
        boolean boolean3 = node2.hasChildren();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int0 = com.google.javascript.rhino.Token.IMPORT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 107 + "'", int0 == 107);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.SourceMap.DetailLevel detailLevel6 = null;
        compilerOptions0.sourceMapDetailLevel = detailLevel6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(codingConvention5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.getMessage1("", (java.lang.Object) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy0 = com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL;
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy0 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL + "'", variableRenamingPolicy0.equals(com.google.javascript.jscomp.VariableRenamingPolicy.LOCAL));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler0 = null;
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node4.getFirstChild();
        java.lang.String str6 = node4.toString();
        com.google.javascript.jscomp.NodeTraversal.Callback callback7 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse(abstractCompiler0, node4, callback7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "BITXOR 84" + "'", str6.equals("BITXOR 84"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int0 = com.google.javascript.rhino.Token.EXPR_RESULT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int0 = com.google.javascript.rhino.Token.IN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 51 + "'", int0 == 51);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList3, node10, 0, 0);
        boolean boolean16 = node15.isSyntheticBlock();
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        com.google.javascript.jscomp.parsing.Config config1 = com.google.javascript.jscomp.parsing.ParserRunner.createConfig(false);
        org.junit.Assert.assertNotNull(config1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        int int0 = com.google.javascript.rhino.Token.LAST_TOKEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 153 + "'", int0 == 153);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        com.google.javascript.jscomp.DiagnosticType diagnosticType0 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String str1 = diagnosticType0.toString();
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        int int3 = diagnosticType0.compareTo(diagnosticType2);
        org.junit.Assert.assertNotNull(diagnosticType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str1.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = com.google.javascript.rhino.Token.IF;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 108 + "'", int0 == 108);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = com.google.javascript.rhino.Token.FINALLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 121 + "'", int0 == 121);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression0 = null;
        try {
            com.google.javascript.rhino.JSTypeExpression jSTypeExpression1 = com.google.javascript.rhino.JSTypeExpression.makeOptionalArg(jSTypeExpression0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.LEAST_FUNCTION_TYPE));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int0 = com.google.javascript.rhino.Token.URSH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 20 + "'", int0 == 20);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry0 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder1 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry0);
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType2 = functionBuilder1.build();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        compilerOptions0.reportPath = "language version";
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy4 = com.google.javascript.jscomp.VariableRenamingPolicy.OFF;
        compilerOptions0.variableRenaming = variableRenamingPolicy4;
        java.lang.Object obj6 = null;
        java.lang.RuntimeException runtimeException7 = com.google.javascript.rhino.ScriptRuntime.notFunctionError((java.lang.Object) variableRenamingPolicy4, obj6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy4 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.OFF + "'", variableRenamingPolicy4.equals(com.google.javascript.jscomp.VariableRenamingPolicy.OFF));
        org.junit.Assert.assertNotNull(runtimeException7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = com.google.javascript.rhino.Token.POS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 28 + "'", int0 == 28);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        com.google.javascript.rhino.Node node5 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node6 = node5.getFirstChild();
        com.google.javascript.rhino.Node node7 = node5.getLastChild();
        com.google.javascript.rhino.Node[] nodeArray8 = new com.google.javascript.rhino.Node[] { node5 };
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node(85, nodeArray8);
        try {
            com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node(85, nodeArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(node6);
        org.junit.Assert.assertNull(node7);
        org.junit.Assert.assertNotNull(nodeArray8);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((int) (byte) 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        int int0 = com.google.javascript.rhino.Node.NO_SIDE_EFFECTS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        int int0 = com.google.javascript.rhino.Token.ARRAYLIT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 63 + "'", int0 == 63);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int0 = com.google.javascript.rhino.Token.SET_REF_OP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 138 + "'", int0 == 138);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.aliasExternals = true;
        boolean boolean7 = compilerOptions0.removeDeadCode;
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean12 = compilerOptions0.exportTestFunctions;
        boolean boolean13 = compilerOptions0.checkSuspiciousCode;
        compilerOptions0.convertToDottedProperties = false;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = com.google.javascript.rhino.Node.SYNTHETIC_BLOCK_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 37 + "'", int0 == 37);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = com.google.javascript.rhino.Context.FEATURE_STRICT_VARS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int0 = com.google.javascript.rhino.Token.TYPEOFNAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 133 + "'", int0 == 133);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        com.google.javascript.rhino.Node node5 = node3.getLastChild();
        com.google.javascript.rhino.Node node6 = node3.removeChildren();
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.CHECKED_UNKNOWN_TYPE));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        try {
            compiler1.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_OBJECT_FUNCTION_TYPE));
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        boolean boolean1 = context0.isGeneratingDebug();
//        context0.addActivationName("TypeError: hi!");
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "hi!");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile6 = com.google.javascript.jscomp.JSSourceFile.fromFile("BITXOR 84");
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.coalesceVariableNames = true;
        compilerOptions7.generatePseudoNames = false;
        compilerOptions7.aliasExternals = true;
        boolean boolean14 = compilerOptions7.removeDeadCode;
        try {
            com.google.javascript.jscomp.Result result15 = compiler1.compile(jSSourceFile4, jSSourceFile6, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: java.lang.NullPointerException");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromInputStream("TypeError: hi!", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator3);
        com.google.javascript.jscomp.SourceFile.Generator generator6 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile7 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator6);
        java.lang.String str8 = jSSourceFile7.getName();
        com.google.javascript.jscomp.CompilerOptions compilerOptions9 = new com.google.javascript.jscomp.CompilerOptions();
        try {
            com.google.javascript.jscomp.Result result10 = compiler1.compile(jSSourceFile4, jSSourceFile7, compilerOptions9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSSourceFile7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int0 = com.google.javascript.rhino.Token.GOTO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.AMBIGUOUS_FUNCTION_DECL;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        com.google.javascript.jscomp.CompilerOptions.TracerMode tracerMode0 = com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST;
        org.junit.Assert.assertTrue("'" + tracerMode0 + "' != '" + com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST + "'", tracerMode0.equals(com.google.javascript.jscomp.CompilerOptions.TracerMode.FAST));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = com.google.javascript.rhino.Context.FEATURE_MEMBER_EXPR_AS_FUNCTION_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int0 = com.google.javascript.rhino.Context.VERSION_UNKNOWN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        compilerOptions0.removeEmptyFunctions = false;
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int0 = com.google.javascript.rhino.Token.LOCAL_BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 137 + "'", int0 == 137);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        int int0 = com.google.javascript.rhino.Node.FLAG_GLOBAL_STATE_UNMODIFIED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        int int0 = com.google.javascript.rhino.Node.LOCALCOUNT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        com.google.javascript.rhino.EvaluatorException evaluatorException3 = new com.google.javascript.rhino.EvaluatorException("", "", 0);
        java.lang.String str4 = evaluatorException3.sourceName();
        evaluatorException3.initLineNumber(133);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        boolean boolean5 = node3.isLocalResultCall();
        boolean boolean6 = node3.isOnlyModifiesThisCall();
        try {
            int int8 = node3.getExistingIntProp(112);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = com.google.javascript.rhino.Token.SCRIPT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 132 + "'", int0 == 132);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        boolean boolean5 = node3.isLocalResultCall();
        boolean boolean6 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        node10.setOptionalArg(false);
        boolean boolean15 = node10.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node21 = node19.getChildAtIndex((int) (short) 0);
        node19.setOptionalArg(false);
        node3.addChildAfter(node10, node19);
        int int25 = node10.getCharno();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node30 = node29.getFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder31 = node29.new FileLevelJsDocBuilder();
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler33 = null;
        com.google.javascript.rhino.Node[] nodeArray34 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList35 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean36 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList35, nodeArray34);
        com.google.javascript.jscomp.NodeTraversal.Callback callback37 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler33, (java.util.List<com.google.javascript.rhino.Node>) nodeList35, callback37);
        com.google.javascript.rhino.Node node42 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node44 = node42.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node47 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList35, node42, 0, 0);
        java.util.Set<java.lang.String> strSet48 = node47.getDirectives();
        try {
            node10.addChildBefore(node29, node47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 147 + "'", int25 == 147);
        org.junit.Assert.assertNull(node30);
        org.junit.Assert.assertNotNull(nodeArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(node44);
        org.junit.Assert.assertNotNull(node47);
        org.junit.Assert.assertNull(strSet48);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) "language version");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        java.util.Locale locale4 = context0.getLocale();
//        context0.setInstructionObserverThreshold(87);
//        com.google.javascript.rhino.Context context7 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj9 = context7.getThreadLocal((java.lang.Object) "language version");
//        com.google.javascript.rhino.ErrorReporter errorReporter10 = context7.getErrorReporter();
//        java.util.Locale locale11 = context7.getLocale();
//        java.util.Locale locale12 = context0.setLocale(locale11);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertNotNull(context7);
//        org.junit.Assert.assertNull(obj9);
//        org.junit.Assert.assertNull(errorReporter10);
//        org.junit.Assert.assertNotNull(locale11);
//        org.junit.Assert.assertNotNull(locale12);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString("");
        com.google.javascript.rhino.Node node3 = null;
        com.google.javascript.rhino.Node node4 = null;
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node11 = node9.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node(5, node9);
        try {
            com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(5, node2, node3, node4, node9, 65, 105);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertNull(node11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        boolean boolean5 = node3.isLocalResultCall();
        boolean boolean6 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        node10.setOptionalArg(false);
        boolean boolean15 = node10.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node21 = node19.getChildAtIndex((int) (short) 0);
        node19.setOptionalArg(false);
        node3.addChildAfter(node10, node19);
        java.lang.Iterable<com.google.javascript.rhino.Node> nodeIterable25 = node10.children();
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(nodeIterable25);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        int int0 = com.google.javascript.rhino.Token.BITXOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy0 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF;
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy0 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy0.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType2 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType3 = jSTypeRegistry1.createNullableType(jSType2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.getCurrentContext();
//        org.junit.Assert.assertNull(context0);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setMutatesGlobalState();
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags1 = new com.google.javascript.rhino.Node.SideEffectFlags((-2));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.PassConfig passConfig3 = null;
        try {
            compiler1.setPassConfig(passConfig3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = com.google.javascript.rhino.Token.TRUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 44 + "'", int0 == 44);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int0 = com.google.javascript.rhino.Node.CASES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 13 + "'", int0 == 13);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node3.getChildAtIndex((int) (short) 0);
        node3.putIntProp(11, 120);
        org.junit.Assert.assertNull(node5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.aliasExternals = true;
        boolean boolean7 = compilerOptions0.removeDeadCode;
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.recordFunctionInformation = true;
        boolean boolean12 = compilerOptions0.exportTestFunctions;
        boolean boolean13 = compilerOptions0.optimizeReturns;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.setSummaryDetailLevel(0);
        java.lang.String str18 = compilerOptions0.debugFunctionSideEffectsPath;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        node3.setLineno(6);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        int int0 = com.google.javascript.rhino.Token.BLOCK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 125 + "'", int0 == 125);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Double double0 = com.google.javascript.rhino.ScriptRuntime.NaNobj;
        org.junit.Assert.assertEquals((double) double0, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newNumber((double) 71);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        try {
            com.google.javascript.jscomp.NodeTraversal.traverse((com.google.javascript.jscomp.AbstractCompiler) compiler1, node4, callback5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        com.google.javascript.rhino.EvaluatorException evaluatorException5 = new com.google.javascript.rhino.EvaluatorException("", "ASSIGN_MOD", 29, "JSC_NODE_TRAVERSAL_ERROR: {0}", 135);
        java.io.FilenameFilter filenameFilter6 = null;
        java.lang.String str7 = evaluatorException5.getScriptStackTrace(filenameFilter6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "<No stack trace available>" + "'", str7.equals("<No stack trace available>"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int0 = com.google.javascript.rhino.Token.THROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 49 + "'", int0 == 49);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        com.google.javascript.jscomp.CodingConvention codingConvention0 = null;
        try {
            com.google.javascript.rhino.Node node4 = com.google.javascript.jscomp.NodeUtil.newQualifiedNameNode(codingConvention0, "TypeError: hi!", 7, 117);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.jstype.JSType jSType3 = null;
        try {
            jSTypeRegistry1.overwriteDeclaredType("language version", jSType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.aliasExternals = true;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = null;
        compilerOptions0.reportUnknownTypes = checkLevel7;
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup3;
        com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED = diagnosticGroup3;
        try {
            boolean boolean6 = diagnosticGroupWarningsGuard2.enables(diagnosticGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) (short) 0);
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions3.coalesceVariableNames = true;
        compilerOptions3.generatePseudoNames = false;
        compilerOptions3.aliasExternals = true;
        boolean boolean10 = compilerOptions3.removeDeadCode;
        try {
            context0.unseal((java.lang.Object) boolean10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("bindname", charset1);
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str5 = sourceFile2.getLine(51);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bindname" + "'", str3.equals("bindname"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.Node node6 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node8 = node6.getChildAtIndex((int) (short) 0);
        node6.setOptionalArg(false);
        com.google.javascript.rhino.Node node11 = node6.getNext();
        java.lang.Object obj13 = node6.getProp(14);
        com.google.javascript.rhino.Node node18 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node20 = node18.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node(5, node18);
        boolean boolean22 = node21.hasChildren();
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        try {
            com.google.javascript.rhino.jstype.FunctionType functionType24 = jSTypeRegistry1.createConstructorType("bindname", node6, node21, jSType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNull(node20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int0 = com.google.javascript.rhino.Token.ELLIPSIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 305 + "'", int0 == 305);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = com.google.javascript.rhino.Token.OR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 100 + "'", int0 == 100);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getFileOverview();
        java.lang.String str3 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getReturnType();
        java.lang.String str5 = jSDocInfo0.getTemplateTypeName();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(jSTypeExpression4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.ErrorManager errorManager5 = null;
        compilerInput3.setErrorManager(errorManager5);
        try {
            java.util.Collection<java.lang.String> strCollection7 = compilerInput3.getRequires();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        compilerOptions0.checkSuspiciousCode = true;
        boolean boolean4 = compilerOptions0.rewriteFunctionExpressions;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("BITXOR 84");
        try {
            java.lang.String str2 = jSSourceFile1.getCode();
            org.junit.Assert.fail("Expected exception of type java.io.FileNotFoundException; message: BITXOR 84 (No such file or directory)");
        } catch (java.io.FileNotFoundException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        compilerOptions0.removeUnusedLocalVars = true;
        compilerOptions0.checkMissingGetCssNameBlacklist = "";
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        int int0 = com.google.javascript.rhino.Node.VAR_ARGS_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 29 + "'", int0 == 29);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.rhino.Node node7 = null;
        try {
            com.google.javascript.rhino.Node node10 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("error reporter", (java.util.List<com.google.javascript.rhino.Node>) nodeList3, node7, 29, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.generatePseudoNames = false;
        compilerOptions0.aliasExternals = true;
        boolean boolean7 = compilerOptions0.removeDeadCode;
        compilerOptions0.deadAssignmentElimination = false;
        compilerOptions0.recordFunctionInformation = true;
        byte[] byteArray12 = null;
        compilerOptions0.inputVariableMapSerialized = byteArray12;
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int0 = com.google.javascript.rhino.Token.AND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 101 + "'", int0 == 101);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_4;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 140 + "'", int0 == 140);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        com.google.javascript.jscomp.ErrorFormat errorFormat4 = com.google.javascript.jscomp.ErrorFormat.SINGLELINE;
        compilerOptions0.errorFormat = errorFormat4;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions0.checkMissingGetCssNameLevel;
        boolean boolean7 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertNotNull(errorFormat4);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            com.google.javascript.jscomp.SourceFile sourceFile4 = compilerInput3.getSourceFile();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        compilerOptions0.inlineGetters = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(codingConvention5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = com.google.javascript.rhino.Node.TYPE_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 17 + "'", int0 == 17);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node(34, 0, (-1));
        com.google.javascript.rhino.Node node7 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node8 = node7.getFirstChild();
        java.lang.String str9 = node7.toString();
        java.lang.String str10 = node7.toString();
        node3.addChildToBack(node7);
        try {
            java.lang.String str12 = node7.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR 84 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(node8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "BITXOR 84" + "'", str9.equals("BITXOR 84"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "BITXOR 84" + "'", str10.equals("BITXOR 84"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        int int2 = ecmaError1.getLineNumber();
        java.lang.String str3 = ecmaError1.details();
        java.lang.String str4 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: hi!" + "'", str3.equals("TypeError: hi!"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.SYNTAX_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        int int0 = com.google.javascript.rhino.Node.SIDE_EFFECTS_FLAGS_MASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node3.setVarArgs(false);
        java.lang.Object obj7 = node3.getProp(103);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.lang.String str0 = com.google.javascript.rhino.jstype.JSType.NOT_A_TYPE;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Not declared as a type name" + "'", str0.equals("Not declared as a type name"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        int int2 = ecmaError1.getLineNumber();
        java.lang.String str3 = ecmaError1.details();
        com.google.javascript.rhino.EvaluatorException evaluatorException9 = new com.google.javascript.rhino.EvaluatorException("", "ASSIGN_MOD", 29, "JSC_NODE_TRAVERSAL_ERROR: {0}", 135);
        com.google.javascript.rhino.Node node13 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node14 = node13.getFirstChild();
        boolean boolean15 = node13.isLocalResultCall();
        boolean boolean16 = node13.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node20 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node22 = node20.getChildAtIndex((int) (short) 0);
        node20.setOptionalArg(false);
        boolean boolean25 = node20.isVarArgs();
        com.google.javascript.rhino.Node node29 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node31 = node29.getChildAtIndex((int) (short) 0);
        node29.setOptionalArg(false);
        node13.addChildAfter(node20, node29);
        java.lang.RuntimeException runtimeException35 = com.google.javascript.rhino.ScriptRuntime.undefReadError((java.lang.Object) 29, (java.lang.Object) node29);
        ecmaError1.addSuppressed((java.lang.Throwable) runtimeException35);
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: hi!" + "'", str3.equals("TypeError: hi!"));
        org.junit.Assert.assertNull(node14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(node22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(node31);
        org.junit.Assert.assertNotNull(runtimeException35);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.FILEOVERVIEW_JSDOC = diagnosticGroup0;
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        int int0 = com.google.javascript.rhino.Token.LEAVEWITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int0 = com.google.javascript.rhino.Token.REF_NS_MEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 74 + "'", int0 == 74);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node3.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node10 = node9.getFirstChild();
        boolean boolean11 = node9.isLocalResultCall();
        boolean boolean12 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node18 = node16.getChildAtIndex((int) (short) 0);
        node16.setOptionalArg(false);
        boolean boolean21 = node16.isVarArgs();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node27 = node25.getChildAtIndex((int) (short) 0);
        node25.setOptionalArg(false);
        node9.addChildAfter(node16, node25);
        node3.addChildToFront(node9);
        com.google.javascript.rhino.Node node32 = node3.getFirstChild();
        try {
            java.lang.String str33 = node32.getString();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR 84 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int0 = com.google.javascript.rhino.Node.IS_CONSTANT_NAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        java.util.List<java.lang.String> strList4 = jSModule1.getProvides();
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertNotNull(strList4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int0 = com.google.javascript.rhino.jstype.JSType.ENUMDECL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy6;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(codingConvention5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.UNMAPPED));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.reserveRawExports;
        boolean boolean10 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel11;
        compilerOptions0.checkFunctions = checkLevel11;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = null;
        compilerOptions0.aggressiveVarCheck = checkLevel14;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
//        java.lang.String str4 = ecmaError3.getScriptStackTrace();
//        context0.removeThreadLocal((java.lang.Object) str4);
//        boolean boolean7 = context0.isActivationNeeded("ASSIGN_MOD");
//        int int8 = context0.getOptimizationLevel();
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(ecmaError3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        com.google.javascript.rhino.Parser parser0 = null;
        java.io.Reader reader1 = null;
        com.google.javascript.rhino.TokenStream tokenStream4 = new com.google.javascript.rhino.TokenStream(parser0, reader1, "error reporter", 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("Not declared as a type name", charset1);
        org.junit.Assert.assertNotNull(sourceFile2);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            java.lang.String str4 = compilerInput3.getCode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        java.lang.String str1 = jSDocInfo0.getReturnDescription();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.rhino.Node node9 = com.google.javascript.rhino.Node.newString(117, "error reporter");
        node9.setOptionalArg(false);
        com.google.javascript.rhino.Node node14 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("error reporter", (java.util.List<com.google.javascript.rhino.Node>) nodeList3, node9, 124, 34);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(node9);
        org.junit.Assert.assertNotNull(node14);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getFileOverview();
        java.lang.String str3 = jSDocInfo0.getBlockDescription();
        java.lang.String str4 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSDocInfo.Visibility visibility5 = jSDocInfo0.getVisibility();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(visibility5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel3;
        compilerOptions0.aliasableGlobals = "language version";
        boolean boolean7 = compilerOptions0.checkControlStructures;
        boolean boolean8 = compilerOptions0.foldConstants;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        try {
            int int4 = compiler1.getErrorCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNull(sourceMap3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.ALL_TYPE));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node3.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node10 = node9.getFirstChild();
        boolean boolean11 = node9.isLocalResultCall();
        boolean boolean12 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node18 = node16.getChildAtIndex((int) (short) 0);
        node16.setOptionalArg(false);
        boolean boolean21 = node16.isVarArgs();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node27 = node25.getChildAtIndex((int) (short) 0);
        node25.setOptionalArg(false);
        node9.addChildAfter(node16, node25);
        node3.addChildToFront(node9);
        com.google.javascript.rhino.Node node32 = node3.getFirstChild();
        try {
            node32.setString("bindname");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR 84 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNotNull(node32);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int0 = com.google.javascript.rhino.Token.JSR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 131 + "'", int0 == 131);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        try {
            compiler5.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.isConstructor();
        java.lang.String str2 = jSDocInfo0.getFileOverview();
        java.lang.String str3 = jSDocInfo0.getBlockDescription();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getReturnType();
        boolean boolean5 = jSDocInfo0.hasTypedefType();
        java.lang.String str6 = jSDocInfo0.getBlockDescription();
        boolean boolean7 = jSDocInfo0.isExport();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(jSTypeExpression4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        int int2 = ecmaError1.getLineNumber();
        java.lang.String str3 = ecmaError1.details();
        try {
            ecmaError1.initLineNumber((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: hi!" + "'", str3.equals("TypeError: hi!"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node12.setVarArgs(false);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(85, node4, node8, node12);
        com.google.javascript.rhino.Node node16 = node4.getLastSibling();
        boolean boolean17 = node16.isLocalResultCall();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromFile("BITXOR 84");
        com.google.javascript.jscomp.JSModule[] jSModuleArray5 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph6 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray5);
        com.google.javascript.jscomp.CompilerOptions compilerOptions7 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions7.coalesceVariableNames = true;
        compilerOptions7.generatePseudoNames = false;
        compilerOptions7.aliasExternals = true;
        boolean boolean14 = compilerOptions7.removeDeadCode;
        compilerOptions7.deadAssignmentElimination = false;
        compilerOptions7.recordFunctionInformation = true;
        boolean boolean19 = compilerOptions7.exportTestFunctions;
        boolean boolean20 = compilerOptions7.checkSuspiciousCode;
        try {
            com.google.javascript.jscomp.Result result21 = compiler1.compile(jSSourceFile4, jSModuleArray5, compilerOptions7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertNotNull(jSModuleArray5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString(117, "error reporter");
        com.google.javascript.rhino.Node node4 = new com.google.javascript.rhino.Node(123, node3);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.setAllFlags();
        sideEffectFlags0.setThrows();
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        try {
//            com.google.javascript.rhino.EvaluatorException evaluatorException5 = com.google.javascript.rhino.Context.reportRuntimeError("language version", "language version", 90, "NUMBER 71.0\n", 0);
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: language version (language version#90)");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int0 = com.google.javascript.rhino.Token.BITAND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        boolean boolean5 = compilerOptions0.inlineLocalVariables;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler5.getState();
        try {
            compiler5.optimize();
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: INTERNAL COMPILER ERROR.\nPlease report this problem.\nnull");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(intermediateState7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node3.setVarArgs(false);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node11 = node9.getChildAtIndex((int) (short) 0);
        node9.setOptionalArg(false);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler15 = null;
        com.google.javascript.rhino.Node[] nodeArray16 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList17 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList17, nodeArray16);
        com.google.javascript.jscomp.NodeTraversal.Callback callback19 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler15, (java.util.List<com.google.javascript.rhino.Node>) nodeList17, callback19);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node26 = node24.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node29 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList17, node24, 0, 0);
        try {
            node3.addChildBefore(node9, node24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(node11);
        org.junit.Assert.assertNotNull(nodeArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(node26);
        org.junit.Assert.assertNotNull(node29);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int0 = com.google.javascript.rhino.Context.VERSION_1_3;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 130 + "'", int0 == 130);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        com.google.javascript.rhino.Node node4 = node3.removeFirstChild();
        node3.setOptionalArg(false);
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertNull(node4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState2 = compiler1.getState();
        com.google.javascript.jscomp.SourceMap sourceMap3 = compiler1.getSourceMap();
        try {
            compiler1.parse();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState2);
        org.junit.Assert.assertNull(sourceMap3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            com.google.javascript.rhino.Context.reportWarning("ASSIGN_MOD");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: No Context associated with current Thread");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 32, (int) (byte) 100, 29);
        boolean boolean4 = node3.isQualifiedName();
        org.junit.Assert.assertNotNull(node3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        com.google.javascript.rhino.Node node8 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node12.setVarArgs(false);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node(85, node4, node8, node12);
        boolean boolean16 = node12.isUnscopedQualifiedName();
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        int int4 = jSModule1.getDepth();
        com.google.javascript.jscomp.SourceAst sourceAst5 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput8 = new com.google.javascript.jscomp.CompilerInput(sourceAst5, "hi!", true);
        boolean boolean9 = compilerInput8.isExtern();
        com.google.javascript.jscomp.JSModule jSModule11 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList12 = jSModule11.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule14 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList15 = jSModule14.getDependencies();
        jSModule11.addDependency(jSModule14);
        java.lang.String str17 = jSModule14.getName();
        compilerInput8.setModule(jSModule14);
        com.google.javascript.jscomp.SourceAst sourceAst19 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceAst19, "hi!", true);
        try {
            jSModule1.addAfter(compilerInput8, compilerInput22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(jSModuleList12);
        org.junit.Assert.assertNotNull(jSModuleList15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(117, "error reporter");
        node2.setCharno((int) (byte) 10);
        org.junit.Assert.assertNotNull(node2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.shouldPreserveTry();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.hasType();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getTypedefType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSTypeExpression4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        try {
            com.google.javascript.jscomp.Region region5 = compilerInput3.getRegion(29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = com.google.javascript.rhino.Token.ASSIGN_ADD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 93 + "'", int0 == 93);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node3.getChildAtIndex((int) (short) 0);
        node3.setOptionalArg(false);
        boolean boolean8 = node3.isVarArgs();
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode12 = new com.google.javascript.rhino.ScriptOrFnNode(65, 107, 85);
        java.lang.String str16 = scriptOrFnNode12.toString(false, true, false);
        int int19 = scriptOrFnNode12.addRegexp("language version", "ASSIGN_MOD");
        java.lang.RuntimeException runtimeException20 = com.google.javascript.rhino.ScriptRuntime.undefCallError((java.lang.Object) boolean8, (java.lang.Object) int19);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "GET_REF" + "'", str16.equals("GET_REF"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(runtimeException20);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.OBJECT_NUMBER_STRING));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("bindname", charset1);
        java.lang.String str3 = sourceFile2.toString();
        java.lang.String str5 = sourceFile2.getLine(2);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bindname" + "'", str3.equals("bindname"));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isInterface();
        boolean boolean8 = functionType6.isEmptyType();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        java.lang.String str2 = ecmaError1.getLineSource();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int0 = com.google.javascript.rhino.Node.DEFAULT_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 14 + "'", int0 == 14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState7 = compiler5.getState();
        com.google.javascript.jscomp.JSModule jSModule9 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList10 = jSModule9.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule12 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList13 = jSModule12.getDependencies();
        jSModule9.addDependency(jSModule12);
        java.lang.String str15 = compiler5.toSource(jSModule12);
        com.google.javascript.jscomp.SourceFile.Generator generator17 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile18 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator17);
        com.google.javascript.jscomp.SourceAst sourceAst19 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput22 = new com.google.javascript.jscomp.CompilerInput(sourceAst19, "hi!", true);
        boolean boolean23 = compilerInput22.isExtern();
        com.google.javascript.jscomp.JSModule jSModule25 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList26 = jSModule25.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule28 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList29 = jSModule28.getDependencies();
        jSModule25.addDependency(jSModule28);
        java.lang.String str31 = jSModule28.getName();
        compilerInput22.setModule(jSModule28);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile35 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "hi!");
        jSModule28.addFirst(jSSourceFile35);
        com.google.javascript.jscomp.SourceAst sourceAst37 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput40 = new com.google.javascript.jscomp.CompilerInput(sourceAst37, "hi!", true);
        boolean boolean41 = compilerInput40.isExtern();
        com.google.javascript.jscomp.JSModule jSModule43 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList44 = jSModule43.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule46 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList47 = jSModule46.getDependencies();
        jSModule43.addDependency(jSModule46);
        java.lang.String str49 = jSModule46.getName();
        compilerInput40.setModule(jSModule46);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile53 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "hi!");
        jSModule46.addFirst(jSSourceFile53);
        com.google.javascript.jscomp.SourceFile.Generator generator56 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile57 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator56);
        java.lang.String str58 = jSSourceFile57.getName();
        com.google.javascript.jscomp.SourceFile.Generator generator60 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile61 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("bindname", generator60);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray62 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile35, jSSourceFile53, jSSourceFile57, jSSourceFile61 };
        com.google.javascript.jscomp.CompilerOptions compilerOptions63 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean64 = compilerOptions63.reserveRawExports;
        boolean boolean65 = compilerOptions63.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel66 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions63.checkMissingGetCssNameLevel = checkLevel66;
        compilerOptions63.aliasableGlobals = "language version";
        boolean boolean70 = compilerOptions63.checkControlStructures;
        try {
            com.google.javascript.jscomp.Result result71 = compiler5.compile(jSSourceFile18, jSSourceFileArray62, compilerOptions63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertNotNull(intermediateState7);
        org.junit.Assert.assertNotNull(jSModuleList10);
        org.junit.Assert.assertNotNull(jSModuleList13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(jSSourceFile18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(jSModuleList26);
        org.junit.Assert.assertNotNull(jSModuleList29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(jSModuleList44);
        org.junit.Assert.assertNotNull(jSModuleList47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile53);
        org.junit.Assert.assertNotNull(jSSourceFile57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile61);
        org.junit.Assert.assertNotNull(jSSourceFileArray62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + checkLevel66 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel66.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        int int0 = com.google.javascript.rhino.Node.DIRECTIVES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 47 + "'", int0 == 47);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.DiagnosticType.disabled("ASSIGN_MOD", "<No stack trace available>");
        com.google.javascript.jscomp.CheckLevel checkLevel3 = diagnosticType2.level;
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        com.google.javascript.rhino.Node.SideEffectFlags sideEffectFlags0 = new com.google.javascript.rhino.Node.SideEffectFlags();
        sideEffectFlags0.clearSideEffectFlags();
        sideEffectFlags0.setThrows();
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        java.lang.String str4 = compilerOptions0.aliasStringsBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.shouldPreserveTry();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.hasType();
        boolean boolean4 = jSDocInfo0.isImplicitCast();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.removeDeadCode = true;
        compilerOptions0.computeFunctionSideEffects = true;
        com.google.javascript.jscomp.VariableRenamingPolicy variableRenamingPolicy10 = com.google.javascript.jscomp.VariableRenamingPolicy.ALL;
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy11 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.setRenamingPolicy(variableRenamingPolicy10, propertyRenamingPolicy11);
        boolean boolean13 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + variableRenamingPolicy10 + "' != '" + com.google.javascript.jscomp.VariableRenamingPolicy.ALL + "'", variableRenamingPolicy10.equals(com.google.javascript.jscomp.VariableRenamingPolicy.ALL));
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy11 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy11.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        int int0 = com.google.javascript.rhino.Token.DO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 114 + "'", int0 == 114);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(65, 107, 85);
        java.lang.String str7 = scriptOrFnNode3.toString(false, true, false);
        int int10 = scriptOrFnNode3.addRegexp("language version", "ASSIGN_MOD");
        int int12 = scriptOrFnNode3.addVar("");
        java.lang.Object obj13 = null;
        try {
            scriptOrFnNode3.setCompilerData(obj13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GET_REF" + "'", str7.equals("GET_REF"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        java.io.PrintStream printStream5 = null;
        com.google.javascript.jscomp.Compiler compiler6 = new com.google.javascript.jscomp.Compiler(printStream5);
        com.google.javascript.jscomp.PerformanceTracker performanceTracker7 = compiler6.tracker;
        try {
            com.google.javascript.rhino.Node node8 = compilerInput3.getAstRoot((com.google.javascript.jscomp.AbstractCompiler) compiler6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(performanceTracker7);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = com.google.javascript.rhino.Token.SWITCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 110 + "'", int0 == 110);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        com.google.javascript.rhino.Token token0 = new com.google.javascript.rhino.Token();
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        com.google.javascript.rhino.Node node3 = com.google.javascript.rhino.Node.newNumber((double) 103, 4, 4095);
        org.junit.Assert.assertNotNull(node3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int0 = com.google.javascript.rhino.Node.USES_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isInterface();
        boolean boolean9 = functionType6.isPropertyInExterns("bindname");
        boolean boolean10 = functionType6.canBeCalled();
        boolean boolean11 = functionType6.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean9 = compilerOptions8.reserveRawExports;
        boolean boolean10 = compilerOptions8.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions8.checkMissingGetCssNameLevel = checkLevel11;
        compilerOptions0.checkFunctions = checkLevel11;
        java.util.List<java.lang.String> strList15 = null;
        try {
            compilerOptions0.setReplaceStringsConfiguration("error reporter", strList15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + checkLevel11 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel11.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = com.google.javascript.rhino.Token.RETHROW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 50 + "'", int0 == 50);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        com.google.javascript.rhino.Node node5 = node4.removeFirstChild();
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node10 = node9.getFirstChild();
        boolean boolean11 = node9.isLocalResultCall();
        boolean boolean12 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node18 = node16.getChildAtIndex((int) (short) 0);
        node16.setOptionalArg(false);
        boolean boolean21 = node16.isVarArgs();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node27 = node25.getChildAtIndex((int) (short) 0);
        node25.setOptionalArg(false);
        node9.addChildAfter(node16, node25);
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry31 = null;
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder32 = new com.google.javascript.rhino.jstype.FunctionBuilder(jSTypeRegistry31);
        com.google.javascript.rhino.Node node36 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node38 = node36.getChildAtIndex((int) (short) 0);
        node36.setOptionalArg(false);
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder41 = functionBuilder32.withParamsNode(node36);
        com.google.javascript.rhino.Node node45 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node46 = node45.getFirstChild();
        com.google.javascript.rhino.Node.FileLevelJsDocBuilder fileLevelJsDocBuilder47 = node45.new FileLevelJsDocBuilder();
        com.google.javascript.rhino.jstype.FunctionBuilder functionBuilder48 = functionBuilder41.withParamsNode(node45);
        try {
            com.google.javascript.rhino.Node node51 = new com.google.javascript.rhino.Node((int) (short) 100, node5, node9, node45, 112, 133);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node4);
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNull(node38);
        org.junit.Assert.assertNotNull(functionBuilder41);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(functionBuilder48);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isBooleanObjectType();
        boolean boolean8 = functionType6.matchesUint32Context();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) "language version");
//        context0.seal((java.lang.Object) 41);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(obj2);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.NUMBER_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = com.google.javascript.rhino.Context.FEATURE_PARENT_PROTO_PROPRTIES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setColorizeErrorOutput(false);
        compilerOptions0.setDefineToNumberLiteral("ASSIGN_MOD", 58);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int0 = com.google.javascript.rhino.Token.XML;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 141 + "'", int0 == 141);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.STRING_VALUE_OR_OBJECT_TYPE));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.EXTERNS_VALIDATION;
        com.google.javascript.jscomp.JSError jSError1 = null;
        try {
            boolean boolean2 = diagnosticGroup0.matches(jSError1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(diagnosticGroup0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "hi!", true);
        boolean boolean8 = compilerInput7.isExtern();
        com.google.javascript.jscomp.SourceFile.Generator generator10 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile11 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator10);
        com.google.javascript.jscomp.CompilerInput compilerInput12 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile11);
        com.google.javascript.jscomp.SourceAst sourceAst13 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput16 = new com.google.javascript.jscomp.CompilerInput(sourceAst13, "hi!", true);
        boolean boolean17 = compilerInput16.isExtern();
        com.google.javascript.jscomp.CompilerInput[] compilerInputArray18 = new com.google.javascript.jscomp.CompilerInput[] { compilerInput3, compilerInput7, compilerInput12, compilerInput16 };
        java.util.ArrayList<com.google.javascript.jscomp.CompilerInput> compilerInputList19 = new java.util.ArrayList<com.google.javascript.jscomp.CompilerInput>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.CompilerInput>) compilerInputList19, compilerInputArray18);
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput> compilerInputSortedDependencies21 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.CompilerInput>((java.util.List<com.google.javascript.jscomp.CompilerInput>) compilerInputList19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Expected setErrorManager to be called first");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(jSSourceFile11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(compilerInputArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        jSTypeRegistry5.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        boolean boolean11 = functionType10.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType10);
        com.google.javascript.rhino.ErrorReporter errorReporter13 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry14 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter13);
        jSTypeRegistry14.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType17 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray18 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType19 = jSTypeRegistry14.createConstructorTypeWithVarArgs(jSType17, jSTypeArray18);
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        jSTypeRegistry21.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        boolean boolean27 = functionType26.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter28 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry29 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter28);
        jSTypeRegistry29.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType32 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray33 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry29.createConstructorTypeWithVarArgs(jSType32, jSTypeArray33);
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry14.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType26, jSTypeArray33);
        boolean boolean36 = functionType35.isOrdinaryFunction();
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray38 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType35, false, jSTypeArray38);
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeArray18);
        org.junit.Assert.assertNotNull(functionType19);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(jSTypeArray33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(jSTypeArray38);
        org.junit.Assert.assertNotNull(functionType39);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(117, "error reporter");
        node2.setOptionalArg(false);
        boolean boolean5 = node2.isOnlyModifiesThisCall();
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        try {
            java.lang.String str2 = com.google.javascript.rhino.ScriptRuntime.escapeString("", ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: FAILED ASSERTION");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.io.PrintStream printStream0 = null;
        com.google.javascript.jscomp.Compiler compiler1 = new com.google.javascript.jscomp.Compiler(printStream0);
        com.google.javascript.jscomp.SourceFile.Generator generator3 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile4 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator3);
        java.lang.String str5 = jSSourceFile4.getName();
        java.lang.String str6 = jSSourceFile4.toString();
        com.google.javascript.jscomp.SourceAst sourceAst7 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput10 = new com.google.javascript.jscomp.CompilerInput(sourceAst7, "hi!", true);
        boolean boolean11 = compilerInput10.isExtern();
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList14 = jSModule13.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule16 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList17 = jSModule16.getDependencies();
        jSModule13.addDependency(jSModule16);
        java.lang.String str19 = jSModule16.getName();
        compilerInput10.setModule(jSModule16);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile23 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "hi!");
        jSModule16.addFirst(jSSourceFile23);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile26 = com.google.javascript.jscomp.JSSourceFile.fromFile("BITXOR 84");
        com.google.javascript.jscomp.SourceFile.Generator generator28 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile29 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator28);
        java.lang.String str30 = jSSourceFile29.getName();
        com.google.javascript.jscomp.SourceAst sourceAst31 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput34 = new com.google.javascript.jscomp.CompilerInput(sourceAst31, "hi!", true);
        boolean boolean35 = compilerInput34.isExtern();
        com.google.javascript.jscomp.JSModule jSModule37 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList38 = jSModule37.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule40 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList41 = jSModule40.getDependencies();
        jSModule37.addDependency(jSModule40);
        java.lang.String str43 = jSModule40.getName();
        compilerInput34.setModule(jSModule40);
        com.google.javascript.jscomp.JSSourceFile jSSourceFile47 = com.google.javascript.jscomp.JSSourceFile.fromCode("language version", "hi!");
        jSModule40.addFirst(jSSourceFile47);
        com.google.javascript.jscomp.JSSourceFile[] jSSourceFileArray49 = new com.google.javascript.jscomp.JSSourceFile[] { jSSourceFile4, jSSourceFile23, jSSourceFile26, jSSourceFile29, jSSourceFile47 };
        com.google.javascript.jscomp.JSModule jSModule51 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList52 = jSModule51.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet53 = jSModule51.getThisAndAllDependencies();
        com.google.javascript.jscomp.JSModule[] jSModuleArray54 = com.google.javascript.jscomp.JSModule.sortJsModules((java.util.Collection<com.google.javascript.jscomp.JSModule>) jSModuleSet53);
        com.google.javascript.jscomp.CompilerOptions compilerOptions55 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean56 = compilerOptions55.reserveRawExports;
        boolean boolean57 = compilerOptions55.inlineGetters;
        compilerOptions55.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CodingConvention codingConvention60 = compilerOptions55.getCodingConvention();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy61 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        compilerOptions55.anonymousFunctionNaming = anonymousFunctionNamingPolicy61;
        compilerOptions55.checkControlStructures = true;
        compilerOptions55.removeTryCatchFinally = true;
        try {
            com.google.javascript.jscomp.Result result67 = compiler1.compile(jSSourceFileArray49, jSModuleArray54, compilerOptions55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSModuleList14);
        org.junit.Assert.assertNotNull(jSModuleList17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile23);
        org.junit.Assert.assertNotNull(jSSourceFile26);
        org.junit.Assert.assertNotNull(jSSourceFile29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(jSModuleList38);
        org.junit.Assert.assertNotNull(jSModuleList41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(jSSourceFile47);
        org.junit.Assert.assertNotNull(jSSourceFileArray49);
        org.junit.Assert.assertNotNull(jSModuleList52);
        org.junit.Assert.assertNotNull(jSModuleSet53);
        org.junit.Assert.assertNotNull(jSModuleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(codingConvention60);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy61 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy61.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        boolean boolean1 = com.google.javascript.rhino.Context.isValidOptimizationLevel(103);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = null;
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_TYPES = diagnosticGroup0;
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.GLOBAL_THIS));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet4 = jSModule1.getAllDependencies();
        boolean boolean6 = jSModule1.removeByName("bindname");
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertNotNull(jSModuleSet4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        com.google.javascript.rhino.JSDocInfo.StringPosition stringPosition0 = new com.google.javascript.rhino.JSDocInfo.StringPosition();
        stringPosition0.setPositionInformation((int) ' ', (int) (byte) -1, 6, 130);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel5 = null;
        compilerOptions0.checkShadowVars = checkLevel5;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = compilerOptions0.brokenClosureRequiresLevel;
        boolean boolean8 = compilerOptions0.checkSuspiciousCode;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            com.google.javascript.rhino.EcmaError ecmaError4 = com.google.javascript.rhino.ScriptRuntime.typeError3("", "GET_REF", "Not declared as a type name", "<No stack trace available>");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property ");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(65, 107, 85);
        java.lang.String str7 = scriptOrFnNode3.toString(false, true, false);
        try {
            java.lang.String str9 = scriptOrFnNode3.getParamOrVarName(71);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: 71 ∉ [0, 0)");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GET_REF" + "'", str7.equals("GET_REF"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        com.google.javascript.rhino.Context.checkOptimizationLevel(1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node4 = node3.getFirstChild();
        boolean boolean5 = node3.isLocalResultCall();
        boolean boolean6 = node3.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        node10.setOptionalArg(false);
        boolean boolean15 = node10.isVarArgs();
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node21 = node19.getChildAtIndex((int) (short) 0);
        node19.setOptionalArg(false);
        node3.addChildAfter(node10, node19);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection25 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node10);
        org.junit.Assert.assertNull(node4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(node21);
        org.junit.Assert.assertNotNull(nodeCollection25);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.Node node11 = com.google.javascript.rhino.Node.newString("error reporter", 76, 118);
        com.google.javascript.rhino.Node node15 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node19 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node19.setVarArgs(false);
        com.google.javascript.rhino.Node node22 = new com.google.javascript.rhino.Node(85, node11, node15, node19);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope24 = null;
        try {
            com.google.javascript.rhino.jstype.JSType jSType26 = jSTypeRegistry1.createFromTypeNodes(node15, "GET_REF", jSTypeStaticScope24, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: Unexpected node in type expression: BITXOR 84");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(node11);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.shouldPreserveTry();
        java.util.Set<java.lang.String> strSet2 = jSDocInfo0.getSuppressions();
        boolean boolean3 = jSDocInfo0.hasType();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression4 = jSDocInfo0.getReturnType();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getTypedefType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strSet2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(jSTypeExpression4);
        org.junit.Assert.assertNull(jSTypeExpression5);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        com.google.javascript.rhino.EcmaError ecmaError3 = com.google.javascript.rhino.ScriptRuntime.constructError("", "hi!");
//        java.lang.String str4 = ecmaError3.getScriptStackTrace();
//        context0.removeThreadLocal((java.lang.Object) str4);
//        boolean boolean7 = context0.isActivationNeeded("ASSIGN_MOD");
//        com.google.javascript.rhino.ErrorReporter errorReporter8 = null;
//        try {
//            com.google.javascript.rhino.ErrorReporter errorReporter9 = context0.setErrorReporter(errorReporter8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNotNull(ecmaError3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<No stack trace available>" + "'", str4.equals("<No stack trace available>"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        java.io.PrintStream printStream4 = null;
        com.google.javascript.jscomp.Compiler compiler5 = new com.google.javascript.jscomp.Compiler(printStream4);
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler5);
        com.google.javascript.jscomp.CompilerInput compilerInput9 = new com.google.javascript.jscomp.CompilerInput((com.google.javascript.jscomp.SourceAst) compilerInput3, "JSC_NODE_TRAVERSAL_ERROR: {0}", true);
        try {
            java.lang.String str10 = compilerInput9.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int0 = com.google.javascript.rhino.Token.USE_STACK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 134 + "'", int0 == 134);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) "language version");
        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
        int int4 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(errorReporter3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("bindname", charset1);
        java.lang.String str3 = sourceFile2.toString();
        sourceFile2.setOriginalPath("");
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "bindname" + "'", str3.equals("bindname"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int0 = com.google.javascript.rhino.Token.BANG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 306 + "'", int0 == 306);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        try {
            com.google.javascript.jscomp.CompilerInput compilerInput2 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isJSIdentifier("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.hasThisType();
        boolean boolean2 = jSDocInfo0.isDeprecated();
        boolean boolean3 = jSDocInfo0.isNoSideEffects();
        boolean boolean4 = jSDocInfo0.isConstant();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int0 = com.google.javascript.rhino.Token.BITNOT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 27 + "'", int0 == 27);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CodingConvention codingConvention5 = compilerOptions0.getCodingConvention();
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy6 = com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED;
        compilerOptions0.anonymousFunctionNaming = anonymousFunctionNamingPolicy6;
        compilerOptions0.checkControlStructures = true;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.DEPRECATED;
        com.google.javascript.jscomp.CompilerOptions compilerOptions11 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean12 = compilerOptions11.reserveRawExports;
        boolean boolean13 = compilerOptions11.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel14 = compilerOptions11.checkGlobalThisLevel;
        compilerOptions0.setWarningLevel(diagnosticGroup10, checkLevel14);
        com.google.javascript.jscomp.DiagnosticGroups.CHECK_REGEXP = diagnosticGroup10;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(codingConvention5);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy6 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED + "'", anonymousFunctionNamingPolicy6.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.MAPPED));
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + checkLevel14 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel14.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.nio.charset.Charset charset1 = null;
        com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromFile("bindname", charset1);
        com.google.javascript.jscomp.Region region4 = sourceFile2.getRegion(4);
        org.junit.Assert.assertNotNull(sourceFile2);
        org.junit.Assert.assertNull(region4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        jSTypeRegistry6.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        jSTypeRegistry21.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry6.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType18, jSTypeArray25);
        java.lang.String str28 = functionType27.toString();
        com.google.javascript.rhino.jstype.EnumType enumType29 = jSTypeRegistry1.createEnumType("function (new:{...}): function (new:{...}): ?", (com.google.javascript.rhino.jstype.JSType) functionType27);
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        try {
            jSTypeRegistry1.overwriteDeclaredType("", jSType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (new:{...}): function (new:{...}): ?" + "'", str28.equals("function (new:{...}): function (new:{...}): ?"));
        org.junit.Assert.assertNotNull(enumType29);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node5 = node3.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node9 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node10 = node9.getFirstChild();
        boolean boolean11 = node9.isLocalResultCall();
        boolean boolean12 = node9.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node18 = node16.getChildAtIndex((int) (short) 0);
        node16.setOptionalArg(false);
        boolean boolean21 = node16.isVarArgs();
        com.google.javascript.rhino.Node node25 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node27 = node25.getChildAtIndex((int) (short) 0);
        node25.setOptionalArg(false);
        node9.addChildAfter(node16, node25);
        node3.addChildToFront(node9);
        com.google.javascript.rhino.Node node32 = node3.getFirstChild();
        boolean boolean33 = node32.isOptionalArg();
        org.junit.Assert.assertNull(node5);
        org.junit.Assert.assertNull(node10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(node18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(node27);
        org.junit.Assert.assertNotNull(node32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        com.google.javascript.jscomp.CompilerOptions compilerOptions1 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean2 = compilerOptions1.reserveRawExports;
        boolean boolean3 = compilerOptions1.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = compilerOptions1.checkUnreachableCode;
        com.google.javascript.rhino.EvaluatorException evaluatorException10 = new com.google.javascript.rhino.EvaluatorException("Not declared as a type name", "ASSIGN_MOD", (int) (byte) 10, "TypeError: hi!", 133);
        try {
            java.lang.String str11 = com.google.javascript.rhino.ScriptRuntime.getMessage2("error reporter", (java.lang.Object) checkLevel4, (java.lang.Object) "Not declared as a type name");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: no message resource found for message property error reporter");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + checkLevel4 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel4.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("");
        java.io.PrintStream printStream2 = null;
        com.google.javascript.jscomp.Compiler compiler3 = new com.google.javascript.jscomp.Compiler(printStream2);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState4 = compiler3.getState();
        com.google.javascript.jscomp.SourceMap sourceMap5 = compiler3.getSourceMap();
        try {
            jSModule1.sortInputsByDeps(compiler3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intermediateState4);
        org.junit.Assert.assertNull(sourceMap5);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        com.google.javascript.jscomp.SourceFile.Generator generator1 = null;
        com.google.javascript.jscomp.JSSourceFile jSSourceFile2 = com.google.javascript.jscomp.JSSourceFile.fromGenerator("hi!", generator1);
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(jSSourceFile2);
        try {
            java.lang.String str4 = compilerInput3.getPathRelativeToClosureBase();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSSourceFile2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        int int0 = com.google.javascript.rhino.Node.SPECIAL_PROP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 18 + "'", int0 == 18);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Object obj0 = null;
        java.nio.charset.Charset charset2 = null;
        com.google.javascript.jscomp.SourceFile sourceFile3 = com.google.javascript.jscomp.SourceFile.fromFile("", charset2);
        java.lang.RuntimeException runtimeException5 = com.google.javascript.rhino.ScriptRuntime.undefWriteError(obj0, (java.lang.Object) charset2, (java.lang.Object) 6);
        org.junit.Assert.assertNotNull(sourceFile3);
        org.junit.Assert.assertNotNull(runtimeException5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        boolean boolean7 = functionType6.isInterface();
        boolean boolean8 = functionType6.isBooleanObjectType();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int0 = com.google.javascript.rhino.Token.THIS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 42 + "'", int0 == 42);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        com.google.javascript.rhino.JSDocInfo jSDocInfo0 = new com.google.javascript.rhino.JSDocInfo();
        boolean boolean1 = jSDocInfo0.hasThisType();
        boolean boolean2 = jSDocInfo0.isDeprecated();
        int int3 = jSDocInfo0.getImplementedInterfaceCount();
        java.util.Set<java.lang.String> strSet4 = jSDocInfo0.getModifies();
        com.google.javascript.rhino.JSTypeExpression jSTypeExpression5 = jSDocInfo0.getEnumParameterType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(strSet4);
        org.junit.Assert.assertNull(jSTypeExpression5);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        jSTypeRegistry6.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        jSTypeRegistry21.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry6.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType18, jSTypeArray25);
        java.lang.String str28 = functionType27.toString();
        com.google.javascript.rhino.jstype.EnumType enumType29 = jSTypeRegistry1.createEnumType("function (new:{...}): function (new:{...}): ?", (com.google.javascript.rhino.jstype.JSType) functionType27);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry1.getForgivingType(jSTypeStaticScope30, "NUMBER 71.0\n", "hi!", 138, 108);
        boolean boolean36 = jSType35.matchesNumberContext();
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (new:{...}): function (new:{...}): ?" + "'", str28.equals("function (new:{...}): function (new:{...}): ?"));
        org.junit.Assert.assertNotNull(enumType29);
        org.junit.Assert.assertNotNull(jSType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("hi!");
        int int2 = ecmaError1.getLineNumber();
        java.lang.String str3 = ecmaError1.details();
        int int4 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TypeError: hi!" + "'", str3.equals("TypeError: hi!"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        boolean boolean4 = compilerOptions0.allowLegacyJsMessages;
        java.util.List<java.lang.String> strList5 = null;
        try {
            compilerOptions0.setManageClosureDependencies(strList5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        jSTypeRegistry16.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType13, jSTypeArray20);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry1.getForgivingType(jSTypeStaticScope23, "GET_REF", "bindname", (int) '4', 115);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode(115, 4095, 111);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler35 = null;
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.jscomp.NodeTraversal.Callback callback39 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler35, (java.util.List<com.google.javascript.rhino.Node>) nodeList37, callback39);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node46 = node44.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node49 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList37, node44, 0, 0);
        boolean boolean50 = node49.isOnlyModifiesThisCall();
        int int52 = node49.getIntProp(138);
        scriptOrFnNode33.setCompilerData((java.lang.Object) 138);
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54);
        jSTypeRegistry55.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry55.createConstructorTypeWithVarArgs(jSType58, jSTypeArray59);
        boolean boolean61 = functionType60.isBooleanObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        jSTypeRegistry63.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66);
        jSTypeRegistry67.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry67.createConstructorTypeWithVarArgs(jSType70, jSTypeArray71);
        boolean boolean73 = functionType72.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry63.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType72);
        boolean boolean75 = functionType60.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType72);
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry1.createObjectType("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode33, (com.google.javascript.rhino.jstype.ObjectType) functionType60);
        com.google.javascript.rhino.ErrorReporter errorReporter77 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry78 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter77);
        jSTypeRegistry78.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter81 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry82 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter81);
        jSTypeRegistry82.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType85 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray86 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType87 = jSTypeRegistry82.createConstructorTypeWithVarArgs(jSType85, jSTypeArray86);
        boolean boolean88 = functionType87.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType89 = jSTypeRegistry78.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType87);
        boolean boolean90 = objectType76.canAssignTo(jSType89);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(objectType76);
        org.junit.Assert.assertNotNull(jSTypeArray86);
        org.junit.Assert.assertNotNull(functionType87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(jSType89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        com.google.javascript.rhino.Node node3 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        node3.setWasEmptyNode(false);
        boolean boolean6 = node3.isNoSideEffectsCall();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        jSTypeRegistry16.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType13, jSTypeArray20);
        boolean boolean23 = functionType22.isBooleanValueType();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        com.google.javascript.jscomp.JSModule[] jSModuleArray0 = new com.google.javascript.jscomp.JSModule[] {};
        com.google.javascript.jscomp.JSModuleGraph jSModuleGraph1 = new com.google.javascript.jscomp.JSModuleGraph(jSModuleArray0);
        com.google.javascript.jscomp.JSModule jSModule3 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList4 = jSModule3.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule6 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList7 = jSModule6.getDependencies();
        jSModule3.addDependency(jSModule6);
        com.google.javascript.jscomp.JSModule jSModule10 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList11 = jSModule10.getDependencies();
        com.google.javascript.jscomp.JSModule jSModule13 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList14 = jSModule13.getDependencies();
        jSModule10.addDependency(jSModule13);
        java.lang.String str16 = jSModule13.getName();
        boolean boolean17 = jSModuleGraph1.dependsOn(jSModule3, jSModule13);
        com.google.javascript.jscomp.CompilerInput compilerInput18 = null;
        try {
            jSModule13.remove(compilerInput18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleArray0);
        org.junit.Assert.assertNotNull(jSModuleList4);
        org.junit.Assert.assertNotNull(jSModuleList7);
        org.junit.Assert.assertNotNull(jSModuleList11);
        org.junit.Assert.assertNotNull(jSModuleList14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        com.google.javascript.rhino.ErrorReporter errorReporter3 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry4 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter3);
        jSTypeRegistry4.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType15 = jSTypeRegistry4.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType13);
        jSTypeRegistry4.clearTemplateTypeName();
        com.google.javascript.rhino.ErrorReporter errorReporter17 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry18 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter17);
        jSTypeRegistry18.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType21 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray22 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType23 = jSTypeRegistry18.createConstructorTypeWithVarArgs(jSType21, jSTypeArray22);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        jSTypeRegistry25.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType28 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray29 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType30 = jSTypeRegistry25.createConstructorTypeWithVarArgs(jSType28, jSTypeArray29);
        boolean boolean31 = functionType30.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter32 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry33 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter32);
        jSTypeRegistry33.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType36 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray37 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType38 = jSTypeRegistry33.createConstructorTypeWithVarArgs(jSType36, jSTypeArray37);
        com.google.javascript.rhino.jstype.FunctionType functionType39 = jSTypeRegistry18.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType30, jSTypeArray37);
        boolean boolean40 = functionType39.isOrdinaryFunction();
        boolean boolean41 = functionType39.isEmptyType();
        com.google.javascript.rhino.jstype.JSType jSType42 = jSTypeRegistry4.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType39);
        try {
            jSTypeRegistry1.overwriteDeclaredType("BITXOR 84", jSType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSType15);
        org.junit.Assert.assertNotNull(jSTypeArray22);
        org.junit.Assert.assertNotNull(functionType23);
        org.junit.Assert.assertNotNull(jSTypeArray29);
        org.junit.Assert.assertNotNull(functionType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(jSTypeArray37);
        org.junit.Assert.assertNotNull(functionType38);
        org.junit.Assert.assertNotNull(functionType39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(jSType42);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.reserveRawExports;
        boolean boolean5 = compilerOptions3.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = compilerOptions3.checkUnreachableCode;
        compilerOptions0.aggressiveVarCheck = checkLevel6;
        compilerOptions0.strictMessageReplacement = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel6 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel6.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int0 = com.google.javascript.rhino.Node.REGEXP_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        jSTypeRegistry6.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        jSTypeRegistry21.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry6.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType18, jSTypeArray25);
        java.lang.String str28 = functionType27.toString();
        com.google.javascript.rhino.jstype.EnumType enumType29 = jSTypeRegistry1.createEnumType("function (new:{...}): function (new:{...}): ?", (com.google.javascript.rhino.jstype.JSType) functionType27);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope30 = null;
        com.google.javascript.rhino.jstype.JSType jSType35 = jSTypeRegistry1.getForgivingType(jSTypeStaticScope30, "NUMBER 71.0\n", "hi!", 138, 108);
        com.google.javascript.rhino.jstype.ObjectType objectType36 = null;
        try {
            java.util.Collection<com.google.javascript.rhino.jstype.FunctionType> functionTypeCollection37 = jSTypeRegistry1.getDirectImplementors(objectType36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (new:{...}): function (new:{...}): ?" + "'", str28.equals("function (new:{...}): function (new:{...}): ?"));
        org.junit.Assert.assertNotNull(enumType29);
        org.junit.Assert.assertNotNull(jSType35);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.ErrorManager errorManager5 = null;
        compilerInput3.setErrorManager(errorManager5);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler8.getState();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler8.getSourceMap();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        com.google.javascript.jscomp.LightweightMessageFormatter lightweightMessageFormatter12 = new com.google.javascript.jscomp.LightweightMessageFormatter((com.google.javascript.jscomp.SourceExcerptProvider) compiler8);
        lightweightMessageFormatter12.setColorize(false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNull(sourceMap10);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int0 = com.google.javascript.rhino.Token.SETNAME;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        com.google.javascript.jscomp.JSSourceFile jSSourceFile1 = com.google.javascript.jscomp.JSSourceFile.fromFile("Not declared as a type name");
        org.junit.Assert.assertNotNull(jSSourceFile1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler2 = null;
        com.google.javascript.rhino.Node[] nodeArray3 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList4 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList4, nodeArray3);
        com.google.javascript.jscomp.NodeTraversal.Callback callback6 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler2, (java.util.List<com.google.javascript.rhino.Node>) nodeList4, callback6);
        com.google.javascript.rhino.Node node11 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node13 = node11.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node16 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList4, node11, 0, 0);
        boolean boolean17 = node16.isOnlyModifiesThisCall();
        int int19 = node16.getIntProp(138);
        node16.setLineno((int) '4');
        com.google.javascript.jscomp.DiagnosticType diagnosticType22 = null;
        java.lang.String[] strArray26 = new java.lang.String[] { "bindname", "GET_REF", "BITXOR 84" };
        try {
            com.google.javascript.jscomp.JSError jSError27 = com.google.javascript.jscomp.JSError.make("", node16, diagnosticType22, strArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(nodeArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(node13);
        org.junit.Assert.assertNotNull(node16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(strArray26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        jSTypeRegistry16.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType13, jSTypeArray20);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope23 = null;
        com.google.javascript.rhino.jstype.JSType jSType28 = jSTypeRegistry1.getForgivingType(jSTypeStaticScope23, "GET_REF", "bindname", (int) '4', 115);
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode33 = new com.google.javascript.rhino.ScriptOrFnNode(115, 4095, 111);
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler35 = null;
        com.google.javascript.rhino.Node[] nodeArray36 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList37 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList37, nodeArray36);
        com.google.javascript.jscomp.NodeTraversal.Callback callback39 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler35, (java.util.List<com.google.javascript.rhino.Node>) nodeList37, callback39);
        com.google.javascript.rhino.Node node44 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node46 = node44.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node49 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList37, node44, 0, 0);
        boolean boolean50 = node49.isOnlyModifiesThisCall();
        int int52 = node49.getIntProp(138);
        scriptOrFnNode33.setCompilerData((java.lang.Object) 138);
        com.google.javascript.rhino.ErrorReporter errorReporter54 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry55 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter54);
        jSTypeRegistry55.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType58 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray59 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry55.createConstructorTypeWithVarArgs(jSType58, jSTypeArray59);
        boolean boolean61 = functionType60.isBooleanObjectType();
        com.google.javascript.rhino.ErrorReporter errorReporter62 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry63 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter62);
        jSTypeRegistry63.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter66 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry67 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter66);
        jSTypeRegistry67.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType70 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray71 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType72 = jSTypeRegistry67.createConstructorTypeWithVarArgs(jSType70, jSTypeArray71);
        boolean boolean73 = functionType72.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType74 = jSTypeRegistry63.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType72);
        boolean boolean75 = functionType60.isEquivalentTo((com.google.javascript.rhino.jstype.JSType) functionType72);
        com.google.javascript.rhino.jstype.ObjectType objectType76 = jSTypeRegistry1.createObjectType("<No stack trace available>", (com.google.javascript.rhino.Node) scriptOrFnNode33, (com.google.javascript.rhino.jstype.ObjectType) functionType60);
        scriptOrFnNode33.setBaseLineno(57);
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNotNull(jSType28);
        org.junit.Assert.assertNotNull(nodeArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(node46);
        org.junit.Assert.assertNotNull(node49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(jSTypeArray59);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(jSTypeArray71);
        org.junit.Assert.assertNotNull(functionType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(jSType74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(objectType76);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        com.google.javascript.rhino.Node node4 = com.google.javascript.rhino.Node.newString(0, "", 111, (-1));
        org.junit.Assert.assertNotNull(node4);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        jSTypeRegistry5.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        try {
            com.google.javascript.rhino.jstype.JSType jSType11 = jSTypeRegistry1.createOptionalType(jSType8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.VISIBILITY;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticType diagnosticType2 = com.google.javascript.jscomp.NodeTraversal.NODE_TRAVERSAL_ERROR;
        java.lang.String str3 = diagnosticType2.toString();
        boolean boolean4 = diagnosticGroup0.matches(diagnosticType2);
        com.google.javascript.jscomp.DiagnosticGroups.STRICT_MODULE_DEP_CHECK = diagnosticGroup0;
        com.google.javascript.jscomp.DiagnosticGroups.MISSING_PROPERTIES = diagnosticGroup0;
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JSC_NODE_TRAVERSAL_ERROR: {0}" + "'", str3.equals("JSC_NODE_TRAVERSAL_ERROR: {0}"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        com.google.javascript.rhino.jstype.JSTypeNative jSTypeNative0 = com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE;
        org.junit.Assert.assertTrue("'" + jSTypeNative0 + "' != '" + com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE + "'", jSTypeNative0.equals(com.google.javascript.rhino.jstype.JSTypeNative.RANGE_ERROR_FUNCTION_TYPE));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        java.util.Set<com.google.javascript.jscomp.JSModule> jSModuleSet3 = jSModule1.getThisAndAllDependencies();
        com.google.javascript.jscomp.SourceAst sourceAst4 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput7 = new com.google.javascript.jscomp.CompilerInput(sourceAst4, "hi!", true);
        boolean boolean8 = compilerInput7.isExtern();
        boolean boolean9 = compilerInput7.isExtern();
        jSModule1.add(compilerInput7);
        org.junit.Assert.assertNotNull(jSModuleList2);
        org.junit.Assert.assertNotNull(jSModuleSet3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        int int0 = com.google.javascript.rhino.Token.WITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 119 + "'", int0 == 119);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.removeDeadCode = true;
        compilerOptions0.computeFunctionSideEffects = true;
        java.lang.String str10 = compilerOptions0.checkMissingGetCssNameBlacklist;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) (short) 0);
        int int3 = context0.getOptimizationLevel();
        org.junit.Assert.assertNotNull(context0);
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.checkSuspiciousCode = false;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        com.google.javascript.jscomp.AbstractCompiler abstractCompiler1 = null;
        com.google.javascript.rhino.Node[] nodeArray2 = new com.google.javascript.rhino.Node[] {};
        java.util.ArrayList<com.google.javascript.rhino.Node> nodeList3 = new java.util.ArrayList<com.google.javascript.rhino.Node>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.rhino.Node>) nodeList3, nodeArray2);
        com.google.javascript.jscomp.NodeTraversal.Callback callback5 = null;
        com.google.javascript.jscomp.NodeTraversal.traverseRoots(abstractCompiler1, (java.util.List<com.google.javascript.rhino.Node>) nodeList3, callback5);
        com.google.javascript.rhino.Node node10 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node12 = node10.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node15 = com.google.javascript.jscomp.NodeUtil.newFunctionNode("BITXOR 84", (java.util.List<com.google.javascript.rhino.Node>) nodeList3, node10, 0, 0);
        boolean boolean16 = node15.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node17 = com.google.javascript.jscomp.NodeUtil.newExpr(node15);
        java.util.Collection<com.google.javascript.rhino.Node> nodeCollection18 = com.google.javascript.jscomp.NodeUtil.getVarsDeclaredInBranch(node15);
        org.junit.Assert.assertNotNull(nodeArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(node12);
        org.junit.Assert.assertNotNull(node15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(node17);
        org.junit.Assert.assertNotNull(nodeCollection18);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup0 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel1 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard2 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup0, checkLevel1);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup3 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel4 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard5 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup3, checkLevel4);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray6 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard5 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList7 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7, warningsGuardArray6);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard9 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList7);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup10 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel11 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard12 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup10, checkLevel11);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray13 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard12 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList14 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList14, warningsGuardArray13);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard16 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList14);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray17 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard9, composeWarningsGuard16 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList18 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList18, warningsGuardArray17);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard20 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList18);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup21 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel22 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard23 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup21, checkLevel22);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray24 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard23 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList25 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean26 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25, warningsGuardArray24);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard27 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList25);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup28 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel29 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard30 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup28, checkLevel29);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray31 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard2, composeWarningsGuard20, composeWarningsGuard27, diagnosticGroupWarningsGuard30 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList32 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32, warningsGuardArray31);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard34 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList32);
        org.junit.Assert.assertNotNull(diagnosticGroup0);
        org.junit.Assert.assertNotNull(diagnosticGroup3);
        org.junit.Assert.assertNotNull(warningsGuardArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup10);
        org.junit.Assert.assertNotNull(warningsGuardArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup21);
        org.junit.Assert.assertNotNull(warningsGuardArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup28);
        org.junit.Assert.assertNotNull(warningsGuardArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        int int0 = com.google.javascript.rhino.Node.DESCENDANTS_FLAG;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        jSTypeRegistry2.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType5, jSTypeArray6);
        boolean boolean8 = functionType7.isInterface();
        boolean boolean10 = functionType7.isPropertyInExterns("bindname");
        boolean boolean11 = functionType7.canBeCalled();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        jSTypeRegistry20.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        boolean boolean26 = functionType25.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        jSTypeRegistry28.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry13.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType25, jSTypeArray32);
        boolean boolean35 = functionType34.isStringObjectType();
        boolean boolean36 = functionType34.isVoidType();
        boolean boolean37 = functionType7.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        jSTypeRegistry39.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        jSTypeRegistry46.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        jSTypeRegistry54.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry39.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType51, jSTypeArray58);
        boolean boolean61 = functionType60.isStringObjectType();
        boolean boolean62 = functionType60.isVoidType();
        functionType60.clearResolved();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType64 = null;
        googleCodingConvention0.applySubclassRelationship(functionType34, functionType60, subclassType64);
        boolean boolean67 = googleCodingConvention0.isPrivate("");
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) "language version");
//        com.google.javascript.rhino.ErrorReporter errorReporter3 = context0.getErrorReporter();
//        java.util.Locale locale4 = context0.getLocale();
//        java.util.Locale locale5 = null;
//        java.util.Locale locale6 = context0.setLocale(locale5);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(obj2);
//        org.junit.Assert.assertNull(errorReporter3);
//        org.junit.Assert.assertNotNull(locale4);
//        org.junit.Assert.assertNotNull(locale6);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode3 = new com.google.javascript.rhino.ScriptOrFnNode(65, 107, 85);
        java.lang.String str7 = scriptOrFnNode3.toString(false, true, false);
        java.lang.String str8 = scriptOrFnNode3.getSourceName();
        int int9 = scriptOrFnNode3.getEncodedSourceStart();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GET_REF" + "'", str7.equals("GET_REF"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        jSTypeRegistry16.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType13, jSTypeArray20);
        com.google.javascript.rhino.ErrorReporter errorReporter24 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry25 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter24);
        jSTypeRegistry25.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter29 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry30 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter29);
        jSTypeRegistry30.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType33 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray34 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType35 = jSTypeRegistry30.createConstructorTypeWithVarArgs(jSType33, jSTypeArray34);
        com.google.javascript.rhino.ErrorReporter errorReporter36 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry37 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter36);
        jSTypeRegistry37.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType40 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray41 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType42 = jSTypeRegistry37.createConstructorTypeWithVarArgs(jSType40, jSTypeArray41);
        boolean boolean43 = functionType42.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter44 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry45 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter44);
        jSTypeRegistry45.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType48 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray49 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType50 = jSTypeRegistry45.createConstructorTypeWithVarArgs(jSType48, jSTypeArray49);
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry30.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType42, jSTypeArray49);
        java.lang.String str52 = functionType51.toString();
        com.google.javascript.rhino.jstype.EnumType enumType53 = jSTypeRegistry25.createEnumType("function (new:{...}): function (new:{...}): ?", (com.google.javascript.rhino.jstype.JSType) functionType51);
        com.google.javascript.rhino.jstype.StaticScope<com.google.javascript.rhino.jstype.JSType> jSTypeStaticScope54 = null;
        com.google.javascript.rhino.jstype.JSType jSType59 = jSTypeRegistry25.getForgivingType(jSTypeStaticScope54, "NUMBER 71.0\n", "hi!", 138, 108);
        com.google.javascript.rhino.jstype.JSType jSType60 = null;
        boolean boolean61 = jSType59.isEquivalentTo(jSType60);
        try {
            jSTypeRegistry1.overwriteDeclaredType("JSC_NODE_TRAVERSAL_ERROR: {0}", jSType60);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: null");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNotNull(jSTypeArray34);
        org.junit.Assert.assertNotNull(functionType35);
        org.junit.Assert.assertNotNull(jSTypeArray41);
        org.junit.Assert.assertNotNull(functionType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(jSTypeArray49);
        org.junit.Assert.assertNotNull(functionType50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "function (new:{...}): function (new:{...}): ?" + "'", str52.equals("function (new:{...}): function (new:{...}): ?"));
        org.junit.Assert.assertNotNull(enumType53);
        org.junit.Assert.assertNotNull(jSType59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        com.google.javascript.rhino.EcmaError ecmaError1 = com.google.javascript.rhino.ScriptRuntime.typeError("function (new:{...}): function (new:{...}): ?");
        int int2 = ecmaError1.getColumnNumber();
        org.junit.Assert.assertNotNull(ecmaError1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.String str1 = com.google.javascript.rhino.ScriptRuntime.escapeString("@IMPLEMENTATION.VERSION@");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "@IMPLEMENTATION.VERSION@" + "'", str1.equals("@IMPLEMENTATION.VERSION@"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.inferTypesInGlobalScope;
        java.util.Map<java.lang.String, com.google.javascript.rhino.Node> strMap2 = compilerOptions0.getDefineReplacements();
        com.google.javascript.jscomp.SourceMap.Format format3 = compilerOptions0.sourceMapFormat;
        boolean boolean4 = compilerOptions0.removeUnusedPrototypePropertiesInExterns;
        java.util.Set<java.lang.String> strSet5 = compilerOptions0.stripTypes;
        compilerOptions0.removeDeadCode = true;
        com.google.javascript.jscomp.CompilerOptions compilerOptions8 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions8.coalesceVariableNames = true;
        compilerOptions8.exportTestFunctions = false;
        compilerOptions8.foldConstants = false;
        com.google.javascript.jscomp.CompilerOptions compilerOptions15 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean16 = compilerOptions15.reserveRawExports;
        boolean boolean17 = compilerOptions15.inlineGetters;
        com.google.javascript.jscomp.CompilerOptions compilerOptions18 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean19 = compilerOptions18.reserveRawExports;
        boolean boolean20 = compilerOptions18.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel21 = compilerOptions18.checkUnreachableCode;
        compilerOptions15.aggressiveVarCheck = checkLevel21;
        compilerOptions8.checkShadowVars = checkLevel21;
        compilerOptions0.reportUnknownTypes = checkLevel21;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(strMap2);
        org.junit.Assert.assertNotNull(format3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + checkLevel21 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel21.equals(com.google.javascript.jscomp.CheckLevel.OFF));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        com.google.javascript.jscomp.JSModule jSModule1 = new com.google.javascript.jscomp.JSModule("hi!");
        java.util.List<com.google.javascript.jscomp.JSModule> jSModuleList2 = jSModule1.getDependencies();
        try {
            com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.JSModule> jSModuleSortedDependencies3 = new com.google.javascript.jscomp.deps.SortedDependencies<com.google.javascript.jscomp.JSModule>(jSModuleList2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jSModuleList2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int0 = com.google.javascript.rhino.Token.SHNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 46 + "'", int0 == 46);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("BITXOR 84", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = com.google.javascript.jscomp.CheckLevel.ERROR;
        compilerOptions0.checkMissingGetCssNameLevel = checkLevel3;
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup5 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel6 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard7 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup5, checkLevel6);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray8 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard7 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList9 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9, warningsGuardArray8);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard11 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList9);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup12 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        com.google.javascript.jscomp.CheckLevel checkLevel13 = null;
        com.google.javascript.jscomp.DiagnosticGroupWarningsGuard diagnosticGroupWarningsGuard14 = new com.google.javascript.jscomp.DiagnosticGroupWarningsGuard(diagnosticGroup12, checkLevel13);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray15 = new com.google.javascript.jscomp.WarningsGuard[] { diagnosticGroupWarningsGuard14 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList16 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean17 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList16, warningsGuardArray15);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard18 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList16);
        com.google.javascript.jscomp.WarningsGuard[] warningsGuardArray19 = new com.google.javascript.jscomp.WarningsGuard[] { composeWarningsGuard11, composeWarningsGuard18 };
        java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard> warningsGuardList20 = new java.util.ArrayList<com.google.javascript.jscomp.WarningsGuard>();
        boolean boolean21 = java.util.Collections.addAll((java.util.Collection<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList20, warningsGuardArray19);
        com.google.javascript.jscomp.ComposeWarningsGuard composeWarningsGuard22 = new com.google.javascript.jscomp.ComposeWarningsGuard((java.util.List<com.google.javascript.jscomp.WarningsGuard>) warningsGuardList20);
        compilerOptions0.addWarningsGuard((com.google.javascript.jscomp.WarningsGuard) composeWarningsGuard22);
        com.google.javascript.jscomp.DiagnosticGroup diagnosticGroup24 = com.google.javascript.jscomp.DiagnosticGroups.ACCESS_CONTROLS;
        try {
            boolean boolean25 = composeWarningsGuard22.enables(diagnosticGroup24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
        org.junit.Assert.assertNotNull(diagnosticGroup5);
        org.junit.Assert.assertNotNull(warningsGuardArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup12);
        org.junit.Assert.assertNotNull(warningsGuardArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(warningsGuardArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(diagnosticGroup24);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter5 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry6 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter5);
        jSTypeRegistry6.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType9 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray10 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType11 = jSTypeRegistry6.createConstructorTypeWithVarArgs(jSType9, jSTypeArray10);
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        boolean boolean19 = functionType18.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter20 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry21 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter20);
        jSTypeRegistry21.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType24 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray25 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType26 = jSTypeRegistry21.createConstructorTypeWithVarArgs(jSType24, jSTypeArray25);
        com.google.javascript.rhino.jstype.FunctionType functionType27 = jSTypeRegistry6.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType18, jSTypeArray25);
        java.lang.String str28 = functionType27.toString();
        com.google.javascript.rhino.jstype.EnumType enumType29 = jSTypeRegistry1.createEnumType("function (new:{...}): function (new:{...}): ?", (com.google.javascript.rhino.jstype.JSType) functionType27);
        jSTypeRegistry1.identifyNonNullableName("GET_REF");
        org.junit.Assert.assertNotNull(jSTypeArray10);
        org.junit.Assert.assertNotNull(functionType11);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(jSTypeArray25);
        org.junit.Assert.assertNotNull(functionType26);
        org.junit.Assert.assertNotNull(functionType27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "function (new:{...}): function (new:{...}): ?" + "'", str28.equals("function (new:{...}): function (new:{...}): ?"));
        org.junit.Assert.assertNotNull(enumType29);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        com.google.javascript.jscomp.CheckLevel checkLevel3 = compilerOptions0.checkUnreachableCode;
        boolean boolean4 = compilerOptions0.aliasKeywords;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + checkLevel3 + "' != '" + com.google.javascript.jscomp.CheckLevel.OFF + "'", checkLevel3.equals(com.google.javascript.jscomp.CheckLevel.OFF));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        com.google.javascript.rhino.Context context0 = com.google.javascript.rhino.Context.enter();
//        java.lang.Object obj2 = context0.getThreadLocal((java.lang.Object) (short) 0);
//        context0.setGeneratingSource(true);
//        org.junit.Assert.assertNotNull(context0);
//        org.junit.Assert.assertNull(obj2);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.jsOutputFile;
        boolean boolean2 = compilerOptions0.checkUnusedPropertiesEarly;
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.io.InputStream inputStream1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromInputStream("bindname", inputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int0 = com.google.javascript.rhino.Node.INCRDECR_PROP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 31 + "'", int0 == 31);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        int int0 = com.google.javascript.rhino.Token.ENTERWITH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        int int0 = com.google.javascript.rhino.Token.SETVAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 55 + "'", int0 == 55);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        compilerOptions0.coalesceVariableNames = true;
        compilerOptions0.exportTestFunctions = false;
        compilerOptions0.foldConstants = false;
        com.google.javascript.jscomp.CheckLevel checkLevel7 = com.google.javascript.jscomp.CheckLevel.WARNING;
        compilerOptions0.reportUnknownTypes = checkLevel7;
        org.junit.Assert.assertTrue("'" + checkLevel7 + "' != '" + com.google.javascript.jscomp.CheckLevel.WARNING + "'", checkLevel7.equals(com.google.javascript.jscomp.CheckLevel.WARNING));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.reportPath = "";
        com.google.javascript.jscomp.PropertyRenamingPolicy propertyRenamingPolicy7 = com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC;
        compilerOptions0.propertyRenaming = propertyRenamingPolicy7;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + propertyRenamingPolicy7 + "' != '" + com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC + "'", propertyRenamingPolicy7.equals(com.google.javascript.jscomp.PropertyRenamingPolicy.HEURISTIC));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        com.google.javascript.rhino.Node node2 = com.google.javascript.rhino.Node.newString(103, "");
        boolean boolean3 = node2.isUnscopedQualifiedName();
        java.lang.Appendable appendable4 = null;
        try {
            node2.appendStringTree(appendable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(node2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.lang.String str1 = com.google.javascript.rhino.Token.name(41);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NULL" + "'", str1.equals("NULL"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        com.google.javascript.jscomp.SourceAst sourceAst0 = null;
        com.google.javascript.jscomp.CompilerInput compilerInput3 = new com.google.javascript.jscomp.CompilerInput(sourceAst0, "hi!", true);
        boolean boolean4 = compilerInput3.isExtern();
        com.google.javascript.jscomp.ErrorManager errorManager5 = null;
        compilerInput3.setErrorManager(errorManager5);
        java.io.PrintStream printStream7 = null;
        com.google.javascript.jscomp.Compiler compiler8 = new com.google.javascript.jscomp.Compiler(printStream7);
        com.google.javascript.jscomp.Compiler.IntermediateState intermediateState9 = compiler8.getState();
        com.google.javascript.jscomp.SourceMap sourceMap10 = compiler8.getSourceMap();
        compilerInput3.setCompiler((com.google.javascript.jscomp.AbstractCompiler) compiler8);
        try {
            compilerInput3.clearAst();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(intermediateState9);
        org.junit.Assert.assertNull(sourceMap10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int0 = com.google.javascript.rhino.Token.SHEQ;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 45 + "'", int0 == 45);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        compilerOptions0.generateExports = true;
        com.google.javascript.jscomp.SourceMap.Format format4 = compilerOptions0.sourceMapFormat;
        boolean boolean5 = compilerOptions0.deadAssignmentElimination;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(format4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int0 = com.google.javascript.rhino.Token.ENUM_NEXT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 59 + "'", int0 == 59);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        java.lang.String str1 = compilerOptions0.aliasableGlobals;
        boolean boolean2 = compilerOptions0.rewriteFunctionExpressions;
        com.google.javascript.jscomp.CompilerOptions compilerOptions3 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean4 = compilerOptions3.reserveRawExports;
        boolean boolean5 = compilerOptions3.inlineGetters;
        compilerOptions3.deadAssignmentElimination = false;
        com.google.javascript.jscomp.CheckLevel checkLevel8 = null;
        compilerOptions3.checkShadowVars = checkLevel8;
        com.google.javascript.jscomp.CheckLevel checkLevel10 = compilerOptions3.brokenClosureRequiresLevel;
        compilerOptions0.checkUnreachableCode = checkLevel10;
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + checkLevel10 + "' != '" + com.google.javascript.jscomp.CheckLevel.ERROR + "'", checkLevel10.equals(com.google.javascript.jscomp.CheckLevel.ERROR));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        try {
//            com.google.javascript.rhino.Context.reportError("TypeError: hi!");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: TypeError: hi!");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        com.google.javascript.jscomp.CompilerOptions compilerOptions0 = new com.google.javascript.jscomp.CompilerOptions();
        boolean boolean1 = compilerOptions0.reserveRawExports;
        boolean boolean2 = compilerOptions0.inlineGetters;
        compilerOptions0.setNameAnonymousFunctionsOnly(false);
        compilerOptions0.checkDuplicateMessages = false;
        compilerOptions0.inputDelimiter = "";
        com.google.javascript.jscomp.AnonymousFunctionNamingPolicy anonymousFunctionNamingPolicy9 = compilerOptions0.anonymousFunctionNaming;
        boolean boolean10 = compilerOptions0.tightenTypes;
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + anonymousFunctionNamingPolicy9 + "' != '" + com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF + "'", anonymousFunctionNamingPolicy9.equals(com.google.javascript.jscomp.AnonymousFunctionNamingPolicy.OFF));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType4 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray5 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType6 = jSTypeRegistry1.createConstructorTypeWithVarArgs(jSType4, jSTypeArray5);
        com.google.javascript.rhino.ErrorReporter errorReporter7 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry8 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter7);
        jSTypeRegistry8.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType11 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray12 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType13 = jSTypeRegistry8.createConstructorTypeWithVarArgs(jSType11, jSTypeArray12);
        boolean boolean14 = functionType13.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter15 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry16 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter15);
        jSTypeRegistry16.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType19 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray20 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType21 = jSTypeRegistry16.createConstructorTypeWithVarArgs(jSType19, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType22 = jSTypeRegistry1.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType13, jSTypeArray20);
        com.google.javascript.rhino.jstype.FunctionType functionType23 = functionType22.getConstructor();
        boolean boolean24 = functionType22.matchesInt32Context();
        org.junit.Assert.assertNotNull(jSTypeArray5);
        org.junit.Assert.assertNotNull(functionType6);
        org.junit.Assert.assertNotNull(jSTypeArray12);
        org.junit.Assert.assertNotNull(functionType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(jSTypeArray20);
        org.junit.Assert.assertNotNull(functionType21);
        org.junit.Assert.assertNotNull(functionType22);
        org.junit.Assert.assertNull(functionType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int int0 = com.google.javascript.rhino.Token.ADD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 21 + "'", int0 == 21);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.util.logging.Level level0 = null;
        com.google.javascript.jscomp.Compiler.setLoggingLevel(level0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        com.google.javascript.jscomp.GoogleCodingConvention googleCodingConvention0 = new com.google.javascript.jscomp.GoogleCodingConvention();
        com.google.javascript.rhino.ErrorReporter errorReporter1 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry2 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter1);
        jSTypeRegistry2.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType5 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray6 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType7 = jSTypeRegistry2.createConstructorTypeWithVarArgs(jSType5, jSTypeArray6);
        boolean boolean8 = functionType7.isInterface();
        boolean boolean10 = functionType7.isPropertyInExterns("bindname");
        boolean boolean11 = functionType7.canBeCalled();
        com.google.javascript.rhino.ErrorReporter errorReporter12 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry13 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter12);
        jSTypeRegistry13.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType16 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray17 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType18 = jSTypeRegistry13.createConstructorTypeWithVarArgs(jSType16, jSTypeArray17);
        com.google.javascript.rhino.ErrorReporter errorReporter19 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry20 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter19);
        jSTypeRegistry20.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType23 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray24 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType25 = jSTypeRegistry20.createConstructorTypeWithVarArgs(jSType23, jSTypeArray24);
        boolean boolean26 = functionType25.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter27 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry28 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter27);
        jSTypeRegistry28.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType31 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray32 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType33 = jSTypeRegistry28.createConstructorTypeWithVarArgs(jSType31, jSTypeArray32);
        com.google.javascript.rhino.jstype.FunctionType functionType34 = jSTypeRegistry13.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType25, jSTypeArray32);
        boolean boolean35 = functionType34.isStringObjectType();
        boolean boolean36 = functionType34.isVoidType();
        boolean boolean37 = functionType7.differsFrom((com.google.javascript.rhino.jstype.JSType) functionType34);
        com.google.javascript.rhino.ErrorReporter errorReporter38 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry39 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter38);
        jSTypeRegistry39.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType42 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray43 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType44 = jSTypeRegistry39.createConstructorTypeWithVarArgs(jSType42, jSTypeArray43);
        com.google.javascript.rhino.ErrorReporter errorReporter45 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry46 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter45);
        jSTypeRegistry46.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType49 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray50 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType51 = jSTypeRegistry46.createConstructorTypeWithVarArgs(jSType49, jSTypeArray50);
        boolean boolean52 = functionType51.isInterface();
        com.google.javascript.rhino.ErrorReporter errorReporter53 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry54 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter53);
        jSTypeRegistry54.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType57 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray58 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType59 = jSTypeRegistry54.createConstructorTypeWithVarArgs(jSType57, jSTypeArray58);
        com.google.javascript.rhino.jstype.FunctionType functionType60 = jSTypeRegistry39.createConstructorType((com.google.javascript.rhino.jstype.JSType) functionType51, jSTypeArray58);
        boolean boolean61 = functionType60.isStringObjectType();
        boolean boolean62 = functionType60.isVoidType();
        functionType60.clearResolved();
        com.google.javascript.jscomp.CodingConvention.SubclassType subclassType64 = null;
        googleCodingConvention0.applySubclassRelationship(functionType34, functionType60, subclassType64);
        boolean boolean67 = googleCodingConvention0.isPrivate("error reporter");
        com.google.javascript.rhino.Node node71 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node72 = node71.getFirstChild();
        boolean boolean73 = node71.isLocalResultCall();
        boolean boolean74 = node71.isOnlyModifiesThisCall();
        com.google.javascript.rhino.Node node78 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node80 = node78.getChildAtIndex((int) (short) 0);
        node78.setOptionalArg(false);
        boolean boolean83 = node78.isVarArgs();
        com.google.javascript.rhino.Node node87 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node89 = node87.getChildAtIndex((int) (short) 0);
        node87.setOptionalArg(false);
        node71.addChildAfter(node78, node87);
        int int93 = node78.getCharno();
        try {
            boolean boolean94 = googleCodingConvention0.isOptionalParameter(node78);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: BITXOR 84 is not a string node");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(jSTypeArray6);
        org.junit.Assert.assertNotNull(functionType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(jSTypeArray17);
        org.junit.Assert.assertNotNull(functionType18);
        org.junit.Assert.assertNotNull(jSTypeArray24);
        org.junit.Assert.assertNotNull(functionType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(jSTypeArray32);
        org.junit.Assert.assertNotNull(functionType33);
        org.junit.Assert.assertNotNull(functionType34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(jSTypeArray43);
        org.junit.Assert.assertNotNull(functionType44);
        org.junit.Assert.assertNotNull(jSTypeArray50);
        org.junit.Assert.assertNotNull(functionType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(jSTypeArray58);
        org.junit.Assert.assertNotNull(functionType59);
        org.junit.Assert.assertNotNull(functionType60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(node72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(node80);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(node89);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 147 + "'", int93 == 147);
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        try {
//            com.google.javascript.rhino.Context.reportError("error reporter");
//            org.junit.Assert.fail("Expected exception of type com.google.javascript.rhino.EvaluatorException; message: error reporter");
//        } catch (com.google.javascript.rhino.EvaluatorException e) {
//        }
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.io.Reader reader1 = null;
        try {
            com.google.javascript.jscomp.SourceFile sourceFile2 = com.google.javascript.jscomp.SourceFile.fromReader("NUMBER 71.0\n", reader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        com.google.javascript.rhino.Node node1 = null;
        com.google.javascript.rhino.ScriptOrFnNode scriptOrFnNode5 = new com.google.javascript.rhino.ScriptOrFnNode(65, 107, 85);
        java.lang.String str9 = scriptOrFnNode5.toString(false, true, false);
        int int12 = scriptOrFnNode5.addRegexp("language version", "ASSIGN_MOD");
        com.google.javascript.rhino.Node node16 = new com.google.javascript.rhino.Node(34, 0, (-1));
        com.google.javascript.rhino.Node node21 = new com.google.javascript.rhino.Node((int) (short) 10, 84, 147);
        com.google.javascript.rhino.Node node23 = node21.getChildAtIndex((int) (short) 0);
        com.google.javascript.rhino.Node node24 = new com.google.javascript.rhino.Node(5, node21);
        try {
            com.google.javascript.rhino.Node node27 = new com.google.javascript.rhino.Node(124, node1, (com.google.javascript.rhino.Node) scriptOrFnNode5, node16, node24, 0, 61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GET_REF" + "'", str9.equals("GET_REF"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(node23);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        com.google.javascript.rhino.ErrorReporter errorReporter0 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry1 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter0);
        jSTypeRegistry1.forwardDeclareType("bindname");
        com.google.javascript.rhino.ErrorReporter errorReporter4 = null;
        com.google.javascript.rhino.jstype.JSTypeRegistry jSTypeRegistry5 = new com.google.javascript.rhino.jstype.JSTypeRegistry(errorReporter4);
        jSTypeRegistry5.forwardDeclareType("bindname");
        com.google.javascript.rhino.jstype.JSType jSType8 = null;
        com.google.javascript.rhino.jstype.JSType[] jSTypeArray9 = new com.google.javascript.rhino.jstype.JSType[] {};
        com.google.javascript.rhino.jstype.FunctionType functionType10 = jSTypeRegistry5.createConstructorTypeWithVarArgs(jSType8, jSTypeArray9);
        boolean boolean11 = functionType10.isBooleanObjectType();
        com.google.javascript.rhino.jstype.JSType jSType12 = jSTypeRegistry1.createOptionalNullableType((com.google.javascript.rhino.jstype.JSType) functionType10);
        java.lang.Iterable<com.google.javascript.rhino.jstype.JSType> jSTypeIterable14 = jSTypeRegistry1.getTypesWithProperty("language version");
        org.junit.Assert.assertNotNull(jSTypeArray9);
        org.junit.Assert.assertNotNull(functionType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(jSType12);
        org.junit.Assert.assertNotNull(jSTypeIterable14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        boolean boolean1 = com.google.javascript.rhino.TokenStream.isKeyword("error reporter");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

